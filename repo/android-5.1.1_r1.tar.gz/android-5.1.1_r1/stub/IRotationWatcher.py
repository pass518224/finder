from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRotationWatcher:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IRotationWatcher"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IRotationWatcher"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onRotationChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onRotationChanged", _arg0)
                # {'_arg0': 'int'}
