from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IActivityRecognitionHardwareWatcher:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.location.IActivityRecognitionHardwareWatcher"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.location.IActivityRecognitionHardwareWatcher"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onInstanceChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.location.IActivityRecognitionHardware", data.readStrongBinder())
                return self.callFunction("onInstanceChanged", _arg0)
                # {'_arg0': 'android.hardware.location.IActivityRecognitionHardware'}
