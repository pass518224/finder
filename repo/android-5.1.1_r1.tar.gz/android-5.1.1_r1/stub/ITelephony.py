from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITelephony:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.ITelephony"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.ITelephony"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_dial"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("dial", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_call"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("call", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_endCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("endCall")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_endCallForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("endCallForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_answerRingingCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("answerRingingCall")
                # {}
            if mycase("TRANSACTION_answerRingingCallForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("answerRingingCallForSubscriber", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_silenceRinger"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("silenceRinger")
                # {}
            if mycase("TRANSACTION_isOffhook"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isOffhook")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isOffhookForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isOffhookForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_isRingingForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isRingingForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_isRinging"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isRinging")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isIdle"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isIdle")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isIdleForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isIdleForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_isRadioOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isRadioOn")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isRadioOnForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isRadioOnForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_isSimPinEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isSimPinEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_supplyPin"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("supplyPin", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_supplyPinForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("supplyPinForSubscriber", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_supplyPuk"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("supplyPuk", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_supplyPukForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("supplyPukForSubscriber", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_supplyPinReportResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("supplyPinReportResult", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_supplyPinReportResultForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("supplyPinReportResultForSubscriber", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_supplyPukReportResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("supplyPukReportResult", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_supplyPukReportResultForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("supplyPukReportResultForSubscriber", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_handlePinMmi"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("handlePinMmi", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_handlePinMmiForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("handlePinMmiForSubscriber", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_toggleRadioOnOff"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("toggleRadioOnOff")
                # {}
            if mycase("TRANSACTION_toggleRadioOnOffForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("toggleRadioOnOffForSubscriber", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setRadio"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setRadio", _arg0)
                # {'_arg0': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_setRadioForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setRadioForSubscriber", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setRadioPower"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setRadioPower", _arg0)
                # {'_arg0': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_updateServiceLocation"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("updateServiceLocation")
                # {}
            if mycase("TRANSACTION_updateServiceLocationForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("updateServiceLocationForSubscriber", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_enableLocationUpdates"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enableLocationUpdates")
                # {}
            if mycase("TRANSACTION_enableLocationUpdatesForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("enableLocationUpdatesForSubscriber", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_disableLocationUpdates"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disableLocationUpdates")
                # {}
            if mycase("TRANSACTION_disableLocationUpdatesForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("disableLocationUpdatesForSubscriber", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_enableDataConnectivity"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enableDataConnectivity")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_disableDataConnectivity"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disableDataConnectivity")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isDataConnectivityPossible"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isDataConnectivityPossible")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getCellLocation"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCellLocation")
                # {'_result': 'android.os.Bundle'}
            if mycase("TRANSACTION_getNeighboringCellInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getNeighboringCellInfo", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.util.List<android.telephony.NeighboringCellInfo>'}
            if mycase("TRANSACTION_getCallState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCallState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getCallStateForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCallStateForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getDataActivity"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDataActivity")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getDataState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDataState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getActivePhoneType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActivePhoneType")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getActivePhoneTypeForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getActivePhoneTypeForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getCdmaEriIconIndex"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCdmaEriIconIndex")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getCdmaEriIconIndexForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCdmaEriIconIndexForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getCdmaEriIconMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCdmaEriIconMode")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getCdmaEriIconModeForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCdmaEriIconModeForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getCdmaEriText"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCdmaEriText")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getCdmaEriTextForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCdmaEriTextForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_needsOtaServiceProvisioning"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("needsOtaServiceProvisioning")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setVoiceMailNumber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("setVoiceMailNumber", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_getVoiceMessageCount"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVoiceMessageCount")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getVoiceMessageCountForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getVoiceMessageCountForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getNetworkType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNetworkType")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getNetworkTypeForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getNetworkTypeForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getDataNetworkType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDataNetworkType")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getDataNetworkTypeForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getDataNetworkTypeForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getVoiceNetworkType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVoiceNetworkType")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getVoiceNetworkTypeForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getVoiceNetworkTypeForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_hasIccCard"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasIccCard")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_hasIccCardUsingSlotId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("hasIccCardUsingSlotId", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getLteOnCdmaMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLteOnCdmaMode")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getLteOnCdmaModeForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getLteOnCdmaModeForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getAllCellInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllCellInfo")
                # {'_result': 'java.util.List<android.telephony.CellInfo>'}
            if mycase("TRANSACTION_setCellInfoListRate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setCellInfoListRate", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getDefaultSim"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultSim")
                # {'_result': 'int'}
            if mycase("TRANSACTION_iccOpenLogicalChannel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("iccOpenLogicalChannel", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.telephony.IccOpenLogicalChannelResponse'}
            if mycase("TRANSACTION_iccCloseLogicalChannel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("iccCloseLogicalChannel", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_iccTransmitApduLogicalChannel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                _arg6 = data.readString()
                return self.callFunction("iccTransmitApduLogicalChannel", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'java.lang.String', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg6': 'java.lang.String', '_arg4': 'int', '_arg5': 'int'}
            if mycase("TRANSACTION_iccTransmitApduBasicChannel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readString()
                return self.callFunction("iccTransmitApduBasicChannel", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'java.lang.String', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int', '_arg5': 'java.lang.String'}
            if mycase("TRANSACTION_iccExchangeSimIO"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readString()
                return self.callFunction("iccExchangeSimIO", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'byte', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int', '_arg5': 'java.lang.String'}
            if mycase("TRANSACTION_sendEnvelopeWithStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("sendEnvelopeWithStatus", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_nvReadItem"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("nvReadItem", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_nvWriteItem"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("nvWriteItem", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_nvWriteCdmaPrl"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                return self.callFunction("nvWriteCdmaPrl", _arg0)
                # {'_arg0': 'byte', '_result': 'boolean'}
            if mycase("TRANSACTION_nvResetConfig"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("nvResetConfig", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getCalculatedPreferredNetworkType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCalculatedPreferredNetworkType")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getPreferredNetworkType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPreferredNetworkType")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getTetherApnRequired"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTetherApnRequired")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setPreferredNetworkType"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setPreferredNetworkType", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setDataEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setDataEnabled", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getDataEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getDataEnabled", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getPcscfAddress"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPcscfAddress", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_setImsRegistrationState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setImsRegistrationState", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_getCdmaMdn"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCdmaMdn", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getCdmaMin"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCdmaMin", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getCarrierPrivilegeStatus"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCarrierPrivilegeStatus")
                # {'_result': 'int'}
            if mycase("TRANSACTION_checkCarrierPrivilegesForPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("checkCarrierPrivilegesForPackage", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_getCarrierPackageNamesForIntent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                return self.callFunction("getCarrierPackageNamesForIntent", _arg0)
                # {'_arg0': 'android.content.Intent', '_result': 'java.util.List<java.lang.String>', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setLine1NumberForDisplayForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("setLine1NumberForDisplayForSubscriber", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_getLine1NumberForDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getLine1NumberForDisplay", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getLine1AlphaTagForDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getLine1AlphaTagForDisplay", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getMergedSubscriberIds"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMergedSubscriberIds")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_setOperatorBrandOverride"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setOperatorBrandOverride", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_setRoamingOverride"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArrayList()
                _arg1 = data.createStringArrayList()
                _arg2 = data.createStringArrayList()
                _arg3 = data.createStringArrayList()
                return self.callFunction("setRoamingOverride", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.util.List<java.lang.String>', '_arg3': 'java.util.List<java.lang.String>', '_arg0': 'java.util.List<java.lang.String>', '_arg1': 'java.util.List<java.lang.String>', '_result': 'boolean'}
            if mycase("TRANSACTION_invokeOemRilRequestRaw"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                _arg1_length = data.readInt()
                if (_arg1_length < 0):
                    _arg1 = None
                else:
                    _arg1 = [None for _i in range(_arg1_length)] # byte
                return self.callFunction("invokeOemRilRequestRaw", _arg0, _arg1)
                # {'_result': 'int', '_arg1_length': 'int', '_arg0': 'byte', '_arg1': 'byte', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_needMobileRadioShutdown"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("needMobileRadioShutdown")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_shutdownMobileRadios"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("shutdownMobileRadios")
                # {}
            if mycase("TRANSACTION_setRadioCapability"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.telephony.RadioAccessFamily")
                return self.callFunction("setRadioCapability", _arg0)
                # {'_arg0': 'android.telephony.RadioAccessFamily'}
            if mycase("TRANSACTION_getRadioAccessFamily"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getRadioAccessFamily", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_enableVideoCalling"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("enableVideoCalling", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_isVideoCallingEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isVideoCallingEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isImsRegistered"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isImsRegistered")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getDeviceId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDeviceId")
                # {'_result': 'java.lang.String'}
