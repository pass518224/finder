from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsConfig:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsConfig"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsConfig"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getProvisionedValue"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getProvisionedValue", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getProvisionedStringValue"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getProvisionedStringValue", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_setProvisionedValue"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setProvisionedValue", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setProvisionedStringValue"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("setProvisionedStringValue", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getFeatureValue"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = self.interfaceResolver("com.android.ims.ImsConfigListener", data.readStrongBinder())
                return self.callFunction("getFeatureValue", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsConfigListener', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setFeatureValue"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("com.android.ims.ImsConfigListener", data.readStrongBinder())
                return self.callFunction("setFeatureValue", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'com.android.ims.ImsConfigListener', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getVolteProvisioned"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVolteProvisioned")
                # {'_result': 'boolean'}
