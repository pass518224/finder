from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputFilter:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IInputFilter"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IInputFilter"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_install"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IInputFilterHost", data.readStrongBinder())
                return self.callFunction("install", _arg0)
                # {'_arg0': 'android.view.IInputFilterHost'}
            if mycase("TRANSACTION_uninstall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("uninstall")
                # {}
            if mycase("TRANSACTION_filterInputEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.InputEvent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("filterInputEvent", _arg0, _arg1)
                # {'_arg0': 'android.view.InputEvent', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
