from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAudioPolicyCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.audiopolicy.IAudioPolicyCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.audiopolicy.IAudioPolicyCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_notifyAudioFocusGrant"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.AudioFocusInfo", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("notifyAudioFocusGrant", _arg0, _arg1)
                # {'_arg0': 'android.media.AudioFocusInfo', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyAudioFocusLoss"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.AudioFocusInfo", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("notifyAudioFocusLoss", _arg0, _arg1)
                # {'_arg0': 'android.media.AudioFocusInfo', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
