from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITelephonyRegistry:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.ITelephonyRegistry"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.ITelephonyRegistry"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_addOnSubscriptionsChangedListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.telephony.IOnSubscriptionsChangedListener", data.readStrongBinder())
                return self.callFunction("addOnSubscriptionsChangedListener", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'com.android.internal.telephony.IOnSubscriptionsChangedListener'}
            if mycase("TRANSACTION_removeOnSubscriptionsChangedListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.telephony.IOnSubscriptionsChangedListener", data.readStrongBinder())
                return self.callFunction("removeOnSubscriptionsChangedListener", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'com.android.internal.telephony.IOnSubscriptionsChangedListener'}
            if mycase("TRANSACTION_listen"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.telephony.IPhoneStateListener", data.readStrongBinder())
                _arg2 = data.readInt()
                _arg3 = (0 != data.readInt())
                return self.callFunction("listen", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'com.android.internal.telephony.IPhoneStateListener'}
            if mycase("TRANSACTION_listenForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = self.interfaceResolver("com.android.internal.telephony.IPhoneStateListener", data.readStrongBinder())
                _arg3 = data.readInt()
                _arg4 = (0 != data.readInt())
                return self.callFunction("listenForSubscriber", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'com.android.internal.telephony.IPhoneStateListener', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'boolean'}
            if mycase("TRANSACTION_notifyCallState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("notifyCallState", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_notifyCallStateForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("notifyCallStateForSubscriber", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_notifyServiceStateForPhoneId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.telephony.ServiceState", data)
                else:
                    _arg2 = None
                return self.callFunction("notifyServiceStateForPhoneId", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.telephony.ServiceState', '_arg0': 'int', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifySignalStrength"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.SignalStrength", data)
                else:
                    _arg0 = None
                return self.callFunction("notifySignalStrength", _arg0)
                # {'_arg0': 'android.telephony.SignalStrength', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifySignalStrengthForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telephony.SignalStrength", data)
                else:
                    _arg1 = None
                return self.callFunction("notifySignalStrengthForSubscriber", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.telephony.SignalStrength', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyMessageWaitingChangedForPhoneId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("notifyMessageWaitingChangedForPhoneId", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_notifyCallForwardingChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("notifyCallForwardingChanged", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_notifyCallForwardingChangedForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("notifyCallForwardingChangedForSubscriber", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_notifyDataActivity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("notifyDataActivity", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_notifyDataActivityForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("notifyDataActivityForSubscriber", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_notifyDataConnection"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readString()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.net.LinkProperties", data)
                else:
                    _arg5 = None
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.net.NetworkCapabilities", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                _arg8 = (0 != data.readInt())
                return self.callFunction("notifyDataConnection", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'boolean', '_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'boolean', '_arg6': 'android.net.NetworkCapabilities', '_arg7': 'int', '_arg4': 'java.lang.String', '_arg5': 'android.net.LinkProperties', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyDataConnectionForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                _arg3 = data.readString()
                _arg4 = data.readString()
                _arg5 = data.readString()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.net.LinkProperties", data)
                else:
                    _arg6 = None
                if (0 != data.readInt()):
                    _arg7 = self.creatorResolver("android.net.NetworkCapabilities", data)
                else:
                    _arg7 = None
                _arg8 = data.readInt()
                _arg9 = (0 != data.readInt())
                return self.callFunction("notifyDataConnectionForSubscriber", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9)
                # {'_arg8': 'int', '_arg9': 'boolean', '_arg2': 'boolean', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int', '_arg6': 'android.net.LinkProperties', '_arg7': 'android.net.NetworkCapabilities', '_arg4': 'java.lang.String', '_arg5': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyDataConnectionFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("notifyDataConnectionFailed", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_notifyDataConnectionFailedForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("notifyDataConnectionFailedForSubscriber", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_notifyCellLocation"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("notifyCellLocation", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyCellLocationForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("notifyCellLocationForSubscriber", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyOtaspChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("notifyOtaspChanged", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_notifyCellInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.telephony.CellInfo")
                return self.callFunction("notifyCellInfo", _arg0)
                # {'_arg0': 'java.util.List<android.telephony.CellInfo>'}
            if mycase("TRANSACTION_notifyPreciseCallState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("notifyPreciseCallState", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_notifyDisconnectCause"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("notifyDisconnectCause", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_notifyPreciseDataConnectionFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                return self.callFunction("notifyPreciseDataConnectionFailed", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_notifyCellInfoForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createTypedArrayList("android.telephony.CellInfo")
                return self.callFunction("notifyCellInfoForSubscriber", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.util.List<android.telephony.CellInfo>'}
            if mycase("TRANSACTION_notifyDataConnectionRealTimeInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.DataConnectionRealTimeInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("notifyDataConnectionRealTimeInfo", _arg0)
                # {'_arg0': 'android.telephony.DataConnectionRealTimeInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyVoLteServiceStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.VoLteServiceState", data)
                else:
                    _arg0 = None
                return self.callFunction("notifyVoLteServiceStateChanged", _arg0)
                # {'_arg0': 'android.telephony.VoLteServiceState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyOemHookRawEventForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createByteArray()
                return self.callFunction("notifyOemHookRawEventForSubscriber", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'byte'}
            if mycase("TRANSACTION_notifySubscriptionInfoChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("notifySubscriptionInfoChanged")
                # {}
