from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaRouterClient:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IMediaRouterClient"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IMediaRouterClient"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onStateChanged")
                # {}
