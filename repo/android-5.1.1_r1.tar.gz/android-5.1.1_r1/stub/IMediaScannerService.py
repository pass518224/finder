from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaScannerService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IMediaScannerService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IMediaScannerService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_requestScanFile"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = self.interfaceResolver("android.media.IMediaScannerListener", data.readStrongBinder())
                return self.callFunction("requestScanFile", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.media.IMediaScannerListener', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_scanFile"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("scanFile", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
