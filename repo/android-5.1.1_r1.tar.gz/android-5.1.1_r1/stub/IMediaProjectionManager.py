from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaProjectionManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.projection.IMediaProjectionManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.projection.IMediaProjectionManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_hasProjectionPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("hasProjectionPermission", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_createProjection"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = (0 != data.readInt())
                return self.callFunction("createProjection", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'boolean', '_arg0': 'int', '_arg1': 'java.lang.String', '_result': 'android.media.projection.IMediaProjection'}
            if mycase("TRANSACTION_isValidMediaProjection"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.projection.IMediaProjection", data.readStrongBinder())
                return self.callFunction("isValidMediaProjection", _arg0)
                # {'_arg0': 'android.media.projection.IMediaProjection', '_result': 'boolean'}
            if mycase("TRANSACTION_getActiveProjectionInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveProjectionInfo")
                # {'_result': 'android.media.projection.MediaProjectionInfo'}
            if mycase("TRANSACTION_stopActiveProjection"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopActiveProjection")
                # {}
            if mycase("TRANSACTION_addCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.projection.IMediaProjectionWatcherCallback", data.readStrongBinder())
                return self.callFunction("addCallback", _arg0)
                # {'_arg0': 'android.media.projection.IMediaProjectionWatcherCallback'}
            if mycase("TRANSACTION_removeCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.projection.IMediaProjectionWatcherCallback", data.readStrongBinder())
                return self.callFunction("removeCallback", _arg0)
                # {'_arg0': 'android.media.projection.IMediaProjectionWatcherCallback'}
