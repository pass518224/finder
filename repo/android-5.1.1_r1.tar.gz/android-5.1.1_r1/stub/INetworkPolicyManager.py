from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetworkPolicyManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.INetworkPolicyManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.INetworkPolicyManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setUidPolicy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setUidPolicy", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_addUidPolicy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("addUidPolicy", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_removeUidPolicy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("removeUidPolicy", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getUidPolicy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getUidPolicy", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getUidsWithPolicy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getUidsWithPolicy", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_isUidForeground"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isUidForeground", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getPowerSaveAppIdWhitelist"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPowerSaveAppIdWhitelist")
                # {'_result': 'int'}
            if mycase("TRANSACTION_registerListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.INetworkPolicyListener", data.readStrongBinder())
                return self.callFunction("registerListener", _arg0)
                # {'_arg0': 'android.net.INetworkPolicyListener'}
            if mycase("TRANSACTION_unregisterListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.INetworkPolicyListener", data.readStrongBinder())
                return self.callFunction("unregisterListener", _arg0)
                # {'_arg0': 'android.net.INetworkPolicyListener'}
            if mycase("TRANSACTION_setNetworkPolicies"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.net.NetworkPolicy")
                return self.callFunction("setNetworkPolicies", _arg0)
                # {'_arg0': 'android.net.NetworkPolicy'}
            if mycase("TRANSACTION_getNetworkPolicies"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNetworkPolicies")
                # {'_result': 'android.net.NetworkPolicy'}
            if mycase("TRANSACTION_snoozeLimit"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkTemplate", data)
                else:
                    _arg0 = None
                return self.callFunction("snoozeLimit", _arg0)
                # {'_arg0': 'android.net.NetworkTemplate', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setRestrictBackground"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setRestrictBackground", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_getRestrictBackground"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getRestrictBackground")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getNetworkQuotaInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkState", data)
                else:
                    _arg0 = None
                return self.callFunction("getNetworkQuotaInfo", _arg0)
                # {'_arg0': 'android.net.NetworkState', '_result': 'android.net.NetworkQuotaInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isNetworkMetered"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkState", data)
                else:
                    _arg0 = None
                return self.callFunction("isNetworkMetered", _arg0)
                # {'_arg0': 'android.net.NetworkState', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
