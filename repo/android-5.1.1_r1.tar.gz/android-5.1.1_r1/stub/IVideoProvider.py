from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVideoProvider:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telecom.IVideoProvider"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telecom.IVideoProvider"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setVideoCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("setVideoCallback", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_setCamera"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setCamera", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setPreviewSurface"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg0 = None
                return self.callFunction("setPreviewSurface", _arg0)
                # {'_arg0': 'android.view.Surface', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setDisplaySurface"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg0 = None
                return self.callFunction("setDisplaySurface", _arg0)
                # {'_arg0': 'android.view.Surface', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setDeviceOrientation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setDeviceOrientation", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setZoom"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readFloat()
                return self.callFunction("setZoom", _arg0)
                # {'_arg0': 'float'}
            if mycase("TRANSACTION_sendSessionModifyRequest"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.VideoProfile", data)
                else:
                    _arg0 = None
                return self.callFunction("sendSessionModifyRequest", _arg0)
                # {'_arg0': 'android.telecom.VideoProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendSessionModifyResponse"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.VideoProfile", data)
                else:
                    _arg0 = None
                return self.callFunction("sendSessionModifyResponse", _arg0)
                # {'_arg0': 'android.telecom.VideoProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_requestCameraCapabilities"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("requestCameraCapabilities")
                # {}
            if mycase("TRANSACTION_requestCallDataUsage"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("requestCallDataUsage")
                # {}
            if mycase("TRANSACTION_setPauseImage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setPauseImage", _arg0)
                # {'_arg0': 'java.lang.String'}
