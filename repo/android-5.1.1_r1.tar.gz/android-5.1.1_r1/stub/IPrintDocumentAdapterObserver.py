from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrintDocumentAdapterObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IPrintDocumentAdapterObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IPrintDocumentAdapterObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onDestroy"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDestroy")
                # {}
