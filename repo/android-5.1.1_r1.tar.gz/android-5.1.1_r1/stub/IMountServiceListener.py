from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMountServiceListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "IMountServiceListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "IMountServiceListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onUsbMassStorageConnectionChanged"):
                data.enforceInterface(DESCRIPTOR)
                connected = (0 != data.readInt())
                return self.callFunction("onUsbMassStorageConnectionChanged", connected)
                # {'connected': 'boolean'}
            if mycase("TRANSACTION_onStorageStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                path = data.readString()
                oldState = data.readString()
                newState = data.readString()
                return self.callFunction("onStorageStateChanged", path, oldState, newState)
                # {'path': 'String', 'oldState': 'String', 'newState': 'String'}
