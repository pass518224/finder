from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccountAuthenticator:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.accounts.IAccountAuthenticator"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.accounts.IAccountAuthenticator"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_addAccount"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.createStringArray()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg4 = None
                return self.callFunction("addAccount", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'java.lang.String', '_arg4': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_confirmCredentials"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("confirmCredentials", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'android.accounts.Account', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAuthToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("getAuthToken", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.os.Bundle', '_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'android.accounts.Account', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAuthTokenLabel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("getAuthTokenLabel", _arg0, _arg1)
                # {'_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_updateCredentials"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("updateCredentials", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.os.Bundle', '_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'android.accounts.Account', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_editProperties"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("editProperties", _arg0, _arg1)
                # {'_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_hasFeatures"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = data.createStringArray()
                return self.callFunction("hasFeatures", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAccountRemovalAllowed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                return self.callFunction("getAccountRemovalAllowed", _arg0, _arg1)
                # {'_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAccountCredentialsForCloning"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                return self.callFunction("getAccountCredentialsForCloning", _arg0, _arg1)
                # {'_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addAccountFromCredentials"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountAuthenticatorResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("addAccountFromCredentials", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'android.accounts.IAccountAuthenticatorResponse', '_arg1': 'android.accounts.Account', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
