from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISyncAdapter:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.ISyncAdapter"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.ISyncAdapter"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_startSync"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.ISyncContext", data.readStrongBinder())
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("startSync", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.accounts.Account', '_arg3': 'android.os.Bundle', '_arg0': 'android.content.ISyncContext', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_cancelSync"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.ISyncContext", data.readStrongBinder())
                return self.callFunction("cancelSync", _arg0)
                # {'_arg0': 'android.content.ISyncContext'}
            if mycase("TRANSACTION_initialize"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("initialize", _arg0, _arg1)
                # {'_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
