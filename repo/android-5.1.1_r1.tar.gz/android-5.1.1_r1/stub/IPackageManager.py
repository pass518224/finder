from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPackageManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IPackageManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IPackageManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_isPackageAvailable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("isPackageAvailable", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getPackageInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("getPackageInfo", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'android.content.pm.PackageInfo'}
            if mycase("TRANSACTION_getPackageUid"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getPackageUid", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getPackageGids"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPackageGids", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_currentToCanonicalPackageNames"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                return self.callFunction("currentToCanonicalPackageNames", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_canonicalToCurrentPackageNames"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                return self.callFunction("canonicalToCurrentPackageNames", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getPermissionInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getPermissionInfo", _arg0, _arg1)
                # {'_result': 'android.content.pm.PermissionInfo', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_queryPermissionsByGroup"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("queryPermissionsByGroup", _arg0, _arg1)
                # {'_result': 'java.util.List<android.content.pm.PermissionInfo>', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getPermissionGroupInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getPermissionGroupInfo", _arg0, _arg1)
                # {'_result': 'android.content.pm.PermissionGroupInfo', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getAllPermissionGroups"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getAllPermissionGroups", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.content.pm.PermissionGroupInfo>'}
            if mycase("TRANSACTION_getApplicationInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("getApplicationInfo", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'android.content.pm.ApplicationInfo'}
            if mycase("TRANSACTION_getActivityInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("getActivityInfo", _arg0, _arg1, _arg2)
                # {'_result': 'android.content.pm.ActivityInfo', '_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_activitySupportsIntent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                return self.callFunction("activitySupportsIntent", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'java.lang.String', '_arg0': 'android.content.ComponentName', '_arg1': 'android.content.Intent', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_getReceiverInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("getReceiverInfo", _arg0, _arg1, _arg2)
                # {'_result': 'android.content.pm.ActivityInfo', '_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getServiceInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("getServiceInfo", _arg0, _arg1, _arg2)
                # {'_result': 'android.content.pm.ServiceInfo', '_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getProviderInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("getProviderInfo", _arg0, _arg1, _arg2)
                # {'_result': 'android.content.pm.ProviderInfo', '_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_checkPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("checkPermission", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_checkUidPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("checkUidPermission", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_addPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.PermissionInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("addPermission", _arg0)
                # {'_arg0': 'android.content.pm.PermissionInfo', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removePermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removePermission", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_grantPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("grantPermission", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_revokePermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("revokePermission", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_isProtectedBroadcast"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isProtectedBroadcast", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_checkSignatures"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("checkSignatures", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_checkUidSignatures"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("checkUidSignatures", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getPackagesForUid"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getPackagesForUid", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getNameForUid"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getNameForUid", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getUidForSharedUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getUidForSharedUser", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_getFlagsForUid"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getFlagsForUid", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_isUidPrivileged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isUidPrivileged", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getAppOpPermissionPackages"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getAppOpPermissionPackages", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_resolveIntent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("resolveIntent", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'android.content.pm.ResolveInfo', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_canForwardTo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("canForwardTo", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_queryIntentActivities"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("queryIntentActivities", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'java.util.List<android.content.pm.ResolveInfo>', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_queryIntentActivityOptions"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.createTypedArray("android.content.Intent")
                _arg2 = data.createStringArray()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg3 = None
                _arg4 = data.readString()
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                return self.callFunction("queryIntentActivityOptions", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'java.util.List<android.content.pm.ResolveInfo>', '_arg2': 'java.lang.String', '_arg3': 'android.content.Intent', '_arg0': 'android.content.ComponentName', '_arg1': 'android.content.Intent', '_arg6': 'int', '_arg4': 'java.lang.String', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_queryIntentReceivers"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("queryIntentReceivers", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'java.util.List<android.content.pm.ResolveInfo>', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_resolveService"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("resolveService", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'android.content.pm.ResolveInfo', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_queryIntentServices"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("queryIntentServices", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'java.util.List<android.content.pm.ResolveInfo>', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_queryIntentContentProviders"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("queryIntentContentProviders", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'java.util.List<android.content.pm.ResolveInfo>', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getInstalledPackages"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("getInstalledPackages", _arg0, _arg1)
                # {'_result': 'android.content.pm.ParceledListSlice', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getPackagesHoldingPermissions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("getPackagesHoldingPermissions", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'android.content.pm.ParceledListSlice'}
            if mycase("TRANSACTION_getInstalledApplications"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("getInstalledApplications", _arg0, _arg1)
                # {'_result': 'android.content.pm.ParceledListSlice', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getPersistentApplications"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getPersistentApplications", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.content.pm.ApplicationInfo>'}
            if mycase("TRANSACTION_resolveContentProvider"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("resolveContentProvider", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'android.content.pm.ProviderInfo'}
            if mycase("TRANSACTION_querySyncProviders"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArrayList()
                _arg1 = data.createTypedArrayList("android.content.pm.ProviderInfo")
                return self.callFunction("querySyncProviders", _arg0, _arg1)
                # {'_arg0': 'java.util.List<java.lang.String>', '_arg1': 'java.util.List<android.content.pm.ProviderInfo>'}
            if mycase("TRANSACTION_queryContentProviders"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("queryContentProviders", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'java.util.List<android.content.pm.ProviderInfo>'}
            if mycase("TRANSACTION_getInstrumentationInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getInstrumentationInfo", _arg0, _arg1)
                # {'_result': 'android.content.pm.InstrumentationInfo', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_queryInstrumentation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("queryInstrumentation", _arg0, _arg1)
                # {'_result': 'java.util.List<android.content.pm.InstrumentationInfo>', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_installPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.content.pm.IPackageInstallObserver2", data.readStrongBinder())
                _arg2 = data.readInt()
                _arg3 = data.readString()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.content.pm.VerificationParams", data)
                else:
                    _arg4 = None
                _arg5 = data.readString()
                return self.callFunction("installPackage", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'android.content.pm.IPackageInstallObserver2', '_arg4': 'android.content.pm.VerificationParams', '_arg5': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_installPackageAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.content.pm.IPackageInstallObserver2", data.readStrongBinder())
                _arg2 = data.readInt()
                _arg3 = data.readString()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.content.pm.VerificationParams", data)
                else:
                    _arg4 = None
                _arg5 = data.readString()
                _arg6 = data.readInt()
                return self.callFunction("installPackageAsUser", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'android.content.pm.IPackageInstallObserver2', '_arg6': 'int', '_arg4': 'android.content.pm.VerificationParams', '_arg5': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_finishPackageInstall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("finishPackageInstall", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setInstallerPackageName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("setInstallerPackageName", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_deletePackageAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.content.pm.IPackageDeleteObserver", data.readStrongBinder())
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("deletePackageAsUser", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.content.pm.IPackageDeleteObserver'}
            if mycase("TRANSACTION_deletePackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.content.pm.IPackageDeleteObserver2", data.readStrongBinder())
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("deletePackage", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.content.pm.IPackageDeleteObserver2'}
            if mycase("TRANSACTION_getInstallerPackageName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getInstallerPackageName", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_addPackageToPreferred"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("addPackageToPreferred", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_removePackageFromPreferred"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removePackageFromPreferred", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_getPreferredPackages"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getPreferredPackages", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.content.pm.PackageInfo>'}
            if mycase("TRANSACTION_resetPreferredActivities"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("resetPreferredActivities", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getLastChosenActivity"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("getLastChosenActivity", _arg0, _arg1, _arg2)
                # {'_result': 'android.content.pm.ResolveInfo', '_arg2': 'int', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setLastChosenActivity"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.content.IntentFilter", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg5 = None
                return self.callFunction("setLastChosenActivity", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'android.content.IntentFilter', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', '_arg4': 'int', '_arg5': 'android.content.ComponentName', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addPreferredActivity"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.IntentFilter", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.createTypedArray("android.content.ComponentName")
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                return self.callFunction("addPreferredActivity", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.content.ComponentName', '_arg3': 'android.content.ComponentName', '_arg0': 'android.content.IntentFilter', '_arg1': 'int', '_arg4': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_replacePreferredActivity"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.IntentFilter", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.createTypedArray("android.content.ComponentName")
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                return self.callFunction("replacePreferredActivity", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.content.ComponentName', '_arg3': 'android.content.ComponentName', '_arg0': 'android.content.IntentFilter', '_arg1': 'int', '_arg4': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearPackagePreferredActivities"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("clearPackagePreferredActivities", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_getPreferredActivities"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = list()
                _arg1 = list()
                _arg2 = data.readString()
                return self.callFunction("getPreferredActivities", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.util.List<android.content.IntentFilter>', '_arg1': 'java.util.List<android.content.ComponentName>', '_result': 'int'}
            if mycase("TRANSACTION_addPersistentPreferredActivity"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.IntentFilter", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("addPersistentPreferredActivity", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.IntentFilter', '_arg1': 'android.content.ComponentName', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_clearPackagePersistentPreferredActivities"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("clearPackagePersistentPreferredActivities", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_addCrossProfileIntentFilter"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.IntentFilter", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                return self.callFunction("addCrossProfileIntentFilter", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.IntentFilter', '_arg1': 'java.lang.String', '_arg4': 'int', '_arg5': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearCrossProfileIntentFilters"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("clearCrossProfileIntentFilters", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getHomeActivities"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = list()
                return self.callFunction("getHomeActivities", _arg0)
                # {'_arg0': 'java.util.List<android.content.pm.ResolveInfo>', '_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_setComponentEnabledSetting"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("setComponentEnabledSetting", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getComponentEnabledSetting"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getComponentEnabledSetting", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setApplicationEnabledSetting"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readString()
                return self.callFunction("setApplicationEnabledSetting", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg4': 'java.lang.String'}
            if mycase("TRANSACTION_getApplicationEnabledSetting"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getApplicationEnabledSetting", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setPackageStoppedState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                return self.callFunction("setPackageStoppedState", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_freeStorageAndNotify"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = self.interfaceResolver("android.content.pm.IPackageDataObserver", data.readStrongBinder())
                return self.callFunction("freeStorageAndNotify", _arg0, _arg1)
                # {'_arg0': 'long', '_arg1': 'android.content.pm.IPackageDataObserver'}
            if mycase("TRANSACTION_freeStorage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.IntentSender", data)
                else:
                    _arg1 = None
                return self.callFunction("freeStorage", _arg0, _arg1)
                # {'_arg0': 'long', '_arg1': 'android.content.IntentSender', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deleteApplicationCacheFiles"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.content.pm.IPackageDataObserver", data.readStrongBinder())
                return self.callFunction("deleteApplicationCacheFiles", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.content.pm.IPackageDataObserver'}
            if mycase("TRANSACTION_clearApplicationUserData"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.content.pm.IPackageDataObserver", data.readStrongBinder())
                _arg2 = data.readInt()
                return self.callFunction("clearApplicationUserData", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.content.pm.IPackageDataObserver'}
            if mycase("TRANSACTION_getPackageSizeInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = self.interfaceResolver("android.content.pm.IPackageStatsObserver", data.readStrongBinder())
                return self.callFunction("getPackageSizeInfo", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.content.pm.IPackageStatsObserver', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getSystemSharedLibraryNames"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSystemSharedLibraryNames")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getSystemAvailableFeatures"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSystemAvailableFeatures")
                # {'_result': 'android.content.pm.FeatureInfo'}
            if mycase("TRANSACTION_hasSystemFeature"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("hasSystemFeature", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_enterSafeMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enterSafeMode")
                # {}
            if mycase("TRANSACTION_isSafeMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isSafeMode")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_systemReady"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("systemReady")
                # {}
            if mycase("TRANSACTION_hasSystemUidErrors"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasSystemUidErrors")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_performBootDexOpt"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("performBootDexOpt")
                # {}
            if mycase("TRANSACTION_performDexOptIfNeeded"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("performDexOptIfNeeded", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_forceDexOpt"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("forceDexOpt", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_updateExternalMediaStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("updateExternalMediaStatus", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_nextPackageToClean"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.PackageCleanItem", data)
                else:
                    _arg0 = None
                return self.callFunction("nextPackageToClean", _arg0)
                # {'_arg0': 'android.content.pm.PackageCleanItem', '_result': 'android.content.pm.PackageCleanItem', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_movePackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.content.pm.IPackageMoveObserver", data.readStrongBinder())
                _arg2 = data.readInt()
                return self.callFunction("movePackage", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.content.pm.IPackageMoveObserver'}
            if mycase("TRANSACTION_addPermissionAsync"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.PermissionInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("addPermissionAsync", _arg0)
                # {'_arg0': 'android.content.pm.PermissionInfo', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setInstallLocation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setInstallLocation", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getInstallLocation"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getInstallLocation")
                # {'_result': 'int'}
            if mycase("TRANSACTION_installExistingPackageAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("installExistingPackageAsUser", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_verifyPendingInstall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("verifyPendingInstall", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_extendVerificationTimeout"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readLong()
                return self.callFunction("extendVerificationTimeout", _arg0, _arg1, _arg2)
                # {'_arg2': 'long', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getVerifierDeviceIdentity"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVerifierDeviceIdentity")
                # {'_result': 'android.content.pm.VerifierDeviceIdentity'}
            if mycase("TRANSACTION_isFirstBoot"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isFirstBoot")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isOnlyCoreApps"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isOnlyCoreApps")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isUpgrade"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isUpgrade")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setPermissionEnforced"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setPermissionEnforced", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_isPermissionEnforced"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isPermissionEnforced", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_isStorageLow"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isStorageLow")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setApplicationHiddenSettingAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                return self.callFunction("setApplicationHiddenSettingAsUser", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_getApplicationHiddenSettingAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getApplicationHiddenSettingAsUser", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getPackageInstaller"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPackageInstaller")
                # {'_result': 'android.content.pm.IPackageInstaller'}
            if mycase("TRANSACTION_setBlockUninstallForUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                return self.callFunction("setBlockUninstallForUser", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_getBlockUninstallForUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getBlockUninstallForUser", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getKeySetByAlias"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("getKeySetByAlias", _arg0, _arg1)
                # {'_result': 'android.content.pm.KeySet', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getSigningKeySet"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getSigningKeySet", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.content.pm.KeySet'}
            if mycase("TRANSACTION_isPackageSignedByKeySet"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.pm.KeySet", data)
                else:
                    _arg1 = None
                return self.callFunction("isPackageSignedByKeySet", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'android.content.pm.KeySet', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isPackageSignedByKeySetExactly"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.pm.KeySet", data)
                else:
                    _arg1 = None
                return self.callFunction("isPackageSignedByKeySetExactly", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'android.content.pm.KeySet', 'ELSE:': {}, 'IF': {}}
