from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IKeyguardExitCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.policy.IKeyguardExitCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.policy.IKeyguardExitCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onKeyguardExitResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onKeyguardExitResult", _arg0)
                # {'_arg0': 'boolean'}
