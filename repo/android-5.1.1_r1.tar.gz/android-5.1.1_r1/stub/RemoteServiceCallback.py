from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class RemoteServiceCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telecom.RemoteServiceCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telecom.RemoteServiceCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onError"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onError")
                # {}
            if mycase("TRANSACTION_onResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.content.ComponentName")
                _arg1 = data.createBinderArrayList()
                return self.callFunction("onResult", _arg0, _arg1)
                # {'_arg0': 'java.util.List<android.content.ComponentName>', '_arg1': 'java.util.List<android.os.IBinder>'}
