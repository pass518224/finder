from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IFaceLockCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.policy.IFaceLockCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.policy.IFaceLockCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_unlock"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("unlock")
                # {}
            if mycase("TRANSACTION_cancel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("cancel")
                # {}
            if mycase("TRANSACTION_reportFailedAttempt"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("reportFailedAttempt")
                # {}
            if mycase("TRANSACTION_pokeWakelock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("pokeWakelock", _arg0)
                # {'_arg0': 'int'}
