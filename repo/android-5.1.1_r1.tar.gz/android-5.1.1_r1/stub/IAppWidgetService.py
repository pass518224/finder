from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAppWidgetService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.appwidget.IAppWidgetService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.appwidget.IAppWidgetService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_startListening"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.appwidget.IAppWidgetHost", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = list()
                return self.callFunction("startListening", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.util.List<android.widget.RemoteViews>', '_arg0': 'com.android.internal.appwidget.IAppWidgetHost', '_arg1': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_stopListening"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("stopListening", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_allocateAppWidgetId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("allocateAppWidgetId", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_deleteAppWidgetId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("deleteAppWidgetId", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_deleteHost"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("deleteHost", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_deleteAllHosts"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("deleteAllHosts")
                # {}
            if mycase("TRANSACTION_getAppWidgetViews"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getAppWidgetViews", _arg0, _arg1)
                # {'_result': 'android.widget.RemoteViews', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getAppWidgetIdsForHost"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getAppWidgetIdsForHost", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_createAppWidgetConfigIntentSender"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("createAppWidgetConfigIntentSender", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'android.content.IntentSender'}
            if mycase("TRANSACTION_updateAppWidgetIds"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createIntArray()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.widget.RemoteViews", data)
                else:
                    _arg2 = None
                return self.callFunction("updateAppWidgetIds", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.widget.RemoteViews', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateAppWidgetOptions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("updateAppWidgetOptions", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAppWidgetOptions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getAppWidgetOptions", _arg0, _arg1)
                # {'_result': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_partiallyUpdateAppWidgetIds"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createIntArray()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.widget.RemoteViews", data)
                else:
                    _arg2 = None
                return self.callFunction("partiallyUpdateAppWidgetIds", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.widget.RemoteViews', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateAppWidgetProvider"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.widget.RemoteViews", data)
                else:
                    _arg1 = None
                return self.callFunction("updateAppWidgetProvider", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'android.widget.RemoteViews', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyAppWidgetViewDataChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createIntArray()
                _arg2 = data.readInt()
                return self.callFunction("notifyAppWidgetViewDataChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getInstalledProvidersForProfile"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("getInstalledProvidersForProfile", _arg0, _arg1)
                # {'_result': 'java.util.List<android.appwidget.AppWidgetProviderInfo>', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getAppWidgetInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getAppWidgetInfo", _arg0, _arg1)
                # {'_result': 'android.appwidget.AppWidgetProviderInfo', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_hasBindAppWidgetPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("hasBindAppWidgetPermission", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setBindAppWidgetPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setBindAppWidgetPermission", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_bindAppWidgetId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg3 = None
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg4 = None
                return self.callFunction("bindAppWidgetId", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'android.content.ComponentName', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg4': 'android.os.Bundle', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_bindRemoteViewsService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg2 = None
                _arg3 = data.readStrongBinder()
                return self.callFunction("bindRemoteViewsService", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.content.Intent', '_arg3': 'android.os.IBinder', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unbindRemoteViewsService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg2 = None
                return self.callFunction("unbindRemoteViewsService", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.content.Intent', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAppWidgetIds"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("getAppWidgetIds", _arg0)
                # {'_arg0': 'android.content.ComponentName', '_result': 'int', 'ELSE:': {}, 'IF': {}}
