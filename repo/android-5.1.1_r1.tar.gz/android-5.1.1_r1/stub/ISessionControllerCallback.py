from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISessionControllerCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.session.ISessionControllerCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.session.ISessionControllerCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("onEvent", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onSessionDestroyed"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onSessionDestroyed")
                # {}
            if mycase("TRANSACTION_onPlaybackStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.session.PlaybackState", data)
                else:
                    _arg0 = None
                return self.callFunction("onPlaybackStateChanged", _arg0)
                # {'_arg0': 'android.media.session.PlaybackState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onMetadataChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.MediaMetadata", data)
                else:
                    _arg0 = None
                return self.callFunction("onMetadataChanged", _arg0)
                # {'_arg0': 'android.media.MediaMetadata', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onQueueChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.ParceledListSlice", data)
                else:
                    _arg0 = None
                return self.callFunction("onQueueChanged", _arg0)
                # {'_arg0': 'android.content.pm.ParceledListSlice', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onQueueTitleChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                return self.callFunction("onQueueTitleChanged", _arg0)
                # {'_arg0': 'java.lang.CharSequence', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onExtrasChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("onExtrasChanged", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onVolumeInfoChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.session.ParcelableVolumeInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("onVolumeInfoChanged", _arg0)
                # {'_arg0': 'android.media.session.ParcelableVolumeInfo', 'ELSE:': {}, 'IF': {}}
