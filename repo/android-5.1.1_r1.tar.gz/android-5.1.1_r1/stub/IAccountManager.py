from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccountManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.accounts.IAccountManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.accounts.IAccountManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getPassword"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                return self.callFunction("getPassword", _arg0)
                # {'_arg0': 'android.accounts.Account', '_result': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getUserData"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("getUserData", _arg0, _arg1)
                # {'_result': 'java.lang.String', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAuthenticatorTypes"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getAuthenticatorTypes", _arg0)
                # {'_arg0': 'int', '_result': 'android.accounts.AuthenticatorDescription'}
            if mycase("TRANSACTION_getAccounts"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getAccounts", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.accounts.Account'}
            if mycase("TRANSACTION_getAccountsForPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getAccountsForPackage", _arg0, _arg1)
                # {'_result': 'android.accounts.Account', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getAccountsByTypeForPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("getAccountsByTypeForPackage", _arg0, _arg1)
                # {'_result': 'android.accounts.Account', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getAccountsAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getAccountsAsUser", _arg0, _arg1)
                # {'_result': 'android.accounts.Account', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_hasFeatures"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = data.createStringArray()
                return self.callFunction("hasFeatures", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAccountsByFeatures"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.createStringArray()
                return self.callFunction("getAccountsByFeatures", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_addAccountExplicitly"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("addAccountExplicitly", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.os.Bundle', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeAccount"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = (0 != data.readInt())
                return self.callFunction("removeAccount", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeAccountAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = (0 != data.readInt())
                _arg3 = data.readInt()
                return self.callFunction("removeAccountAsUser", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'boolean', '_arg3': 'int', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeAccountExplicitly"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                return self.callFunction("removeAccountExplicitly", _arg0)
                # {'_arg0': 'android.accounts.Account', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_copyAccountToUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("copyAccountToUser", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_invalidateAuthToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("invalidateAuthToken", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_peekAuthToken"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("peekAuthToken", _arg0, _arg1)
                # {'_result': 'java.lang.String', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAuthToken"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("setAuthToken", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPassword"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("setPassword", _arg0, _arg1)
                # {'_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearPassword"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                return self.callFunction("clearPassword", _arg0)
                # {'_arg0': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setUserData"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("setUserData", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateAppPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = (0 != data.readInt())
                return self.callFunction("updateAppPermission", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'boolean', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAuthToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                _arg3 = (0 != data.readInt())
                _arg4 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg5 = None
                return self.callFunction("getAuthToken", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'java.lang.String', '_arg3': 'boolean', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'android.accounts.Account', '_arg4': 'boolean', '_arg5': 'android.os.Bundle', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addAccount"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.createStringArray()
                _arg4 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg5 = None
                return self.callFunction("addAccount", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'java.lang.String', '_arg4': 'boolean', '_arg5': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addAccountAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.createStringArray()
                _arg4 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg5 = None
                _arg6 = data.readInt()
                return self.callFunction("addAccountAsUser", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'java.lang.String', '_arg6': 'int', '_arg4': 'boolean', '_arg5': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateCredentials"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                _arg3 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg4 = None
                return self.callFunction("updateCredentials", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'boolean', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'android.accounts.Account', '_arg4': 'android.os.Bundle', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_editProperties"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("editProperties", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_confirmCredentialsAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                _arg3 = (0 != data.readInt())
                _arg4 = data.readInt()
                return self.callFunction("confirmCredentialsAsUser", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.os.Bundle', '_arg3': 'boolean', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'android.accounts.Account', '_arg4': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAuthTokenLabel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("getAuthTokenLabel", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_addSharedAccountAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("addSharedAccountAsUser", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.accounts.Account', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getSharedAccountsAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getSharedAccountsAsUser", _arg0)
                # {'_arg0': 'int', '_result': 'android.accounts.Account'}
            if mycase("TRANSACTION_removeSharedAccountAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("removeSharedAccountAsUser", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.accounts.Account', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_renameAccount"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accounts.IAccountManagerResponse", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                return self.callFunction("renameAccount", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.accounts.IAccountManagerResponse', '_arg1': 'android.accounts.Account', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPreviousName"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                return self.callFunction("getPreviousName", _arg0)
                # {'_arg0': 'android.accounts.Account', '_result': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_renameSharedAccountAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("renameSharedAccountAsUser", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
