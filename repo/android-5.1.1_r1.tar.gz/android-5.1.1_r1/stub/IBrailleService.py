from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBrailleService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.googlecode.eyesfree.braille.display.IBrailleService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.googlecode.eyesfree.braille.display.IBrailleService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.googlecode.eyesfree.braille.display.IBrailleServiceCallback", data.readStrongBinder())
                return self.callFunction("registerCallback", _arg0)
                # {'_arg0': 'com.googlecode.eyesfree.braille.display.IBrailleServiceCallback', '_result': 'boolean'}
            if mycase("TRANSACTION_unregisterCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.googlecode.eyesfree.braille.display.IBrailleServiceCallback", data.readStrongBinder())
                return self.callFunction("unregisterCallback", _arg0)
                # {'_arg0': 'com.googlecode.eyesfree.braille.display.IBrailleServiceCallback'}
            if mycase("TRANSACTION_displayDots"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                return self.callFunction("displayDots", _arg0)
                # {'_arg0': 'byte'}
