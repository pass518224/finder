from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccessibilityManagerClient:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.accessibility.IAccessibilityManagerClient"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.accessibility.IAccessibilityManagerClient"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setState", _arg0)
                # {'_arg0': 'int'}
