from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPackageInstallerCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IPackageInstallerCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IPackageInstallerCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onSessionCreated"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onSessionCreated", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onSessionBadgingChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onSessionBadgingChanged", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onSessionActiveChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("onSessionActiveChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_onSessionProgressChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readFloat()
                return self.callFunction("onSessionProgressChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'float'}
            if mycase("TRANSACTION_onSessionFinished"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("onSessionFinished", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
