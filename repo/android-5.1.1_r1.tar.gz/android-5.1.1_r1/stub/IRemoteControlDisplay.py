from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRemoteControlDisplay:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IRemoteControlDisplay"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IRemoteControlDisplay"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setCurrentClientId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg1 = None
                _arg2 = (0 != data.readInt())
                return self.callFunction("setCurrentClientId", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'int', '_arg1': 'android.app.PendingIntent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setEnabled", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setPlaybackState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readLong()
                _arg3 = data.readLong()
                _arg4 = data.readFloat()
                return self.callFunction("setPlaybackState", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'long', '_arg3': 'long', '_arg0': 'int', '_arg1': 'int', '_arg4': 'float'}
            if mycase("TRANSACTION_setTransportControlInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setTransportControlInfo", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setMetadata"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("setMetadata", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setArtwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Bitmap", data)
                else:
                    _arg1 = None
                return self.callFunction("setArtwork", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.graphics.Bitmap', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAllMetadata"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.graphics.Bitmap", data)
                else:
                    _arg2 = None
                return self.callFunction("setAllMetadata", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.graphics.Bitmap', '_arg0': 'int', '_arg1': 'android.os.Bundle', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
