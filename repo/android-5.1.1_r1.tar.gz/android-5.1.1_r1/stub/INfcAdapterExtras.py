from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INfcAdapterExtras:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.nfc.INfcAdapterExtras"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.nfc.INfcAdapterExtras"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_open"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readStrongBinder()
                return self.callFunction("open", _arg0, _arg1)
                # {'_result': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readStrongBinder()
                return self.callFunction("close", _arg0, _arg1)
                # {'_result': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_transceive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createByteArray()
                return self.callFunction("transceive", _arg0, _arg1)
                # {'_result': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'byte'}
            if mycase("TRANSACTION_getCardEmulationRoute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getCardEmulationRoute", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_setCardEmulationRoute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setCardEmulationRoute", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_authenticate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createByteArray()
                return self.callFunction("authenticate", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'byte'}
            if mycase("TRANSACTION_getDriverName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getDriverName", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
