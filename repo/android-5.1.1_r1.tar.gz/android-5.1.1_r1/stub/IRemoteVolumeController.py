from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRemoteVolumeController:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IRemoteVolumeController"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IRemoteVolumeController"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_remoteVolumeChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.session.ISessionController", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("remoteVolumeChanged", _arg0, _arg1)
                # {'_arg0': 'android.media.session.ISessionController', '_arg1': 'int'}
            if mycase("TRANSACTION_updateRemoteController"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.session.ISessionController", data.readStrongBinder())
                return self.callFunction("updateRemoteController", _arg0)
                # {'_arg0': 'android.media.session.ISessionController'}
