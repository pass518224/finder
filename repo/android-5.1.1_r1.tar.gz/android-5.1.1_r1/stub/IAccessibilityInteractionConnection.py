from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccessibilityInteractionConnection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.accessibility.IAccessibilityInteractionConnection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.accessibility.IAccessibilityInteractionConnection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_findAccessibilityNodeInfoByAccessibilityId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Region", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                _arg6 = data.readLong()
                if (0 != data.readInt()):
                    _arg7 = self.creatorResolver("android.view.MagnificationSpec", data)
                else:
                    _arg7 = None
                return self.callFunction("findAccessibilityNodeInfoByAccessibilityId", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'int', '_arg3': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg0': 'long', '_arg1': 'android.graphics.Region', '_arg6': 'long', '_arg7': 'android.view.MagnificationSpec', '_arg4': 'int', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_findAccessibilityNodeInfosByViewId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.graphics.Region", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readLong()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.view.MagnificationSpec", data)
                else:
                    _arg8 = None
                return self.callFunction("findAccessibilityNodeInfosByViewId", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'android.view.MagnificationSpec', '_arg2': 'android.graphics.Region', '_arg3': 'int', '_arg0': 'long', '_arg1': 'java.lang.String', '_arg6': 'int', '_arg7': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_findAccessibilityNodeInfosByText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.graphics.Region", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readLong()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.view.MagnificationSpec", data)
                else:
                    _arg8 = None
                return self.callFunction("findAccessibilityNodeInfosByText", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'android.view.MagnificationSpec', '_arg2': 'android.graphics.Region', '_arg3': 'int', '_arg0': 'long', '_arg1': 'java.lang.String', '_arg6': 'int', '_arg7': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_findFocus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.graphics.Region", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readLong()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.view.MagnificationSpec", data)
                else:
                    _arg8 = None
                return self.callFunction("findFocus", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'android.view.MagnificationSpec', '_arg2': 'android.graphics.Region', '_arg3': 'int', '_arg0': 'long', '_arg1': 'int', '_arg6': 'int', '_arg7': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_focusSearch"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.graphics.Region", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readLong()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.view.MagnificationSpec", data)
                else:
                    _arg8 = None
                return self.callFunction("focusSearch", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'android.view.MagnificationSpec', '_arg2': 'android.graphics.Region', '_arg3': 'int', '_arg0': 'long', '_arg1': 'int', '_arg6': 'int', '_arg7': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_performAccessibilityAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readLong()
                return self.callFunction("performAccessibilityAction", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'android.os.Bundle', '_arg3': 'int', '_arg0': 'long', '_arg1': 'int', '_arg6': 'int', '_arg7': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'int', 'ELSE:': {}, 'IF': {}}
