from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IFusedGeofenceHardware:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.IFusedGeofenceHardware"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.IFusedGeofenceHardware"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_isSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_addGeofences"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.hardware.location.GeofenceHardwareRequestParcelable")
                return self.callFunction("addGeofences", _arg0)
                # {'_arg0': 'android.hardware.location.GeofenceHardwareRequestParcelable'}
            if mycase("TRANSACTION_removeGeofences"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createIntArray()
                return self.callFunction("removeGeofences", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_pauseMonitoringGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("pauseMonitoringGeofence", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_resumeMonitoringGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("resumeMonitoringGeofence", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_modifyGeofenceOptions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                return self.callFunction("modifyGeofenceOptions", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int', '_arg5': 'int'}
