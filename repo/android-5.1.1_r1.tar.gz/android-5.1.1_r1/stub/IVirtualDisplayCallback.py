from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVirtualDisplayCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.display.IVirtualDisplayCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.display.IVirtualDisplayCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onPaused"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onPaused")
                # {}
            if mycase("TRANSACTION_onResumed"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onResumed")
                # {}
            if mycase("TRANSACTION_onStopped"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onStopped")
                # {}
