from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetInitiatedListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.INetInitiatedListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.INetInitiatedListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sendNiResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("sendNiResponse", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'int'}
