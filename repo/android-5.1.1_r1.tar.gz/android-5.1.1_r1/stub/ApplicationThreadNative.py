from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IApplicationThread:
    pass
    BACKUP_MODE_INCREMENTAL = 0
    BACKUP_MODE_FULL = 1
    BACKUP_MODE_RESTORE = 2
    BACKUP_MODE_RESTORE_FULL = 3
    DEBUG_OFF = 0
    DEBUG_ON = 1
    DEBUG_WAIT = 2
    PACKAGE_REMOVED = 0
    EXTERNAL_STORAGE_UNAVAILABLE = 1
    descriptor = "android.app.IApplicationThread"
class OnTransact(IApplicationThread, Stub):
    def onTransact(self, code, data, reply):
        for mycase in Switch(code):
            if mycase("SCHEDULE_PAUSE_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                finished = (data.readInt() != 0)
                userLeaving = (data.readInt() != 0)
                configChanges = data.readInt()
                dontReport = (data.readInt() != 0)
                return self.callFunction("schedulePauseActivity", b, finished, userLeaving, configChanges, dontReport)
                # {'userLeaving': 'boolean', 'finished': 'boolean', 'b': 'IBinder', 'configChanges': 'int', 'dontReport': 'boolean'}
            if mycase("SCHEDULE_STOP_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                show = (data.readInt() != 0)
                configChanges = data.readInt()
                return self.callFunction("scheduleStopActivity", b, show, configChanges)
                # {'b': 'IBinder', 'configChanges': 'int', 'show': 'boolean'}
            if mycase("SCHEDULE_WINDOW_VISIBILITY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                show = (data.readInt() != 0)
                return self.callFunction("scheduleWindowVisibility", b, show)
                # {'b': 'IBinder', 'show': 'boolean'}
            if mycase("SCHEDULE_SLEEPING_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                sleeping = (data.readInt() != 0)
                return self.callFunction("scheduleSleeping", b, sleeping)
                # {'b': 'IBinder', 'sleeping': 'boolean'}
            if mycase("SCHEDULE_RESUME_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                procState = data.readInt()
                isForward = (data.readInt() != 0)
                resumeArgs = data.readBundle()
                return self.callFunction("scheduleResumeActivity", b, procState, isForward, resumeArgs)
                # {'resumeArgs': 'Bundle', 'b': 'IBinder', 'isForward': 'boolean', 'procState': 'int'}
            if mycase("SCHEDULE_SEND_RESULT_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                ri = data.createTypedArrayList("ResultInfo")
                return self.callFunction("scheduleSendResult", b, ri)
                # {'b': 'IBinder', 'ri': 'List<ResultInfo>'}
            if mycase("SCHEDULE_LAUNCH_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                intent = self.creatorResolver("android.content.Intent", data)
                b = data.readStrongBinder()
                ident = data.readInt()
                info = self.creatorResolver("android.content.pm.ActivityInfo", data)
                curConfig = self.creatorResolver("android.content.res.Configuration", data)
                compatInfo = self.creatorResolver("android.content.res.CompatibilityInfo", data)
                referrer = data.readString()
                voiceInteractor = self.interfaceResolver("IVoiceInteractor", data.readStrongBinder())
                procState = data.readInt()
                state = data.readBundle()
                persistentState = data.readPersistableBundle()
                ri = data.createTypedArrayList("ResultInfo")
                pi = data.createTypedArrayList("ReferrerIntent")
                notResumed = (data.readInt() != 0)
                isForward = (data.readInt() != 0)
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                return self.callFunction("scheduleLaunchActivity", intent, b, ident, info, curConfig, compatInfo, referrer, voiceInteractor, procState, state, persistentState, ri, pi, notResumed, isForward, profilerInfo)
                # {'info': 'ActivityInfo', 'ident': 'int', 'referrer': 'String', 'voiceInteractor': 'IVoiceInteractor', 'persistentState': 'PersistableBundle', 'isForward': 'boolean', 'ri': 'List<ResultInfo>', 'state': 'Bundle', 'b': 'IBinder', 'intent': 'Intent', 'procState': 'int', 'notResumed': 'boolean', 'compatInfo': 'CompatibilityInfo', 'pi': 'List<ReferrerIntent>', 'curConfig': 'Configuration', 'profilerInfo': 'ProfilerInfo'}
            if mycase("SCHEDULE_RELAUNCH_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                ri = data.createTypedArrayList("ResultInfo")
                pi = data.createTypedArrayList("ReferrerIntent")
                configChanges = data.readInt()
                notResumed = (data.readInt() != 0)
                config = None
                if (data.readInt() != 0):
                    config = self.creatorResolver("android.content.res.Configuration", data)
                return self.callFunction("scheduleRelaunchActivity", b, ri, pi, configChanges, notResumed, config)
                # {'b': 'IBinder', 'configChanges': 'int', 'notResumed': 'boolean', 'pi': 'List<ReferrerIntent>', 'config': 'Configuration', 'ri': 'List<ResultInfo>', 'IF': {}}
            if mycase("SCHEDULE_NEW_INTENT_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                pi = data.createTypedArrayList("ReferrerIntent")
                b = data.readStrongBinder()
                return self.callFunction("scheduleNewIntent", pi, b)
                # {'pi': 'List<ReferrerIntent>', 'b': 'IBinder'}
            if mycase("SCHEDULE_FINISH_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                finishing = (data.readInt() != 0)
                configChanges = data.readInt()
                return self.callFunction("scheduleDestroyActivity", b, finishing, configChanges)
                # {'finishing': 'boolean', 'b': 'IBinder', 'configChanges': 'int'}
            if mycase("SCHEDULE_RECEIVER_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                intent = self.creatorResolver("android.content.Intent", data)
                info = self.creatorResolver("android.content.pm.ActivityInfo", data)
                compatInfo = self.creatorResolver("android.content.res.CompatibilityInfo", data)
                resultCode = data.readInt()
                resultData = data.readString()
                resultExtras = data.readBundle()
                sync = (data.readInt() != 0)
                sendingUser = data.readInt()
                processState = data.readInt()
                return self.callFunction("scheduleReceiver", intent, info, compatInfo, resultCode, resultData, resultExtras, sync, sendingUser, processState)
                # {'info': 'ActivityInfo', 'resultData': 'String', 'resultExtras': 'Bundle', 'sync': 'boolean', 'compatInfo': 'CompatibilityInfo', 'processState': 'int', 'intent': 'Intent', 'resultCode': 'int', 'sendingUser': 'int'}
            if mycase("SCHEDULE_CREATE_SERVICE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                info = self.creatorResolver("android.content.pm.ServiceInfo", data)
                compatInfo = self.creatorResolver("android.content.res.CompatibilityInfo", data)
                processState = data.readInt()
                return self.callFunction("scheduleCreateService", token, info, compatInfo, processState)
                # {'info': 'ServiceInfo', 'token': 'IBinder', 'compatInfo': 'CompatibilityInfo', 'processState': 'int'}
            if mycase("SCHEDULE_BIND_SERVICE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                intent = self.creatorResolver("android.content.Intent", data)
                rebind = (data.readInt() != 0)
                processState = data.readInt()
                return self.callFunction("scheduleBindService", token, intent, rebind, processState)
                # {'rebind': 'boolean', 'token': 'IBinder', 'intent': 'Intent', 'processState': 'int'}
            if mycase("SCHEDULE_UNBIND_SERVICE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                intent = self.creatorResolver("android.content.Intent", data)
                return self.callFunction("scheduleUnbindService", token, intent)
                # {'token': 'IBinder', 'intent': 'Intent'}
            if mycase("SCHEDULE_SERVICE_ARGS_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                taskRemoved = (data.readInt() != 0)
                startId = data.readInt()
                fl = data.readInt()
                if (data.readInt() != 0):
                    args = self.creatorResolver("android.content.Intent", data)
                else:
                    args = None
                return self.callFunction("scheduleServiceArgs", token, taskRemoved, startId, fl, args)
                # {'startId': 'int', 'args': 'Intent', 'taskRemoved': 'boolean', 'token': 'IBinder', 'fl': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("SCHEDULE_STOP_SERVICE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("scheduleStopService", token)
                # {'token': 'IBinder'}
            if mycase("BIND_APPLICATION_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                packageName = data.readString()
                info = self.creatorResolver("android.content.pm.ApplicationInfo", data)
                providers = data.createTypedArrayList("ProviderInfo")
                testName = self.newInstance("ComponentName", data) if (data.readInt() != 0) else None
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                testArgs = data.readBundle()
                binder = data.readStrongBinder()
                testWatcher = self.interfaceResolver("IInstrumentationWatcher", binder)
                binder = data.readStrongBinder()
                uiAutomationConnection = self.interfaceResolver("IUiAutomationConnection", binder)
                testMode = data.readInt()
                openGlTrace = (data.readInt() != 0)
                restrictedBackupMode = (data.readInt() != 0)
                persistent = (data.readInt() != 0)
                config = self.creatorResolver("android.content.res.Configuration", data)
                compatInfo = self.creatorResolver("android.content.res.CompatibilityInfo", data)
                services = data.readHashMap(None)
                coreSettings = data.readBundle()
                return self.callFunction("bindApplication", packageName, info, providers, testName, profilerInfo, testArgs, testWatcher, uiAutomationConnection, testMode, openGlTrace, restrictedBackupMode, persistent, config, compatInfo, services, coreSettings)
                # {'info': 'ApplicationInfo', 'testArgs': 'Bundle', 'providers': 'List<ProviderInfo>', 'packageName': 'String', 'persistent': 'boolean', 'testName': 'ComponentName', 'testWatcher': 'IInstrumentationWatcher', 'uiAutomationConnection': 'IUiAutomationConnection', 'services': 'HashMap<String, IBinder>', 'binder': 'IBinder', 'openGlTrace': 'boolean', 'compatInfo': 'CompatibilityInfo', 'testMode': 'int', 'restrictedBackupMode': 'boolean', 'coreSettings': 'Bundle', 'profilerInfo': 'ProfilerInfo', 'config': 'Configuration'}
            if mycase("SCHEDULE_EXIT_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                return self.callFunction("scheduleExit")
                # {}
            if mycase("SCHEDULE_SUICIDE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                return self.callFunction("scheduleSuicide")
                # {}
            if mycase("SCHEDULE_CONFIGURATION_CHANGED_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                config = self.creatorResolver("android.content.res.Configuration", data)
                return self.callFunction("scheduleConfigurationChanged", config)
                # {'config': 'Configuration'}
            if mycase("UPDATE_TIME_ZONE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                return self.callFunction("updateTimeZone")
                # {}
            if mycase("CLEAR_DNS_CACHE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                return self.callFunction("clearDnsCache")
                # {}
            if mycase("SET_HTTP_PROXY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                proxy = data.readString()
                port = data.readString()
                exclList = data.readString()
                pacFileUrl = self.creatorResolver("android.net.Uri", data)
                return self.callFunction("setHttpProxy", proxy, port, exclList, pacFileUrl)
                # {'exclList': 'String', 'pacFileUrl': 'Uri', 'proxy': 'String', 'port': 'String'}
            if mycase("PROCESS_IN_BACKGROUND_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                return self.callFunction("processInBackground")
                # {}
            if mycase("DUMP_SERVICE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                fd = data.readFileDescriptor()
                service = data.readStrongBinder()
                args = data.readStringArray()
                if (fd != None):
                    return self.callFunction("dumpService", fd.getFileDescriptor(), service, args)
                return True
                # {'args': 'String', 'fd': 'ParcelFileDescriptor', 'service': 'IBinder', 'IF': {}}
            if mycase("DUMP_PROVIDER_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                fd = data.readFileDescriptor()
                service = data.readStrongBinder()
                args = data.readStringArray()
                if (fd != None):
                    return self.callFunction("dumpProvider", fd.getFileDescriptor(), service, args)
                return True
                # {'args': 'String', 'fd': 'ParcelFileDescriptor', 'service': 'IBinder', 'IF': {}}
            if mycase("SCHEDULE_REGISTERED_RECEIVER_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                receiver = self.interfaceResolver("IIntentReceiver", data.readStrongBinder())
                intent = self.creatorResolver("android.content.Intent", data)
                resultCode = data.readInt()
                dataStr = data.readString()
                extras = data.readBundle()
                ordered = (data.readInt() != 0)
                sticky = (data.readInt() != 0)
                sendingUser = data.readInt()
                processState = data.readInt()
                return self.callFunction("scheduleRegisteredReceiver", receiver, intent, resultCode, dataStr, extras, ordered, sticky, sendingUser, processState)
                # {'ordered': 'boolean', 'sticky': 'boolean', 'extras': 'Bundle', 'intent': 'Intent', 'processState': 'int', 'receiver': 'IIntentReceiver', 'resultCode': 'int', 'sendingUser': 'int', 'dataStr': 'String'}
            if mycase("SCHEDULE_LOW_MEMORY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                return self.callFunction("scheduleLowMemory")
                # {}
            if mycase("SCHEDULE_ACTIVITY_CONFIGURATION_CHANGED_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                b = data.readStrongBinder()
                return self.callFunction("scheduleActivityConfigurationChanged", b)
                # {'b': 'IBinder'}
            if mycase("PROFILER_CONTROL_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                start = (data.readInt() != 0)
                profileType = data.readInt()
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                return self.callFunction("profilerControl", start, profilerInfo, profileType)
                # {'start': 'boolean', 'profilerInfo': 'ProfilerInfo', 'profileType': 'int'}
            if mycase("SET_SCHEDULING_GROUP_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                group = data.readInt()
                return self.callFunction("setSchedulingGroup", group)
                # {'group': 'int'}
            if mycase("SCHEDULE_CREATE_BACKUP_AGENT_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                appInfo = self.creatorResolver("android.content.pm.ApplicationInfo", data)
                compatInfo = self.creatorResolver("android.content.res.CompatibilityInfo", data)
                backupMode = data.readInt()
                return self.callFunction("scheduleCreateBackupAgent", appInfo, compatInfo, backupMode)
                # {'appInfo': 'ApplicationInfo', 'compatInfo': 'CompatibilityInfo', 'backupMode': 'int'}
            if mycase("SCHEDULE_DESTROY_BACKUP_AGENT_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                appInfo = self.creatorResolver("android.content.pm.ApplicationInfo", data)
                compatInfo = self.creatorResolver("android.content.res.CompatibilityInfo", data)
                return self.callFunction("scheduleDestroyBackupAgent", appInfo, compatInfo)
                # {'appInfo': 'ApplicationInfo', 'compatInfo': 'CompatibilityInfo'}
            if mycase("DISPATCH_PACKAGE_BROADCAST_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                cmd = data.readInt()
                packages = data.readStringArray()
                return self.callFunction("dispatchPackageBroadcast", cmd, packages)
                # {'cmd': 'int', 'packages': 'String'}
            if mycase("SCHEDULE_CRASH_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                msg = data.readString()
                return self.callFunction("scheduleCrash", msg)
                # {'msg': 'String'}
            if mycase("DUMP_HEAP_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                managed = (data.readInt() != 0)
                path = data.readString()
                fd = self.creatorResolver("android.os.ParcelFileDescriptor", data) if (data.readInt() != 0) else None
                return self.callFunction("dumpHeap", managed, path, fd)
                # {'path': 'String', 'fd': 'ParcelFileDescriptor', 'managed': 'boolean'}
            if mycase("DUMP_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                fd = data.readFileDescriptor()
                activity = data.readStrongBinder()
                prefix = data.readString()
                args = data.readStringArray()
                if (fd != None):
                    return self.callFunction("dumpActivity", fd.getFileDescriptor(), activity, prefix, args)
                return True
                # {'prefix': 'String', 'args': 'String', 'fd': 'ParcelFileDescriptor', 'IF': {}, 'activity': 'IBinder'}
            if mycase("SET_CORE_SETTINGS_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                settings = data.readBundle()
                return self.callFunction("setCoreSettings", settings)
                # {'settings': 'Bundle'}
            if mycase("UPDATE_PACKAGE_COMPATIBILITY_INFO_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                pkg = data.readString()
                compat = self.creatorResolver("android.content.res.CompatibilityInfo", data)
                return self.callFunction("updatePackageCompatibilityInfo", pkg, compat)
                # {'compat': 'CompatibilityInfo', 'pkg': 'String'}
            if mycase("SCHEDULE_TRIM_MEMORY_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                level = data.readInt()
                return self.callFunction("scheduleTrimMemory", level)
                # {'level': 'int'}
            if mycase("DUMP_MEM_INFO_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                fd = data.readFileDescriptor()
                mi = self.creatorResolver("Debug.MemoryInfo", data)
                checkin = (data.readInt() != 0)
                dumpInfo = (data.readInt() != 0)
                dumpDalvik = (data.readInt() != 0)
                args = data.readStringArray()
                if (fd != None):
                    return self.callFunction("dumpMemInfo", fd.getFileDescriptor(), mi, checkin, dumpInfo, dumpDalvik, args)
                reply.writeNoException()
                return True
                # {'checkin': 'boolean', 'args': 'String', 'mi': 'Debug.MemoryInfo', 'fd': 'ParcelFileDescriptor', 'dumpDalvik': 'boolean', 'dumpInfo': 'boolean', 'IF': {}}
            if mycase("DUMP_GFX_INFO_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                fd = data.readFileDescriptor()
                args = data.readStringArray()
                if (fd != None):
                    return self.callFunction("dumpGfxInfo", fd.getFileDescriptor(), args)
                reply.writeNoException()
                return True
                # {'args': 'String', 'fd': 'ParcelFileDescriptor', 'IF': {}}
            if mycase("DUMP_DB_INFO_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                fd = data.readFileDescriptor()
                args = data.readStringArray()
                if (fd != None):
                    return self.callFunction("dumpDbInfo", fd.getFileDescriptor(), args)
                reply.writeNoException()
                return True
                # {'args': 'String', 'fd': 'ParcelFileDescriptor', 'IF': {}}
            if mycase("UNSTABLE_PROVIDER_DIED_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                provider = data.readStrongBinder()
                return self.callFunction("unstableProviderDied", provider)
                # {'provider': 'IBinder'}
            if mycase("REQUEST_ASSIST_CONTEXT_EXTRAS_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                activityToken = data.readStrongBinder()
                requestToken = data.readStrongBinder()
                requestType = data.readInt()
                return self.callFunction("requestAssistContextExtras", activityToken, requestToken, requestType)
                # {'requestType': 'int', 'activityToken': 'IBinder', 'requestToken': 'IBinder'}
            if mycase("SCHEDULE_TRANSLUCENT_CONVERSION_COMPLETE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                timeout = (data.readInt() == 1)
                return self.callFunction("scheduleTranslucentConversionComplete", token, timeout)
                # {'token': 'IBinder', 'timeout': 'boolean'}
            if mycase("SCHEDULE_ON_NEW_ACTIVITY_OPTIONS_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                options = self.newInstance("ActivityOptions", data.readBundle())
                return self.callFunction("scheduleOnNewActivityOptions", token, options)
                # {'token': 'IBinder', 'options': 'ActivityOptions'}
            if mycase("SET_PROCESS_STATE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                state = data.readInt()
                return self.callFunction("setProcessState", state)
                # {'state': 'int'}
            if mycase("SCHEDULE_INSTALL_PROVIDER_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                provider = self.creatorResolver("android.content.pm.ProviderInfo", data)
                return self.callFunction("scheduleInstallProvider", provider)
                # {'provider': 'ProviderInfo'}
            if mycase("UPDATE_TIME_PREFS_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                is24Hour = data.readByte()
                return self.callFunction("updateTimePrefs", (is24Hour == None))
                # {'is24Hour': 'byte'}
            if mycase("CANCEL_VISIBLE_BEHIND_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("scheduleCancelVisibleBehind", token)
                # {'token': 'IBinder'}
            if mycase("BACKGROUND_VISIBLE_BEHIND_CHANGED_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                enabled = (data.readInt() > 0)
                return self.callFunction("scheduleBackgroundVisibleBehindChanged", token, enabled)
                # {'token': 'IBinder', 'enabled': 'boolean'}
            if mycase("ENTER_ANIMATION_COMPLETE_TRANSACTION"):
                data.enforceInterface(IApplicationThread.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("scheduleEnterAnimationComplete", token)
                # {'token': 'IBinder'}
