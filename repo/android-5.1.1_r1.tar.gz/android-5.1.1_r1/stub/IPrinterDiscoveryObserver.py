from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrinterDiscoveryObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IPrinterDiscoveryObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IPrinterDiscoveryObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onPrintersAdded"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.ParceledListSlice", data)
                else:
                    _arg0 = None
                return self.callFunction("onPrintersAdded", _arg0)
                # {'_arg0': 'android.content.pm.ParceledListSlice', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPrintersRemoved"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.ParceledListSlice", data)
                else:
                    _arg0 = None
                return self.callFunction("onPrintersRemoved", _arg0)
                # {'_arg0': 'android.content.pm.ParceledListSlice', 'ELSE:': {}, 'IF': {}}
