from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsRegistrationListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsRegistrationListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsRegistrationListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registrationConnected"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("registrationConnected")
                # {}
            if mycase("TRANSACTION_registrationDisconnected"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("registrationDisconnected")
                # {}
            if mycase("TRANSACTION_registrationResumed"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("registrationResumed")
                # {}
            if mycase("TRANSACTION_registrationSuspended"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("registrationSuspended")
                # {}
            if mycase("TRANSACTION_registrationServiceCapabilityChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("registrationServiceCapabilityChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_registrationFeatureCapabilityChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1_length = data.readInt()
                if (_arg1_length < 0):
                    _arg1 = None
                else:
                    _arg1 = [None for _i in range(_arg1_length)] # 
                _arg2_length = data.readInt()
                if (_arg2_length < 0):
                    _arg2 = None
                else:
                    _arg2 = [None for _i in range(_arg2_length)] # 
                return self.callFunction("registrationFeatureCapabilityChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg1_length': 'int', '_arg0': 'int', '_arg1': 'int', '_arg2_length': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
