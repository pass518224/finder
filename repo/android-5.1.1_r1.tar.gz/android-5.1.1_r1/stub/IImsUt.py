from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsUt:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsUt"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsUt"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("close")
                # {}
            if mycase("TRANSACTION_queryCallBarring"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("queryCallBarring", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_queryCallForward"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("queryCallForward", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_queryCallWaiting"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("queryCallWaiting")
                # {'_result': 'int'}
            if mycase("TRANSACTION_queryCLIR"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("queryCLIR")
                # {'_result': 'int'}
            if mycase("TRANSACTION_queryCLIP"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("queryCLIP")
                # {'_result': 'int'}
            if mycase("TRANSACTION_queryCOLR"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("queryCOLR")
                # {'_result': 'int'}
            if mycase("TRANSACTION_queryCOLP"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("queryCOLP")
                # {'_result': 'int'}
            if mycase("TRANSACTION_transact"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("transact", _arg0)
                # {'_arg0': 'android.os.Bundle', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateCallBarring"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                _arg2 = data.createStringArray()
                return self.callFunction("updateCallBarring", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'boolean', '_result': 'int'}
            if mycase("TRANSACTION_updateCallForward"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                return self.callFunction("updateCallForward", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'int'}
            if mycase("TRANSACTION_updateCallWaiting"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("updateCallWaiting", _arg0)
                # {'_arg0': 'boolean', '_result': 'int'}
            if mycase("TRANSACTION_updateCLIR"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("updateCLIR", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_updateCLIP"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("updateCLIP", _arg0)
                # {'_arg0': 'boolean', '_result': 'int'}
            if mycase("TRANSACTION_updateCOLR"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("updateCOLR", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_updateCOLP"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("updateCOLP", _arg0)
                # {'_arg0': 'boolean', '_result': 'int'}
            if mycase("TRANSACTION_setListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsUtListener", data.readStrongBinder())
                return self.callFunction("setListener", _arg0)
                # {'_arg0': 'com.android.ims.internal.IImsUtListener'}
