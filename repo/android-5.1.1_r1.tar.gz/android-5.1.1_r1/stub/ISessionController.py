from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISessionController:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.session.ISessionController"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.session.ISessionController"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sendCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ResultReceiver", data)
                else:
                    _arg2 = None
                return self.callFunction("sendCommand", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.ResultReceiver', '_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendMediaButton"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.KeyEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("sendMediaButton", _arg0)
                # {'_arg0': 'android.view.KeyEvent', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_registerCallbackListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.session.ISessionControllerCallback", data.readStrongBinder())
                return self.callFunction("registerCallbackListener", _arg0)
                # {'_arg0': 'android.media.session.ISessionControllerCallback'}
            if mycase("TRANSACTION_unregisterCallbackListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.session.ISessionControllerCallback", data.readStrongBinder())
                return self.callFunction("unregisterCallbackListener", _arg0)
                # {'_arg0': 'android.media.session.ISessionControllerCallback'}
            if mycase("TRANSACTION_isTransportControlEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isTransportControlEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getPackageName"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPackageName")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getTag"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTag")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getLaunchPendingIntent"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLaunchPendingIntent")
                # {'_result': 'android.app.PendingIntent'}
            if mycase("TRANSACTION_getFlags"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getFlags")
                # {'_result': 'long'}
            if mycase("TRANSACTION_getVolumeAttributes"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVolumeAttributes")
                # {'_result': 'android.media.session.ParcelableVolumeInfo'}
            if mycase("TRANSACTION_adjustVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("adjustVolume", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setVolumeTo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("setVolumeTo", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_play"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("play")
                # {}
            if mycase("TRANSACTION_playFromMediaId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("playFromMediaId", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_playFromSearch"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("playFromSearch", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_skipToQueueItem"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("skipToQueueItem", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_pause"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("pause")
                # {}
            if mycase("TRANSACTION_stop"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stop")
                # {}
            if mycase("TRANSACTION_next"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("next")
                # {}
            if mycase("TRANSACTION_previous"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("previous")
                # {}
            if mycase("TRANSACTION_fastForward"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("fastForward")
                # {}
            if mycase("TRANSACTION_rewind"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("rewind")
                # {}
            if mycase("TRANSACTION_seekTo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("seekTo", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_rate"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.Rating", data)
                else:
                    _arg0 = None
                return self.callFunction("rate", _arg0)
                # {'_arg0': 'android.media.Rating', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendCustomAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("sendCustomAction", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getMetadata"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMetadata")
                # {'_result': 'android.media.MediaMetadata'}
            if mycase("TRANSACTION_getPlaybackState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPlaybackState")
                # {'_result': 'android.media.session.PlaybackState'}
            if mycase("TRANSACTION_getQueue"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getQueue")
                # {'_result': 'android.content.pm.ParceledListSlice'}
            if mycase("TRANSACTION_getQueueTitle"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getQueueTitle")
                # {'_result': 'java.lang.CharSequence'}
            if mycase("TRANSACTION_getExtras"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getExtras")
                # {'_result': 'android.os.Bundle'}
            if mycase("TRANSACTION_getRatingType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getRatingType")
                # {'_result': 'int'}
