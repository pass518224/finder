from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISms:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.ISms"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.ISms"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getAllMessagesFromIccEf"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getAllMessagesFromIccEf", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.util.List<com.android.internal.telephony.SmsRawData>'}
            if mycase("TRANSACTION_getAllMessagesFromIccEfForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("getAllMessagesFromIccEfForSubscriber", _arg0, _arg1)
                # {'_result': 'java.util.List<com.android.internal.telephony.SmsRawData>', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_updateMessageOnIccEf"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.createByteArray()
                return self.callFunction("updateMessageOnIccEf", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'byte', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_updateMessageOnIccEfForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.createByteArray()
                return self.callFunction("updateMessageOnIccEfForSubscriber", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'byte'}
            if mycase("TRANSACTION_copyMessageToIccEf"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.createByteArray()
                _arg3 = data.createByteArray()
                return self.callFunction("copyMessageToIccEf", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'byte', '_arg3': 'byte', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_copyMessageToIccEfForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.createByteArray()
                _arg4 = data.createByteArray()
                return self.callFunction("copyMessageToIccEfForSubscriber", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'byte', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'byte'}
            if mycase("TRANSACTION_sendData"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                _arg4 = data.createByteArray()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg5 = None
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg6 = None
                return self.callFunction("sendData", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg6': 'android.app.PendingIntent', '_arg4': 'byte', '_arg5': 'android.app.PendingIntent', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendDataForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                _arg5 = data.createByteArray()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg6 = None
                if (0 != data.readInt()):
                    _arg7 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg7 = None
                return self.callFunction("sendDataForSubscriber", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'android.app.PendingIntent', '_arg7': 'android.app.PendingIntent', '_arg4': 'int', '_arg5': 'byte', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg4 = None
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg5 = None
                return self.callFunction("sendText", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg4': 'android.app.PendingIntent', '_arg5': 'android.app.PendingIntent', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendTextForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readString()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg5 = None
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg6 = None
                return self.callFunction("sendTextForSubscriber", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'android.app.PendingIntent', '_arg4': 'java.lang.String', '_arg5': 'android.app.PendingIntent', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_injectSmsPdu"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg2 = None
                return self.callFunction("injectSmsPdu", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.app.PendingIntent', '_arg0': 'byte', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendMultipartText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.createStringArrayList()
                _arg4 = data.createTypedArrayList("android.app.PendingIntent")
                _arg5 = data.createTypedArrayList("android.app.PendingIntent")
                return self.callFunction("sendMultipartText", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.util.List<java.lang.String>', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg4': 'java.util.List<android.app.PendingIntent>', '_arg5': 'java.util.List<android.app.PendingIntent>'}
            if mycase("TRANSACTION_sendMultipartTextForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.createStringArrayList()
                _arg5 = data.createTypedArrayList("android.app.PendingIntent")
                _arg6 = data.createTypedArrayList("android.app.PendingIntent")
                return self.callFunction("sendMultipartTextForSubscriber", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'java.util.List<android.app.PendingIntent>', '_arg4': 'java.util.List<java.lang.String>', '_arg5': 'java.util.List<android.app.PendingIntent>'}
            if mycase("TRANSACTION_enableCellBroadcast"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("enableCellBroadcast", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_enableCellBroadcastForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("enableCellBroadcastForSubscriber", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_disableCellBroadcast"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("disableCellBroadcast", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_disableCellBroadcastForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("disableCellBroadcastForSubscriber", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_enableCellBroadcastRange"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("enableCellBroadcastRange", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_enableCellBroadcastRangeForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("enableCellBroadcastRangeForSubscriber", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_disableCellBroadcastRange"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("disableCellBroadcastRange", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_disableCellBroadcastRangeForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("disableCellBroadcastRangeForSubscriber", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getPremiumSmsPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPremiumSmsPermission", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_getPremiumSmsPermissionForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("getPremiumSmsPermissionForSubscriber", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setPremiumSmsPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setPremiumSmsPermission", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setPremiumSmsPermissionForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("setPremiumSmsPermissionForSubscriber", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_isImsSmsSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isImsSmsSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isImsSmsSupportedForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isImsSmsSupportedForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_isSmsSimPickActivityNeeded"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isSmsSimPickActivityNeeded", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getPreferredSmsSubscription"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPreferredSmsSubscription")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getImsSmsFormat"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getImsSmsFormat")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getImsSmsFormatForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getImsSmsFormatForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_isSMSPromptEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isSMSPromptEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_sendStoredText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg2 = None
                _arg3 = data.readString()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg4 = None
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg5 = None
                return self.callFunction("sendStoredText", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'android.net.Uri', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'android.app.PendingIntent', '_arg5': 'android.app.PendingIntent', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendStoredMultipartText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg2 = None
                _arg3 = data.readString()
                _arg4 = data.createTypedArrayList("android.app.PendingIntent")
                _arg5 = data.createTypedArrayList("android.app.PendingIntent")
                return self.callFunction("sendStoredMultipartText", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'android.net.Uri', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'java.util.List<android.app.PendingIntent>', '_arg5': 'java.util.List<android.app.PendingIntent>', 'ELSE:': {}, 'IF': {}}
