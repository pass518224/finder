from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWallpaperManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IWallpaperManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IWallpaperManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setWallpaper"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setWallpaper", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.os.ParcelFileDescriptor'}
            if mycase("TRANSACTION_setWallpaperComponent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("setWallpaperComponent", _arg0)
                # {'_arg0': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getWallpaper"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.app.IWallpaperManagerCallback", data.readStrongBinder())
                _arg1 = self.newInstance("android.os.Bundle", )
                return self.callFunction("getWallpaper", _arg0, _arg1)
                # {'_result': 'android.os.ParcelFileDescriptor', '_arg0': 'android.app.IWallpaperManagerCallback', '_arg1': 'android.os.Bundle'}
            if mycase("TRANSACTION_getWallpaperInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWallpaperInfo")
                # {'_result': 'android.app.WallpaperInfo'}
            if mycase("TRANSACTION_clearWallpaper"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearWallpaper")
                # {}
            if mycase("TRANSACTION_hasNamedWallpaper"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("hasNamedWallpaper", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_setDimensionHints"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setDimensionHints", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getWidthHint"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWidthHint")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getHeightHint"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getHeightHint")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setDisplayPadding"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg0 = None
                return self.callFunction("setDisplayPadding", _arg0)
                # {'_arg0': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getName"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getName")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_settingsRestored"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("settingsRestored")
                # {}
