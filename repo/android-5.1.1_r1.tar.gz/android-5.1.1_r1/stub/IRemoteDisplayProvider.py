from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRemoteDisplayProvider:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IRemoteDisplayProvider"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IRemoteDisplayProvider"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IRemoteDisplayCallback", data.readStrongBinder())
                return self.callFunction("setCallback", _arg0)
                # {'_arg0': 'android.media.IRemoteDisplayCallback'}
            if mycase("TRANSACTION_setDiscoveryMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setDiscoveryMode", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("connect", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("disconnect", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setVolume", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_adjustVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("adjustVolume", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
