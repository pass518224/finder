from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothGatt:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothGatt"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothGatt"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getDevicesMatchingConnectionStates"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createIntArray()
                return self.callFunction("getDevicesMatchingConnectionStates", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_startScan"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.bluetooth.le.ScanSettings", data)
                else:
                    _arg2 = None
                _arg3 = data.createTypedArrayList("android.bluetooth.le.ScanFilter")
                _arg4 = data.readArrayList(cl)
                return self.callFunction("startScan", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'cl': 'java.lang.ClassLoader', '_arg2': 'android.bluetooth.le.ScanSettings', '_arg3': 'java.util.List<android.bluetooth.le.ScanFilter>', '_arg0': 'int', '_arg1': 'boolean', '_arg4': 'java.util.List', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopScan"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("stopScan", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_flushPendingBatchResults"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("flushPendingBatchResults", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_startMultiAdvertising"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.bluetooth.le.AdvertiseData", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.bluetooth.le.AdvertiseData", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.bluetooth.le.AdvertiseSettings", data)
                else:
                    _arg3 = None
                return self.callFunction("startMultiAdvertising", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.bluetooth.le.AdvertiseData', '_arg3': 'android.bluetooth.le.AdvertiseSettings', '_arg0': 'int', '_arg1': 'android.bluetooth.le.AdvertiseData', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopMultiAdvertising"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("stopMultiAdvertising", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_registerClient"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.bluetooth.IBluetoothGattCallback", data.readStrongBinder())
                return self.callFunction("registerClient", _arg0, _arg1)
                # {'_arg0': 'android.os.ParcelUuid', '_arg1': 'android.bluetooth.IBluetoothGattCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("unregisterClient", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_clientConnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                _arg3 = data.readInt()
                return self.callFunction("clientConnect", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'boolean', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_clientDisconnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("clientDisconnect", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_refreshDevice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("refreshDevice", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_discoverServices"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("discoverServices", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_readCharacteristic"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                return self.callFunction("readCharacteristic", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'android.os.ParcelUuid', '_arg7': 'int', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_writeCharacteristic"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                _arg8 = data.readInt()
                _arg9 = data.createByteArray()
                return self.callFunction("writeCharacteristic", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9)
                # {'_arg8': 'int', '_arg9': 'byte', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'android.os.ParcelUuid', '_arg7': 'int', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_readDescriptor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg8 = None
                _arg9 = data.readInt()
                return self.callFunction("readDescriptor", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9)
                # {'_arg8': 'android.os.ParcelUuid', '_arg9': 'int', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'android.os.ParcelUuid', '_arg7': 'int', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_writeDescriptor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg8 = None
                _arg9 = data.readInt()
                _arg10 = data.readInt()
                _arg11 = data.createByteArray()
                return self.callFunction("writeDescriptor", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9, _arg10, _arg11)
                # {'_arg8': 'android.os.ParcelUuid', '_arg9': 'int', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'android.os.ParcelUuid', '_arg7': 'int', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, '_arg11': 'byte', '_arg10': 'int', 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_registerForNotification"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = (0 != data.readInt())
                return self.callFunction("registerForNotification", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'android.os.ParcelUuid', '_arg7': 'boolean', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_beginReliableWrite"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("beginReliableWrite", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_endReliableWrite"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("endReliableWrite", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_readRemoteRssi"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("readRemoteRssi", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_configureMTU"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("configureMTU", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_connectionParameterUpdate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("connectionParameterUpdate", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_registerServer"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.bluetooth.IBluetoothGattServerCallback", data.readStrongBinder())
                return self.callFunction("registerServer", _arg0, _arg1)
                # {'_arg0': 'android.os.ParcelUuid', '_arg1': 'android.bluetooth.IBluetoothGattServerCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterServer"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("unregisterServer", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_serverConnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                _arg3 = data.readInt()
                return self.callFunction("serverConnect", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'boolean', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_serverDisconnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("serverDisconnect", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_beginServiceDeclaration"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = (0 != data.readInt())
                return self.callFunction("beginServiceDeclaration", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg4': 'android.os.ParcelUuid', '_arg5': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addIncludedService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg3 = None
                return self.callFunction("addIncludedService", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'android.os.ParcelUuid', '_arg0': 'int', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addCharacteristic"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("addCharacteristic", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'android.os.ParcelUuid', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addDescriptor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("addDescriptor", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'android.os.ParcelUuid', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_endServiceDeclaration"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("endServiceDeclaration", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_removeService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg3 = None
                return self.callFunction("removeService", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'android.os.ParcelUuid', '_arg0': 'int', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearServices"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("clearServices", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_sendResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.createByteArray()
                return self.callFunction("sendResponse", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'int', '_arg5': 'byte'}
            if mycase("TRANSACTION_sendNotification"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = (0 != data.readInt())
                _arg8 = data.createByteArray()
                return self.callFunction("sendNotification", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'byte', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg6': 'android.os.ParcelUuid', '_arg7': 'boolean', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
