from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INotificationManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.INotificationManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.INotificationManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_cancelAllNotifications"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("cancelAllNotifications", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_enqueueToast"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.app.ITransientNotification", data.readStrongBinder())
                _arg2 = data.readInt()
                return self.callFunction("enqueueToast", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.app.ITransientNotification'}
            if mycase("TRANSACTION_cancelToast"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.app.ITransientNotification", data.readStrongBinder())
                return self.callFunction("cancelToast", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.app.ITransientNotification'}
            if mycase("TRANSACTION_enqueueNotificationWithTag"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.app.Notification", data)
                else:
                    _arg4 = None
                _arg5 = data.createIntArray()
                _arg6 = data.readInt()
                return self.callFunction("enqueueNotificationWithTag", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg6': 'int', '_arg4': 'android.app.Notification', '_arg5': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_cancelNotificationWithTag"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("cancelNotificationWithTag", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setNotificationsEnabledForPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setNotificationsEnabledForPackage", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_areNotificationsEnabledForPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("areNotificationsEnabledForPackage", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setPackagePriority"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPackagePriority", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getPackagePriority"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getPackagePriority", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setPackageVisibilityOverride"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPackageVisibilityOverride", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getPackageVisibilityOverride"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getPackageVisibilityOverride", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getActiveNotifications"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getActiveNotifications", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.service.notification.StatusBarNotification'}
            if mycase("TRANSACTION_getHistoricalNotifications"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getHistoricalNotifications", _arg0, _arg1)
                # {'_result': 'android.service.notification.StatusBarNotification', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_registerListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("registerListener", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.service.notification.INotificationListener', '_arg1': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("unregisterListener", _arg0, _arg1)
                # {'_arg0': 'android.service.notification.INotificationListener', '_arg1': 'int'}
            if mycase("TRANSACTION_cancelNotificationFromListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                return self.callFunction("cancelNotificationFromListener", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'android.service.notification.INotificationListener', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_cancelNotificationsFromListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                _arg1 = data.createStringArray()
                return self.callFunction("cancelNotificationsFromListener", _arg0, _arg1)
                # {'_arg0': 'android.service.notification.INotificationListener', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getActiveNotificationsFromListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                _arg1 = data.createStringArray()
                _arg2 = data.readInt()
                return self.callFunction("getActiveNotificationsFromListener", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.service.notification.INotificationListener', '_arg1': 'java.lang.String', '_result': 'android.content.pm.ParceledListSlice'}
            if mycase("TRANSACTION_requestHintsFromListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("requestHintsFromListener", _arg0, _arg1)
                # {'_arg0': 'android.service.notification.INotificationListener', '_arg1': 'int'}
            if mycase("TRANSACTION_getHintsFromListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                return self.callFunction("getHintsFromListener", _arg0)
                # {'_arg0': 'android.service.notification.INotificationListener', '_result': 'int'}
            if mycase("TRANSACTION_requestInterruptionFilterFromListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("requestInterruptionFilterFromListener", _arg0, _arg1)
                # {'_arg0': 'android.service.notification.INotificationListener', '_arg1': 'int'}
            if mycase("TRANSACTION_getInterruptionFilterFromListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                return self.callFunction("getInterruptionFilterFromListener", _arg0)
                # {'_arg0': 'android.service.notification.INotificationListener', '_result': 'int'}
            if mycase("TRANSACTION_setOnNotificationPostedTrimFromListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.INotificationListener", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("setOnNotificationPostedTrimFromListener", _arg0, _arg1)
                # {'_arg0': 'android.service.notification.INotificationListener', '_arg1': 'int'}
            if mycase("TRANSACTION_getEffectsSuppressor"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getEffectsSuppressor")
                # {'_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_matchesCallFilter"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("matchesCallFilter", _arg0)
                # {'_arg0': 'android.os.Bundle', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isSystemConditionProviderEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isSystemConditionProviderEnabled", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_getZenModeConfig"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getZenModeConfig")
                # {'_result': 'android.service.notification.ZenModeConfig'}
            if mycase("TRANSACTION_setZenModeConfig"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.service.notification.ZenModeConfig", data)
                else:
                    _arg0 = None
                return self.callFunction("setZenModeConfig", _arg0)
                # {'_arg0': 'android.service.notification.ZenModeConfig', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyConditions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.service.notification.IConditionProvider", data.readStrongBinder())
                _arg2 = data.createTypedArray("android.service.notification.Condition")
                return self.callFunction("notifyConditions", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.service.notification.Condition', '_arg0': 'java.lang.String', '_arg1': 'android.service.notification.IConditionProvider'}
            if mycase("TRANSACTION_requestZenModeConditions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.IConditionListener", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("requestZenModeConditions", _arg0, _arg1)
                # {'_arg0': 'android.service.notification.IConditionListener', '_arg1': 'int'}
            if mycase("TRANSACTION_setZenModeCondition"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.service.notification.Condition", data)
                else:
                    _arg0 = None
                return self.callFunction("setZenModeCondition", _arg0)
                # {'_arg0': 'android.service.notification.Condition', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAutomaticZenModeConditions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.net.Uri")
                return self.callFunction("setAutomaticZenModeConditions", _arg0)
                # {'_arg0': 'android.net.Uri'}
            if mycase("TRANSACTION_getAutomaticZenModeConditions"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAutomaticZenModeConditions")
                # {'_result': 'android.service.notification.Condition'}
