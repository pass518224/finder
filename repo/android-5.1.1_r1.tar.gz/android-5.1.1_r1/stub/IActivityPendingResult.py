from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IActivityPendingResult:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IActivityPendingResult"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IActivityPendingResult"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sendResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("sendResult", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.os.Bundle', '_arg0': 'int', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
