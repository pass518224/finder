from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IUiModeManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IUiModeManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IUiModeManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_enableCarMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("enableCarMode", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_disableCarMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("disableCarMode", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getCurrentModeType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentModeType")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setNightMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setNightMode", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getNightMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNightMode")
                # {'_result': 'int'}
