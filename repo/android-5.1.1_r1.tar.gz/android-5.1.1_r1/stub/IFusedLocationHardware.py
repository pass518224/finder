from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IFusedLocationHardware:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.location.IFusedLocationHardware"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.location.IFusedLocationHardware"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerSink"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.location.IFusedLocationHardwareSink", data.readStrongBinder())
                return self.callFunction("registerSink", _arg0)
                # {'_arg0': 'android.hardware.location.IFusedLocationHardwareSink'}
            if mycase("TRANSACTION_unregisterSink"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.location.IFusedLocationHardwareSink", data.readStrongBinder())
                return self.callFunction("unregisterSink", _arg0)
                # {'_arg0': 'android.hardware.location.IFusedLocationHardwareSink'}
            if mycase("TRANSACTION_getSupportedBatchSize"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSupportedBatchSize")
                # {'_result': 'int'}
            if mycase("TRANSACTION_startBatching"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.location.FusedBatchOptions", data)
                else:
                    _arg1 = None
                return self.callFunction("startBatching", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.location.FusedBatchOptions', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopBatching"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("stopBatching", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_updateBatchingOptions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.location.FusedBatchOptions", data)
                else:
                    _arg1 = None
                return self.callFunction("updateBatchingOptions", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.location.FusedBatchOptions', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_requestBatchOfLocations"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("requestBatchOfLocations", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_supportsDiagnosticDataInjection"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("supportsDiagnosticDataInjection")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_injectDiagnosticData"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("injectDiagnosticData", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_supportsDeviceContextInjection"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("supportsDeviceContextInjection")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_injectDeviceContext"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("injectDeviceContext", _arg0)
                # {'_arg0': 'int'}
