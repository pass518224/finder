from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INsdManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.nsd.INsdManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.nsd.INsdManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getMessenger"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMessenger")
                # {'_result': 'android.os.Messenger'}
            if mycase("TRANSACTION_setEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setEnabled", _arg0)
                # {'_arg0': 'boolean'}
