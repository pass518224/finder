from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IActivityRecognitionHardwareSink:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.location.IActivityRecognitionHardwareSink"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.location.IActivityRecognitionHardwareSink"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onActivityChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.location.ActivityChangedEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("onActivityChanged", _arg0)
                # {'_arg0': 'android.hardware.location.ActivityChangedEvent', 'ELSE:': {}, 'IF': {}}
