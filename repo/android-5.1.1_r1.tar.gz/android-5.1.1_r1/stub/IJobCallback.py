from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IJobCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.job.IJobCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.job.IJobCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_acknowledgeStartMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("acknowledgeStartMessage", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_acknowledgeStopMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("acknowledgeStopMessage", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_jobFinished"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("jobFinished", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
