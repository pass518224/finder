from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IProxyCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.net.IProxyCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.net.IProxyCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getProxyPort"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("getProxyPort", _arg0)
                # {'_arg0': 'android.os.IBinder'}
