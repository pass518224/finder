from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWifiP2pManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.wifi.p2p.IWifiP2pManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.wifi.p2p.IWifiP2pManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getMessenger"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMessenger")
                # {'_result': 'android.os.Messenger'}
            if mycase("TRANSACTION_getP2pStateMachineMessenger"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getP2pStateMachineMessenger")
                # {'_result': 'android.os.Messenger'}
            if mycase("TRANSACTION_setMiracastMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setMiracastMode", _arg0)
                # {'_arg0': 'int'}
