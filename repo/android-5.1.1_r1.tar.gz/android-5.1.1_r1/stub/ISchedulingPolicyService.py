from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISchedulingPolicyService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.ISchedulingPolicyService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.ISchedulingPolicyService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_requestPriority"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("requestPriority", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'int'}
