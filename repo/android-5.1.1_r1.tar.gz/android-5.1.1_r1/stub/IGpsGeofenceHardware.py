from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGpsGeofenceHardware:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.IGpsGeofenceHardware"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.IGpsGeofenceHardware"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_isHardwareGeofenceSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isHardwareGeofenceSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_addCircularHardwareGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readDouble()
                _arg2 = data.readDouble()
                _arg3 = data.readDouble()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readInt()
                return self.callFunction("addCircularHardwareGeofence", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_result': 'boolean', '_arg2': 'double', '_arg3': 'double', '_arg0': 'int', '_arg1': 'double', '_arg6': 'int', '_arg7': 'int', '_arg4': 'int', '_arg5': 'int'}
            if mycase("TRANSACTION_removeHardwareGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("removeHardwareGeofence", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_pauseHardwareGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("pauseHardwareGeofence", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_resumeHardwareGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("resumeHardwareGeofence", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'int'}
