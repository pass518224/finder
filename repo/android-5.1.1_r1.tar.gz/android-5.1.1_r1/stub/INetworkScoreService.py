from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetworkScoreService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.INetworkScoreService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.INetworkScoreService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_updateScores"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.net.ScoredNetwork")
                return self.callFunction("updateScores", _arg0)
                # {'_arg0': 'android.net.ScoredNetwork', '_result': 'boolean'}
            if mycase("TRANSACTION_clearScores"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearScores")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setActiveScorer"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setActiveScorer", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_disableScoring"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disableScoring")
                # {}
            if mycase("TRANSACTION_registerNetworkScoreCache"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.net.INetworkScoreCache", data.readStrongBinder())
                return self.callFunction("registerNetworkScoreCache", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.net.INetworkScoreCache'}
