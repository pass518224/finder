from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVoiceInteractionSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.voice.IVoiceInteractionSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.voice.IVoiceInteractionSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_taskStarted"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("taskStarted", _arg0, _arg1)
                # {'_arg0': 'android.content.Intent', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_taskFinished"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("taskFinished", _arg0, _arg1)
                # {'_arg0': 'android.content.Intent', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_closeSystemDialogs"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("closeSystemDialogs")
                # {}
            if mycase("TRANSACTION_destroy"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("destroy")
                # {}
