from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICarrierMessagingCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.carrier.ICarrierMessagingCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.carrier.ICarrierMessagingCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onFilterComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onFilterComplete", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onSendSmsComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onSendSmsComplete", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onSendMultipartSmsComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createIntArray()
                return self.callFunction("onSendMultipartSmsComplete", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onSendMmsComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createByteArray()
                return self.callFunction("onSendMmsComplete", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'byte'}
            if mycase("TRANSACTION_onDownloadMmsComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onDownloadMmsComplete", _arg0)
                # {'_arg0': 'int'}
