from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMountService:
    pass
    ENCRYPTION_STATE_NONE = 1
    ENCRYPTION_STATE_OK = 0
class OnTransact(Stub):
    DESCRIPTOR = "IMountService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "IMountService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerListener"):
                data.enforceInterface(DESCRIPTOR)
                listener = self.interfaceResolver("IMountServiceListener", data.readStrongBinder())
                return self.callFunction("registerListener", listener)
                # {'listener': 'IMountServiceListener'}
            if mycase("TRANSACTION_unregisterListener"):
                data.enforceInterface(DESCRIPTOR)
                listener = self.interfaceResolver("IMountServiceListener", data.readStrongBinder())
                return self.callFunction("unregisterListener", listener)
                # {'listener': 'IMountServiceListener'}
            if mycase("TRANSACTION_isUsbMassStorageConnected"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isUsbMassStorageConnected")
                # {'result': 'boolean'}
            if mycase("TRANSACTION_setUsbMassStorageEnabled"):
                data.enforceInterface(DESCRIPTOR)
                enable = (0 != data.readInt())
                return self.callFunction("setUsbMassStorageEnabled", enable)
                # {'enable': 'boolean'}
            if mycase("TRANSACTION_isUsbMassStorageEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isUsbMassStorageEnabled")
                # {'result': 'boolean'}
            if mycase("TRANSACTION_mountVolume"):
                data.enforceInterface(DESCRIPTOR)
                mountPoint = data.readString()
                return self.callFunction("mountVolume", mountPoint)
                # {'mountPoint': 'String', 'resultCode': 'int'}
            if mycase("TRANSACTION_unmountVolume"):
                data.enforceInterface(DESCRIPTOR)
                mountPoint = data.readString()
                force = (0 != data.readInt())
                removeEncrypt = (0 != data.readInt())
                return self.callFunction("unmountVolume", mountPoint, force, removeEncrypt)
                # {'mountPoint': 'String', 'force': 'boolean', 'removeEncrypt': 'boolean'}
            if mycase("TRANSACTION_formatVolume"):
                data.enforceInterface(DESCRIPTOR)
                mountPoint = data.readString()
                return self.callFunction("formatVolume", mountPoint)
                # {'mountPoint': 'String', 'result': 'int'}
            if mycase("TRANSACTION_getStorageUsers"):
                data.enforceInterface(DESCRIPTOR)
                path = data.readString()
                return self.callFunction("getStorageUsers", path)
                # {'path': 'String', 'pids': 'int'}
            if mycase("TRANSACTION_getVolumeState"):
                data.enforceInterface(DESCRIPTOR)
                mountPoint = data.readString()
                return self.callFunction("getVolumeState", mountPoint)
                # {'mountPoint': 'String', 'state': 'String'}
            if mycase("TRANSACTION_createSecureContainer"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                sizeMb = data.readInt()
                fstype = data.readString()
                key = data.readString()
                ownerUid = data.readInt()
                external = (0 != data.readInt())
                return self.callFunction("createSecureContainer", id, sizeMb, fstype, key, ownerUid, external)
                # {'ownerUid': 'int', 'fstype': 'String', 'sizeMb': 'int', 'external': 'boolean', 'key': 'String', 'resultCode': 'int', 'id': 'String'}
            if mycase("TRANSACTION_finalizeSecureContainer"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                return self.callFunction("finalizeSecureContainer", id)
                # {'resultCode': 'int', 'id': 'String'}
            if mycase("TRANSACTION_destroySecureContainer"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                force = (0 != data.readInt())
                return self.callFunction("destroySecureContainer", id, force)
                # {'resultCode': 'int', 'force': 'boolean', 'id': 'String'}
            if mycase("TRANSACTION_mountSecureContainer"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                key = data.readString()
                ownerUid = data.readInt()
                readOnly = (data.readInt() != 0)
                return self.callFunction("mountSecureContainer", id, key, ownerUid, readOnly)
                # {'resultCode': 'int', 'ownerUid': 'int', 'readOnly': 'boolean', 'id': 'String', 'key': 'String'}
            if mycase("TRANSACTION_unmountSecureContainer"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                force = (0 != data.readInt())
                return self.callFunction("unmountSecureContainer", id, force)
                # {'resultCode': 'int', 'force': 'boolean', 'id': 'String'}
            if mycase("TRANSACTION_isSecureContainerMounted"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                return self.callFunction("isSecureContainerMounted", id)
                # {'status': 'boolean', 'id': 'String'}
            if mycase("TRANSACTION_renameSecureContainer"):
                data.enforceInterface(DESCRIPTOR)
                oldId = data.readString()
                newId = data.readString()
                return self.callFunction("renameSecureContainer", oldId, newId)
                # {'resultCode': 'int', 'newId': 'String', 'oldId': 'String'}
            if mycase("TRANSACTION_getSecureContainerPath"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                return self.callFunction("getSecureContainerPath", id)
                # {'path': 'String', 'id': 'String'}
            if mycase("TRANSACTION_getSecureContainerList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSecureContainerList")
                # {'ids': 'String'}
            if mycase("TRANSACTION_shutdown"):
                data.enforceInterface(DESCRIPTOR)
                observer = self.interfaceResolver("IMountShutdownObserver", data.readStrongBinder())
                return self.callFunction("shutdown", observer)
                # {'observer': 'IMountShutdownObserver'}
            if mycase("TRANSACTION_finishMediaUpdate"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("finishMediaUpdate")
                # {}
            if mycase("TRANSACTION_mountObb"):
                data.enforceInterface(DESCRIPTOR)
                rawPath = data.readString()
                canonicalPath = data.readString()
                key = data.readString()
                observer = self.interfaceResolver("IObbActionListener", data.readStrongBinder())
                nonce = data.readInt()
                return self.callFunction("mountObb", rawPath, canonicalPath, key, observer, nonce)
                # {'rawPath': 'String', 'nonce': 'int', 'observer': 'IObbActionListener', 'key': 'String', 'canonicalPath': 'String'}
            if mycase("TRANSACTION_unmountObb"):
                data.enforceInterface(DESCRIPTOR)
                filename = data.readString()
                force = (0 != data.readInt())
                observer = self.interfaceResolver("IObbActionListener", data.readStrongBinder())
                nonce = data.readInt()
                return self.callFunction("unmountObb", filename, force, observer, nonce)
                # {'nonce': 'int', 'force': 'boolean', 'observer': 'IObbActionListener', 'filename': 'String'}
            if mycase("TRANSACTION_isObbMounted"):
                data.enforceInterface(DESCRIPTOR)
                filename = data.readString()
                return self.callFunction("isObbMounted", filename)
                # {'status': 'boolean', 'filename': 'String'}
            if mycase("TRANSACTION_getMountedObbPath"):
                data.enforceInterface(DESCRIPTOR)
                filename = data.readString()
                return self.callFunction("getMountedObbPath", filename)
                # {'mountedPath': 'String', 'filename': 'String'}
            if mycase("TRANSACTION_isExternalStorageEmulated"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isExternalStorageEmulated")
                # {'emulated': 'boolean'}
            if mycase("TRANSACTION_decryptStorage"):
                data.enforceInterface(DESCRIPTOR)
                password = data.readString()
                return self.callFunction("decryptStorage", password)
                # {'password': 'String', 'result': 'int'}
            if mycase("TRANSACTION_encryptStorage"):
                data.enforceInterface(DESCRIPTOR)
                type = data.readInt()
                password = data.readString()
                return self.callFunction("encryptStorage", type, password)
                # {'password': 'String', 'type': 'int', 'result': 'int'}
            if mycase("TRANSACTION_changeEncryptionPassword"):
                data.enforceInterface(DESCRIPTOR)
                type = data.readInt()
                password = data.readString()
                return self.callFunction("changeEncryptionPassword", type, password)
                # {'password': 'String', 'type': 'int', 'result': 'int'}
            if mycase("TRANSACTION_getVolumeList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVolumeList")
                # {'result': 'StorageVolume'}
            if mycase("TRANSACTION_getSecureContainerFilesystemPath"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                return self.callFunction("getSecureContainerFilesystemPath", id)
                # {'path': 'String', 'id': 'String'}
            if mycase("TRANSACTION_getEncryptionState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getEncryptionState")
                # {'result': 'int'}
            if mycase("TRANSACTION_fixPermissionsSecureContainer"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                gid = data.readInt()
                filename = data.readString()
                return self.callFunction("fixPermissionsSecureContainer", id, gid, filename)
                # {'resultCode': 'int', 'gid': 'int', 'id': 'String', 'filename': 'String'}
            if mycase("TRANSACTION_mkdirs"):
                data.enforceInterface(DESCRIPTOR)
                callingPkg = data.readString()
                path = data.readString()
                return self.callFunction("mkdirs", callingPkg, path)
                # {'path': 'String', 'callingPkg': 'String', 'result': 'int'}
            if mycase("TRANSACTION_getPasswordType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPasswordType")
                # {'result': 'int'}
            if mycase("TRANSACTION_getPassword"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPassword")
                # {'result': 'String'}
            if mycase("TRANSACTION_clearPassword"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearPassword")
                # {}
            if mycase("TRANSACTION_setField"):
                data.enforceInterface(DESCRIPTOR)
                field = data.readString()
                contents = data.readString()
                return self.callFunction("setField", field, contents)
                # {'field': 'String', 'contents': 'String'}
            if mycase("TRANSACTION_getField"):
                data.enforceInterface(DESCRIPTOR)
                field = data.readString()
                return self.callFunction("getField", field)
                # {'field': 'String', 'contents': 'String'}
            if mycase("TRANSACTION_resizeSecureContainer"):
                data.enforceInterface(DESCRIPTOR)
                id = data.readString()
                sizeMb = data.readInt()
                key = data.readString()
                return self.callFunction("resizeSecureContainer", id, sizeMb, key)
                # {'sizeMb': 'int', 'resultCode': 'int', 'id': 'String', 'key': 'String'}
            if mycase("TRANSACTION_lastMaintenance"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("lastMaintenance")
                # {'lastMaintenance': 'long'}
            if mycase("TRANSACTION_runMaintenance"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("runMaintenance")
                # {}
    ENCRYPTION_STATE_NONE = 1
    ENCRYPTION_STATE_OK = 0
