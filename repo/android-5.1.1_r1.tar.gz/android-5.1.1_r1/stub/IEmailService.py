from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IEmailService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.emailcommon.service.IEmailService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.emailcommon.service.IEmailService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_loadAttachment"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.emailcommon.service.IEmailServiceCallback", data.readStrongBinder())
                _arg1 = data.readLong()
                _arg2 = data.readLong()
                _arg3 = (0 != data.readInt())
                return self.callFunction("loadAttachment", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'long', '_arg3': 'boolean', '_arg0': 'com.android.emailcommon.service.IEmailServiceCallback', '_arg1': 'long'}
            if mycase("TRANSACTION_updateFolderList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("updateFolderList", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_sendMail"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("sendMail", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_sync"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("sync", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'long', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_pushModify"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("pushModify", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_validate"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("com.android.emailcommon.service.HostAuthCompat", data)
                else:
                    _arg0 = None
                return self.callFunction("validate", _arg0)
                # {'_arg0': 'com.android.emailcommon.service.HostAuthCompat', '_result': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_searchMessages"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.emailcommon.service.SearchParams", data)
                else:
                    _arg1 = None
                _arg2 = data.readLong()
                return self.callFunction("searchMessages", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'long', '_arg0': 'long', '_arg1': 'com.android.emailcommon.service.SearchParams', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendMeetingResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readInt()
                return self.callFunction("sendMeetingResponse", _arg0, _arg1)
                # {'_arg0': 'long', '_arg1': 'int'}
            if mycase("TRANSACTION_autoDiscover"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("autoDiscover", _arg0, _arg1)
                # {'_result': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setLogging"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setLogging", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_deleteExternalAccountPIMData"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("deleteExternalAccountPIMData", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_getApiVersion"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getApiVersion")
                # {'_result': 'int'}
