from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IApplicationToken:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IApplicationToken"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IApplicationToken"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_windowsDrawn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("windowsDrawn")
                # {}
            if mycase("TRANSACTION_windowsVisible"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("windowsVisible")
                # {}
            if mycase("TRANSACTION_windowsGone"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("windowsGone")
                # {}
            if mycase("TRANSACTION_keyDispatchingTimedOut"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("keyDispatchingTimedOut", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_getKeyDispatchingTimeout"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getKeyDispatchingTimeout")
                # {'_result': 'long'}
