from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRemoteViewsFactory:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.widget.IRemoteViewsFactory"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.widget.IRemoteViewsFactory"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onDataSetChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDataSetChanged")
                # {}
            if mycase("TRANSACTION_onDataSetChangedAsync"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDataSetChangedAsync")
                # {}
            if mycase("TRANSACTION_onDestroy"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                return self.callFunction("onDestroy", _arg0)
                # {'_arg0': 'android.content.Intent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCount"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCount")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getViewAt"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getViewAt", _arg0)
                # {'_arg0': 'int', '_result': 'android.widget.RemoteViews'}
            if mycase("TRANSACTION_getLoadingView"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLoadingView")
                # {'_result': 'android.widget.RemoteViews'}
            if mycase("TRANSACTION_getViewTypeCount"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getViewTypeCount")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getItemId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getItemId", _arg0)
                # {'_arg0': 'int', '_result': 'long'}
            if mycase("TRANSACTION_hasStableIds"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasStableIds")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isCreated"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isCreated")
                # {'_result': 'boolean'}
