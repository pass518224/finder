from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPolicyService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.emailcommon.service.IPolicyService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.emailcommon.service.IPolicyService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_isActive"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("com.android.emailcommon.provider.Policy", data)
                else:
                    _arg0 = None
                return self.callFunction("isActive", _arg0)
                # {'_arg0': 'com.android.emailcommon.provider.Policy', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAccountHoldFlag"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setAccountHoldFlag", _arg0, _arg1)
                # {'_arg0': 'long', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setAccountPolicy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.emailcommon.provider.Policy", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                return self.callFunction("setAccountPolicy", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'long', '_arg1': 'com.android.emailcommon.provider.Policy', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAccountPolicy2"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.emailcommon.provider.Policy", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                _arg3 = (0 != data.readInt())
                return self.callFunction("setAccountPolicy2", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'boolean', '_arg0': 'long', '_arg1': 'com.android.emailcommon.provider.Policy', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_remoteWipe"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("remoteWipe")
                # {}
            if mycase("TRANSACTION_canDisableCamera"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("canDisableCamera")
                # {'_result': 'boolean'}
