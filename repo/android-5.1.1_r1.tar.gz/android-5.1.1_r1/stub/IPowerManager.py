from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPowerManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.IPowerManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.IPowerManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_acquireWakeLock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readString()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg4 = None
                _arg5 = data.readString()
                return self.callFunction("acquireWakeLock", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.os.IBinder', '_arg1': 'int', '_arg4': 'android.os.WorkSource', '_arg5': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_acquireWakeLockWithUid"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                return self.callFunction("acquireWakeLockWithUid", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.os.IBinder', '_arg1': 'int', '_arg4': 'int'}
            if mycase("TRANSACTION_releaseWakeLock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("releaseWakeLock", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_updateWakeLockUids"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.createIntArray()
                return self.callFunction("updateWakeLockUids", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_powerHint"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("powerHint", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_updateWakeLockWorkSource"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                return self.callFunction("updateWakeLockWorkSource", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.os.IBinder', '_arg1': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isWakeLockLevelSupported"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isWakeLockLevelSupported", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_userActivity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("userActivity", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'long', '_arg1': 'int'}
            if mycase("TRANSACTION_wakeUp"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("wakeUp", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_goToSleep"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("goToSleep", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'long', '_arg1': 'int'}
            if mycase("TRANSACTION_nap"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("nap", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_isInteractive"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isInteractive")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isPowerSaveMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isPowerSaveMode")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setPowerSaveMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setPowerSaveMode", _arg0)
                # {'_arg0': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_reboot"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("reboot", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'boolean', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_shutdown"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("shutdown", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_crash"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("crash", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setStayOnSetting"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setStayOnSetting", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_boostScreenBrightness"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("boostScreenBrightness", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_setTemporaryScreenBrightnessSettingOverride"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setTemporaryScreenBrightnessSettingOverride", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setTemporaryScreenAutoBrightnessAdjustmentSettingOverride"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readFloat()
                return self.callFunction("setTemporaryScreenAutoBrightnessAdjustmentSettingOverride", _arg0)
                # {'_arg0': 'float'}
            if mycase("TRANSACTION_setAttentionLight"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("setAttentionLight", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
