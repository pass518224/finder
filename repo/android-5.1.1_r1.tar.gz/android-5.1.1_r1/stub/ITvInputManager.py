from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITvInputManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.tv.ITvInputManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.tv.ITvInputManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getTvInputList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getTvInputList", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.media.tv.TvInputInfo>'}
            if mycase("TRANSACTION_getTvInputInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getTvInputInfo", _arg0, _arg1)
                # {'_result': 'android.media.tv.TvInputInfo', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getTvInputState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getTvInputState", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getTvContentRatingSystemList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getTvContentRatingSystemList", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.media.tv.TvContentRatingSystemInfo>'}
            if mycase("TRANSACTION_registerCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.tv.ITvInputManagerCallback", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("registerCallback", _arg0, _arg1)
                # {'_arg0': 'android.media.tv.ITvInputManagerCallback', '_arg1': 'int'}
            if mycase("TRANSACTION_unregisterCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.tv.ITvInputManagerCallback", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("unregisterCallback", _arg0, _arg1)
                # {'_arg0': 'android.media.tv.ITvInputManagerCallback', '_arg1': 'int'}
            if mycase("TRANSACTION_isParentalControlsEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isParentalControlsEnabled", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setParentalControlsEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("setParentalControlsEnabled", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
            if mycase("TRANSACTION_isRatingBlocked"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("isRatingBlocked", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getBlockedRatings"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getBlockedRatings", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<java.lang.String>'}
            if mycase("TRANSACTION_addBlockedRating"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("addBlockedRating", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_removeBlockedRating"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("removeBlockedRating", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_createSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.tv.ITvInputClient", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("createSession", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.media.tv.ITvInputClient', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_releaseSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("releaseSession", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_setMainSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("setMainSession", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_setSurface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("setSurface", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'android.view.Surface', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dispatchSurfaceChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                return self.callFunction("dispatchSurfaceChanged", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'int', '_arg4': 'int'}
            if mycase("TRANSACTION_setVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readFloat()
                _arg2 = data.readInt()
                return self.callFunction("setVolume", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'float'}
            if mycase("TRANSACTION_tune"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("tune", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.os.Bundle', '_arg3': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'android.net.Uri', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setCaptionEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                return self.callFunction("setCaptionEnabled", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'boolean'}
            if mycase("TRANSACTION_selectTrack"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                return self.callFunction("selectTrack", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_sendAppPrivateCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("sendAppPrivateCommand", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.os.Bundle', '_arg3': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createOverlayView"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("createOverlayView", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.graphics.Rect', '_arg3': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'android.os.IBinder', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_relayoutOverlayView"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("relayoutOverlayView", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeOverlayView"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("removeOverlayView", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_requestUnblockContent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("requestUnblockContent", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getHardwareList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getHardwareList")
                # {'_result': 'java.util.List<android.media.tv.TvInputHardwareInfo>'}
            if mycase("TRANSACTION_acquireTvInputHardware"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.media.tv.ITvInputHardwareCallback", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.media.tv.TvInputInfo", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("acquireTvInputHardware", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'android.media.tv.ITvInputHardware', '_arg2': 'android.media.tv.TvInputInfo', '_arg3': 'int', '_arg0': 'int', '_arg1': 'android.media.tv.ITvInputHardwareCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_releaseTvInputHardware"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.media.tv.ITvInputHardware", data.readStrongBinder())
                _arg2 = data.readInt()
                return self.callFunction("releaseTvInputHardware", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'android.media.tv.ITvInputHardware'}
            if mycase("TRANSACTION_getAvailableTvStreamConfigList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getAvailableTvStreamConfigList", _arg0, _arg1)
                # {'_result': 'java.util.List<android.media.tv.TvStreamConfig>', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_captureFrame"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.media.tv.TvStreamConfig", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("captureFrame", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'android.media.tv.TvStreamConfig', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.view.Surface', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isSingleSessionActive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isSingleSessionActive", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
