from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRecognitionService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.speech.IRecognitionService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.speech.IRecognitionService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_startListening"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.speech.IRecognitionListener", data.readStrongBinder())
                return self.callFunction("startListening", _arg0, _arg1)
                # {'_arg0': 'android.content.Intent', '_arg1': 'android.speech.IRecognitionListener', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopListening"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.speech.IRecognitionListener", data.readStrongBinder())
                return self.callFunction("stopListening", _arg0)
                # {'_arg0': 'android.speech.IRecognitionListener'}
            if mycase("TRANSACTION_cancel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.speech.IRecognitionListener", data.readStrongBinder())
                return self.callFunction("cancel", _arg0)
                # {'_arg0': 'android.speech.IRecognitionListener'}
