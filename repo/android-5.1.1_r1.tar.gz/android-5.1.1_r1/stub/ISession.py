from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.session.ISession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.session.ISession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sendEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("sendEvent", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getController"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getController")
                # {'_result': 'android.media.session.ISessionController'}
            if mycase("TRANSACTION_setFlags"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setFlags", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setActive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setActive", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setMediaButtonReceiver"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg0 = None
                return self.callFunction("setMediaButtonReceiver", _arg0)
                # {'_arg0': 'android.app.PendingIntent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setLaunchPendingIntent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg0 = None
                return self.callFunction("setLaunchPendingIntent", _arg0)
                # {'_arg0': 'android.app.PendingIntent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_destroy"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("destroy")
                # {}
            if mycase("TRANSACTION_setMetadata"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.MediaMetadata", data)
                else:
                    _arg0 = None
                return self.callFunction("setMetadata", _arg0)
                # {'_arg0': 'android.media.MediaMetadata', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPlaybackState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.session.PlaybackState", data)
                else:
                    _arg0 = None
                return self.callFunction("setPlaybackState", _arg0)
                # {'_arg0': 'android.media.session.PlaybackState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setQueue"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.ParceledListSlice", data)
                else:
                    _arg0 = None
                return self.callFunction("setQueue", _arg0)
                # {'_arg0': 'android.content.pm.ParceledListSlice', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setQueueTitle"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                return self.callFunction("setQueueTitle", _arg0)
                # {'_arg0': 'java.lang.CharSequence', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setExtras"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("setExtras", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setRatingType"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setRatingType", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setPlaybackToLocal"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.AudioAttributes", data)
                else:
                    _arg0 = None
                return self.callFunction("setPlaybackToLocal", _arg0)
                # {'_arg0': 'android.media.AudioAttributes', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPlaybackToRemote"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setPlaybackToRemote", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setCurrentVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setCurrentVolume", _arg0)
                # {'_arg0': 'int'}
