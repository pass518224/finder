from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaContainerService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.app.IMediaContainerService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.app.IMediaContainerService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_copyPackageToContainer"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = (0 != data.readInt())
                _arg4 = (0 != data.readInt())
                _arg5 = data.readString()
                return self.callFunction("copyPackageToContainer", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'java.lang.String', '_arg2': 'java.lang.String', '_arg3': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg4': 'boolean', '_arg5': 'java.lang.String'}
            if mycase("TRANSACTION_copyPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.os.IParcelFileDescriptorFactory", data.readStrongBinder())
                return self.callFunction("copyPackage", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'com.android.internal.os.IParcelFileDescriptorFactory'}
            if mycase("TRANSACTION_getMinimalPackageInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("getMinimalPackageInfo", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'android.content.pm.PackageInfoLite'}
            if mycase("TRANSACTION_getObbInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getObbInfo", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.content.res.ObbInfo'}
            if mycase("TRANSACTION_calculateDirectorySize"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("calculateDirectorySize", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'long'}
            if mycase("TRANSACTION_getFileSystemStats"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getFileSystemStats", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'long'}
            if mycase("TRANSACTION_clearDirectory"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("clearDirectory", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_calculateInstalledSize"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readString()
                return self.callFunction("calculateInstalledSize", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'boolean', '_result': 'long'}
