from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IUsbManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.usb.IUsbManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.usb.IUsbManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getDeviceList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.newInstance("android.os.Bundle", )
                return self.callFunction("getDeviceList", _arg0)
                # {'_arg0': 'android.os.Bundle'}
            if mycase("TRANSACTION_openDevice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("openDevice", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.os.ParcelFileDescriptor'}
            if mycase("TRANSACTION_getCurrentAccessory"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentAccessory")
                # {'_result': 'android.hardware.usb.UsbAccessory'}
            if mycase("TRANSACTION_openAccessory"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbAccessory", data)
                else:
                    _arg0 = None
                return self.callFunction("openAccessory", _arg0)
                # {'_arg0': 'android.hardware.usb.UsbAccessory', '_result': 'android.os.ParcelFileDescriptor', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setDevicePackage"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("setDevicePackage", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.hardware.usb.UsbDevice', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAccessoryPackage"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbAccessory", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("setAccessoryPackage", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.hardware.usb.UsbAccessory', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hasDevicePermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("hasDevicePermission", _arg0)
                # {'_arg0': 'android.hardware.usb.UsbDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hasAccessoryPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbAccessory", data)
                else:
                    _arg0 = None
                return self.callFunction("hasAccessoryPermission", _arg0)
                # {'_arg0': 'android.hardware.usb.UsbAccessory', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_requestDevicePermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg2 = None
                return self.callFunction("requestDevicePermission", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.app.PendingIntent', '_arg0': 'android.hardware.usb.UsbDevice', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_requestAccessoryPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbAccessory", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg2 = None
                return self.callFunction("requestAccessoryPermission", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.app.PendingIntent', '_arg0': 'android.hardware.usb.UsbAccessory', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_grantDevicePermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("grantDevicePermission", _arg0, _arg1)
                # {'_arg0': 'android.hardware.usb.UsbDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_grantAccessoryPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.usb.UsbAccessory", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("grantAccessoryPermission", _arg0, _arg1)
                # {'_arg0': 'android.hardware.usb.UsbAccessory', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hasDefaults"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("hasDefaults", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_clearDefaults"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("clearDefaults", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setCurrentFunction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setCurrentFunction", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setMassStorageBackingFile"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setMassStorageBackingFile", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_allowUsbDebugging"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readString()
                return self.callFunction("allowUsbDebugging", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_denyUsbDebugging"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("denyUsbDebugging")
                # {}
            if mycase("TRANSACTION_clearUsbDebuggingKeys"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearUsbDebuggingKeys")
                # {}
