from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothHeadsetClient:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothHeadsetClient"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothHeadsetClient"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("connect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("disconnect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_acceptIncomingConnect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("acceptIncomingConnect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_rejectIncomingConnect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("rejectIncomingConnect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getConnectedDevices"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConnectedDevices")
                # {'_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_getDevicesMatchingConnectionStates"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createIntArray()
                return self.callFunction("getDevicesMatchingConnectionStates", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_getConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getConnectionState", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPriority"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setPriority", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPriority"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getPriority", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startVoiceRecognition"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("startVoiceRecognition", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopVoiceRecognition"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("stopVoiceRecognition", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCurrentCalls"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getCurrentCalls", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'java.util.List<android.bluetooth.BluetoothHeadsetClientCall>', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCurrentAgEvents"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getCurrentAgEvents", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_acceptCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("acceptCall", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_holdCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("holdCall", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_rejectCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("rejectCall", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_terminateCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("terminateCall", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_enterPrivateMode"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("enterPrivateMode", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_explicitCallTransfer"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("explicitCallTransfer", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_redial"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("redial", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dial"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("dial", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dialMemory"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("dialMemory", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendDTMF"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readByte()
                return self.callFunction("sendDTMF", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'byte', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getLastVoiceTagNumber"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getLastVoiceTagNumber", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAudioState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getAudioState", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_connectAudio"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("connectAudio")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_disconnectAudio"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnectAudio")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getCurrentAgFeatures"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getCurrentAgFeatures", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
