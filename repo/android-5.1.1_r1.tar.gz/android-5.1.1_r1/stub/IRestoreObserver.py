from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRestoreObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.backup.IRestoreObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.backup.IRestoreObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_restoreSetsAvailable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.app.backup.RestoreSet")
                return self.callFunction("restoreSetsAvailable", _arg0)
                # {'_arg0': 'android.app.backup.RestoreSet'}
            if mycase("TRANSACTION_restoreStarting"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("restoreStarting", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onUpdate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("onUpdate", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_restoreFinished"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("restoreFinished", _arg0)
                # {'_arg0': 'int'}
