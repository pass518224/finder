from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAppWidgetHost:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.appwidget.IAppWidgetHost"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.appwidget.IAppWidgetHost"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_updateAppWidget"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.widget.RemoteViews", data)
                else:
                    _arg1 = None
                return self.callFunction("updateAppWidget", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.widget.RemoteViews', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_providerChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.appwidget.AppWidgetProviderInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("providerChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.appwidget.AppWidgetProviderInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_providersChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("providersChanged")
                # {}
            if mycase("TRANSACTION_viewDataChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("viewDataChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
