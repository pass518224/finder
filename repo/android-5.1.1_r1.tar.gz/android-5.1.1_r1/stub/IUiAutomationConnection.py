from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IUiAutomationConnection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IUiAutomationConnection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IUiAutomationConnection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accessibilityservice.IAccessibilityServiceClient", data.readStrongBinder())
                return self.callFunction("connect", _arg0)
                # {'_arg0': 'android.accessibilityservice.IAccessibilityServiceClient'}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnect")
                # {}
            if mycase("TRANSACTION_injectInputEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.InputEvent", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("injectInputEvent", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.view.InputEvent', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setRotation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setRotation", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_takeScreenshot"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("takeScreenshot", _arg0, _arg1)
                # {'_result': 'android.graphics.Bitmap', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_shutdown"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("shutdown")
                # {}
            if mycase("TRANSACTION_clearWindowContentFrameStats"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("clearWindowContentFrameStats", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getWindowContentFrameStats"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getWindowContentFrameStats", _arg0)
                # {'_arg0': 'int', '_result': 'android.view.WindowContentFrameStats'}
            if mycase("TRANSACTION_clearWindowAnimationFrameStats"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearWindowAnimationFrameStats")
                # {}
            if mycase("TRANSACTION_getWindowAnimationFrameStats"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWindowAnimationFrameStats")
                # {'_result': 'android.view.WindowAnimationFrameStats'}
            if mycase("TRANSACTION_executeShellCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg1 = None
                return self.callFunction("executeShellCommand", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.ParcelFileDescriptor', 'ELSE:': {}, 'IF': {}}
