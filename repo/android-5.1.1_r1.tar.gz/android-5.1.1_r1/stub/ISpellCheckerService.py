from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISpellCheckerService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.textservice.ISpellCheckerService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.textservice.ISpellCheckerService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getISpellCheckerSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.textservice.ISpellCheckerSessionListener", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("getISpellCheckerSession", _arg0, _arg1, _arg2)
                # {'_result': 'com.android.internal.textservice.ISpellCheckerSession', '_arg2': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'com.android.internal.textservice.ISpellCheckerSessionListener', 'ELSE:': {}, 'IF': {}}
