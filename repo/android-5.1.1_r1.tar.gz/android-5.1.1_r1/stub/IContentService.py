from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IContentService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.IContentService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.IContentService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_unregisterContentObserver"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.database.IContentObserver", data.readStrongBinder())
                return self.callFunction("unregisterContentObserver", _arg0)
                # {'_arg0': 'android.database.IContentObserver'}
            if mycase("TRANSACTION_registerContentObserver"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = self.interfaceResolver("android.database.IContentObserver", data.readStrongBinder())
                _arg3 = data.readInt()
                return self.callFunction("registerContentObserver", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.database.IContentObserver', '_arg3': 'int', '_arg0': 'android.net.Uri', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyChange"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.database.IContentObserver", data.readStrongBinder())
                _arg2 = (0 != data.readInt())
                _arg3 = (0 != data.readInt())
                _arg4 = data.readInt()
                return self.callFunction("notifyChange", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'boolean', '_arg3': 'boolean', '_arg0': 'android.net.Uri', '_arg1': 'android.database.IContentObserver', '_arg4': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_requestSync"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("requestSync", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sync"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.SyncRequest", data)
                else:
                    _arg0 = None
                return self.callFunction("sync", _arg0)
                # {'_arg0': 'android.content.SyncRequest', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_syncAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.SyncRequest", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("syncAsUser", _arg0, _arg1)
                # {'_arg0': 'android.content.SyncRequest', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_cancelSync"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                return self.callFunction("cancelSync", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.content.ComponentName', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_cancelSyncAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("cancelSyncAsUser", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.content.ComponentName', '_arg3': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_cancelRequest"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.SyncRequest", data)
                else:
                    _arg0 = None
                return self.callFunction("cancelRequest", _arg0)
                # {'_arg0': 'android.content.SyncRequest', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getSyncAutomatically"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("getSyncAutomatically", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getSyncAutomaticallyAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("getSyncAutomaticallyAsUser", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setSyncAutomatically"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setSyncAutomatically", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setSyncAutomaticallyAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                _arg3 = data.readInt()
                return self.callFunction("setSyncAutomaticallyAsUser", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'boolean', '_arg3': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPeriodicSyncs"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                return self.callFunction("getPeriodicSyncs", _arg0, _arg1, _arg2)
                # {'_result': 'java.util.List<android.content.PeriodicSync>', '_arg2': 'android.content.ComponentName', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addPeriodicSync"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                _arg3 = data.readLong()
                return self.callFunction("addPeriodicSync", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.os.Bundle', '_arg3': 'long', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removePeriodicSync"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("removePeriodicSync", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getIsSyncable"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("getIsSyncable", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getIsSyncableAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("getIsSyncableAsUser", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setIsSyncable"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("setIsSyncable", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setMasterSyncAutomatically"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setMasterSyncAutomatically", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setMasterSyncAutomaticallyAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("setMasterSyncAutomaticallyAsUser", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
            if mycase("TRANSACTION_getMasterSyncAutomatically"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMasterSyncAutomatically")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getMasterSyncAutomaticallyAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getMasterSyncAutomaticallyAsUser", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getCurrentSyncs"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentSyncs")
                # {'_result': 'java.util.List<android.content.SyncInfo>'}
            if mycase("TRANSACTION_getCurrentSyncsAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCurrentSyncsAsUser", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.content.SyncInfo>'}
            if mycase("TRANSACTION_getSyncAdapterTypes"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSyncAdapterTypes")
                # {'_result': 'android.content.SyncAdapterType'}
            if mycase("TRANSACTION_getSyncAdapterTypesAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getSyncAdapterTypesAsUser", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.SyncAdapterType'}
            if mycase("TRANSACTION_isSyncActive"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                return self.callFunction("isSyncActive", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.content.ComponentName', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getSyncStatus"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                return self.callFunction("getSyncStatus", _arg0, _arg1, _arg2)
                # {'_result': 'android.content.SyncStatusInfo', '_arg2': 'android.content.ComponentName', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getSyncStatusAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("getSyncStatusAsUser", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'android.content.SyncStatusInfo', '_arg2': 'android.content.ComponentName', '_arg3': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isSyncPending"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                return self.callFunction("isSyncPending", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.content.ComponentName', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isSyncPendingAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accounts.Account", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("isSyncPendingAsUser", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'android.content.ComponentName', '_arg3': 'int', '_arg0': 'android.accounts.Account', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addStatusChangeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.content.ISyncStatusObserver", data.readStrongBinder())
                return self.callFunction("addStatusChangeListener", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.content.ISyncStatusObserver'}
            if mycase("TRANSACTION_removeStatusChangeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.ISyncStatusObserver", data.readStrongBinder())
                return self.callFunction("removeStatusChangeListener", _arg0)
                # {'_arg0': 'android.content.ISyncStatusObserver'}
