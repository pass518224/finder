from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaBrowserServiceCallbacks:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.media.IMediaBrowserServiceCallbacks"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.media.IMediaBrowserServiceCallbacks"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onConnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.media.session.MediaSession.Token", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("onConnect", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'android.media.session.MediaSession.Token', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onConnectFailed"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onConnectFailed")
                # {}
            if mycase("TRANSACTION_onLoadChildren"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.pm.ParceledListSlice", data)
                else:
                    _arg1 = None
                return self.callFunction("onLoadChildren", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.content.pm.ParceledListSlice', 'ELSE:': {}, 'IF': {}}
