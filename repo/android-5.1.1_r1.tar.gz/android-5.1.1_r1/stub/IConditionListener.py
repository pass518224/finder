from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IConditionListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.notification.IConditionListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.notification.IConditionListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onConditionsReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.service.notification.Condition")
                return self.callFunction("onConditionsReceived", _arg0)
                # {'_arg0': 'android.service.notification.Condition'}
