from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IDropBoxManagerService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.os.IDropBoxManagerService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.os.IDropBoxManagerService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_add"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.DropBoxManager.Entry", data)
                else:
                    _arg0 = None
                return self.callFunction("add", _arg0)
                # {'_arg0': 'android.os.DropBoxManager.Entry', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isTagEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isTagEnabled", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_getNextEntry"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readLong()
                return self.callFunction("getNextEntry", _arg0, _arg1)
                # {'_result': 'android.os.DropBoxManager.Entry', '_arg0': 'java.lang.String', '_arg1': 'long'}
