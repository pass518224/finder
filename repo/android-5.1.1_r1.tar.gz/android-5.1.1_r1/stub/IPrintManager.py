from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrintManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IPrintManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IPrintManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getPrintJobInfos"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("getPrintJobInfos", _arg0, _arg1)
                # {'_result': 'java.util.List<android.print.PrintJobInfo>', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getPrintJobInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("getPrintJobInfo", _arg0, _arg1, _arg2)
                # {'_result': 'android.print.PrintJobInfo', '_arg2': 'int', '_arg0': 'android.print.PrintJobId', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_print"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.print.IPrintDocumentAdapter", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.print.PrintAttributes", data)
                else:
                    _arg2 = None
                _arg3 = data.readString()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                return self.callFunction("print", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'android.os.Bundle', '_arg2': 'android.print.PrintAttributes', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'android.print.IPrintDocumentAdapter', '_arg4': 'int', '_arg5': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_cancelPrintJob"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("cancelPrintJob", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.print.PrintJobId', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_restartPrintJob"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("restartPrintJob", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.print.PrintJobId', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addPrintJobStateChangeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrintJobStateChangeListener", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("addPrintJobStateChangeListener", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.print.IPrintJobStateChangeListener', '_arg1': 'int'}
            if mycase("TRANSACTION_removePrintJobStateChangeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrintJobStateChangeListener", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("removePrintJobStateChangeListener", _arg0, _arg1)
                # {'_arg0': 'android.print.IPrintJobStateChangeListener', '_arg1': 'int'}
            if mycase("TRANSACTION_getInstalledPrintServices"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getInstalledPrintServices", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.printservice.PrintServiceInfo>'}
            if mycase("TRANSACTION_getEnabledPrintServices"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getEnabledPrintServices", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.printservice.PrintServiceInfo>'}
            if mycase("TRANSACTION_createPrinterDiscoverySession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrinterDiscoveryObserver", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("createPrinterDiscoverySession", _arg0, _arg1)
                # {'_arg0': 'android.print.IPrinterDiscoveryObserver', '_arg1': 'int'}
            if mycase("TRANSACTION_startPrinterDiscovery"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrinterDiscoveryObserver", data.readStrongBinder())
                _arg1 = data.createTypedArrayList("android.print.PrinterId")
                _arg2 = data.readInt()
                return self.callFunction("startPrinterDiscovery", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.print.IPrinterDiscoveryObserver', '_arg1': 'java.util.List<android.print.PrinterId>'}
            if mycase("TRANSACTION_stopPrinterDiscovery"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrinterDiscoveryObserver", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("stopPrinterDiscovery", _arg0, _arg1)
                # {'_arg0': 'android.print.IPrinterDiscoveryObserver', '_arg1': 'int'}
            if mycase("TRANSACTION_validatePrinters"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.print.PrinterId")
                _arg1 = data.readInt()
                return self.callFunction("validatePrinters", _arg0, _arg1)
                # {'_arg0': 'java.util.List<android.print.PrinterId>', '_arg1': 'int'}
            if mycase("TRANSACTION_startPrinterStateTracking"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrinterId", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("startPrinterStateTracking", _arg0, _arg1)
                # {'_arg0': 'android.print.PrinterId', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopPrinterStateTracking"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrinterId", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("stopPrinterStateTracking", _arg0, _arg1)
                # {'_arg0': 'android.print.PrinterId', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_destroyPrinterDiscoverySession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrinterDiscoveryObserver", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("destroyPrinterDiscoverySession", _arg0, _arg1)
                # {'_arg0': 'android.print.IPrinterDiscoveryObserver', '_arg1': 'int'}
