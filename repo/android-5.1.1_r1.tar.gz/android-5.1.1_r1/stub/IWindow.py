from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWindow:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IWindow"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IWindow"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_executeCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg2 = None
                return self.callFunction("executeCommand", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.ParcelFileDescriptor', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_resized"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg3 = None
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg4 = None
                _arg5 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.content.res.Configuration", data)
                else:
                    _arg6 = None
                return self.callFunction("resized", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'android.graphics.Rect', '_arg3': 'android.graphics.Rect', '_arg0': 'android.graphics.Rect', '_arg1': 'android.graphics.Rect', '_arg6': 'android.content.res.Configuration', '_arg4': 'android.graphics.Rect', '_arg5': 'boolean', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_moved"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("moved", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_dispatchAppVisibility"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("dispatchAppVisibility", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_dispatchGetNewSurface"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dispatchGetNewSurface")
                # {}
            if mycase("TRANSACTION_windowFocusChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("windowFocusChanged", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_closeSystemDialogs"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("closeSystemDialogs", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_dispatchWallpaperOffsets"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readFloat()
                _arg1 = data.readFloat()
                _arg2 = data.readFloat()
                _arg3 = data.readFloat()
                _arg4 = (0 != data.readInt())
                return self.callFunction("dispatchWallpaperOffsets", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'float', '_arg3': 'float', '_arg0': 'float', '_arg1': 'float', '_arg4': 'boolean'}
            if mycase("TRANSACTION_dispatchWallpaperCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg4 = None
                _arg5 = (0 != data.readInt())
                return self.callFunction("dispatchWallpaperCommand", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg4': 'android.os.Bundle', '_arg5': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dispatchDragEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.DragEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("dispatchDragEvent", _arg0)
                # {'_arg0': 'android.view.DragEvent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dispatchSystemUiVisibilityChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("dispatchSystemUiVisibilityChanged", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_doneAnimating"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("doneAnimating")
                # {}
            if mycase("TRANSACTION_dispatchWindowShown"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dispatchWindowShown")
                # {}
