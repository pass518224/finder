from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IFullBackupRestoreObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.backup.IFullBackupRestoreObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.backup.IFullBackupRestoreObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onStartBackup"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onStartBackup")
                # {}
            if mycase("TRANSACTION_onBackupPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("onBackupPackage", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onEndBackup"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onEndBackup")
                # {}
            if mycase("TRANSACTION_onStartRestore"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onStartRestore")
                # {}
            if mycase("TRANSACTION_onRestorePackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("onRestorePackage", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onEndRestore"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onEndRestore")
                # {}
            if mycase("TRANSACTION_onTimeout"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onTimeout")
                # {}
