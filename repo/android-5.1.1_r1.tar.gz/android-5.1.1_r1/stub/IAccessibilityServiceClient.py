from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccessibilityServiceClient:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.accessibilityservice.IAccessibilityServiceClient"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.accessibilityservice.IAccessibilityServiceClient"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_init"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accessibilityservice.IAccessibilityServiceConnection", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readStrongBinder()
                return self.callFunction("init", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.IBinder', '_arg0': 'android.accessibilityservice.IAccessibilityServiceConnection', '_arg1': 'int'}
            if mycase("TRANSACTION_onAccessibilityEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.accessibility.AccessibilityEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("onAccessibilityEvent", _arg0)
                # {'_arg0': 'android.view.accessibility.AccessibilityEvent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onInterrupt"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onInterrupt")
                # {}
            if mycase("TRANSACTION_onGesture"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onGesture", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_clearAccessibilityCache"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearAccessibilityCache")
                # {}
            if mycase("TRANSACTION_onKeyEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.KeyEvent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("onKeyEvent", _arg0, _arg1)
                # {'_arg0': 'android.view.KeyEvent', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
