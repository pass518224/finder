from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITvInputServiceCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.tv.ITvInputServiceCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.tv.ITvInputServiceCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_addHardwareTvInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.media.tv.TvInputInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("addHardwareTvInput", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.media.tv.TvInputInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addHdmiTvInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.media.tv.TvInputInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("addHdmiTvInput", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.media.tv.TvInputInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeTvInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removeTvInput", _arg0)
                # {'_arg0': 'java.lang.String'}
