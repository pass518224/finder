from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWapPushManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.IWapPushManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.IWapPushManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_processMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg2 = None
                return self.callFunction("processMessage", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'android.content.Intent', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                _arg5 = (0 != data.readInt())
                _arg6 = (0 != data.readInt())
                return self.callFunction("addPackage", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'boolean', '_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg6': 'boolean', '_arg4': 'int', '_arg5': 'boolean'}
            if mycase("TRANSACTION_updatePackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                _arg5 = (0 != data.readInt())
                _arg6 = (0 != data.readInt())
                return self.callFunction("updatePackage", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'boolean', '_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg6': 'boolean', '_arg4': 'int', '_arg5': 'boolean'}
            if mycase("TRANSACTION_deletePackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                return self.callFunction("deletePackage", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_result': 'boolean'}
