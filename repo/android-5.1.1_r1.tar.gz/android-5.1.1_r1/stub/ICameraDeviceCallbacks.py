from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICameraDeviceCallbacks:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.camera2.ICameraDeviceCallbacks"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.camera2.ICameraDeviceCallbacks"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onDeviceError"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.hardware.camera2.impl.CaptureResultExtras", data)
                else:
                    _arg1 = None
                return self.callFunction("onDeviceError", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.hardware.camera2.impl.CaptureResultExtras', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onDeviceIdle"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDeviceIdle")
                # {}
            if mycase("TRANSACTION_onCaptureStarted"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.camera2.impl.CaptureResultExtras", data)
                else:
                    _arg0 = None
                _arg1 = data.readLong()
                return self.callFunction("onCaptureStarted", _arg0, _arg1)
                # {'_arg0': 'android.hardware.camera2.impl.CaptureResultExtras', '_arg1': 'long', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onResultReceived"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.camera2.impl.CameraMetadataNative", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.hardware.camera2.impl.CaptureResultExtras", data)
                else:
                    _arg1 = None
                return self.callFunction("onResultReceived", _arg0, _arg1)
                # {'_arg0': 'android.hardware.camera2.impl.CameraMetadataNative', '_arg1': 'android.hardware.camera2.impl.CaptureResultExtras', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
