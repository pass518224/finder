from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPhoneSubInfo:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.IPhoneSubInfo"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.IPhoneSubInfo"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getDeviceId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDeviceId")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getNaiForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getNaiForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getDeviceIdForPhone"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getDeviceIdForPhone", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getImeiForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getImeiForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getDeviceSvn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDeviceSvn")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getDeviceSvnUsingSubId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getDeviceSvnUsingSubId", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getSubscriberId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSubscriberId")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getSubscriberIdForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getSubscriberIdForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getGroupIdLevel1"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getGroupIdLevel1")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getGroupIdLevel1ForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getGroupIdLevel1ForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIccSerialNumber"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getIccSerialNumber")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIccSerialNumberForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getIccSerialNumberForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getLine1Number"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLine1Number")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getLine1NumberForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getLine1NumberForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getLine1AlphaTag"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLine1AlphaTag")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getLine1AlphaTagForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getLine1AlphaTagForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getMsisdn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMsisdn")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getMsisdnForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getMsisdnForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getVoiceMailNumber"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVoiceMailNumber")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getVoiceMailNumberForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getVoiceMailNumberForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getCompleteVoiceMailNumber"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCompleteVoiceMailNumber")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getCompleteVoiceMailNumberForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCompleteVoiceMailNumberForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getVoiceMailAlphaTag"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVoiceMailAlphaTag")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getVoiceMailAlphaTagForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getVoiceMailAlphaTagForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIsimImpi"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getIsimImpi")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIsimDomain"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getIsimDomain")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIsimImpu"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getIsimImpu")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIsimIst"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getIsimIst")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIsimPcscf"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getIsimPcscf")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIsimChallengeResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getIsimChallengeResponse", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getIccSimChallengeResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("getIccSimChallengeResponse", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int', '_result': 'java.lang.String'}
