from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputMethod:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.view.IInputMethod"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.view.IInputMethod"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_attachToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("attachToken", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_bindInput"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.inputmethod.InputBinding", data)
                else:
                    _arg0 = None
                return self.callFunction("bindInput", _arg0)
                # {'_arg0': 'android.view.inputmethod.InputBinding', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unbindInput"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("unbindInput")
                # {}
            if mycase("TRANSACTION_startInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputContext", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.view.inputmethod.EditorInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("startInput", _arg0, _arg1)
                # {'_arg0': 'com.android.internal.view.IInputContext', '_arg1': 'android.view.inputmethod.EditorInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_restartInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputContext", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.view.inputmethod.EditorInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("restartInput", _arg0, _arg1)
                # {'_arg0': 'com.android.internal.view.IInputContext', '_arg1': 'android.view.inputmethod.EditorInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createSession"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.InputChannel", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("com.android.internal.view.IInputSessionCallback", data.readStrongBinder())
                return self.callFunction("createSession", _arg0, _arg1)
                # {'_arg0': 'android.view.InputChannel', '_arg1': 'com.android.internal.view.IInputSessionCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setSessionEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodSession", data.readStrongBinder())
                _arg1 = (0 != data.readInt())
                return self.callFunction("setSessionEnabled", _arg0, _arg1)
                # {'_arg0': 'com.android.internal.view.IInputMethodSession', '_arg1': 'boolean'}
            if mycase("TRANSACTION_revokeSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodSession", data.readStrongBinder())
                return self.callFunction("revokeSession", _arg0)
                # {'_arg0': 'com.android.internal.view.IInputMethodSession'}
            if mycase("TRANSACTION_showSoftInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ResultReceiver", data)
                else:
                    _arg1 = None
                return self.callFunction("showSoftInput", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.ResultReceiver', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hideSoftInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ResultReceiver", data)
                else:
                    _arg1 = None
                return self.callFunction("hideSoftInput", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.ResultReceiver', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_changeInputMethodSubtype"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.inputmethod.InputMethodSubtype", data)
                else:
                    _arg0 = None
                return self.callFunction("changeInputMethodSubtype", _arg0)
                # {'_arg0': 'android.view.inputmethod.InputMethodSubtype', 'ELSE:': {}, 'IF': {}}
