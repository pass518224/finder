from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IDevicePolicyManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.admin.IDevicePolicyManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.admin.IDevicePolicyManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setPasswordQuality"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordQuality", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordQuality"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordQuality", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordMinimumLength"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordMinimumLength", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordMinimumLength"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordMinimumLength", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordMinimumUpperCase"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordMinimumUpperCase", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordMinimumUpperCase"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordMinimumUpperCase", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordMinimumLowerCase"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordMinimumLowerCase", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordMinimumLowerCase"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordMinimumLowerCase", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordMinimumLetters"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordMinimumLetters", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordMinimumLetters"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordMinimumLetters", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordMinimumNumeric"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordMinimumNumeric", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordMinimumNumeric"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordMinimumNumeric", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordMinimumSymbols"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordMinimumSymbols", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordMinimumSymbols"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordMinimumSymbols", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordMinimumNonLetter"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordMinimumNonLetter", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordMinimumNonLetter"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordMinimumNonLetter", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordHistoryLength"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordHistoryLength", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordHistoryLength"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordHistoryLength", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasswordExpirationTimeout"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                return self.callFunction("setPasswordExpirationTimeout", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'long', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordExpirationTimeout"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordExpirationTimeout", _arg0, _arg1)
                # {'_result': 'long', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPasswordExpiration"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getPasswordExpiration", _arg0, _arg1)
                # {'_result': 'long', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isActivePasswordSufficient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isActivePasswordSufficient", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getCurrentFailedPasswordAttempts"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCurrentFailedPasswordAttempts", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getProfileWithMinimumFailedPasswordsForWipe"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getProfileWithMinimumFailedPasswordsForWipe", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_setMaximumFailedPasswordsForWipe"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setMaximumFailedPasswordsForWipe", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getMaximumFailedPasswordsForWipe"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getMaximumFailedPasswordsForWipe", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_resetPassword"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("resetPassword", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setMaximumTimeToLock"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                return self.callFunction("setMaximumTimeToLock", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'long', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getMaximumTimeToLock"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getMaximumTimeToLock", _arg0, _arg1)
                # {'_result': 'long', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_lockNow"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("lockNow")
                # {}
            if mycase("TRANSACTION_wipeData"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("wipeData", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setGlobalProxy"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                return self.callFunction("setGlobalProxy", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'android.content.ComponentName', '_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getGlobalProxyAdmin"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getGlobalProxyAdmin", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_setRecommendedGlobalProxy"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.ProxyInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("setRecommendedGlobalProxy", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'android.net.ProxyInfo', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_setStorageEncryption"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                return self.callFunction("setStorageEncryption", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getStorageEncryption"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getStorageEncryption", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getStorageEncryptionStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getStorageEncryptionStatus", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_setCameraDisabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                return self.callFunction("setCameraDisabled", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCameraDisabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getCameraDisabled", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setScreenCaptureDisabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setScreenCaptureDisabled", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getScreenCaptureDisabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getScreenCaptureDisabled", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setKeyguardDisabledFeatures"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setKeyguardDisabledFeatures", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getKeyguardDisabledFeatures"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getKeyguardDisabledFeatures", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setActiveAdmin"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                return self.callFunction("setActiveAdmin", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isAdminActive"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("isAdminActive", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getActiveAdmins"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getActiveAdmins", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.content.ComponentName>'}
            if mycase("TRANSACTION_packageHasActiveAdmins"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("packageHasActiveAdmins", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getRemoveWarning"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.RemoteCallback", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("getRemoveWarning", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'android.os.RemoteCallback', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_removeActiveAdmin"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("removeActiveAdmin", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hasGrantedPolicy"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("hasGrantedPolicy", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setActivePasswordState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readInt()
                _arg8 = data.readInt()
                return self.callFunction("setActivePasswordState", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'int', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg6': 'int', '_arg7': 'int', '_arg4': 'int', '_arg5': 'int'}
            if mycase("TRANSACTION_reportFailedPasswordAttempt"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("reportFailedPasswordAttempt", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_reportSuccessfulPasswordAttempt"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("reportSuccessfulPasswordAttempt", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setDeviceOwner"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("setDeviceOwner", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_isDeviceOwner"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isDeviceOwner", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_getDeviceOwner"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDeviceOwner")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getDeviceOwnerName"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDeviceOwnerName")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_clearDeviceOwner"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("clearDeviceOwner", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setProfileOwner"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("setProfileOwner", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getProfileOwner"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getProfileOwner", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_getProfileOwnerName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getProfileOwnerName", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_setProfileEnabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("setProfileEnabled", _arg0)
                # {'_arg0': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setProfileName"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("setProfileName", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearProfileOwner"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("clearProfileOwner", _arg0)
                # {'_arg0': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hasUserSetupCompleted"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasUserSetupCompleted")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_installCaCert"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.createByteArray()
                return self.callFunction("installCaCert", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'byte', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_uninstallCaCert"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("uninstallCaCert", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_enforceCanManageCaCerts"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("enforceCanManageCaCerts", _arg0)
                # {'_arg0': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_installKeyPair"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.createByteArray()
                _arg2 = data.createByteArray()
                _arg3 = data.readString()
                return self.callFunction("installKeyPair", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'byte', '_arg3': 'java.lang.String', '_arg0': 'android.content.ComponentName', '_arg1': 'byte', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addPersistentPreferredActivity"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.IntentFilter", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg2 = None
                return self.callFunction("addPersistentPreferredActivity", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.content.ComponentName', '_arg0': 'android.content.ComponentName', '_arg1': 'android.content.IntentFilter', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_clearPackagePersistentPreferredActivities"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("clearPackagePersistentPreferredActivities", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setApplicationRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("setApplicationRestrictions", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getApplicationRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("getApplicationRestrictions", _arg0, _arg1)
                # {'_result': 'android.os.Bundle', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setRestrictionsProvider"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg1 = None
                return self.callFunction("setRestrictionsProvider", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'android.content.ComponentName', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_getRestrictionsProvider"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getRestrictionsProvider", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_setUserRestriction"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setUserRestriction", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addCrossProfileIntentFilter"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.IntentFilter", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("addCrossProfileIntentFilter", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'android.content.IntentFilter', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_clearCrossProfileIntentFilters"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("clearCrossProfileIntentFilters", _arg0)
                # {'_arg0': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPermittedAccessibilityServices"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readArrayList(cl)
                return self.callFunction("setPermittedAccessibilityServices", _arg0, _arg1)
                # {'_result': 'boolean', 'cl': 'java.lang.ClassLoader', '_arg0': 'android.content.ComponentName', '_arg1': 'java.util.List', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPermittedAccessibilityServices"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("getPermittedAccessibilityServices", _arg0)
                # {'_arg0': 'android.content.ComponentName', '_result': 'java.util.List', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPermittedAccessibilityServicesForUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getPermittedAccessibilityServicesForUser", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List'}
            if mycase("TRANSACTION_setPermittedInputMethods"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readArrayList(cl)
                return self.callFunction("setPermittedInputMethods", _arg0, _arg1)
                # {'_result': 'boolean', 'cl': 'java.lang.ClassLoader', '_arg0': 'android.content.ComponentName', '_arg1': 'java.util.List', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPermittedInputMethods"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("getPermittedInputMethods", _arg0)
                # {'_arg0': 'android.content.ComponentName', '_result': 'java.util.List', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPermittedInputMethodsForCurrentUser"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPermittedInputMethodsForCurrentUser")
                # {'_result': 'java.util.List'}
            if mycase("TRANSACTION_setApplicationHidden"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setApplicationHidden", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isApplicationHidden"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("isApplicationHidden", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("createUser", _arg0, _arg1)
                # {'_result': 'android.os.UserHandle', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createAndInitializeUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg3 = None
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg4 = None
                return self.callFunction("createAndInitializeUser", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'android.os.UserHandle', '_arg2': 'java.lang.String', '_arg3': 'android.content.ComponentName', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', '_arg4': 'android.os.Bundle', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg1 = None
                return self.callFunction("removeUser", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'android.os.UserHandle', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_switchUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg1 = None
                return self.callFunction("switchUser", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'android.os.UserHandle', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_enableSystemApp"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("enableSystemApp", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_enableSystemAppWithIntent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg1 = None
                return self.callFunction("enableSystemAppWithIntent", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'android.content.Intent', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_setAccountManagementDisabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setAccountManagementDisabled", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAccountTypesWithManagementDisabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAccountTypesWithManagementDisabled")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getAccountTypesWithManagementDisabledAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getAccountTypesWithManagementDisabledAsUser", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_setLockTaskPackages"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.createStringArray()
                return self.callFunction("setLockTaskPackages", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getLockTaskPackages"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("getLockTaskPackages", _arg0)
                # {'_arg0': 'android.content.ComponentName', '_result': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isLockTaskPermitted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isLockTaskPermitted", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_setGlobalSetting"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("setGlobalSetting", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setSecureSetting"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("setSecureSetting", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setMasterVolumeMuted"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("setMasterVolumeMuted", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isMasterVolumeMuted"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("isMasterVolumeMuted", _arg0)
                # {'_arg0': 'android.content.ComponentName', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyLockTaskModeChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("notifyLockTaskModeChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'boolean', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setUninstallBlocked"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setUninstallBlocked", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isUninstallBlocked"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("isUninstallBlocked", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setCrossProfileCallerIdDisabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("setCrossProfileCallerIdDisabled", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCrossProfileCallerIdDisabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("getCrossProfileCallerIdDisabled", _arg0)
                # {'_arg0': 'android.content.ComponentName', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCrossProfileCallerIdDisabledForUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCrossProfileCallerIdDisabledForUser", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setTrustAgentConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.PersistableBundle", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("setTrustAgentConfiguration", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.os.PersistableBundle', '_arg3': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'android.content.ComponentName', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_getTrustAgentConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("getTrustAgentConfiguration", _arg0, _arg1, _arg2)
                # {'_result': 'java.util.List<android.os.PersistableBundle>', '_arg2': 'int', '_arg0': 'android.content.ComponentName', '_arg1': 'android.content.ComponentName', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_addCrossProfileWidgetProvider"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("addCrossProfileWidgetProvider", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeCrossProfileWidgetProvider"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("removeCrossProfileWidgetProvider", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCrossProfileWidgetProviders"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("getCrossProfileWidgetProviders", _arg0)
                # {'_arg0': 'android.content.ComponentName', '_result': 'java.util.List<java.lang.String>', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAutoTimeRequired"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setAutoTimeRequired", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAutoTimeRequired"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAutoTimeRequired")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isRemovingAdmin"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("isRemovingAdmin", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
