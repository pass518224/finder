from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBackupManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.backup.IBackupManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.backup.IBackupManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_dataChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("dataChanged", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_clearBackupData"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("clearBackupData", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_agentConnected"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readStrongBinder()
                return self.callFunction("agentConnected", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_agentDisconnected"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("agentDisconnected", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_restoreAtInstall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("restoreAtInstall", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setBackupEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setBackupEnabled", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setAutoRestore"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setAutoRestore", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setBackupProvisioned"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setBackupProvisioned", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_isBackupEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isBackupEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setBackupPassword"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("setBackupPassword", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_hasBackupPassword"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasBackupPassword")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_backupNow"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("backupNow")
                # {}
            if mycase("TRANSACTION_fullBackup"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = (0 != data.readInt())
                _arg3 = (0 != data.readInt())
                _arg4 = (0 != data.readInt())
                _arg5 = (0 != data.readInt())
                _arg6 = (0 != data.readInt())
                _arg7 = (0 != data.readInt())
                _arg8 = data.createStringArray()
                return self.callFunction("fullBackup", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'java.lang.String', '_arg2': 'boolean', '_arg3': 'boolean', '_arg0': 'android.os.ParcelFileDescriptor', '_arg1': 'boolean', '_arg6': 'boolean', '_arg7': 'boolean', '_arg4': 'boolean', '_arg5': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_fullTransportBackup"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                return self.callFunction("fullTransportBackup", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_fullRestore"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                return self.callFunction("fullRestore", _arg0)
                # {'_arg0': 'android.os.ParcelFileDescriptor', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_acknowledgeFullBackupOrRestore"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = self.interfaceResolver("android.app.backup.IFullBackupRestoreObserver", data.readStrongBinder())
                return self.callFunction("acknowledgeFullBackupOrRestore", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'boolean', '_arg4': 'android.app.backup.IFullBackupRestoreObserver'}
            if mycase("TRANSACTION_getCurrentTransport"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentTransport")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_listAllTransports"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("listAllTransports")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_selectBackupTransport"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("selectBackupTransport", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getConfigurationIntent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getConfigurationIntent", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.content.Intent'}
            if mycase("TRANSACTION_getDestinationString"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getDestinationString", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getDataManagementIntent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getDataManagementIntent", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.content.Intent'}
            if mycase("TRANSACTION_getDataManagementLabel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getDataManagementLabel", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_beginRestoreSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("beginRestoreSession", _arg0, _arg1)
                # {'_result': 'android.app.backup.IRestoreSession', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_opComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("opComplete", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setBackupServiceActive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setBackupServiceActive", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_isBackupServiceActive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isBackupServiceActive", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
