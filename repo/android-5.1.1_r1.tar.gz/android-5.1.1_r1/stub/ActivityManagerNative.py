from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IActivityManager:
    pass
    descriptor = "android.app.IActivityManager"
class OnTransact(IActivityManager, Stub):
    sSystemReady = False
    def onTransact(self, code, data, reply):
        sSystemReady = False
        for mycase in Switch(code):
            if mycase("START_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                callingPackage = data.readString()
                intent = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                resultTo = data.readStrongBinder()
                resultWho = data.readString()
                requestCode = data.readInt()
                startFlags = data.readInt()
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                return self.callFunction("startActivity", app, callingPackage, intent, resolvedType, resultTo, resultWho, requestCode, startFlags, profilerInfo, options)
                # {'resultTo': 'IBinder', 'resultWho': 'String', 'b': 'IBinder', 'callingPackage': 'String', 'app': 'IApplicationThread', 'startFlags': 'int', 'requestCode': 'int', 'intent': 'Intent', 'result': 'int', 'profilerInfo': 'ProfilerInfo', 'resolvedType': 'String', 'options': 'Bundle'}
            if mycase("START_ACTIVITY_AS_USER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                callingPackage = data.readString()
                intent = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                resultTo = data.readStrongBinder()
                resultWho = data.readString()
                requestCode = data.readInt()
                startFlags = data.readInt()
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                userId = data.readInt()
                return self.callFunction("startActivityAsUser", app, callingPackage, intent, resolvedType, resultTo, resultWho, requestCode, startFlags, profilerInfo, options, userId)
                # {'resultTo': 'IBinder', 'resultWho': 'String', 'b': 'IBinder', 'callingPackage': 'String', 'app': 'IApplicationThread', 'userId': 'int', 'startFlags': 'int', 'requestCode': 'int', 'intent': 'Intent', 'result': 'int', 'profilerInfo': 'ProfilerInfo', 'resolvedType': 'String', 'options': 'Bundle'}
            if mycase("START_ACTIVITY_AS_CALLER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                callingPackage = data.readString()
                intent = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                resultTo = data.readStrongBinder()
                resultWho = data.readString()
                requestCode = data.readInt()
                startFlags = data.readInt()
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                userId = data.readInt()
                return self.callFunction("startActivityAsCaller", app, callingPackage, intent, resolvedType, resultTo, resultWho, requestCode, startFlags, profilerInfo, options, userId)
                # {'resultTo': 'IBinder', 'resultWho': 'String', 'b': 'IBinder', 'callingPackage': 'String', 'app': 'IApplicationThread', 'userId': 'int', 'startFlags': 'int', 'requestCode': 'int', 'intent': 'Intent', 'result': 'int', 'profilerInfo': 'ProfilerInfo', 'resolvedType': 'String', 'options': 'Bundle'}
            if mycase("START_ACTIVITY_AND_WAIT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                callingPackage = data.readString()
                intent = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                resultTo = data.readStrongBinder()
                resultWho = data.readString()
                requestCode = data.readInt()
                startFlags = data.readInt()
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                userId = data.readInt()
                return self.callFunction("startActivityAndWait", app, callingPackage, intent, resolvedType, resultTo, resultWho, requestCode, startFlags, profilerInfo, options, userId)
                # {'resultTo': 'IBinder', 'resultWho': 'String', 'b': 'IBinder', 'callingPackage': 'String', 'app': 'IApplicationThread', 'userId': 'int', 'startFlags': 'int', 'requestCode': 'int', 'intent': 'Intent', 'result': 'WaitResult', 'profilerInfo': 'ProfilerInfo', 'resolvedType': 'String', 'options': 'Bundle'}
            if mycase("START_ACTIVITY_WITH_CONFIG_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                callingPackage = data.readString()
                intent = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                resultTo = data.readStrongBinder()
                resultWho = data.readString()
                requestCode = data.readInt()
                startFlags = data.readInt()
                config = self.creatorResolver("android.content.res.Configuration", data)
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                userId = data.readInt()
                return self.callFunction("startActivityWithConfig", app, callingPackage, intent, resolvedType, resultTo, resultWho, requestCode, startFlags, config, options, userId)
                # {'resultTo': 'IBinder', 'resultWho': 'String', 'b': 'IBinder', 'callingPackage': 'String', 'config': 'Configuration', 'app': 'IApplicationThread', 'userId': 'int', 'startFlags': 'int', 'requestCode': 'int', 'intent': 'Intent', 'result': 'int', 'resolvedType': 'String', 'options': 'Bundle'}
            if mycase("START_ACTIVITY_INTENT_SENDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                intent = self.creatorResolver("android.content.IntentSender", data)
                fillInIntent = None
                if (data.readInt() != 0):
                    fillInIntent = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                resultTo = data.readStrongBinder()
                resultWho = data.readString()
                requestCode = data.readInt()
                flagsMask = data.readInt()
                flagsValues = data.readInt()
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                return self.callFunction("startActivityIntentSender", app, intent, fillInIntent, resolvedType, resultTo, resultWho, requestCode, flagsMask, flagsValues, options)
                # {'resultTo': 'IBinder', 'resultWho': 'String', 'b': 'IBinder', 'fillInIntent': 'Intent', 'flagsValues': 'int', 'app': 'IApplicationThread', 'requestCode': 'int', 'intent': 'IntentSender', 'result': 'int', 'flagsMask': 'int', 'resolvedType': 'String', 'options': 'Bundle', 'IF': {}}
            if mycase("START_VOICE_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                callingPackage = data.readString()
                callingPid = data.readInt()
                callingUid = data.readInt()
                intent = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                session = self.interfaceResolver("IVoiceInteractionSession", data.readStrongBinder())
                interactor = self.interfaceResolver("IVoiceInteractor", data.readStrongBinder())
                startFlags = data.readInt()
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                userId = data.readInt()
                return self.callFunction("startVoiceActivity", callingPackage, callingPid, callingUid, intent, resolvedType, session, interactor, startFlags, profilerInfo, options, userId)
                # {'options': 'Bundle', 'interactor': 'IVoiceInteractor', 'callingUid': 'int', 'callingPackage': 'String', 'userId': 'int', 'startFlags': 'int', 'session': 'IVoiceInteractionSession', 'intent': 'Intent', 'result': 'int', 'profilerInfo': 'ProfilerInfo', 'resolvedType': 'String', 'callingPid': 'int'}
            if mycase("START_NEXT_MATCHING_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                callingActivity = data.readStrongBinder()
                intent = self.creatorResolver("android.content.Intent", data)
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                return self.callFunction("startNextMatchingActivity", callingActivity, intent, options)
                # {'callingActivity': 'IBinder', 'intent': 'Intent', 'options': 'Bundle', 'result': 'boolean'}
            if mycase("START_ACTIVITY_FROM_RECENTS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                taskId = data.readInt()
                options = None if (data.readInt() == 0) else self.creatorResolver("android.os.Bundle", data)
                return self.callFunction("startActivityFromRecents", taskId, options)
                # {'options': 'Bundle', 'taskId': 'int', 'result': 'int'}
            if mycase("FINISH_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                resultData = None
                resultCode = data.readInt()
                if (data.readInt() != 0):
                    resultData = self.creatorResolver("android.content.Intent", data)
                finishTask = (data.readInt() != 0)
                return self.callFunction("finishActivity", token, resultCode, resultData, finishTask)
                # {'finishTask': 'boolean', 'resultData': 'Intent', 'token': 'IBinder', 'res': 'boolean', 'resultCode': 'int', 'IF': {}}
            if mycase("FINISH_SUB_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                resultWho = data.readString()
                requestCode = data.readInt()
                return self.callFunction("finishSubActivity", token, resultWho, requestCode)
                # {'resultWho': 'String', 'token': 'IBinder', 'requestCode': 'int'}
            if mycase("FINISH_ACTIVITY_AFFINITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("finishActivityAffinity", token)
                # {'res': 'boolean', 'token': 'IBinder'}
            if mycase("FINISH_VOICE_TASK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                session = self.interfaceResolver("IVoiceInteractionSession", data.readStrongBinder())
                return self.callFunction("finishVoiceTask", session)
                # {'session': 'IVoiceInteractionSession'}
            if mycase("RELEASE_ACTIVITY_INSTANCE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("releaseActivityInstance", token)
                # {'res': 'boolean', 'token': 'IBinder'}
            if mycase("RELEASE_SOME_ACTIVITIES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                app = self.interfaceResolver("ApplicationThreadNativ", data.readStrongBinder())
                return self.callFunction("releaseSomeActivities", app)
                # {'app': 'IApplicationThread'}
            if mycase("WILL_ACTIVITY_BE_VISIBLE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("willActivityBeVisible", token)
                # {'res': 'boolean', 'token': 'IBinder'}
            if mycase("REGISTER_RECEIVER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b) if (b != None) else None
                packageName = data.readString()
                b = data.readStrongBinder()
                rec = self.interfaceResolver("IIntentReceiver", b) if (b != None) else None
                filter = self.creatorResolver("android.content.IntentFilter", data)
                perm = data.readString()
                userId = data.readInt()
                return self.callFunction("registerReceiver", app, packageName, rec, filter, perm, userId)
                # {'b': 'IBinder', 'app': 'IApplicationThread', 'userId': 'int', 'perm': 'String', 'filter': 'IntentFilter', 'intent': 'Intent', 'rec': 'IIntentReceiver', 'packageName': 'String'}
            if mycase("UNREGISTER_RECEIVER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                if (b == None):
                    return True
                rec = self.interfaceResolver("IIntentReceiver", b)
                return self.callFunction("unregisterReceiver", rec)
                # {'rec': 'IIntentReceiver', 'b': 'IBinder', 'IF': {}}
            if mycase("BROADCAST_INTENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b) if (b != None) else None
                intent = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                b = data.readStrongBinder()
                resultTo = self.interfaceResolver("IIntentReceiver", b) if (b != None) else None
                resultCode = data.readInt()
                resultData = data.readString()
                resultExtras = data.readBundle()
                perm = data.readString()
                appOp = data.readInt()
                serialized = (data.readInt() != 0)
                sticky = (data.readInt() != 0)
                userId = data.readInt()
                return self.callFunction("broadcastIntent", app, intent, resolvedType, resultTo, resultCode, resultData, resultExtras, perm, appOp, serialized, sticky, userId)
                # {'resultTo': 'IIntentReceiver', 'b': 'IBinder', 'res': 'int', 'serialized': 'boolean', 'resultData': 'String', 'app': 'IApplicationThread', 'userId': 'int', 'perm': 'String', 'sticky': 'boolean', 'intent': 'Intent', 'appOp': 'int', 'resultCode': 'int', 'resolvedType': 'String', 'resultExtras': 'Bundle'}
            if mycase("UNBROADCAST_INTENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b) if (b != None) else None
                intent = self.creatorResolver("android.content.Intent", data)
                userId = data.readInt()
                return self.callFunction("unbroadcastIntent", app, intent, userId)
                # {'userId': 'int', 'app': 'IApplicationThread', 'b': 'IBinder', 'intent': 'Intent'}
            if mycase("FINISH_RECEIVER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                who = data.readStrongBinder()
                resultCode = data.readInt()
                resultData = data.readString()
                resultExtras = data.readBundle()
                resultAbort = (data.readInt() != 0)
                if (who != None):
                    return self.callFunction("finishReceiver", who, resultCode, resultData, resultExtras, resultAbort)
                reply.writeNoException()
                return True
                # {'resultData': 'String', 'resultExtras': 'Bundle', 'who': 'IBinder', 'resultCode': 'int', 'resultAbort': 'boolean', 'IF': {}}
            if mycase("ATTACH_APPLICATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                app = self.interfaceResolver("ApplicationThreadNativ", data.readStrongBinder())
                if (app != None):
                    return self.callFunction("attachApplication", app)
                reply.writeNoException()
                return True
                # {'app': 'IApplicationThread', 'IF': {}}
            if mycase("ACTIVITY_IDLE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                config = None
                if (data.readInt() != 0):
                    config = self.creatorResolver("android.content.res.Configuration", data)
                stopProfiling = (data.readInt() != 0)
                if (token != None):
                    return self.callFunction("activityIdle", token, config, stopProfiling)
                reply.writeNoException()
                return True
                # {'token': 'IBinder', 'stopProfiling': 'boolean', 'config': 'Configuration', 'IFI': {}, 'IF': {}}
            if mycase("ACTIVITY_RESUMED_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("activityResumed", token)
                # {'token': 'IBinder'}
            if mycase("ACTIVITY_PAUSED_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("activityPaused", token)
                # {'token': 'IBinder'}
            if mycase("ACTIVITY_STOPPED_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                map = data.readBundle()
                persistentState = data.readPersistableBundle()
                description = self.creatorResolver("TextUtils.CHAR_SEQUENCE_CREATO", data)
                return self.callFunction("activityStopped", token, map, persistentState, description)
                # {'map': 'Bundle', 'token': 'IBinder', 'persistentState': 'PersistableBundle', 'description': 'CharSequence'}
            if mycase("ACTIVITY_SLEPT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("activitySlept", token)
                # {'token': 'IBinder'}
            if mycase("ACTIVITY_DESTROYED_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("activityDestroyed", token)
                # {'token': 'IBinder'}
            if mycase("GET_CALLING_PACKAGE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("getCallingPackage", token) if (token != None) else None
                # {'res': 'String', 'token': 'IBinder'}
            if mycase("GET_CALLING_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("getCallingActivity", token)
                # {'token': 'IBinder', 'cn': 'ComponentName'}
            if mycase("GET_APP_TASKS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                callingPackage = data.readString()
                return self.callFunction("getAppTasks", callingPackage)
                # {'list': 'List<IAppTask>', 'callingPackage': 'String'}
            if mycase("ADD_APP_TASK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                activityToken = data.readStrongBinder()
                intent = self.creatorResolver("android.content.Intent", data)
                descr = self.creatorResolver("ActivityManager.TaskDescription", data)
                thumbnail = self.creatorResolver("android.graphics.Bitmap", data)
                return self.callFunction("addAppTask", activityToken, intent, descr, thumbnail)
                # {'res': 'int', 'activityToken': 'IBinder', 'intent': 'Intent', 'thumbnail': 'Bitmap', 'descr': 'ActivityManager.TaskDescription'}
            if mycase("GET_APP_TASK_THUMBNAIL_SIZE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getAppTaskThumbnailSize")
                # {'size': 'Point'}
            if mycase("GET_TASKS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                maxNum = data.readInt()
                fl = data.readInt()
                return self.callFunction("getTasks", maxNum, fl)
                # {'fl': 'int', 'list': 'List<ActivityManager.RunningTaskInfo>', 'maxNum': 'int'}
            if mycase("GET_RECENT_TASKS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                maxNum = data.readInt()
                fl = data.readInt()
                userId = data.readInt()
                return self.callFunction("getRecentTasks", maxNum, fl, userId)
                # {'fl': 'int', 'list': 'List<ActivityManager.RecentTaskInfo>', 'maxNum': 'int', 'userId': 'int'}
            if mycase("GET_TASK_THUMBNAIL_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                id = data.readInt()
                return self.callFunction("getTaskThumbnail", id)
                # {'taskThumbnail': 'ActivityManager.TaskThumbnail', 'id': 'int'}
            if mycase("GET_SERVICES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                maxNum = data.readInt()
                fl = data.readInt()
                return self.callFunction("getServices", maxNum, fl)
                # {'fl': 'int', 'list': 'List<ActivityManager.RunningServiceInfo>', 'maxNum': 'int'}
            if mycase("GET_PROCESSES_IN_ERROR_STATE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getProcessesInErrorState")
                # {'list': 'List<ActivityManager.ProcessErrorStateInfo>'}
            if mycase("GET_RUNNING_APP_PROCESSES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getRunningAppProcesses")
                # {'list': 'List<ActivityManager.RunningAppProcessInfo>'}
            if mycase("GET_RUNNING_EXTERNAL_APPLICATIONS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getRunningExternalApplications")
                # {'list': 'List<ApplicationInfo>'}
            if mycase("MOVE_TASK_TO_FRONT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                task = data.readInt()
                fl = data.readInt()
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                return self.callFunction("moveTaskToFront", task, fl, options)
                # {'task': 'int', 'fl': 'int', 'options': 'Bundle'}
            if mycase("MOVE_TASK_TO_BACK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                task = data.readInt()
                return self.callFunction("moveTaskToBack", task)
                # {'task': 'int'}
            if mycase("MOVE_ACTIVITY_TASK_TO_BACK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                nonRoot = (data.readInt() != 0)
                return self.callFunction("moveActivityTaskToBack", token, nonRoot)
                # {'res': 'boolean', 'token': 'IBinder', 'nonRoot': 'boolean'}
            if mycase("MOVE_TASK_BACKWARDS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                task = data.readInt()
                return self.callFunction("moveTaskBackwards", task)
                # {'task': 'int'}
            if mycase("MOVE_TASK_TO_STACK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                taskId = data.readInt()
                stackId = data.readInt()
                toTop = (data.readInt() != 0)
                return self.callFunction("moveTaskToStack", taskId, stackId, toTop)
                # {'stackId': 'int', 'toTop': 'boolean', 'taskId': 'int'}
            if mycase("RESIZE_STACK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                stackId = data.readInt()
                weight = data.readFloat()
                r = self.creatorResolver("android.graphics.Rect", data)
                return self.callFunction("resizeStack", stackId, r)
                # {'stackId': 'int', 'r': 'Rect', 'weight': 'float'}
            if mycase("GET_ALL_STACK_INFOS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getAllStackInfos")
                # {'list': 'List<StackInfo>'}
            if mycase("GET_STACK_INFO_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                stackId = data.readInt()
                return self.callFunction("getStackInfo", stackId)
                # {'stackId': 'int', 'info': 'StackInfo'}
            if mycase("IS_IN_HOME_STACK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                taskId = data.readInt()
                return self.callFunction("isInHomeStack", taskId)
                # {'isInHomeStack': 'boolean', 'taskId': 'int'}
            if mycase("SET_FOCUSED_STACK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                stackId = data.readInt()
                return self.callFunction("setFocusedStack", stackId)
                # {'stackId': 'int'}
            if mycase("REGISTER_TASK_STACK_LISTENER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("registerTaskStackListener", self.interfaceResolver("ITaskStackListener", token))
                # {'token': 'IBinder'}
            if mycase("GET_TASK_FOR_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                onlyRoot = (data.readInt() != 0)
                return self.callFunction("getTaskForActivity", token, onlyRoot) if (token != None) else -1
                # {'res': 'int', 'token': 'IBinder', 'onlyRoot': 'boolean'}
            if mycase("GET_CONTENT_PROVIDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                name = data.readString()
                userId = data.readInt()
                stable = (data.readInt() != 0)
                return self.callFunction("getContentProvider", app, name, userId, stable)
                # {'cph': 'ContentProviderHolder', 'b': 'IBinder', 'name': 'String', 'app': 'IApplicationThread', 'userId': 'int', 'stable': 'boolean'}
            if mycase("GET_CONTENT_PROVIDER_EXTERNAL_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                name = data.readString()
                userId = data.readInt()
                token = data.readStrongBinder()
                return self.callFunction("getContentProviderExternal", name, userId, token)
                # {'cph': 'ContentProviderHolder', 'token': 'IBinder', 'userId': 'int', 'name': 'String'}
            if mycase("PUBLISH_CONTENT_PROVIDERS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                providers = data.createTypedArrayList("ContentProviderHolder")
                return self.callFunction("publishContentProviders", app, providers)
                # {'app': 'IApplicationThread', 'b': 'IBinder', 'providers': 'ArrayList<ContentProviderHolder>'}
            if mycase("REF_CONTENT_PROVIDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                stable = data.readInt()
                unstable = data.readInt()
                return self.callFunction("refContentProvider", b, stable, unstable)
                # {'res': 'boolean', 'b': 'IBinder', 'unstable': 'int', 'stable': 'int'}
            if mycase("UNSTABLE_PROVIDER_DIED_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                return self.callFunction("unstableProviderDied", b)
                # {'b': 'IBinder'}
            if mycase("APP_NOT_RESPONDING_VIA_PROVIDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                return self.callFunction("appNotRespondingViaProvider", b)
                # {'b': 'IBinder'}
            if mycase("REMOVE_CONTENT_PROVIDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                stable = (data.readInt() != 0)
                return self.callFunction("removeContentProvider", b, stable)
                # {'b': 'IBinder', 'stable': 'boolean'}
            if mycase("REMOVE_CONTENT_PROVIDER_EXTERNAL_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                name = data.readString()
                token = data.readStrongBinder()
                return self.callFunction("removeContentProviderExternal", name, token)
                # {'token': 'IBinder', 'name': 'String'}
            if mycase("GET_RUNNING_SERVICE_CONTROL_PANEL_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                comp = self.creatorResolver("android.content.ComponentName", data)
                return self.callFunction("getRunningServiceControlPanel", comp)
                # {'comp': 'ComponentName', 'pi': 'PendingIntent'}
            if mycase("START_SERVICE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                service = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                userId = data.readInt()
                return self.callFunction("startService", app, service, resolvedType, userId)
                # {'b': 'IBinder', 'cn': 'ComponentName', 'service': 'Intent', 'app': 'IApplicationThread', 'userId': 'int', 'resolvedType': 'String'}
            if mycase("STOP_SERVICE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                service = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                userId = data.readInt()
                return self.callFunction("stopService", app, service, resolvedType, userId)
                # {'b': 'IBinder', 'service': 'Intent', 'res': 'int', 'app': 'IApplicationThread', 'userId': 'int', 'resolvedType': 'String'}
            if mycase("STOP_SERVICE_TOKEN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                className = 'ComponentName.readFromParcel(data)'
                token = data.readStrongBinder()
                startId = data.readInt()
                return self.callFunction("stopServiceToken", className, token, startId)
                # {'className': 'ComponentName', 'res': 'boolean', 'token': 'IBinder', 'startId': 'int'}
            if mycase("SET_SERVICE_FOREGROUND_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                className = 'ComponentName.readFromParcel(data)'
                token = data.readStrongBinder()
                id = data.readInt()
                notification = None
                if (data.readInt() != 0):
                    notification = self.creatorResolver("android.app.Notification", data)
                removeNotification = (data.readInt() != 0)
                return self.callFunction("setServiceForeground", className, token, id, notification, removeNotification)
                # {'notification': 'Notification', 'removeNotification': 'boolean', 'className': 'ComponentName', 'token': 'IBinder', 'id': 'int', 'IF': {}}
            if mycase("BIND_SERVICE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                token = data.readStrongBinder()
                service = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                b = data.readStrongBinder()
                fl = data.readInt()
                userId = data.readInt()
                conn = self.interfaceResolver("IServiceConnection", b)
                return self.callFunction("bindService", app, token, service, resolvedType, conn, fl, userId)
                # {'b': 'IBinder', 'service': 'Intent', 'resolvedType': 'String', 'app': 'IApplicationThread', 'userId': 'int', 'token': 'IBinder', 'res': 'int', 'fl': 'int', 'conn': 'IServiceConnection'}
            if mycase("UNBIND_SERVICE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                conn = self.interfaceResolver("IServiceConnection", b)
                return self.callFunction("unbindService", conn)
                # {'res': 'boolean', 'b': 'IBinder', 'conn': 'IServiceConnection'}
            if mycase("PUBLISH_SERVICE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                intent = self.creatorResolver("android.content.Intent", data)
                service = data.readStrongBinder()
                return self.callFunction("publishService", token, intent, service)
                # {'token': 'IBinder', 'intent': 'Intent', 'service': 'IBinder'}
            if mycase("UNBIND_FINISHED_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                intent = self.creatorResolver("android.content.Intent", data)
                doRebind = (data.readInt() != 0)
                return self.callFunction("unbindFinished", token, intent, doRebind)
                # {'doRebind': 'boolean', 'token': 'IBinder', 'intent': 'Intent'}
            if mycase("SERVICE_DONE_EXECUTING_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                type = data.readInt()
                startId = data.readInt()
                res = data.readInt()
                return self.callFunction("serviceDoneExecuting", token, type, startId, res)
                # {'startId': 'int', 'token': 'IBinder', 'type': 'int', 'res': 'int'}
            if mycase("START_INSTRUMENTATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                className = 'ComponentName.readFromParcel(data)'
                profileFile = data.readString()
                fl = data.readInt()
                arguments = data.readBundle()
                b = data.readStrongBinder()
                w = self.interfaceResolver("IInstrumentationWatcher", b)
                b = data.readStrongBinder()
                c = self.interfaceResolver("IUiAutomationConnection", b)
                userId = data.readInt()
                abiOverride = data.readString()
                return self.callFunction("startInstrumentation", className, profileFile, fl, arguments, w, c, userId, abiOverride)
                # {'abiOverride': 'String', 'c': 'IUiAutomationConnection', 'b': 'IBinder', 'res': 'boolean', 'userId': 'int', 'className': 'ComponentName', 'arguments': 'Bundle', 'w': 'IInstrumentationWatcher', 'profileFile': 'String', 'fl': 'int'}
            if mycase("FINISH_INSTRUMENTATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                resultCode = data.readInt()
                results = data.readBundle()
                return self.callFunction("finishInstrumentation", app, resultCode, results)
                # {'app': 'IApplicationThread', 'b': 'IBinder', 'resultCode': 'int', 'results': 'Bundle'}
            if mycase("GET_CONFIGURATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getConfiguration")
                # {'config': 'Configuration'}
            if mycase("UPDATE_CONFIGURATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                config = self.creatorResolver("android.content.res.Configuration", data)
                return self.callFunction("updateConfiguration", config)
                # {'config': 'Configuration'}
            if mycase("SET_REQUESTED_ORIENTATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                requestedOrientation = data.readInt()
                return self.callFunction("setRequestedOrientation", token, requestedOrientation)
                # {'token': 'IBinder', 'requestedOrientation': 'int'}
            if mycase("GET_REQUESTED_ORIENTATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("getRequestedOrientation", token)
                # {'token': 'IBinder', 'req': 'int'}
            if mycase("GET_ACTIVITY_CLASS_FOR_TOKEN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("getActivityClassForToken", token)
                # {'token': 'IBinder', 'cn': 'ComponentName'}
            if mycase("GET_PACKAGE_FOR_TOKEN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                reply.writeNoException()
                return self.callFunction("getPackageForToken", token)
                # {'token': 'IBinder'}
            if mycase("GET_INTENT_SENDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                type = data.readInt()
                packageName = data.readString()
                token = data.readStrongBinder()
                resultWho = data.readString()
                requestCode = data.readInt()
                if (data.readInt() != 0):
                    requestIntents = data.createTypedArray("Intent")
                    requestResolvedTypes = data.createStringArray()
                else:
                    requestIntents = None
                    requestResolvedTypes = None
                fl = data.readInt()
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                userId = data.readInt()
                return self.callFunction("getIntentSender", type, packageName, token, resultWho, requestCode, requestIntents, requestResolvedTypes, fl, options, userId)
                # {'resultWho': 'String', 'fl': 'int', 'packageName': 'String', 'userId': 'int', 'requestIntents': 'Intent', 'token': 'IBinder', 'requestCode': 'int', 'ELSE:': {}, 'res': 'IIntentSender', 'type': 'int', 'options': 'Bundle', 'requestResolvedTypes': 'String', 'IF': {}}
            if mycase("CANCEL_INTENT_SENDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                r = self.interfaceResolver("IIntentSender", data.readStrongBinder())
                return self.callFunction("cancelIntentSender", r)
                # {'r': 'IIntentSender'}
            if mycase("GET_PACKAGE_FOR_INTENT_SENDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                r = self.interfaceResolver("IIntentSender", data.readStrongBinder())
                return self.callFunction("getPackageForIntentSender", r)
                # {'res': 'String', 'r': 'IIntentSender'}
            if mycase("GET_UID_FOR_INTENT_SENDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                r = self.interfaceResolver("IIntentSender", data.readStrongBinder())
                return self.callFunction("getUidForIntentSender", r)
                # {'res': 'int', 'r': 'IIntentSender'}
            if mycase("HANDLE_INCOMING_USER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                callingPid = data.readInt()
                callingUid = data.readInt()
                userId = data.readInt()
                allowAll = (data.readInt() != 0)
                requireFull = (data.readInt() != 0)
                name = data.readString()
                callerPackage = data.readString()
                return self.callFunction("handleIncomingUser", callingPid, callingUid, userId, allowAll, requireFull, name, callerPackage)
                # {'callingUid': 'int', 'name': 'String', 'allowAll': 'boolean', 'res': 'int', 'userId': 'int', 'requireFull': 'boolean', 'callerPackage': 'String', 'callingPid': 'int'}
            if mycase("SET_PROCESS_LIMIT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                max = data.readInt()
                return self.callFunction("setProcessLimit", max)
                # {'max': 'int'}
            if mycase("GET_PROCESS_LIMIT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getProcessLimit")
                # {'limit': 'int'}
            if mycase("SET_PROCESS_FOREGROUND_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                pid = data.readInt()
                isForeground = (data.readInt() != 0)
                return self.callFunction("setProcessForeground", token, pid, isForeground)
                # {'token': 'IBinder', 'pid': 'int', 'isForeground': 'boolean'}
            if mycase("CHECK_PERMISSION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                perm = data.readString()
                pid = data.readInt()
                uid = data.readInt()
                return self.callFunction("checkPermission", perm, pid, uid)
                # {'res': 'int', 'pid': 'int', 'uid': 'int', 'perm': 'String'}
            if mycase("CHECK_PERMISSION_WITH_TOKEN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                perm = data.readString()
                pid = data.readInt()
                uid = data.readInt()
                token = data.readStrongBinder()
                return self.callFunction("checkPermissionWithToken", perm, pid, uid, token)
                # {'res': 'int', 'token': 'IBinder', 'pid': 'int', 'uid': 'int', 'perm': 'String'}
            if mycase("CHECK_URI_PERMISSION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                uri = self.creatorResolver("android.net.Uri", data)
                pid = data.readInt()
                uid = data.readInt()
                mode = data.readInt()
                userId = data.readInt()
                callerToken = data.readStrongBinder()
                return self.callFunction("checkUriPermission", uri, pid, uid, mode, userId, callerToken)
                # {'uid': 'int', 'pid': 'int', 'userId': 'int', 'uri': 'Uri', 'mode': 'int', 'res': 'int', 'callerToken': 'IBinder'}
            if mycase("CLEAR_APP_DATA_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                packageName = data.readString()
                observer = self.interfaceResolver("IPackageDataObserver", data.readStrongBinder())
                userId = data.readInt()
                return self.callFunction("clearApplicationUserData", packageName, observer, userId)
                # {'res': 'boolean', 'packageName': 'String', 'userId': 'int', 'observer': 'IPackageDataObserver'}
            if mycase("GRANT_URI_PERMISSION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                targetPkg = data.readString()
                uri = self.creatorResolver("android.net.Uri", data)
                mode = data.readInt()
                userId = data.readInt()
                return self.callFunction("grantUriPermission", app, targetPkg, uri, mode, userId)
                # {'b': 'IBinder', 'app': 'IApplicationThread', 'userId': 'int', 'uri': 'Uri', 'targetPkg': 'String', 'mode': 'int'}
            if mycase("REVOKE_URI_PERMISSION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                uri = self.creatorResolver("android.net.Uri", data)
                mode = data.readInt()
                userId = data.readInt()
                return self.callFunction("revokeUriPermission", app, uri, mode, userId)
                # {'app': 'IApplicationThread', 'b': 'IBinder', 'userId': 'int', 'uri': 'Uri', 'mode': 'int'}
            if mycase("TAKE_PERSISTABLE_URI_PERMISSION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                uri = self.creatorResolver("android.net.Uri", data)
                mode = data.readInt()
                userId = data.readInt()
                return self.callFunction("takePersistableUriPermission", uri, mode, userId)
                # {'userId': 'int', 'uri': 'Uri', 'mode': 'int'}
            if mycase("RELEASE_PERSISTABLE_URI_PERMISSION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                uri = self.creatorResolver("android.net.Uri", data)
                mode = data.readInt()
                userId = data.readInt()
                return self.callFunction("releasePersistableUriPermission", uri, mode, userId)
                # {'userId': 'int', 'uri': 'Uri', 'mode': 'int'}
            if mycase("GET_PERSISTED_URI_PERMISSIONS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                packageName = data.readString()
                incoming = (data.readInt() != 0)
                return self.callFunction("getPersistedUriPermissions", packageName, incoming)
                # {'perms': 'ParceledListSlice<UriPermission>', 'packageName': 'String', 'incoming': 'boolean'}
            if mycase("SHOW_WAITING_FOR_DEBUGGER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                waiting = (data.readInt() != 0)
                return self.callFunction("showWaitingForDebugger", app, waiting)
                # {'app': 'IApplicationThread', 'b': 'IBinder', 'waiting': 'boolean'}
            if mycase("GET_MEMORY_INFO_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                mi = self.newInstance("ActivityManager.MemoryInfo", )
                return self.callFunction("getMemoryInfo", mi)
                # {'mi': 'ActivityManager.MemoryInfo'}
            if mycase("UNHANDLED_BACK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("unhandledBack")
                # {}
            if mycase("OPEN_CONTENT_URI_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                uri = 'Uri.parse(data.readString())'
                return self.callFunction("openContentUri", uri)
                # {'uri': 'Uri', 'pfd': 'ParcelFileDescriptor'}
            if mycase("SET_LOCK_SCREEN_SHOWN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("setLockScreenShown", (data.readInt() != 0))
                # {}
            if mycase("SET_DEBUG_APP_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pn = data.readString()
                wfd = (data.readInt() != 0)
                per = (data.readInt() != 0)
                return self.callFunction("setDebugApp", pn, wfd, per)
                # {'pn': 'String', 'per': 'boolean', 'wfd': 'boolean'}
            if mycase("SET_ALWAYS_FINISH_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                enabled = (data.readInt() != 0)
                return self.callFunction("setAlwaysFinish", enabled)
                # {'enabled': 'boolean'}
            if mycase("SET_ACTIVITY_CONTROLLER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                watcher = self.interfaceResolver("IActivityController", data.readStrongBinder())
                return self.callFunction("setActivityController", watcher)
                # {'watcher': 'IActivityController'}
            if mycase("ENTER_SAFE_MODE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("enterSafeMode")
                # {}
            if mycase("NOTE_WAKEUP_ALARM_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                _is = self.interfaceResolver("IIntentSender", data.readStrongBinder())
                sourceUid = data.readInt()
                sourcePkg = data.readString()
                return self.callFunction("noteWakeupAlarm", _is, sourceUid, sourcePkg)
                # {'sourcePkg': 'String', '_is': 'IIntentSender', 'sourceUid': 'int'}
            if mycase("KILL_PIDS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pids = data.createIntArray()
                reason = data.readString()
                secure = (data.readInt() != 0)
                return self.callFunction("killPids", pids, reason, secure)
                # {'res': 'boolean', 'pids': 'int', 'reason': 'String', 'secure': 'boolean'}
            if mycase("KILL_PROCESSES_BELOW_FOREGROUND_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                reason = data.readString()
                return self.callFunction("killProcessesBelowForeground", reason)
                # {'res': 'boolean', 'reason': 'String'}
            if mycase("HANDLE_APPLICATION_CRASH_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                app = data.readStrongBinder()
                ci = self.newInstance("ApplicationErrorReport.CrashInfo", data)
                return self.callFunction("handleApplicationCrash", app, ci)
                # {'app': 'IBinder', 'ci': 'ApplicationErrorReport.CrashInfo'}
            if mycase("HANDLE_APPLICATION_WTF_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                app = data.readStrongBinder()
                tag = data.readString()
                system = (data.readInt() != 0)
                ci = self.newInstance("ApplicationErrorReport.CrashInfo", data)
                return self.callFunction("handleApplicationWtf", app, tag, system, ci)
                # {'res': 'boolean', 'app': 'IBinder', 'tag': 'String', 'ci': 'ApplicationErrorReport.CrashInfo', 'system': 'boolean'}
            if mycase("HANDLE_APPLICATION_STRICT_MODE_VIOLATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                app = data.readStrongBinder()
                violationMask = data.readInt()
                info = self.newInstance("StrictMode.ViolationInfo", data)
                return self.callFunction("handleApplicationStrictModeViolation", app, violationMask, info)
                # {'violationMask': 'int', 'info': 'StrictMode.ViolationInfo', 'app': 'IBinder'}
            if mycase("SIGNAL_PERSISTENT_PROCESSES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                sig = data.readInt()
                return self.callFunction("signalPersistentProcesses", sig)
                # {'sig': 'int'}
            if mycase("KILL_BACKGROUND_PROCESSES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                packageName = data.readString()
                userId = data.readInt()
                return self.callFunction("killBackgroundProcesses", packageName, userId)
                # {'packageName': 'String', 'userId': 'int'}
            if mycase("KILL_ALL_BACKGROUND_PROCESSES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("killAllBackgroundProcesses")
                # {}
            if mycase("FORCE_STOP_PACKAGE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                packageName = data.readString()
                userId = data.readInt()
                return self.callFunction("forceStopPackage", packageName, userId)
                # {'packageName': 'String', 'userId': 'int'}
            if mycase("GET_MY_MEMORY_STATE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                info = self.newInstance("ActivityManager.RunningAppProcessInfo", )
                return self.callFunction("getMyMemoryState", info)
                # {'info': 'ActivityManager.RunningAppProcessInfo'}
            if mycase("GET_DEVICE_CONFIGURATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getDeviceConfigurationInfo")
                # {'config': 'ConfigurationInfo'}
            if mycase("PROFILE_CONTROL_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                process = data.readString()
                userId = data.readInt()
                start = (data.readInt() != 0)
                profileType = data.readInt()
                profilerInfo = self.creatorResolver("android.app.ProfilerInfo", data) if (data.readInt() != 0) else None
                return self.callFunction("profileControl", process, userId, start, profilerInfo, profileType)
                # {'process': 'String', 'res': 'boolean', 'userId': 'int', 'start': 'boolean', 'profileType': 'int', 'profilerInfo': 'ProfilerInfo'}
            if mycase("SHUTDOWN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("shutdown", data.readInt())
                # {'res': 'boolean'}
            if mycase("STOP_APP_SWITCHES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("stopAppSwitches")
                # {}
            if mycase("RESUME_APP_SWITCHES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("resumeAppSwitches")
                # {}
            if mycase("PEEK_SERVICE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                service = self.creatorResolver("android.content.Intent", data)
                resolvedType = data.readString()
                return self.callFunction("peekService", service, resolvedType)
                # {'binder': 'IBinder', 'resolvedType': 'String', 'service': 'Intent'}
            if mycase("START_BACKUP_AGENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                info = self.creatorResolver("android.content.pm.ApplicationInfo", data)
                backupRestoreMode = data.readInt()
                return self.callFunction("bindBackupAgent", info, backupRestoreMode)
                # {'info': 'ApplicationInfo', 'backupRestoreMode': 'int', 'success': 'boolean'}
            if mycase("BACKUP_AGENT_CREATED_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                packageName = data.readString()
                agent = data.readStrongBinder()
                return self.callFunction("backupAgentCreated", packageName, agent)
                # {'packageName': 'String', 'agent': 'IBinder'}
            if mycase("UNBIND_BACKUP_AGENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                info = self.creatorResolver("android.content.pm.ApplicationInfo", data)
                return self.callFunction("unbindBackupAgent", info)
                # {'info': 'ApplicationInfo'}
            if mycase("ADD_PACKAGE_DEPENDENCY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                packageName = data.readString()
                return self.callFunction("addPackageDependency", packageName)
                # {'packageName': 'String'}
            if mycase("KILL_APPLICATION_WITH_APPID_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pkg = data.readString()
                appid = data.readInt()
                reason = data.readString()
                return self.callFunction("killApplicationWithAppId", pkg, appid, reason)
                # {'reason': 'String', 'pkg': 'String', 'appid': 'int'}
            if mycase("CLOSE_SYSTEM_DIALOGS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                reason = data.readString()
                return self.callFunction("closeSystemDialogs", reason)
                # {'reason': 'String'}
            if mycase("GET_PROCESS_MEMORY_INFO_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pids = data.createIntArray()
                return self.callFunction("getProcessMemoryInfo", pids)
                # {'res': 'Debug.MemoryInfo', 'pids': 'int'}
            if mycase("KILL_APPLICATION_PROCESS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                processName = data.readString()
                uid = data.readInt()
                return self.callFunction("killApplicationProcess", processName, uid)
                # {'processName': 'String', 'uid': 'int'}
            if mycase("OVERRIDE_PENDING_TRANSITION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                packageName = data.readString()
                enterAnim = data.readInt()
                exitAnim = data.readInt()
                return self.callFunction("overridePendingTransition", token, packageName, enterAnim, exitAnim)
                # {'token': 'IBinder', 'enterAnim': 'int', 'packageName': 'String', 'exitAnim': 'int'}
            if mycase("IS_USER_A_MONKEY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("isUserAMonkey")
                # {'areThey': 'boolean'}
            if mycase("SET_USER_IS_MONKEY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                monkey = (data.readInt() == 1)
                return self.callFunction("setUserIsMonkey", monkey)
                # {'monkey': 'boolean'}
            if mycase("FINISH_HEAVY_WEIGHT_APP_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("finishHeavyWeightApp")
                # {}
            if mycase("IS_IMMERSIVE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("isImmersive", token)
                # {'token': 'IBinder', 'isit': 'boolean'}
            if mycase("IS_TOP_OF_TASK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("isTopOfTask", token)
                # {'token': 'IBinder', 'isTopOfTask': 'boolean'}
            if mycase("CONVERT_FROM_TRANSLUCENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("convertFromTranslucent", token)
                # {'token': 'IBinder', 'converted': 'boolean'}
            if mycase("CONVERT_TO_TRANSLUCENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                if (data.readInt() == 0):
                    bundle = None
                else:
                    bundle = data.readBundle()
                options = None if (bundle == None) else self.newInstance("ActivityOptions", bundle)
                return self.callFunction("convertToTranslucent", token, options)
                # {'bundle': 'Bundle', 'token': 'IBinder', 'converted': 'boolean', 'options': 'ActivityOptions', 'ELSE:': {}, 'IF': {}}
            if mycase("GET_ACTIVITY_OPTIONS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("getActivityOptions", token)
                # {'token': 'IBinder', 'options': 'ActivityOptions'}
            if mycase("SET_IMMERSIVE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                imm = (data.readInt() == 1)
                return self.callFunction("setImmersive", token, imm)
                # {'token': 'IBinder', 'imm': 'boolean'}
            if mycase("IS_TOP_ACTIVITY_IMMERSIVE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("isTopActivityImmersive")
                # {'isit': 'boolean'}
            if mycase("CRASH_APPLICATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                uid = data.readInt()
                initialPid = data.readInt()
                packageName = data.readString()
                message = data.readString()
                return self.callFunction("crashApplication", uid, initialPid, packageName, message)
                # {'initialPid': 'int', 'packageName': 'String', 'message': 'String', 'uid': 'int'}
            if mycase("GET_PROVIDER_MIME_TYPE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                uri = self.creatorResolver("android.net.Uri", data)
                userId = data.readInt()
                return self.callFunction("getProviderMimeType", uri, userId)
                # {'type': 'String', 'userId': 'int', 'uri': 'Uri'}
            if mycase("NEW_URI_PERMISSION_OWNER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                name = data.readString()
                return self.callFunction("newUriPermissionOwner", name)
                # {'name': 'String', 'perm': 'IBinder'}
            if mycase("GRANT_URI_PERMISSION_FROM_OWNER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                owner = data.readStrongBinder()
                fromUid = data.readInt()
                targetPkg = data.readString()
                uri = self.creatorResolver("android.net.Uri", data)
                mode = data.readInt()
                sourceUserId = data.readInt()
                targetUserId = data.readInt()
                return self.callFunction("grantUriPermissionFromOwner", owner, fromUid, targetPkg, uri, mode, sourceUserId, targetUserId)
                # {'fromUid': 'int', 'targetUserId': 'int', 'sourceUserId': 'int', 'uri': 'Uri', 'targetPkg': 'String', 'mode': 'int', 'owner': 'IBinder'}
            if mycase("REVOKE_URI_PERMISSION_FROM_OWNER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                owner = data.readStrongBinder()
                uri = None
                if (data.readInt() != 0):
                    uri = self.creatorResolver("android.net.Uri", data)
                mode = data.readInt()
                userId = data.readInt()
                return self.callFunction("revokeUriPermissionFromOwner", owner, uri, mode, userId)
                # {'owner': 'IBinder', 'mode': 'int', 'userId': 'int', 'uri': 'Uri', 'IF': {}}
            if mycase("CHECK_GRANT_URI_PERMISSION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                callingUid = data.readInt()
                targetPkg = data.readString()
                uri = self.creatorResolver("android.net.Uri", data)
                modeFlags = data.readInt()
                userId = data.readInt()
                return self.callFunction("checkGrantUriPermission", callingUid, targetPkg, uri, modeFlags, userId)
                # {'callingUid': 'int', 'res': 'int', 'userId': 'int', 'uri': 'Uri', 'targetPkg': 'String', 'modeFlags': 'int'}
            if mycase("DUMP_HEAP_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                process = data.readString()
                userId = data.readInt()
                managed = (data.readInt() != 0)
                path = data.readString()
                fd = self.creatorResolver("android.os.ParcelFileDescriptor", data) if (data.readInt() != 0) else None
                return self.callFunction("dumpHeap", process, userId, managed, path, fd)
                # {'managed': 'boolean', 'process': 'String', 'res': 'boolean', 'userId': 'int', 'fd': 'ParcelFileDescriptor', 'path': 'String'}
            if mycase("START_ACTIVITIES_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                b = data.readStrongBinder()
                app = self.interfaceResolver("ApplicationThreadNativ", b)
                callingPackage = data.readString()
                intents = data.createTypedArray("Intent")
                resolvedTypes = data.createStringArray()
                resultTo = data.readStrongBinder()
                options = self.creatorResolver("android.os.Bundle", data) if (data.readInt() != 0) else None
                userId = data.readInt()
                return self.callFunction("startActivities", app, callingPackage, intents, resolvedTypes, resultTo, options, userId)
                # {'resultTo': 'IBinder', 'intents': 'Intent', 'b': 'IBinder', 'callingPackage': 'String', 'app': 'IApplicationThread', 'userId': 'int', 'resolvedTypes': 'String', 'result': 'int', 'options': 'Bundle'}
            if mycase("GET_FRONT_ACTIVITY_SCREEN_COMPAT_MODE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getFrontActivityScreenCompatMode")
                # {'mode': 'int'}
            if mycase("SET_FRONT_ACTIVITY_SCREEN_COMPAT_MODE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                mode = data.readInt()
                return self.callFunction("setFrontActivityScreenCompatMode", mode)
                # {'mode': 'int'}
            if mycase("GET_PACKAGE_SCREEN_COMPAT_MODE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pkg = data.readString()
                return self.callFunction("getPackageScreenCompatMode", pkg)
                # {'pkg': 'String', 'mode': 'int'}
            if mycase("SET_PACKAGE_SCREEN_COMPAT_MODE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pkg = data.readString()
                mode = data.readInt()
                return self.callFunction("setPackageScreenCompatMode", pkg, mode)
                # {'pkg': 'String', 'mode': 'int'}
            if mycase("SWITCH_USER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                userid = data.readInt()
                return self.callFunction("switchUser", userid)
                # {'userid': 'int', 'result': 'boolean'}
            if mycase("START_USER_IN_BACKGROUND_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                userid = data.readInt()
                return self.callFunction("startUserInBackground", userid)
                # {'userid': 'int', 'result': 'boolean'}
            if mycase("STOP_USER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                userid = data.readInt()
                callback = self.interfaceResolver("IStopUserCallback", data.readStrongBinder())
                return self.callFunction("stopUser", userid, callback)
                # {'callback': 'IStopUserCallback', 'userid': 'int', 'result': 'int'}
            if mycase("GET_CURRENT_USER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getCurrentUser")
                # {'userInfo': 'UserInfo'}
            if mycase("IS_USER_RUNNING_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                userid = data.readInt()
                orStopping = (data.readInt() != 0)
                return self.callFunction("isUserRunning", userid, orStopping)
                # {'orStopping': 'boolean', 'userid': 'int', 'result': 'boolean'}
            if mycase("GET_RUNNING_USER_IDS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getRunningUserIds")
                # {'result': 'int'}
            if mycase("REMOVE_TASK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                taskId = data.readInt()
                return self.callFunction("removeTask", taskId)
                # {'result': 'boolean', 'taskId': 'int'}
            if mycase("REGISTER_PROCESS_OBSERVER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                observer = self.interfaceResolver("IProcessObserver", data.readStrongBinder())
                return self.callFunction("registerProcessObserver", observer)
                # {'observer': 'IProcessObserver'}
            if mycase("UNREGISTER_PROCESS_OBSERVER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                observer = self.interfaceResolver("IProcessObserver", data.readStrongBinder())
                return self.callFunction("unregisterProcessObserver", observer)
                # {'observer': 'IProcessObserver'}
            if mycase("GET_PACKAGE_ASK_SCREEN_COMPAT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pkg = data.readString()
                return self.callFunction("getPackageAskScreenCompat", pkg)
                # {'ask': 'boolean', 'pkg': 'String'}
            if mycase("SET_PACKAGE_ASK_SCREEN_COMPAT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pkg = data.readString()
                ask = (data.readInt() != 0)
                return self.callFunction("setPackageAskScreenCompat", pkg, ask)
                # {'ask': 'boolean', 'pkg': 'String'}
            if mycase("IS_INTENT_SENDER_TARGETED_TO_PACKAGE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                r = self.interfaceResolver("IIntentSender", data.readStrongBinder())
                return self.callFunction("isIntentSenderTargetedToPackage", r)
                # {'res': 'boolean', 'r': 'IIntentSender'}
            if mycase("IS_INTENT_SENDER_AN_ACTIVITY_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                r = self.interfaceResolver("IIntentSender", data.readStrongBinder())
                return self.callFunction("isIntentSenderAnActivity", r)
                # {'res': 'boolean', 'r': 'IIntentSender'}
            if mycase("GET_INTENT_FOR_INTENT_SENDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                r = self.interfaceResolver("IIntentSender", data.readStrongBinder())
                return self.callFunction("getIntentForIntentSender", r)
                # {'r': 'IIntentSender', 'intent': 'Intent'}
            if mycase("GET_TAG_FOR_INTENT_SENDER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                r = self.interfaceResolver("IIntentSender", data.readStrongBinder())
                prefix = data.readString()
                return self.callFunction("getTagForIntentSender", r, prefix)
                # {'prefix': 'String', 'r': 'IIntentSender', 'tag': 'String'}
            if mycase("UPDATE_PERSISTENT_CONFIGURATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                config = self.creatorResolver("android.content.res.Configuration", data)
                return self.callFunction("updatePersistentConfiguration", config)
                # {'config': 'Configuration'}
            if mycase("GET_PROCESS_PSS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pids = data.createIntArray()
                return self.callFunction("getProcessPss", pids)
                # {'pss': 'long', 'pids': 'int'}
            if mycase("SHOW_BOOT_MESSAGE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                msg = self.creatorResolver("TextUtils.CHAR_SEQUENCE_CREATO", data)
                always = (data.readInt() != 0)
                return self.callFunction("showBootMessage", msg, always)
                # {'msg': 'CharSequence', 'always': 'boolean'}
            if mycase("KEYGUARD_WAITING_FOR_ACTIVITY_DRAWN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("keyguardWaitingForActivityDrawn")
                # {}
            if mycase("SHOULD_UP_RECREATE_TASK_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                destAffinity = data.readString()
                return self.callFunction("shouldUpRecreateTask", token, destAffinity)
                # {'res': 'boolean', 'token': 'IBinder', 'destAffinity': 'String'}
            if mycase("NAVIGATE_UP_TO_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                target = self.creatorResolver("android.content.Intent", data)
                resultCode = data.readInt()
                resultData = None
                if (data.readInt() != 0):
                    resultData = self.creatorResolver("android.content.Intent", data)
                return self.callFunction("navigateUpTo", token, target, resultCode, resultData)
                # {'target': 'Intent', 'resultData': 'Intent', 'token': 'IBinder', 'res': 'boolean', 'resultCode': 'int', 'IF': {}}
            if mycase("GET_LAUNCHED_FROM_UID_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("getLaunchedFromUid", token)
                # {'res': 'int', 'token': 'IBinder'}
            if mycase("GET_LAUNCHED_FROM_PACKAGE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("getLaunchedFromPackage", token)
                # {'res': 'String', 'token': 'IBinder'}
            if mycase("REGISTER_USER_SWITCH_OBSERVER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                observer = self.interfaceResolver("IUserSwitchObserver", data.readStrongBinder())
                return self.callFunction("registerUserSwitchObserver", observer)
                # {'observer': 'IUserSwitchObserver'}
            if mycase("UNREGISTER_USER_SWITCH_OBSERVER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                observer = self.interfaceResolver("IUserSwitchObserver", data.readStrongBinder())
                return self.callFunction("unregisterUserSwitchObserver", observer)
                # {'observer': 'IUserSwitchObserver'}
            if mycase("REQUEST_BUG_REPORT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("requestBugReport")
                # {}
            if mycase("INPUT_DISPATCHING_TIMED_OUT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                pid = data.readInt()
                aboveSystem = (data.readInt() != 0)
                reason = data.readString()
                return self.callFunction("inputDispatchingTimedOut", pid, aboveSystem, reason)
                # {'res': 'long', 'reason': 'String', 'aboveSystem': 'boolean', 'pid': 'int'}
            if mycase("GET_ASSIST_CONTEXT_EXTRAS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                requestType = data.readInt()
                return self.callFunction("getAssistContextExtras", requestType)
                # {'requestType': 'int', 'res': 'Bundle'}
            if mycase("REPORT_ASSIST_CONTEXT_EXTRAS_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                extras = data.readBundle()
                return self.callFunction("reportAssistContextExtras", token, extras)
                # {'token': 'IBinder', 'extras': 'Bundle'}
            if mycase("LAUNCH_ASSIST_INTENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                intent = self.creatorResolver("android.content.Intent", data)
                requestType = data.readInt()
                hint = data.readString()
                userHandle = data.readInt()
                return self.callFunction("launchAssistIntent", intent, requestType, hint, userHandle)
                # {'requestType': 'int', 'res': 'boolean', 'intent': 'Intent', 'userHandle': 'int', 'hint': 'String'}
            if mycase("KILL_UID_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                uid = data.readInt()
                reason = data.readString()
                return self.callFunction("killUid", uid, reason)
                # {'reason': 'String', 'uid': 'int'}
            if mycase("HANG_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                who = data.readStrongBinder()
                allowRestart = (data.readInt() != 0)
                return self.callFunction("hang", who, allowRestart)
                # {'who': 'IBinder', 'allowRestart': 'boolean'}
            if mycase("REPORT_ACTIVITY_FULLY_DRAWN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("reportActivityFullyDrawn", token)
                # {'token': 'IBinder'}
            if mycase("NOTIFY_ACTIVITY_DRAWN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("notifyActivityDrawn", token)
                # {'token': 'IBinder'}
            if mycase("RESTART_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("restart")
                # {}
            if mycase("PERFORM_IDLE_MAINTENANCE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("performIdleMaintenance")
                # {}
            if mycase("CREATE_ACTIVITY_CONTAINER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                parentActivityToken = data.readStrongBinder()
                callback = self.interfaceResolver("IActivityContainerCallback", data.readStrongBinder())
                return self.callFunction("createActivityContainer", parentActivityToken, callback)
                # {'callback': 'IActivityContainerCallback', 'parentActivityToken': 'IBinder', 'activityContainer': 'IActivityContainer'}
            if mycase("DELETE_ACTIVITY_CONTAINER_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                activityContainer = self.interfaceResolver("IActivityContainer", data.readStrongBinder())
                return self.callFunction("deleteActivityContainer", activityContainer)
                # {'activityContainer': 'IActivityContainer'}
            if mycase("GET_ACTIVITY_DISPLAY_ID_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                activityToken = data.readStrongBinder()
                return self.callFunction("getActivityDisplayId", activityToken)
                # {'displayId': 'int', 'activityToken': 'IBinder'}
            if mycase("GET_HOME_ACTIVITY_TOKEN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("getHomeActivityToken")
                # {'homeActivityToken': 'IBinder'}
            if mycase("START_LOCK_TASK_BY_TASK_ID_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                taskId = data.readInt()
                return self.callFunction("startLockTaskMode", taskId)
                # {'taskId': 'int'}
            if mycase("START_LOCK_TASK_BY_TOKEN_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("startLockTaskMode", token)
                # {'token': 'IBinder'}
            if mycase("START_LOCK_TASK_BY_CURRENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("startLockTaskModeOnCurrent")
                # {}
            if mycase("STOP_LOCK_TASK_MODE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("stopLockTaskMode")
                # {}
            if mycase("STOP_LOCK_TASK_BY_CURRENT_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("stopLockTaskModeOnCurrent")
                # {}
            if mycase("IS_IN_LOCK_TASK_MODE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("isInLockTaskMode")
                # {'isInLockTaskMode': 'boolean'}
            if mycase("SET_TASK_DESCRIPTION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                values = self.creatorResolver("ActivityManager.TaskDescription", data)
                return self.callFunction("setTaskDescription", token, values)
                # {'token': 'IBinder', 'values': 'ActivityManager.TaskDescription'}
            if mycase("GET_TASK_DESCRIPTION_ICON_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                filename = data.readString()
                return self.callFunction("getTaskDescriptionIcon", filename)
                # {'icon': 'Bitmap', 'filename': 'String'}
            if mycase("START_IN_PLACE_ANIMATION_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                if (data.readInt() == 0):
                    bundle = None
                else:
                    bundle = data.readBundle()
                options = None if (bundle == None) else self.newInstance("ActivityOptions", bundle)
                return self.callFunction("startInPlaceAnimationOnFrontMostApplication", options)
                # {'options': 'ActivityOptions', 'ELSE:': {}, 'bundle': 'Bundle', 'IF': {}}
            if mycase("REQUEST_VISIBLE_BEHIND_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                enable = (data.readInt() > 0)
                return self.callFunction("requestVisibleBehind", token, enable)
                # {'token': 'IBinder', 'enable': 'boolean', 'success': 'boolean'}
            if mycase("IS_BACKGROUND_VISIBLE_BEHIND_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("isBackgroundVisibleBehind", token)
                # {'token': 'IBinder', 'enabled': 'boolean'}
            if mycase("BACKGROUND_RESOURCES_RELEASED_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("backgroundResourcesReleased", token)
                # {'token': 'IBinder'}
            if mycase("NOTIFY_LAUNCH_TASK_BEHIND_COMPLETE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("notifyLaunchTaskBehindComplete", token)
                # {'token': 'IBinder'}
            if mycase("NOTIFY_ENTER_ANIMATION_COMPLETE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                token = data.readStrongBinder()
                return self.callFunction("notifyEnterAnimationComplete", token)
                # {'token': 'IBinder'}
            if mycase("BOOT_ANIMATION_COMPLETE_TRANSACTION"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("bootAnimationComplete")
                # {}
            if mycase("SYSTEM_BACKUP_RESTORED"):
                data.enforceInterface(IActivityManager.descriptor)
                return self.callFunction("systemBackupRestored")
                # {}
