from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITrustAgentService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.trust.ITrustAgentService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.trust.ITrustAgentService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onUnlockAttempt"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onUnlockAttempt", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onTrustTimeout"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onTrustTimeout")
                # {}
            if mycase("TRANSACTION_onDeviceLocked"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDeviceLocked")
                # {}
            if mycase("TRANSACTION_onDeviceUnlocked"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDeviceUnlocked")
                # {}
            if mycase("TRANSACTION_onConfigure"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.os.PersistableBundle")
                _arg1 = data.readStrongBinder()
                return self.callFunction("onConfigure", _arg0, _arg1)
                # {'_arg0': 'java.util.List<android.os.PersistableBundle>', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_setCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.trust.ITrustAgentServiceCallback", data.readStrongBinder())
                return self.callFunction("setCallback", _arg0)
                # {'_arg0': 'android.service.trust.ITrustAgentServiceCallback'}
