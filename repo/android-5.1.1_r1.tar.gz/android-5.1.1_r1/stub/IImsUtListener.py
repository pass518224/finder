from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsUtListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsUtListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsUtListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_utConfigurationUpdated"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsUt", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("utConfigurationUpdated", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsUt', '_arg1': 'int'}
            if mycase("TRANSACTION_utConfigurationUpdateFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsUt", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg2 = None
                return self.callFunction("utConfigurationUpdateFailed", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsReasonInfo', '_arg0': 'com.android.ims.internal.IImsUt', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_utConfigurationQueried"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsUt", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("utConfigurationQueried", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'com.android.ims.internal.IImsUt', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_utConfigurationQueryFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsUt", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg2 = None
                return self.callFunction("utConfigurationQueryFailed", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsReasonInfo', '_arg0': 'com.android.ims.internal.IImsUt', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_utConfigurationCallBarringQueried"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsUt", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.createTypedArray("com.android.ims.ImsSsInfo")
                return self.callFunction("utConfigurationCallBarringQueried", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsSsInfo', '_arg0': 'com.android.ims.internal.IImsUt', '_arg1': 'int'}
            if mycase("TRANSACTION_utConfigurationCallForwardQueried"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsUt", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.createTypedArray("com.android.ims.ImsCallForwardInfo")
                return self.callFunction("utConfigurationCallForwardQueried", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsCallForwardInfo', '_arg0': 'com.android.ims.internal.IImsUt', '_arg1': 'int'}
            if mycase("TRANSACTION_utConfigurationCallWaitingQueried"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsUt", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.createTypedArray("com.android.ims.ImsSsInfo")
                return self.callFunction("utConfigurationCallWaitingQueried", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsSsInfo', '_arg0': 'com.android.ims.internal.IImsUt', '_arg1': 'int'}
