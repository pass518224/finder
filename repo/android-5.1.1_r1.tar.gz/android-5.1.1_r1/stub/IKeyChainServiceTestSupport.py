from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IKeyChainServiceTestSupport:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.keychain.tests.support.IKeyChainServiceTestSupport"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.keychain.tests.support.IKeyChainServiceTestSupport"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_keystoreReset"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("keystoreReset")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_keystorePassword"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("keystorePassword", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_keystorePut"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createByteArray()
                return self.callFunction("keystorePut", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'byte'}
            if mycase("TRANSACTION_keystoreImportKey"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createByteArray()
                return self.callFunction("keystoreImportKey", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'byte'}
            if mycase("TRANSACTION_revokeAppPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("revokeAppPermission", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_grantAppPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("grantAppPermission", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
