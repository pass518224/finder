from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccessibilityServiceConnection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.accessibilityservice.IAccessibilityServiceConnection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.accessibilityservice.IAccessibilityServiceConnection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setServiceInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.accessibilityservice.AccessibilityServiceInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("setServiceInfo", _arg0)
                # {'_arg0': 'android.accessibilityservice.AccessibilityServiceInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_findAccessibilityNodeInfoByAccessibilityId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg4 = data.readInt()
                _arg5 = data.readLong()
                return self.callFunction("findAccessibilityNodeInfoByAccessibilityId", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg0': 'int', '_arg1': 'long', '_arg4': 'int', '_arg5': 'long'}
            if mycase("TRANSACTION_findAccessibilityNodeInfosByText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readLong()
                return self.callFunction("findAccessibilityNodeInfosByText", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'boolean', '_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'int', '_arg1': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'long'}
            if mycase("TRANSACTION_findAccessibilityNodeInfosByViewId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readLong()
                return self.callFunction("findAccessibilityNodeInfosByViewId", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'boolean', '_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'int', '_arg1': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'long'}
            if mycase("TRANSACTION_findFocus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readLong()
                return self.callFunction("findFocus", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'long'}
            if mycase("TRANSACTION_focusSearch"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg5 = data.readLong()
                return self.callFunction("focusSearch", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'long', '_arg4': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', '_arg5': 'long'}
            if mycase("TRANSACTION_performAccessibilityAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                _arg5 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnectionCallback", data.readStrongBinder())
                _arg6 = data.readLong()
                return self.callFunction("performAccessibilityAction", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'android.os.Bundle', '_arg0': 'int', '_arg1': 'long', '_arg6': 'long', '_arg4': 'int', '_arg5': 'android.view.accessibility.IAccessibilityInteractionConnectionCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getWindow"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getWindow", _arg0)
                # {'_arg0': 'int', '_result': 'android.view.accessibility.AccessibilityWindowInfo'}
            if mycase("TRANSACTION_getWindows"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWindows")
                # {'_result': 'java.util.List<android.view.accessibility.AccessibilityWindowInfo>'}
            if mycase("TRANSACTION_getServiceInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getServiceInfo")
                # {'_result': 'android.accessibilityservice.AccessibilityServiceInfo'}
            if mycase("TRANSACTION_performGlobalAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("performGlobalAction", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setOnKeyEventResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("setOnKeyEventResult", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
