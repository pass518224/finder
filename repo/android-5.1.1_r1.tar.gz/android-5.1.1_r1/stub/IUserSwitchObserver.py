from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IUserSwitchObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IUserSwitchObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IUserSwitchObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onUserSwitching"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.os.IRemoteCallback", data.readStrongBinder())
                return self.callFunction("onUserSwitching", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.IRemoteCallback'}
            if mycase("TRANSACTION_onUserSwitchComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onUserSwitchComplete", _arg0)
                # {'_arg0': 'int'}
