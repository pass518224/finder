from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerAdapter"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.bluetooth.IBluetoothManagerCallback", data.readStrongBinder())
                return self.callFunction("registerAdapter", _arg0)
                # {'_arg0': 'android.bluetooth.IBluetoothManagerCallback', '_result': 'android.bluetooth.IBluetooth'}
            if mycase("TRANSACTION_unregisterAdapter"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.bluetooth.IBluetoothManagerCallback", data.readStrongBinder())
                return self.callFunction("unregisterAdapter", _arg0)
                # {'_arg0': 'android.bluetooth.IBluetoothManagerCallback'}
            if mycase("TRANSACTION_registerStateChangeCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.bluetooth.IBluetoothStateChangeCallback", data.readStrongBinder())
                return self.callFunction("registerStateChangeCallback", _arg0)
                # {'_arg0': 'android.bluetooth.IBluetoothStateChangeCallback'}
            if mycase("TRANSACTION_unregisterStateChangeCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.bluetooth.IBluetoothStateChangeCallback", data.readStrongBinder())
                return self.callFunction("unregisterStateChangeCallback", _arg0)
                # {'_arg0': 'android.bluetooth.IBluetoothStateChangeCallback'}
            if mycase("TRANSACTION_isEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_enable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enable")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_enableNoAutoConnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enableNoAutoConnect")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_disable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("disable", _arg0)
                # {'_arg0': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_getBluetoothGatt"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getBluetoothGatt")
                # {'_result': 'android.bluetooth.IBluetoothGatt'}
            if mycase("TRANSACTION_bindBluetoothProfileService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.bluetooth.IBluetoothProfileServiceConnection", data.readStrongBinder())
                return self.callFunction("bindBluetoothProfileService", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'android.bluetooth.IBluetoothProfileServiceConnection'}
            if mycase("TRANSACTION_unbindBluetoothProfileService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.bluetooth.IBluetoothProfileServiceConnection", data.readStrongBinder())
                return self.callFunction("unbindBluetoothProfileService", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.bluetooth.IBluetoothProfileServiceConnection'}
            if mycase("TRANSACTION_getAddress"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAddress")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getName"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getName")
                # {'_result': 'java.lang.String'}
