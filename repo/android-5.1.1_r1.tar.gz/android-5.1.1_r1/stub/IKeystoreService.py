from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IKeystoreService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.security.keystore"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.security.keystore"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_test"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("test")
                # {'resultCode': 'int'}
