from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothPbap:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothPbap"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothPbap"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getClient"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getClient")
                # {'_result': 'android.bluetooth.BluetoothDevice'}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("connect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnect")
                # {}
            if mycase("TRANSACTION_isConnected"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("isConnected", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
