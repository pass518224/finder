from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IEmailServiceCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.emailcommon.service.IEmailServiceCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.emailcommon.service.IEmailServiceCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_loadAttachmentStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("loadAttachmentStatus", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'long', '_arg1': 'long'}
