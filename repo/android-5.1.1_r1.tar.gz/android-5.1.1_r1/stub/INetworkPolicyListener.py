from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetworkPolicyListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.INetworkPolicyListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.INetworkPolicyListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onUidRulesChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onUidRulesChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onMeteredIfacesChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                return self.callFunction("onMeteredIfacesChanged", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onRestrictBackgroundChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onRestrictBackgroundChanged", _arg0)
                # {'_arg0': 'boolean'}
