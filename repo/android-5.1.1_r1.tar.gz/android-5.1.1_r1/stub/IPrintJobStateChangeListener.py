from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrintJobStateChangeListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IPrintJobStateChangeListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IPrintJobStateChangeListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onPrintJobStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg0 = None
                return self.callFunction("onPrintJobStateChanged", _arg0)
                # {'_arg0': 'android.print.PrintJobId', 'ELSE:': {}, 'IF': {}}
