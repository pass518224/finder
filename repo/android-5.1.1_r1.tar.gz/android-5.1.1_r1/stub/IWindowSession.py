from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWindowSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IWindowSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IWindowSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_add"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.view.WindowManager.LayoutParams", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.newInstance("android.graphics.Rect", )
                _arg5 = self.newInstance("android.graphics.Rect", )
                _arg6 = self.newInstance("android.view.InputChannel", )
                return self.callFunction("add", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'int', '_arg2': 'android.view.WindowManager.LayoutParams', '_arg3': 'int', '_arg0': 'android.view.IWindow', '_arg1': 'int', '_arg6': 'android.view.InputChannel', '_arg4': 'android.graphics.Rect', '_arg5': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addToDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.view.WindowManager.LayoutParams", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = self.newInstance("android.graphics.Rect", )
                _arg6 = self.newInstance("android.graphics.Rect", )
                _arg7 = self.newInstance("android.view.InputChannel", )
                return self.callFunction("addToDisplay", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_result': 'int', '_arg2': 'android.view.WindowManager.LayoutParams', '_arg3': 'int', '_arg0': 'android.view.IWindow', '_arg1': 'int', '_arg6': 'android.graphics.Rect', '_arg7': 'android.view.InputChannel', '_arg4': 'int', '_arg5': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addWithoutInputChannel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.view.WindowManager.LayoutParams", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.newInstance("android.graphics.Rect", )
                _arg5 = self.newInstance("android.graphics.Rect", )
                return self.callFunction("addWithoutInputChannel", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'int', '_arg2': 'android.view.WindowManager.LayoutParams', '_arg3': 'int', '_arg0': 'android.view.IWindow', '_arg1': 'int', '_arg4': 'android.graphics.Rect', '_arg5': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addToDisplayWithoutInputChannel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.view.WindowManager.LayoutParams", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = self.newInstance("android.graphics.Rect", )
                _arg6 = self.newInstance("android.graphics.Rect", )
                return self.callFunction("addToDisplayWithoutInputChannel", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'int', '_arg2': 'android.view.WindowManager.LayoutParams', '_arg3': 'int', '_arg0': 'android.view.IWindow', '_arg1': 'int', '_arg6': 'android.graphics.Rect', '_arg4': 'int', '_arg5': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_remove"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                return self.callFunction("remove", _arg0)
                # {'_arg0': 'android.view.IWindow'}
            if mycase("TRANSACTION_relayout"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.view.WindowManager.LayoutParams", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = self.newInstance("android.graphics.Rect", )
                _arg8 = self.newInstance("android.graphics.Rect", )
                _arg9 = self.newInstance("android.graphics.Rect", )
                _arg10 = self.newInstance("android.graphics.Rect", )
                _arg11 = self.newInstance("android.graphics.Rect", )
                _arg12 = self.newInstance("android.content.res.Configuration", )
                _arg13 = self.newInstance("android.view.Surface", )
                return self.callFunction("relayout", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9, _arg10, _arg11, _arg12, _arg13)
                # {'_arg8': 'android.graphics.Rect', '_arg9': 'android.graphics.Rect', '_arg2': 'android.view.WindowManager.LayoutParams', '_arg3': 'int', '_arg0': 'android.view.IWindow', '_arg1': 'int', '_arg6': 'int', '_arg7': 'android.graphics.Rect', '_arg4': 'int', '_arg5': 'int', '_result': 'int', '_arg12': 'android.content.res.Configuration', '_arg13': 'android.view.Surface', '_arg10': 'android.graphics.Rect', '_arg11': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_performDeferredDestroy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                return self.callFunction("performDeferredDestroy", _arg0)
                # {'_arg0': 'android.view.IWindow'}
            if mycase("TRANSACTION_outOfMemory"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                return self.callFunction("outOfMemory", _arg0)
                # {'_arg0': 'android.view.IWindow', '_result': 'boolean'}
            if mycase("TRANSACTION_setTransparentRegion"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Region", data)
                else:
                    _arg1 = None
                return self.callFunction("setTransparentRegion", _arg0, _arg1)
                # {'_arg0': 'android.view.IWindow', '_arg1': 'android.graphics.Region', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setInsets"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg3 = None
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.graphics.Region", data)
                else:
                    _arg4 = None
                return self.callFunction("setInsets", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.graphics.Rect', '_arg3': 'android.graphics.Rect', '_arg0': 'android.view.IWindow', '_arg1': 'int', '_arg4': 'android.graphics.Region', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getDisplayFrame"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = self.newInstance("android.graphics.Rect", )
                return self.callFunction("getDisplayFrame", _arg0, _arg1)
                # {'_arg0': 'android.view.IWindow', '_arg1': 'android.graphics.Rect'}
            if mycase("TRANSACTION_finishDrawing"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                return self.callFunction("finishDrawing", _arg0)
                # {'_arg0': 'android.view.IWindow'}
            if mycase("TRANSACTION_setInTouchMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setInTouchMode", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_getInTouchMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getInTouchMode")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_performHapticFeedback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("performHapticFeedback", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.view.IWindow', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_prepareDrag"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = self.newInstance("android.view.Surface", )
                return self.callFunction("prepareDrag", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'android.os.IBinder', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.view.IWindow', '_arg1': 'int', '_arg4': 'android.view.Surface'}
            if mycase("TRANSACTION_performDrag"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = data.readStrongBinder()
                _arg2 = data.readFloat()
                _arg3 = data.readFloat()
                _arg4 = data.readFloat()
                _arg5 = data.readFloat()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.content.ClipData", data)
                else:
                    _arg6 = None
                return self.callFunction("performDrag", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'boolean', '_arg2': 'float', '_arg3': 'float', '_arg0': 'android.view.IWindow', '_arg1': 'android.os.IBinder', '_arg6': 'android.content.ClipData', '_arg4': 'float', '_arg5': 'float', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_reportDropResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = (0 != data.readInt())
                return self.callFunction("reportDropResult", _arg0, _arg1)
                # {'_arg0': 'android.view.IWindow', '_arg1': 'boolean'}
            if mycase("TRANSACTION_dragRecipientEntered"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                return self.callFunction("dragRecipientEntered", _arg0)
                # {'_arg0': 'android.view.IWindow'}
            if mycase("TRANSACTION_dragRecipientExited"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                return self.callFunction("dragRecipientExited", _arg0)
                # {'_arg0': 'android.view.IWindow'}
            if mycase("TRANSACTION_setWallpaperPosition"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readFloat()
                _arg2 = data.readFloat()
                _arg3 = data.readFloat()
                _arg4 = data.readFloat()
                return self.callFunction("setWallpaperPosition", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'float', '_arg3': 'float', '_arg0': 'android.os.IBinder', '_arg1': 'float', '_arg4': 'float'}
            if mycase("TRANSACTION_wallpaperOffsetsComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("wallpaperOffsetsComplete", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_setWallpaperDisplayOffset"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setWallpaperDisplayOffset", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_sendWallpaperCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg5 = None
                _arg6 = (0 != data.readInt())
                return self.callFunction("sendWallpaperCommand", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'android.os.Bundle', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String', '_arg6': 'boolean', '_arg4': 'int', '_arg5': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_wallpaperCommandComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("wallpaperCommandComplete", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setUniverseTransform"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readFloat()
                _arg2 = data.readFloat()
                _arg3 = data.readFloat()
                _arg4 = data.readFloat()
                _arg5 = data.readFloat()
                _arg6 = data.readFloat()
                _arg7 = data.readFloat()
                return self.callFunction("setUniverseTransform", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'float', '_arg3': 'float', '_arg0': 'android.os.IBinder', '_arg1': 'float', '_arg6': 'float', '_arg7': 'float', '_arg4': 'float', '_arg5': 'float'}
            if mycase("TRANSACTION_onRectangleOnScreenRequested"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg1 = None
                return self.callFunction("onRectangleOnScreenRequested", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getWindowId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("getWindowId", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'android.view.IWindowId'}
