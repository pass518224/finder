from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IServiceConnection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IServiceConnection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IServiceConnection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_connected"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readStrongBinder()
                return self.callFunction("connected", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'android.os.IBinder', 'ELSE:': {}, 'IF': {}}
