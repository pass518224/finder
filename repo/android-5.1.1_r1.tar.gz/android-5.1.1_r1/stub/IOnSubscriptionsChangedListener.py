from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IOnSubscriptionsChangedListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.IOnSubscriptionsChangedListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.IOnSubscriptionsChangedListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onSubscriptionsChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onSubscriptionsChanged")
                # {}
