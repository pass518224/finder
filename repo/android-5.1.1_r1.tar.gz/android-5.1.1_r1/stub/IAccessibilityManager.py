from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccessibilityManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.accessibility.IAccessibilityManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.accessibility.IAccessibilityManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_addClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.accessibility.IAccessibilityManagerClient", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("addClient", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.view.accessibility.IAccessibilityManagerClient', '_arg1': 'int'}
            if mycase("TRANSACTION_sendAccessibilityEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.accessibility.AccessibilityEvent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("sendAccessibilityEvent", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.view.accessibility.AccessibilityEvent', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getInstalledAccessibilityServiceList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getInstalledAccessibilityServiceList", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.accessibilityservice.AccessibilityServiceInfo>'}
            if mycase("TRANSACTION_getEnabledAccessibilityServiceList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("getEnabledAccessibilityServiceList", _arg0, _arg1)
                # {'_result': 'java.util.List<android.accessibilityservice.AccessibilityServiceInfo>', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_interrupt"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("interrupt", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_addAccessibilityInteractionConnection"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                _arg1 = self.interfaceResolver("android.view.accessibility.IAccessibilityInteractionConnection", data.readStrongBinder())
                _arg2 = data.readInt()
                return self.callFunction("addAccessibilityInteractionConnection", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.view.IWindow', '_arg1': 'android.view.accessibility.IAccessibilityInteractionConnection', '_result': 'int'}
            if mycase("TRANSACTION_removeAccessibilityInteractionConnection"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindow", data.readStrongBinder())
                return self.callFunction("removeAccessibilityInteractionConnection", _arg0)
                # {'_arg0': 'android.view.IWindow'}
            if mycase("TRANSACTION_registerUiTestAutomationService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = self.interfaceResolver("android.accessibilityservice.IAccessibilityServiceClient", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.accessibilityservice.AccessibilityServiceInfo", data)
                else:
                    _arg2 = None
                return self.callFunction("registerUiTestAutomationService", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.accessibilityservice.AccessibilityServiceInfo', '_arg0': 'android.os.IBinder', '_arg1': 'android.accessibilityservice.IAccessibilityServiceClient', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterUiTestAutomationService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.accessibilityservice.IAccessibilityServiceClient", data.readStrongBinder())
                return self.callFunction("unregisterUiTestAutomationService", _arg0)
                # {'_arg0': 'android.accessibilityservice.IAccessibilityServiceClient'}
            if mycase("TRANSACTION_temporaryEnableAccessibilityStateUntilKeyguardRemoved"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("temporaryEnableAccessibilityStateUntilKeyguardRemoved", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getWindowToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getWindowToken", _arg0)
                # {'_arg0': 'int', '_result': 'android.os.IBinder'}
