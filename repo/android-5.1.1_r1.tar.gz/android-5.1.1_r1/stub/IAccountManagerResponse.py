from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccountManagerResponse:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.accounts.IAccountManagerResponse"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.accounts.IAccountManagerResponse"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onResult"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("onResult", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onError"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("onError", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
