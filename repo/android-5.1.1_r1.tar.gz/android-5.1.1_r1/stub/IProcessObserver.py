from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IProcessObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IProcessObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IProcessObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onForegroundActivitiesChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("onForegroundActivitiesChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onProcessStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("onProcessStateChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onProcessDied"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onProcessDied", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
