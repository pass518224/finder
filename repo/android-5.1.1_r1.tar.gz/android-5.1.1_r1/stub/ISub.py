from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISub:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.ISub"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.ISub"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getAllSubInfoList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllSubInfoList")
                # {'_result': 'java.util.List<android.telephony.SubscriptionInfo>'}
            if mycase("TRANSACTION_getAllSubInfoCount"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllSubInfoCount")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getActiveSubscriptionInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getActiveSubscriptionInfo", _arg0)
                # {'_arg0': 'int', '_result': 'android.telephony.SubscriptionInfo'}
            if mycase("TRANSACTION_getActiveSubscriptionInfoForIccId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getActiveSubscriptionInfoForIccId", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.telephony.SubscriptionInfo'}
            if mycase("TRANSACTION_getActiveSubscriptionInfoForSimSlotIndex"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getActiveSubscriptionInfoForSimSlotIndex", _arg0)
                # {'_arg0': 'int', '_result': 'android.telephony.SubscriptionInfo'}
            if mycase("TRANSACTION_getActiveSubscriptionInfoList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveSubscriptionInfoList")
                # {'_result': 'java.util.List<android.telephony.SubscriptionInfo>'}
            if mycase("TRANSACTION_getActiveSubInfoCount"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveSubInfoCount")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getActiveSubInfoCountMax"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveSubInfoCountMax")
                # {'_result': 'int'}
            if mycase("TRANSACTION_addSubInfoRecord"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("addSubInfoRecord", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setIconTint"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setIconTint", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setDisplayName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setDisplayName", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setDisplayNameUsingSrc"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readLong()
                return self.callFunction("setDisplayNameUsingSrc", _arg0, _arg1, _arg2)
                # {'_arg2': 'long', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'int'}
            if mycase("TRANSACTION_setDisplayNumber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setDisplayNumber", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setDataRoaming"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setDataRoaming", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getSlotId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getSlotId", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getSubId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getSubId", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getDefaultSubId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultSubId")
                # {'_result': 'int'}
            if mycase("TRANSACTION_clearSubInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearSubInfo")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getPhoneId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getPhoneId", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getDefaultDataSubId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultDataSubId")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setDefaultDataSubId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setDefaultDataSubId", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getDefaultVoiceSubId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultVoiceSubId")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setDefaultVoiceSubId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setDefaultVoiceSubId", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getDefaultSmsSubId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultSmsSubId")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setDefaultSmsSubId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setDefaultSmsSubId", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_clearDefaultsForInactiveSubIds"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearDefaultsForInactiveSubIds")
                # {}
            if mycase("TRANSACTION_getActiveSubIdList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveSubIdList")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getSimStateForSubscriber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getSimStateForSubscriber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
