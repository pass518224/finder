from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRingtonePlayer:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IRingtonePlayer"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IRingtonePlayer"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_play"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.media.AudioAttributes", data)
                else:
                    _arg2 = None
                return self.callFunction("play", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.media.AudioAttributes', '_arg0': 'android.os.IBinder', '_arg1': 'android.net.Uri', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stop"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("stop", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_isPlaying"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("isPlaying", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'boolean'}
            if mycase("TRANSACTION_playAsync"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg1 = None
                _arg2 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.media.AudioAttributes", data)
                else:
                    _arg3 = None
                return self.callFunction("playAsync", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'boolean', '_arg3': 'android.media.AudioAttributes', '_arg0': 'android.net.Uri', '_arg1': 'android.os.UserHandle', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_stopAsync"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopAsync")
                # {}
