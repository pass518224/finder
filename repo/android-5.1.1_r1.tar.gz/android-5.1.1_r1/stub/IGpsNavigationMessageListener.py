from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGpsNavigationMessageListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.IGpsNavigationMessageListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.IGpsNavigationMessageListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onGpsNavigationMessageReceived"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.GpsNavigationMessageEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("onGpsNavigationMessageReceived", _arg0)
                # {'_arg0': 'android.location.GpsNavigationMessageEvent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onStatusChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onStatusChanged", _arg0)
                # {'_arg0': 'int'}
