from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IProcessStats:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.app.IProcessStats"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.app.IProcessStats"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getCurrentStats"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = list()
                return self.callFunction("getCurrentStats", _arg0)
                # {'_arg0': 'java.util.List<android.os.ParcelFileDescriptor>', '_result': 'byte'}
            if mycase("TRANSACTION_getStatsOverTime"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("getStatsOverTime", _arg0)
                # {'_arg0': 'long', '_result': 'android.os.ParcelFileDescriptor'}
            if mycase("TRANSACTION_getCurrentMemoryState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentMemoryState")
                # {'_result': 'int'}
