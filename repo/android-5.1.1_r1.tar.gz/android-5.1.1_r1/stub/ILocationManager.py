from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ILocationManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.ILocationManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.ILocationManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_requestLocationUpdates"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.LocationRequest", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.location.ILocationListener", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg2 = None
                _arg3 = data.readString()
                return self.callFunction("requestLocationUpdates", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.app.PendingIntent', '_arg3': 'java.lang.String', '_arg0': 'android.location.LocationRequest', '_arg1': 'android.location.ILocationListener', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeUpdates"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.ILocationListener", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                return self.callFunction("removeUpdates", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.location.ILocationListener', '_arg1': 'android.app.PendingIntent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_requestGeofence"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.LocationRequest", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.location.Geofence", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg2 = None
                _arg3 = data.readString()
                return self.callFunction("requestGeofence", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.app.PendingIntent', '_arg3': 'java.lang.String', '_arg0': 'android.location.LocationRequest', '_arg1': 'android.location.Geofence', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_removeGeofence"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.Geofence", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                return self.callFunction("removeGeofence", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.location.Geofence', '_arg1': 'android.app.PendingIntent', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_getLastLocation"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.LocationRequest", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("getLastLocation", _arg0, _arg1)
                # {'_result': 'android.location.Location', '_arg0': 'android.location.LocationRequest', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addGpsStatusListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsStatusListener", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("addGpsStatusListener", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.location.IGpsStatusListener', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_removeGpsStatusListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsStatusListener", data.readStrongBinder())
                return self.callFunction("removeGpsStatusListener", _arg0)
                # {'_arg0': 'android.location.IGpsStatusListener'}
            if mycase("TRANSACTION_geocoderIsPresent"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("geocoderIsPresent")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getFromLocation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readDouble()
                _arg1 = data.readDouble()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.location.GeocoderParams", data)
                else:
                    _arg3 = None
                _arg4 = list()
                return self.callFunction("getFromLocation", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'java.lang.String', '_arg2': 'int', '_arg3': 'android.location.GeocoderParams', '_arg0': 'double', '_arg1': 'double', '_arg4': 'java.util.List<android.location.Address>', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getFromLocationName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readDouble()
                _arg2 = data.readDouble()
                _arg3 = data.readDouble()
                _arg4 = data.readDouble()
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.location.GeocoderParams", data)
                else:
                    _arg6 = None
                _arg7 = list()
                return self.callFunction("getFromLocationName", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_result': 'java.lang.String', '_arg2': 'double', '_arg3': 'double', '_arg0': 'java.lang.String', '_arg1': 'double', '_arg6': 'android.location.GeocoderParams', '_arg7': 'java.util.List<android.location.Address>', '_arg4': 'double', '_arg5': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendNiResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("sendNiResponse", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_addGpsMeasurementsListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsMeasurementsListener", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("addGpsMeasurementsListener", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.location.IGpsMeasurementsListener', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_removeGpsMeasurementsListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsMeasurementsListener", data.readStrongBinder())
                return self.callFunction("removeGpsMeasurementsListener", _arg0)
                # {'_arg0': 'android.location.IGpsMeasurementsListener'}
            if mycase("TRANSACTION_addGpsNavigationMessageListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsNavigationMessageListener", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("addGpsNavigationMessageListener", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.location.IGpsNavigationMessageListener', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_removeGpsNavigationMessageListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsNavigationMessageListener", data.readStrongBinder())
                return self.callFunction("removeGpsNavigationMessageListener", _arg0)
                # {'_arg0': 'android.location.IGpsNavigationMessageListener'}
            if mycase("TRANSACTION_getAllProviders"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllProviders")
                # {'_result': 'java.util.List<java.lang.String>'}
            if mycase("TRANSACTION_getProviders"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.Criteria", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("getProviders", _arg0, _arg1)
                # {'_result': 'java.util.List<java.lang.String>', '_arg0': 'android.location.Criteria', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getBestProvider"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.Criteria", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("getBestProvider", _arg0, _arg1)
                # {'_result': 'java.lang.String', '_arg0': 'android.location.Criteria', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_providerMeetsCriteria"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.location.Criteria", data)
                else:
                    _arg1 = None
                return self.callFunction("providerMeetsCriteria", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'android.location.Criteria', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getProviderProperties"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getProviderProperties", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'com.android.internal.location.ProviderProperties'}
            if mycase("TRANSACTION_isProviderEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isProviderEnabled", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_addTestProvider"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.internal.location.ProviderProperties", data)
                else:
                    _arg1 = None
                return self.callFunction("addTestProvider", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'com.android.internal.location.ProviderProperties', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeTestProvider"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removeTestProvider", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setTestProviderLocation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.location.Location", data)
                else:
                    _arg1 = None
                return self.callFunction("setTestProviderLocation", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.location.Location', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearTestProviderLocation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("clearTestProviderLocation", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setTestProviderEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setTestProviderEnabled", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_clearTestProviderEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("clearTestProviderEnabled", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setTestProviderStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                _arg3 = data.readLong()
                return self.callFunction("setTestProviderStatus", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.os.Bundle', '_arg3': 'long', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearTestProviderStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("clearTestProviderStatus", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_sendExtraCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("sendExtraCommand", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_reportLocation"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.Location", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("reportLocation", _arg0, _arg1)
                # {'_arg0': 'android.location.Location', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_locationCallbackFinished"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.ILocationListener", data.readStrongBinder())
                return self.callFunction("locationCallbackFinished", _arg0)
                # {'_arg0': 'android.location.ILocationListener'}
