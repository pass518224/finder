from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBackupTransport:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.backup.IBackupTransport"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.backup.IBackupTransport"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_name"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("name")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_configurationIntent"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("configurationIntent")
                # {'_result': 'android.content.Intent'}
            if mycase("TRANSACTION_currentDestinationString"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("currentDestinationString")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_dataManagementIntent"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dataManagementIntent")
                # {'_result': 'android.content.Intent'}
            if mycase("TRANSACTION_dataManagementLabel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dataManagementLabel")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_transportDirName"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("transportDirName")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_requestBackupTime"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("requestBackupTime")
                # {'_result': 'long'}
            if mycase("TRANSACTION_initializeDevice"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("initializeDevice")
                # {'_result': 'int'}
            if mycase("TRANSACTION_performBackup"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.PackageInfo", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg1 = None
                return self.callFunction("performBackup", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.pm.PackageInfo', '_arg1': 'android.os.ParcelFileDescriptor', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_clearBackupData"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.PackageInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("clearBackupData", _arg0)
                # {'_arg0': 'android.content.pm.PackageInfo', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_finishBackup"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("finishBackup")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getAvailableRestoreSets"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAvailableRestoreSets")
                # {'_result': 'android.app.backup.RestoreSet'}
            if mycase("TRANSACTION_getCurrentRestoreSet"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentRestoreSet")
                # {'_result': 'long'}
            if mycase("TRANSACTION_startRestore"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.createTypedArray("android.content.pm.PackageInfo")
                return self.callFunction("startRestore", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'long', '_arg1': 'android.content.pm.PackageInfo'}
            if mycase("TRANSACTION_nextRestorePackage"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("nextRestorePackage")
                # {'_result': 'android.app.backup.RestoreDescription'}
            if mycase("TRANSACTION_getRestoreData"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                return self.callFunction("getRestoreData", _arg0)
                # {'_arg0': 'android.os.ParcelFileDescriptor', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_finishRestore"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("finishRestore")
                # {}
            if mycase("TRANSACTION_requestFullBackupTime"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("requestFullBackupTime")
                # {'_result': 'long'}
            if mycase("TRANSACTION_performFullBackup"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.PackageInfo", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg1 = None
                return self.callFunction("performFullBackup", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.content.pm.PackageInfo', '_arg1': 'android.os.ParcelFileDescriptor', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_sendBackupData"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("sendBackupData", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_cancelFullBackup"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("cancelFullBackup")
                # {}
            if mycase("TRANSACTION_getNextFullRestoreDataChunk"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                return self.callFunction("getNextFullRestoreDataChunk", _arg0)
                # {'_arg0': 'android.os.ParcelFileDescriptor', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_abortFullRestore"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("abortFullRestore")
                # {'_result': 'int'}
