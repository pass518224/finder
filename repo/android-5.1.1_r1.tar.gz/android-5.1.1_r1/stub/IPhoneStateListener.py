from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPhoneStateListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.IPhoneStateListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.IPhoneStateListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onServiceStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.ServiceState", data)
                else:
                    _arg0 = None
                return self.callFunction("onServiceStateChanged", _arg0)
                # {'_arg0': 'android.telephony.ServiceState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onSignalStrengthChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onSignalStrengthChanged", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onMessageWaitingIndicatorChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onMessageWaitingIndicatorChanged", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onCallForwardingIndicatorChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onCallForwardingIndicatorChanged", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onCellLocationChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("onCellLocationChanged", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onCallStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("onCallStateChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_onDataConnectionStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onDataConnectionStateChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onDataActivity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onDataActivity", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onSignalStrengthsChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.SignalStrength", data)
                else:
                    _arg0 = None
                return self.callFunction("onSignalStrengthsChanged", _arg0)
                # {'_arg0': 'android.telephony.SignalStrength', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onOtaspChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onOtaspChanged", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onCellInfoChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.telephony.CellInfo")
                return self.callFunction("onCellInfoChanged", _arg0)
                # {'_arg0': 'java.util.List<android.telephony.CellInfo>'}
            if mycase("TRANSACTION_onPreciseCallStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.PreciseCallState", data)
                else:
                    _arg0 = None
                return self.callFunction("onPreciseCallStateChanged", _arg0)
                # {'_arg0': 'android.telephony.PreciseCallState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPreciseDataConnectionStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.PreciseDataConnectionState", data)
                else:
                    _arg0 = None
                return self.callFunction("onPreciseDataConnectionStateChanged", _arg0)
                # {'_arg0': 'android.telephony.PreciseDataConnectionState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onDataConnectionRealTimeInfoChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.DataConnectionRealTimeInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("onDataConnectionRealTimeInfoChanged", _arg0)
                # {'_arg0': 'android.telephony.DataConnectionRealTimeInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onVoLteServiceStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.VoLteServiceState", data)
                else:
                    _arg0 = None
                return self.callFunction("onVoLteServiceStateChanged", _arg0)
                # {'_arg0': 'android.telephony.VoLteServiceState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onOemHookRawEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                return self.callFunction("onOemHookRawEvent", _arg0)
                # {'_arg0': 'byte'}
