from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputMethodManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.view.IInputMethodManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.view.IInputMethodManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getInputMethodList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getInputMethodList")
                # {'_result': 'java.util.List<android.view.inputmethod.InputMethodInfo>'}
            if mycase("TRANSACTION_getEnabledInputMethodList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getEnabledInputMethodList")
                # {'_result': 'java.util.List<android.view.inputmethod.InputMethodInfo>'}
            if mycase("TRANSACTION_getEnabledInputMethodSubtypeList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("getEnabledInputMethodSubtypeList", _arg0, _arg1)
                # {'_result': 'java.util.List<android.view.inputmethod.InputMethodSubtype>', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getLastInputMethodSubtype"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLastInputMethodSubtype")
                # {'_result': 'android.view.inputmethod.InputMethodSubtype'}
            if mycase("TRANSACTION_getShortcutInputMethodsAndSubtypes"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getShortcutInputMethodsAndSubtypes")
                # {'_result': 'java.util.List'}
            if mycase("TRANSACTION_addClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                _arg1 = self.interfaceResolver("com.android.internal.view.IInputContext", data.readStrongBinder())
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("addClient", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'com.android.internal.view.IInputMethodClient', '_arg1': 'com.android.internal.view.IInputContext'}
            if mycase("TRANSACTION_removeClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                return self.callFunction("removeClient", _arg0)
                # {'_arg0': 'com.android.internal.view.IInputMethodClient'}
            if mycase("TRANSACTION_startInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                _arg1 = self.interfaceResolver("com.android.internal.view.IInputContext", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.view.inputmethod.EditorInfo", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("startInput", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'com.android.internal.view.InputBindResult', '_arg2': 'android.view.inputmethod.EditorInfo', '_arg3': 'int', '_arg0': 'com.android.internal.view.IInputMethodClient', '_arg1': 'com.android.internal.view.IInputContext', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_finishInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                return self.callFunction("finishInput", _arg0)
                # {'_arg0': 'com.android.internal.view.IInputMethodClient'}
            if mycase("TRANSACTION_showSoftInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ResultReceiver", data)
                else:
                    _arg2 = None
                return self.callFunction("showSoftInput", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.os.ResultReceiver', '_arg0': 'com.android.internal.view.IInputMethodClient', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hideSoftInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ResultReceiver", data)
                else:
                    _arg2 = None
                return self.callFunction("hideSoftInput", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.os.ResultReceiver', '_arg0': 'com.android.internal.view.IInputMethodClient', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_windowGainedFocus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                _arg1 = data.readStrongBinder()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.view.inputmethod.EditorInfo", data)
                else:
                    _arg5 = None
                _arg6 = self.interfaceResolver("com.android.internal.view.IInputContext", data.readStrongBinder())
                return self.callFunction("windowGainedFocus", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'com.android.internal.view.InputBindResult', '_arg2': 'int', '_arg3': 'int', '_arg0': 'com.android.internal.view.IInputMethodClient', '_arg1': 'android.os.IBinder', '_arg6': 'com.android.internal.view.IInputContext', '_arg4': 'int', '_arg5': 'android.view.inputmethod.EditorInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_showInputMethodPickerFromClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                return self.callFunction("showInputMethodPickerFromClient", _arg0)
                # {'_arg0': 'com.android.internal.view.IInputMethodClient'}
            if mycase("TRANSACTION_showInputMethodAndSubtypeEnablerFromClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("showInputMethodAndSubtypeEnablerFromClient", _arg0, _arg1)
                # {'_arg0': 'com.android.internal.view.IInputMethodClient', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setInputMethod"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                return self.callFunction("setInputMethod", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setInputMethodAndSubtype"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.view.inputmethod.InputMethodSubtype", data)
                else:
                    _arg2 = None
                return self.callFunction("setInputMethodAndSubtype", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.view.inputmethod.InputMethodSubtype', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hideMySoftInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("hideMySoftInput", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_showMySoftInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("showMySoftInput", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_updateStatusIcon"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("updateStatusIcon", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setImeWindowStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setImeWindowStatus", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_registerSuggestionSpansForNotification"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.text.style.SuggestionSpan")
                return self.callFunction("registerSuggestionSpansForNotification", _arg0)
                # {'_arg0': 'android.text.style.SuggestionSpan'}
            if mycase("TRANSACTION_notifySuggestionPicked"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.style.SuggestionSpan", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("notifySuggestionPicked", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'int', '_arg0': 'android.text.style.SuggestionSpan', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCurrentInputMethodSubtype"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentInputMethodSubtype")
                # {'_result': 'android.view.inputmethod.InputMethodSubtype'}
            if mycase("TRANSACTION_setCurrentInputMethodSubtype"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.inputmethod.InputMethodSubtype", data)
                else:
                    _arg0 = None
                return self.callFunction("setCurrentInputMethodSubtype", _arg0)
                # {'_arg0': 'android.view.inputmethod.InputMethodSubtype', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_switchToLastInputMethod"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("switchToLastInputMethod", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'boolean'}
            if mycase("TRANSACTION_switchToNextInputMethod"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = (0 != data.readInt())
                return self.callFunction("switchToNextInputMethod", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.os.IBinder', '_arg1': 'boolean'}
            if mycase("TRANSACTION_shouldOfferSwitchingToNextInputMethod"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("shouldOfferSwitchingToNextInputMethod", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'boolean'}
            if mycase("TRANSACTION_setInputMethodEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setInputMethodEnabled", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setAdditionalInputMethodSubtypes"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createTypedArray("android.view.inputmethod.InputMethodSubtype")
                return self.callFunction("setAdditionalInputMethodSubtypes", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.view.inputmethod.InputMethodSubtype'}
            if mycase("TRANSACTION_getInputMethodWindowVisibleHeight"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getInputMethodWindowVisibleHeight")
                # {'_result': 'int'}
            if mycase("TRANSACTION_notifyUserAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("notifyUserAction", _arg0)
                # {'_arg0': 'int'}
