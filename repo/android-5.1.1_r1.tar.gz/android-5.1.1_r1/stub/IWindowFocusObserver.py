from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWindowFocusObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IWindowFocusObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IWindowFocusObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_focusGained"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("focusGained", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_focusLost"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("focusLost", _arg0)
                # {'_arg0': 'android.os.IBinder'}
