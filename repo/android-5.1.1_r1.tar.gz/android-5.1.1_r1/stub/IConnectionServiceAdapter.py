from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IConnectionServiceAdapter:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telecom.IConnectionServiceAdapter"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telecom.IConnectionServiceAdapter"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_handleCreateConnectionComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telecom.ConnectionRequest", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.telecom.ParcelableConnection", data)
                else:
                    _arg2 = None
                return self.callFunction("handleCreateConnectionComplete", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.telecom.ParcelableConnection', '_arg0': 'java.lang.String', '_arg1': 'android.telecom.ConnectionRequest', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setActive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setActive", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setRinging"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setRinging", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setDialing"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setDialing", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setDisconnected"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telecom.DisconnectCause", data)
                else:
                    _arg1 = None
                return self.callFunction("setDisconnected", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.telecom.DisconnectCause', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setOnHold"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setOnHold", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setRingbackRequested"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setRingbackRequested", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setConnectionCapabilities"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setConnectionCapabilities", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setIsConferenced"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("setIsConferenced", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_addConferenceCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telecom.ParcelableConference", data)
                else:
                    _arg1 = None
                return self.callFunction("addConferenceCall", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.telecom.ParcelableConference', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removeCall", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onPostDialWait"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("onPostDialWait", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_onPostDialChar"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = None
                return self.callFunction("onPostDialChar", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'char'}
            if mycase("TRANSACTION_queryRemoteConnectionServices"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.telecom.RemoteServiceCallback", data.readStrongBinder())
                return self.callFunction("queryRemoteConnectionServices", _arg0)
                # {'_arg0': 'com.android.internal.telecom.RemoteServiceCallback'}
            if mycase("TRANSACTION_setVideoProvider"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.telecom.IVideoProvider", data.readStrongBinder())
                return self.callFunction("setVideoProvider", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'com.android.internal.telecom.IVideoProvider'}
            if mycase("TRANSACTION_setVideoState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setVideoState", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setIsVoipAudioMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setIsVoipAudioMode", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setStatusHints"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telecom.StatusHints", data)
                else:
                    _arg1 = None
                return self.callFunction("setStatusHints", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.telecom.StatusHints', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAddress"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("setAddress", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.net.Uri', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setCallerDisplayName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("setCallerDisplayName", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setConferenceableConnections"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createStringArrayList()
                return self.callFunction("setConferenceableConnections", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.util.List<java.lang.String>'}
            if mycase("TRANSACTION_addExistingConnection"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telecom.ParcelableConnection", data)
                else:
                    _arg1 = None
                return self.callFunction("addExistingConnection", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.telecom.ParcelableConnection', 'ELSE:': {}, 'IF': {}}
