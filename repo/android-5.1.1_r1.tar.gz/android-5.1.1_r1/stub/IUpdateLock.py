from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IUpdateLock:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.IUpdateLock"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.IUpdateLock"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_acquireUpdateLock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                return self.callFunction("acquireUpdateLock", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_releaseUpdateLock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("releaseUpdateLock", _arg0)
                # {'_arg0': 'android.os.IBinder'}
