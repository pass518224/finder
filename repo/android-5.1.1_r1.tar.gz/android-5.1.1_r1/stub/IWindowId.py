from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWindowId:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IWindowId"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IWindowId"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerFocusObserver"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindowFocusObserver", data.readStrongBinder())
                return self.callFunction("registerFocusObserver", _arg0)
                # {'_arg0': 'android.view.IWindowFocusObserver'}
            if mycase("TRANSACTION_unregisterFocusObserver"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindowFocusObserver", data.readStrongBinder())
                return self.callFunction("unregisterFocusObserver", _arg0)
                # {'_arg0': 'android.view.IWindowFocusObserver'}
            if mycase("TRANSACTION_isFocused"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isFocused")
                # {'_result': 'boolean'}
