from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITvInputService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.tv.ITvInputService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.tv.ITvInputService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.tv.ITvInputServiceCallback", data.readStrongBinder())
                return self.callFunction("registerCallback", _arg0)
                # {'_arg0': 'android.media.tv.ITvInputServiceCallback'}
            if mycase("TRANSACTION_unregisterCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.tv.ITvInputServiceCallback", data.readStrongBinder())
                return self.callFunction("unregisterCallback", _arg0)
                # {'_arg0': 'android.media.tv.ITvInputServiceCallback'}
            if mycase("TRANSACTION_createSession"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.InputChannel", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.media.tv.ITvInputSessionCallback", data.readStrongBinder())
                _arg2 = data.readString()
                return self.callFunction("createSession", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.view.InputChannel', '_arg1': 'android.media.tv.ITvInputSessionCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyHardwareAdded"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.tv.TvInputHardwareInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("notifyHardwareAdded", _arg0)
                # {'_arg0': 'android.media.tv.TvInputHardwareInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyHardwareRemoved"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.tv.TvInputHardwareInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("notifyHardwareRemoved", _arg0)
                # {'_arg0': 'android.media.tv.TvInputHardwareInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyHdmiDeviceAdded"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.hdmi.HdmiDeviceInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("notifyHdmiDeviceAdded", _arg0)
                # {'_arg0': 'android.hardware.hdmi.HdmiDeviceInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyHdmiDeviceRemoved"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.hdmi.HdmiDeviceInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("notifyHdmiDeviceRemoved", _arg0)
                # {'_arg0': 'android.hardware.hdmi.HdmiDeviceInfo', 'ELSE:': {}, 'IF': {}}
