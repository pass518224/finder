from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ILocationListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.ILocationListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.ILocationListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onLocationChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.Location", data)
                else:
                    _arg0 = None
                return self.callFunction("onLocationChanged", _arg0)
                # {'_arg0': 'android.location.Location', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onStatusChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("onStatusChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onProviderEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("onProviderEnabled", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onProviderDisabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("onProviderDisabled", _arg0)
                # {'_arg0': 'java.lang.String'}
