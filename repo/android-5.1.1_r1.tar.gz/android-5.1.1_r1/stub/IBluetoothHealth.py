from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothHealth:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothHealth"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothHealth"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerAppConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothHealthAppConfiguration", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.bluetooth.IBluetoothHealthCallback", data.readStrongBinder())
                return self.callFunction("registerAppConfiguration", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothHealthAppConfiguration', '_arg1': 'android.bluetooth.IBluetoothHealthCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterAppConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothHealthAppConfiguration", data)
                else:
                    _arg0 = None
                return self.callFunction("unregisterAppConfiguration", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothHealthAppConfiguration', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_connectChannelToSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.bluetooth.BluetoothHealthAppConfiguration", data)
                else:
                    _arg1 = None
                return self.callFunction("connectChannelToSource", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'android.bluetooth.BluetoothHealthAppConfiguration', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_connectChannelToSink"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.bluetooth.BluetoothHealthAppConfiguration", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("connectChannelToSink", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'int', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'android.bluetooth.BluetoothHealthAppConfiguration', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_disconnectChannel"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.bluetooth.BluetoothHealthAppConfiguration", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("disconnectChannel", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'int', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'android.bluetooth.BluetoothHealthAppConfiguration', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_getMainChannelFd"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.bluetooth.BluetoothHealthAppConfiguration", data)
                else:
                    _arg1 = None
                return self.callFunction("getMainChannelFd", _arg0, _arg1)
                # {'_result': 'android.os.ParcelFileDescriptor', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'android.bluetooth.BluetoothHealthAppConfiguration', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_getConnectedHealthDevices"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConnectedHealthDevices")
                # {'_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_getHealthDevicesMatchingConnectionStates"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createIntArray()
                return self.callFunction("getHealthDevicesMatchingConnectionStates", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_getHealthDeviceConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getHealthDeviceConnectionState", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
