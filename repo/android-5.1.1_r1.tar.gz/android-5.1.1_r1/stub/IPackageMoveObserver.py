from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPackageMoveObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IPackageMoveObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IPackageMoveObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_packageMoved"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("packageMoved", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
