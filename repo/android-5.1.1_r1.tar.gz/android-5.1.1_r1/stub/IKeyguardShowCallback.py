from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IKeyguardShowCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.policy.IKeyguardShowCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.policy.IKeyguardShowCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onShown"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("onShown", _arg0)
                # {'_arg0': 'android.os.IBinder'}
