from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IFaceLockInterface:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.policy.IFaceLockInterface"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.policy.IFaceLockInterface"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_startUi"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = (0 != data.readInt())
                return self.callFunction("startUi", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'int', '_arg4': 'int', '_arg5': 'boolean'}
            if mycase("TRANSACTION_stopUi"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopUi")
                # {}
            if mycase("TRANSACTION_startWithoutUi"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("startWithoutUi")
                # {}
            if mycase("TRANSACTION_registerCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.policy.IFaceLockCallback", data.readStrongBinder())
                return self.callFunction("registerCallback", _arg0)
                # {'_arg0': 'com.android.internal.policy.IFaceLockCallback'}
            if mycase("TRANSACTION_unregisterCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.policy.IFaceLockCallback", data.readStrongBinder())
                return self.callFunction("unregisterCallback", _arg0)
                # {'_arg0': 'com.android.internal.policy.IFaceLockCallback'}
