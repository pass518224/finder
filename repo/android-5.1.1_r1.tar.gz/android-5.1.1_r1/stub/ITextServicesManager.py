from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITextServicesManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.textservice.ITextServicesManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.textservice.ITextServicesManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getCurrentSpellChecker"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getCurrentSpellChecker", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.view.textservice.SpellCheckerInfo'}
            if mycase("TRANSACTION_getCurrentSpellCheckerSubtype"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("getCurrentSpellCheckerSubtype", _arg0, _arg1)
                # {'_result': 'android.view.textservice.SpellCheckerSubtype', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getSpellCheckerService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = self.interfaceResolver("com.android.internal.textservice.ITextServicesSessionListener", data.readStrongBinder())
                _arg3 = self.interfaceResolver("com.android.internal.textservice.ISpellCheckerSessionListener", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg4 = None
                return self.callFunction("getSpellCheckerService", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'com.android.internal.textservice.ITextServicesSessionListener', '_arg3': 'com.android.internal.textservice.ISpellCheckerSessionListener', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg4': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_finishSpellCheckerService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.textservice.ISpellCheckerSessionListener", data.readStrongBinder())
                return self.callFunction("finishSpellCheckerService", _arg0)
                # {'_arg0': 'com.android.internal.textservice.ISpellCheckerSessionListener'}
            if mycase("TRANSACTION_setCurrentSpellChecker"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("setCurrentSpellChecker", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setCurrentSpellCheckerSubtype"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setCurrentSpellCheckerSubtype", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setSpellCheckerEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setSpellCheckerEnabled", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_isSpellCheckerEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isSpellCheckerEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getEnabledSpellCheckers"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getEnabledSpellCheckers")
                # {'_result': 'android.view.textservice.SpellCheckerInfo'}
