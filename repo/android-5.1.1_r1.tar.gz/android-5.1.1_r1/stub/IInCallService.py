from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInCallService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telecom.IInCallService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telecom.IInCallService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setInCallAdapter"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.telecom.IInCallAdapter", data.readStrongBinder())
                return self.callFunction("setInCallAdapter", _arg0)
                # {'_arg0': 'com.android.internal.telecom.IInCallAdapter'}
            if mycase("TRANSACTION_addCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.ParcelableCall", data)
                else:
                    _arg0 = None
                return self.callFunction("addCall", _arg0)
                # {'_arg0': 'android.telecom.ParcelableCall', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.ParcelableCall", data)
                else:
                    _arg0 = None
                return self.callFunction("updateCall", _arg0)
                # {'_arg0': 'android.telecom.ParcelableCall', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPostDial"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("setPostDial", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setPostDialWait"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("setPostDialWait", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_onAudioStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.AudioState", data)
                else:
                    _arg0 = None
                return self.callFunction("onAudioStateChanged", _arg0)
                # {'_arg0': 'android.telecom.AudioState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_bringToForeground"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("bringToForeground", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onCanAddCallChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onCanAddCallChanged", _arg0)
                # {'_arg0': 'boolean'}
