from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITranslatorService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.googlecode.eyesfree.braille.translate.ITranslatorService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.googlecode.eyesfree.braille.translate.ITranslatorService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.googlecode.eyesfree.braille.translate.ITranslatorServiceCallback", data.readStrongBinder())
                return self.callFunction("setCallback", _arg0)
                # {'_arg0': 'com.googlecode.eyesfree.braille.translate.ITranslatorServiceCallback'}
            if mycase("TRANSACTION_checkTable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("checkTable", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_translate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("translate", _arg0, _arg1)
                # {'_result': 'byte', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_backTranslate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                _arg1 = data.readString()
                return self.callFunction("backTranslate", _arg0, _arg1)
                # {'_result': 'java.lang.String', '_arg0': 'byte', '_arg1': 'java.lang.String'}
