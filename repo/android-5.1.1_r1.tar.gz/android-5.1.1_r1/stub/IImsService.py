from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_open"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg2 = None
                _arg3 = self.interfaceResolver("com.android.ims.internal.IImsRegistrationListener", data.readStrongBinder())
                return self.callFunction("open", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'int', '_arg2': 'android.app.PendingIntent', '_arg3': 'com.android.ims.internal.IImsRegistrationListener', '_arg0': 'int', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("close", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_isConnected"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("isConnected", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_isOpened"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isOpened", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setRegistrationListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("com.android.ims.internal.IImsRegistrationListener", data.readStrongBinder())
                return self.callFunction("setRegistrationListener", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'com.android.ims.internal.IImsRegistrationListener'}
            if mycase("TRANSACTION_createCallProfile"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("createCallProfile", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'com.android.ims.ImsCallProfile'}
            if mycase("TRANSACTION_createCallSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                _arg2 = self.interfaceResolver("com.android.ims.internal.IImsCallSessionListener", data.readStrongBinder())
                return self.callFunction("createCallSession", _arg0, _arg1, _arg2)
                # {'_result': 'com.android.ims.internal.IImsCallSession', '_arg2': 'com.android.ims.internal.IImsCallSessionListener', '_arg0': 'int', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPendingCallSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("getPendingCallSession", _arg0, _arg1)
                # {'_result': 'com.android.ims.internal.IImsCallSession', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getUtInterface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getUtInterface", _arg0)
                # {'_arg0': 'int', '_result': 'com.android.ims.internal.IImsUt'}
            if mycase("TRANSACTION_getConfigInterface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getConfigInterface", _arg0)
                # {'_arg0': 'int', '_result': 'com.android.ims.internal.IImsConfig'}
            if mycase("TRANSACTION_turnOnIms"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("turnOnIms", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_turnOffIms"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("turnOffIms", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getEcbmInterface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getEcbmInterface", _arg0)
                # {'_arg0': 'int', '_result': 'com.android.ims.internal.IImsEcbm'}
            if mycase("TRANSACTION_setUiTTYMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Message", data)
                else:
                    _arg2 = None
                return self.callFunction("setUiTTYMode", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Message', '_arg0': 'int', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
