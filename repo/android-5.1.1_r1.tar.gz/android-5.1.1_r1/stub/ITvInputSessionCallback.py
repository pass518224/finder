from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITvInputSessionCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.tv.ITvInputSessionCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.tv.ITvInputSessionCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onSessionCreated"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.tv.ITvInputSession", data.readStrongBinder())
                _arg1 = data.readStrongBinder()
                return self.callFunction("onSessionCreated", _arg0, _arg1)
                # {'_arg0': 'android.media.tv.ITvInputSession', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_onSessionEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("onSessionEvent", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onChannelRetuned"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                return self.callFunction("onChannelRetuned", _arg0)
                # {'_arg0': 'android.net.Uri', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onTracksChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.media.tv.TvTrackInfo")
                return self.callFunction("onTracksChanged", _arg0)
                # {'_arg0': 'java.util.List<android.media.tv.TvTrackInfo>'}
            if mycase("TRANSACTION_onTrackSelected"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("onTrackSelected", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_onVideoAvailable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onVideoAvailable")
                # {}
            if mycase("TRANSACTION_onVideoUnavailable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onVideoUnavailable", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onContentAllowed"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onContentAllowed")
                # {}
            if mycase("TRANSACTION_onContentBlocked"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("onContentBlocked", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onLayoutSurface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("onLayoutSurface", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int'}
