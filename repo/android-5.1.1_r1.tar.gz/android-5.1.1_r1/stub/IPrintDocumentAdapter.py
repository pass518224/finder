from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrintDocumentAdapter:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IPrintDocumentAdapter"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IPrintDocumentAdapter"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setObserver"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrintDocumentAdapterObserver", data.readStrongBinder())
                return self.callFunction("setObserver", _arg0)
                # {'_arg0': 'android.print.IPrintDocumentAdapterObserver'}
            if mycase("TRANSACTION_start"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("start")
                # {}
            if mycase("TRANSACTION_layout"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintAttributes", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.print.PrintAttributes", data)
                else:
                    _arg1 = None
                _arg2 = self.interfaceResolver("android.print.ILayoutResultCallback", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                return self.callFunction("layout", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.print.ILayoutResultCallback', '_arg3': 'android.os.Bundle', '_arg0': 'android.print.PrintAttributes', '_arg1': 'android.print.PrintAttributes', '_arg4': 'int', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_write"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.print.PageRange")
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg1 = None
                _arg2 = self.interfaceResolver("android.print.IWriteResultCallback", data.readStrongBinder())
                _arg3 = data.readInt()
                return self.callFunction("write", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.print.IWriteResultCallback', '_arg3': 'int', '_arg0': 'android.print.PageRange', '_arg1': 'android.os.ParcelFileDescriptor', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_finish"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("finish")
                # {}
            if mycase("TRANSACTION_kill"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("kill", _arg0)
                # {'_arg0': 'java.lang.String'}
