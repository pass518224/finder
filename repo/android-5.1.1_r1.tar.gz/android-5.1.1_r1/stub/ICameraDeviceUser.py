from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICameraDeviceUser:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.camera2.ICameraDeviceUser"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.camera2.ICameraDeviceUser"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnect")
                # {}
            if mycase("TRANSACTION_submitRequest"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.camera2.CaptureRequest", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = self.newInstance("android.hardware.camera2.utils.LongParcelable", )
                return self.callFunction("submitRequest", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'android.hardware.camera2.utils.LongParcelable', '_arg0': 'android.hardware.camera2.CaptureRequest', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_submitRequestList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.hardware.camera2.CaptureRequest")
                _arg1 = (0 != data.readInt())
                _arg2 = self.newInstance("android.hardware.camera2.utils.LongParcelable", )
                return self.callFunction("submitRequestList", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.hardware.camera2.utils.LongParcelable', '_arg0': 'java.util.List<android.hardware.camera2.CaptureRequest>', '_arg1': 'boolean', '_result': 'int'}
            if mycase("TRANSACTION_cancelRequest"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.newInstance("android.hardware.camera2.utils.LongParcelable", )
                return self.callFunction("cancelRequest", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'android.hardware.camera2.utils.LongParcelable'}
            if mycase("TRANSACTION_beginConfigure"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("beginConfigure")
                # {'_result': 'int'}
            if mycase("TRANSACTION_endConfigure"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("endConfigure")
                # {'_result': 'int'}
            if mycase("TRANSACTION_deleteStream"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("deleteStream", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_createStream"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg3 = None
                return self.callFunction("createStream", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'int', '_arg2': 'int', '_arg3': 'android.view.Surface', '_arg0': 'int', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createDefaultRequest"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.newInstance("android.hardware.camera2.impl.CameraMetadataNative", )
                return self.callFunction("createDefaultRequest", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'android.hardware.camera2.impl.CameraMetadataNative'}
            if mycase("TRANSACTION_getCameraInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.newInstance("android.hardware.camera2.impl.CameraMetadataNative", )
                return self.callFunction("getCameraInfo", _arg0)
                # {'_arg0': 'android.hardware.camera2.impl.CameraMetadataNative', '_result': 'int'}
            if mycase("TRANSACTION_waitUntilIdle"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("waitUntilIdle")
                # {'_result': 'int'}
            if mycase("TRANSACTION_flush"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.newInstance("android.hardware.camera2.utils.LongParcelable", )
                return self.callFunction("flush", _arg0)
                # {'_arg0': 'android.hardware.camera2.utils.LongParcelable', '_result': 'int'}
