from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputMethodSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.view.IInputMethodSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.view.IInputMethodSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_finishInput"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("finishInput")
                # {}
            if mycase("TRANSACTION_updateExtractedText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.view.inputmethod.ExtractedText", data)
                else:
                    _arg1 = None
                return self.callFunction("updateExtractedText", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.view.inputmethod.ExtractedText', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateSelection"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                return self.callFunction("updateSelection", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int', '_arg5': 'int'}
            if mycase("TRANSACTION_viewClicked"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("viewClicked", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_updateCursor"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg0 = None
                return self.callFunction("updateCursor", _arg0)
                # {'_arg0': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_displayCompletions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.view.inputmethod.CompletionInfo")
                return self.callFunction("displayCompletions", _arg0)
                # {'_arg0': 'android.view.inputmethod.CompletionInfo'}
            if mycase("TRANSACTION_appPrivateCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("appPrivateCommand", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_toggleSoftInput"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("toggleSoftInput", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_finishSession"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("finishSession")
                # {}
            if mycase("TRANSACTION_updateCursorAnchorInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.inputmethod.CursorAnchorInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("updateCursorAnchorInfo", _arg0)
                # {'_arg0': 'android.view.inputmethod.CursorAnchorInfo', 'ELSE:': {}, 'IF': {}}
