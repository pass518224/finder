from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IConnectionService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telecom.IConnectionService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telecom.IConnectionService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_addConnectionServiceAdapter"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.telecom.IConnectionServiceAdapter", data.readStrongBinder())
                return self.callFunction("addConnectionServiceAdapter", _arg0)
                # {'_arg0': 'com.android.internal.telecom.IConnectionServiceAdapter'}
            if mycase("TRANSACTION_removeConnectionServiceAdapter"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.telecom.IConnectionServiceAdapter", data.readStrongBinder())
                return self.callFunction("removeConnectionServiceAdapter", _arg0)
                # {'_arg0': 'com.android.internal.telecom.IConnectionServiceAdapter'}
            if mycase("TRANSACTION_createConnection"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.telecom.ConnectionRequest", data)
                else:
                    _arg2 = None
                _arg3 = (0 != data.readInt())
                _arg4 = (0 != data.readInt())
                return self.callFunction("createConnection", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.telecom.ConnectionRequest', '_arg3': 'boolean', '_arg0': 'android.telecom.PhoneAccountHandle', '_arg1': 'java.lang.String', '_arg4': 'boolean', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_abort"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("abort", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_answerVideo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("answerVideo", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_answer"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("answer", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_reject"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("reject", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("disconnect", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_hold"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("hold", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_unhold"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("unhold", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onAudioStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telecom.AudioState", data)
                else:
                    _arg1 = None
                return self.callFunction("onAudioStateChanged", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.telecom.AudioState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_playDtmfTone"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = None
                return self.callFunction("playDtmfTone", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'char'}
            if mycase("TRANSACTION_stopDtmfTone"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("stopDtmfTone", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_conference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("conference", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_splitFromConference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("splitFromConference", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_mergeConference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("mergeConference", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_swapConference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("swapConference", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onPostDialContinue"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("onPostDialContinue", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
