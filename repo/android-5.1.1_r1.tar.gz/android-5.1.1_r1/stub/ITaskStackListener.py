from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITaskStackListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.ITaskStackListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.ITaskStackListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onTaskStackChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onTaskStackChanged")
                # {}
