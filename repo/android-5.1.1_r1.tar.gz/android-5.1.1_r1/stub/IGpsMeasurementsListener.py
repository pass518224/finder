from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGpsMeasurementsListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.IGpsMeasurementsListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.IGpsMeasurementsListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onGpsMeasurementsReceived"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.location.GpsMeasurementsEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("onGpsMeasurementsReceived", _arg0)
                # {'_arg0': 'android.location.GpsMeasurementsEvent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onStatusChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onStatusChanged", _arg0)
                # {'_arg0': 'int'}
