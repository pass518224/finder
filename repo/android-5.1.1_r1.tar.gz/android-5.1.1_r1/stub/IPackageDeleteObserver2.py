from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPackageDeleteObserver2:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IPackageDeleteObserver2"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IPackageDeleteObserver2"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onUserActionRequired"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                return self.callFunction("onUserActionRequired", _arg0)
                # {'_arg0': 'android.content.Intent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPackageDeleted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("onPackageDeleted", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'int'}
