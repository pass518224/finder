from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothGattServerCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothGattServerCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothGattServerCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onServerRegistered"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onServerRegistered", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onScanResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.createByteArray()
                return self.callFunction("onScanResult", _arg0, _arg1, _arg2)
                # {'_arg2': 'byte', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_onServerConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                _arg3 = data.readString()
                return self.callFunction("onServerConnectionState", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'boolean', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onServiceAdded"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg3 = None
                return self.callFunction("onServiceAdded", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'android.os.ParcelUuid', '_arg0': 'int', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onCharacteristicReadRequest"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = (0 != data.readInt())
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg8 = None
                return self.callFunction("onCharacteristicReadRequest", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'android.os.ParcelUuid', '_arg2': 'int', '_arg3': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'android.os.ParcelUuid', '_arg7': 'int', '_arg4': 'int', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onDescriptorReadRequest"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = (0 != data.readInt())
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg8 = None
                if (0 != data.readInt()):
                    _arg9 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg9 = None
                return self.callFunction("onDescriptorReadRequest", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9)
                # {'_arg8': 'android.os.ParcelUuid', '_arg9': 'android.os.ParcelUuid', '_arg2': 'int', '_arg3': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'android.os.ParcelUuid', '_arg7': 'int', '_arg4': 'int', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onCharacteristicWriteRequest"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = (0 != data.readInt())
                _arg5 = (0 != data.readInt())
                _arg6 = data.readInt()
                _arg7 = data.readInt()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg8 = None
                _arg9 = data.readInt()
                if (0 != data.readInt()):
                    _arg10 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg10 = None
                _arg11 = data.createByteArray()
                return self.callFunction("onCharacteristicWriteRequest", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9, _arg10, _arg11)
                # {'_arg8': 'android.os.ParcelUuid', '_arg9': 'int', '_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'int', '_arg7': 'int', '_arg4': 'boolean', '_arg5': 'boolean', 'ELSE:I': {}, '_arg11': 'byte', '_arg10': 'android.os.ParcelUuid', 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onDescriptorWriteRequest"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = (0 != data.readInt())
                _arg5 = (0 != data.readInt())
                _arg6 = data.readInt()
                _arg7 = data.readInt()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg8 = None
                _arg9 = data.readInt()
                if (0 != data.readInt()):
                    _arg10 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg10 = None
                if (0 != data.readInt()):
                    _arg11 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg11 = None
                _arg12 = data.createByteArray()
                return self.callFunction("onDescriptorWriteRequest", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9, _arg10, _arg11, _arg12)
                # {'_arg8': 'android.os.ParcelUuid', '_arg9': 'int', '_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'int', '_arg7': 'int', '_arg4': 'boolean', '_arg5': 'boolean', 'ELSE:I': {}, '_arg12': 'byte', '_arg11': 'android.os.ParcelUuid', '_arg10': 'android.os.ParcelUuid', 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onExecuteWrite"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("onExecuteWrite", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_onNotificationSent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("onNotificationSent", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_onMtuChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("onMtuChanged", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
