from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INfcAdapter:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.nfc.INfcAdapter"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.nfc.INfcAdapter"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getNfcTagInterface"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNfcTagInterface")
                # {'_result': 'android.nfc.INfcTag'}
            if mycase("TRANSACTION_getNfcCardEmulationInterface"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNfcCardEmulationInterface")
                # {'_result': 'android.nfc.INfcCardEmulation'}
            if mycase("TRANSACTION_getNfcAdapterExtrasInterface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getNfcAdapterExtrasInterface", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.nfc.INfcAdapterExtras'}
            if mycase("TRANSACTION_getState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_disable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("disable", _arg0)
                # {'_arg0': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_enable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enable")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_enableNdefPush"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enableNdefPush")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_disableNdefPush"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disableNdefPush")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isNdefPushEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isNdefPushEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_pausePolling"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("pausePolling", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_resumePolling"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("resumePolling")
                # {}
            if mycase("TRANSACTION_setForegroundDispatch"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg0 = None
                _arg1 = data.createTypedArray("android.content.IntentFilter")
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.nfc.TechListParcel", data)
                else:
                    _arg2 = None
                return self.callFunction("setForegroundDispatch", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.nfc.TechListParcel', '_arg0': 'android.app.PendingIntent', '_arg1': 'android.content.IntentFilter', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAppCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.nfc.IAppCallback", data.readStrongBinder())
                return self.callFunction("setAppCallback", _arg0)
                # {'_arg0': 'android.nfc.IAppCallback'}
            if mycase("TRANSACTION_invokeBeam"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("invokeBeam")
                # {}
            if mycase("TRANSACTION_invokeBeamInternal"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.nfc.BeamShareData", data)
                else:
                    _arg0 = None
                return self.callFunction("invokeBeamInternal", _arg0)
                # {'_arg0': 'android.nfc.BeamShareData', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dispatch"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.nfc.Tag", data)
                else:
                    _arg0 = None
                return self.callFunction("dispatch", _arg0)
                # {'_arg0': 'android.nfc.Tag', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setReaderMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = self.interfaceResolver("android.nfc.IAppCallback", data.readStrongBinder())
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("setReaderMode", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'android.os.Bundle', '_arg0': 'android.os.IBinder', '_arg1': 'android.nfc.IAppCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setP2pModes"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setP2pModes", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_addNfcUnlockHandler"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.nfc.INfcUnlockHandler", data.readStrongBinder())
                _arg1 = data.createIntArray()
                return self.callFunction("addNfcUnlockHandler", _arg0, _arg1)
                # {'_arg0': 'android.nfc.INfcUnlockHandler', '_arg1': 'int'}
            if mycase("TRANSACTION_removeNfcUnlockHandler"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.nfc.INfcUnlockHandler", data.readStrongBinder())
                return self.callFunction("removeNfcUnlockHandler", _arg0)
                # {'_arg0': 'android.nfc.INfcUnlockHandler'}
            if mycase("TRANSACTION_verifyNfcPermission"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("verifyNfcPermission")
                # {}
