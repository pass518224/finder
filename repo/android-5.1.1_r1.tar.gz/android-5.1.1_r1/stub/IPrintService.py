from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrintService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.printservice.IPrintService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.printservice.IPrintService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.printservice.IPrintServiceClient", data.readStrongBinder())
                return self.callFunction("setClient", _arg0)
                # {'_arg0': 'android.printservice.IPrintServiceClient'}
            if mycase("TRANSACTION_requestCancelPrintJob"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("requestCancelPrintJob", _arg0)
                # {'_arg0': 'android.print.PrintJobInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPrintJobQueued"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("onPrintJobQueued", _arg0)
                # {'_arg0': 'android.print.PrintJobInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createPrinterDiscoverySession"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("createPrinterDiscoverySession")
                # {}
            if mycase("TRANSACTION_startPrinterDiscovery"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.print.PrinterId")
                return self.callFunction("startPrinterDiscovery", _arg0)
                # {'_arg0': 'java.util.List<android.print.PrinterId>'}
            if mycase("TRANSACTION_stopPrinterDiscovery"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopPrinterDiscovery")
                # {}
            if mycase("TRANSACTION_validatePrinters"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.print.PrinterId")
                return self.callFunction("validatePrinters", _arg0)
                # {'_arg0': 'java.util.List<android.print.PrinterId>'}
            if mycase("TRANSACTION_startPrinterStateTracking"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrinterId", data)
                else:
                    _arg0 = None
                return self.callFunction("startPrinterStateTracking", _arg0)
                # {'_arg0': 'android.print.PrinterId', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopPrinterStateTracking"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrinterId", data)
                else:
                    _arg0 = None
                return self.callFunction("stopPrinterStateTracking", _arg0)
                # {'_arg0': 'android.print.PrinterId', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_destroyPrinterDiscoverySession"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("destroyPrinterDiscoverySession")
                # {}
