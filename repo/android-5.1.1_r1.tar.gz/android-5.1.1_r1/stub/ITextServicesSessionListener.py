from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITextServicesSessionListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.textservice.ITextServicesSessionListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.textservice.ITextServicesSessionListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onServiceConnected"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.textservice.ISpellCheckerSession", data.readStrongBinder())
                return self.callFunction("onServiceConnected", _arg0)
                # {'_arg0': 'com.android.internal.textservice.ISpellCheckerSession'}
