from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IOnAppsChangedListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IOnAppsChangedListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IOnAppsChangedListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onPackageRemoved"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("onPackageRemoved", _arg0, _arg1)
                # {'_arg0': 'android.os.UserHandle', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPackageAdded"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("onPackageAdded", _arg0, _arg1)
                # {'_arg0': 'android.os.UserHandle', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPackageChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("onPackageChanged", _arg0, _arg1)
                # {'_arg0': 'android.os.UserHandle', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPackagesAvailable"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg0 = None
                _arg1 = data.createStringArray()
                _arg2 = (0 != data.readInt())
                return self.callFunction("onPackagesAvailable", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.os.UserHandle', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPackagesUnavailable"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg0 = None
                _arg1 = data.createStringArray()
                _arg2 = (0 != data.readInt())
                return self.callFunction("onPackagesUnavailable", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.os.UserHandle', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
