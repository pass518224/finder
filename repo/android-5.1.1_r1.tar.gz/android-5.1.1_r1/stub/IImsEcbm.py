from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsEcbm:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsEcbm"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsEcbm"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsEcbmListener", data.readStrongBinder())
                return self.callFunction("setListener", _arg0)
                # {'_arg0': 'com.android.ims.internal.IImsEcbmListener'}
            if mycase("TRANSACTION_exitEmergencyCallbackMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("exitEmergencyCallbackMode")
                # {}
