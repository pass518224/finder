from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ImsConfigListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.ImsConfigListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.ImsConfigListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onGetFeatureResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("onGetFeatureResponse", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onSetFeatureResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("onSetFeatureResponse", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int'}
