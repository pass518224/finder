from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ILauncherApps:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.ILauncherApps"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.ILauncherApps"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_addOnAppsChangedListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.pm.IOnAppsChangedListener", data.readStrongBinder())
                return self.callFunction("addOnAppsChangedListener", _arg0)
                # {'_arg0': 'android.content.pm.IOnAppsChangedListener'}
            if mycase("TRANSACTION_removeOnAppsChangedListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.pm.IOnAppsChangedListener", data.readStrongBinder())
                return self.callFunction("removeOnAppsChangedListener", _arg0)
                # {'_arg0': 'android.content.pm.IOnAppsChangedListener'}
            if mycase("TRANSACTION_getLauncherActivities"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg1 = None
                return self.callFunction("getLauncherActivities", _arg0, _arg1)
                # {'_result': 'java.util.List<android.content.pm.ResolveInfo>', '_arg0': 'java.lang.String', '_arg1': 'android.os.UserHandle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_resolveActivity"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg1 = None
                return self.callFunction("resolveActivity", _arg0, _arg1)
                # {'_result': 'android.content.pm.ResolveInfo', '_arg0': 'android.content.Intent', '_arg1': 'android.os.UserHandle', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_startActivityAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg3 = None
                return self.callFunction("startActivityAsUser", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.os.Bundle', '_arg3': 'android.os.UserHandle', '_arg0': 'android.content.ComponentName', '_arg1': 'android.graphics.Rect', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_showAppDetailsAsUser"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg3 = None
                return self.callFunction("showAppDetailsAsUser", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.os.Bundle', '_arg3': 'android.os.UserHandle', '_arg0': 'android.content.ComponentName', '_arg1': 'android.graphics.Rect', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_isPackageEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg1 = None
                return self.callFunction("isPackageEnabled", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'android.os.UserHandle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isActivityEnabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.UserHandle", data)
                else:
                    _arg1 = None
                return self.callFunction("isActivityEnabled", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.ComponentName', '_arg1': 'android.os.UserHandle', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
