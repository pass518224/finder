from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICarrierMessagingService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.carrier.ICarrierMessagingService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.carrier.ICarrierMessagingService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_filterSms"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.service.carrier.MessagePdu", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.service.carrier.ICarrierMessagingCallback", data.readStrongBinder())
                return self.callFunction("filterSms", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.service.carrier.MessagePdu', '_arg1': 'java.lang.String', '_arg4': 'android.service.carrier.ICarrierMessagingCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendTextSms"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = self.interfaceResolver("android.service.carrier.ICarrierMessagingCallback", data.readStrongBinder())
                return self.callFunction("sendTextSms", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.service.carrier.ICarrierMessagingCallback', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_sendDataSms"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.service.carrier.ICarrierMessagingCallback", data.readStrongBinder())
                return self.callFunction("sendDataSms", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'byte', '_arg1': 'int', '_arg4': 'android.service.carrier.ICarrierMessagingCallback'}
            if mycase("TRANSACTION_sendMultipartTextSms"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArrayList()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = self.interfaceResolver("android.service.carrier.ICarrierMessagingCallback", data.readStrongBinder())
                return self.callFunction("sendMultipartTextSms", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.service.carrier.ICarrierMessagingCallback', '_arg0': 'java.util.List<java.lang.String>', '_arg1': 'int'}
            if mycase("TRANSACTION_sendMms"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg2 = None
                _arg3 = self.interfaceResolver("android.service.carrier.ICarrierMessagingCallback", data.readStrongBinder())
                return self.callFunction("sendMms", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.net.Uri', '_arg3': 'android.service.carrier.ICarrierMessagingCallback', '_arg0': 'android.net.Uri', '_arg1': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_downloadMms"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg2 = None
                _arg3 = self.interfaceResolver("android.service.carrier.ICarrierMessagingCallback", data.readStrongBinder())
                return self.callFunction("downloadMms", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.net.Uri', '_arg3': 'android.service.carrier.ICarrierMessagingCallback', '_arg0': 'android.net.Uri', '_arg1': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
