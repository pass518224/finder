from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRemoteAndroidKeyStore:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "org.chromium.net.IRemoteAndroidKeyStore"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "org.chromium.net.IRemoteAndroidKeyStore"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getClientCertificateAlias"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getClientCertificateAlias")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getEncodedCertificateChain"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getEncodedCertificateChain", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'byte'}
            if mycase("TRANSACTION_getPrivateKeyHandle"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPrivateKeyHandle", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_setClientCallbacks"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("org.chromium.net.IRemoteAndroidKeyStoreCallbacks", data.readStrongBinder())
                return self.callFunction("setClientCallbacks", _arg0)
                # {'_arg0': 'org.chromium.net.IRemoteAndroidKeyStoreCallbacks'}
            if mycase("TRANSACTION_getRSAKeyModulus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getRSAKeyModulus", _arg0)
                # {'_arg0': 'int', '_result': 'byte'}
            if mycase("TRANSACTION_getPrivateKeyEncodedBytes"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getPrivateKeyEncodedBytes", _arg0)
                # {'_arg0': 'int', '_result': 'byte'}
            if mycase("TRANSACTION_getDSAKeyParamQ"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getDSAKeyParamQ", _arg0)
                # {'_arg0': 'int', '_result': 'byte'}
            if mycase("TRANSACTION_getECKeyOrder"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getECKeyOrder", _arg0)
                # {'_arg0': 'int', '_result': 'byte'}
            if mycase("TRANSACTION_rawSignDigestWithPrivateKey"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createByteArray()
                return self.callFunction("rawSignDigestWithPrivateKey", _arg0, _arg1)
                # {'_result': 'byte', '_arg0': 'int', '_arg1': 'byte'}
            if mycase("TRANSACTION_getPrivateKeyType"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getPrivateKeyType", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_releaseKey"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("releaseKey", _arg0)
                # {'_arg0': 'int'}
