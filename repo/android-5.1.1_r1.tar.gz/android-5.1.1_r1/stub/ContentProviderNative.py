from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IContentProvider:
    pass
    descriptor = "android.content.IContentProvider"
class OnTransact(IContentProvider, Stub):
    def onTransact(self, code, data, reply):
        for mycase in Switch(code):
            if mycase("QUERY_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                num = data.readInt()
                projection = None
                if (num > 0):
                    projection = [None for _i in range(num)] # 
                    while (i < num):
                        projection[i] = data.readString()
                        i += 1
                selection = data.readString()
                num = data.readInt()
                selectionArgs = None
                if (num > 0):
                    selectionArgs = [None for _i in range(num)] # 
                    while (i < num):
                        selectionArgs[i] = data.readString()
                        i += 1
                sortOrder = data.readString()
                observer = self.interfaceResolver("IContentObserver", data.readStrongBinder())
                cancellationSignal = self.interfaceResolver("ICancellationSignal", data.readStrongBinder())
                return self.callFunction("query", callingPkg, url, projection, selection, selectionArgs, sortOrder, cancellationSignal)
                # {'selectionArgs': 'String', 'selection': 'String', 'projection': 'String', 'observer': 'IContentObserver', 'url': 'Uri', 'cursor': 'Cursor', 'num': 'int', 'callingPkg': 'String', 'sortOrder': 'String', 'cancellationSignal': 'ICancellationSignal', 'IFI': {'i': 'int', 'For loop': {}}, 'IF': {'i': 'int', 'For loop': {}}}
            if mycase("GET_TYPE_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                url = self.creatorResolver("android.net.Uri", data)
                return self.callFunction("getType", url)
                # {'url': 'Uri', 'type': 'String'}
            if mycase("INSERT_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                values = self.creatorResolver("android.content.ContentValues", data)
                return self.callFunction("insert", callingPkg, url, values)
                # {'url': 'Uri', 'values': 'ContentValues', 'callingPkg': 'String', 'out': 'Uri'}
            if mycase("BULK_INSERT_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                values = data.createTypedArray("ContentValues")
                return self.callFunction("bulkInsert", callingPkg, url, values)
                # {'url': 'Uri', 'values': 'ContentValues', 'callingPkg': 'String', 'count': 'int'}
            if mycase("APPLY_BATCH_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                numOperations = data.readInt()
                operations = self.newInstance("ArrayList<ContentProviderOperation>", numOperations)
                while (i < numOperations):
                    operations.add(i, self.creatorResolver("android.content.ContentProviderOperation", data))
                    i += 1
                return self.callFunction("applyBatch", callingPkg, operations)
                # {'operations': 'ArrayList<ContentProviderOperation>', 'i': 'int', 'results': 'ContentProviderResult', 'callingPkg': 'String', 'numOperations': 'int', 'For loop': {}}
            if mycase("DELETE_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                selection = data.readString()
                selectionArgs = data.readStringArray()
                return self.callFunction("delete", callingPkg, url, selection, selectionArgs)
                # {'url': 'Uri', 'selectionArgs': 'String', 'selection': 'String', 'callingPkg': 'String', 'count': 'int'}
            if mycase("UPDATE_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                values = self.creatorResolver("android.content.ContentValues", data)
                selection = data.readString()
                selectionArgs = data.readStringArray()
                return self.callFunction("update", callingPkg, url, values, selection, selectionArgs)
                # {'selectionArgs': 'String', 'count': 'int', 'selection': 'String', 'url': 'Uri', 'values': 'ContentValues', 'callingPkg': 'String'}
            if mycase("OPEN_FILE_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                mode = data.readString()
                signal = self.interfaceResolver("ICancellationSignal", data.readStrongBinder())
                callerToken = data.readStrongBinder()
                return self.callFunction("openFile", callingPkg, url, mode, signal, callerToken)
                # {'url': 'Uri', 'signal': 'ICancellationSignal', 'fd': 'ParcelFileDescriptor', 'mode': 'String', 'callingPkg': 'String', 'callerToken': 'IBinder'}
            if mycase("OPEN_ASSET_FILE_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                mode = data.readString()
                signal = self.interfaceResolver("ICancellationSignal", data.readStrongBinder())
                return self.callFunction("openAssetFile", callingPkg, url, mode, signal)
                # {'url': 'Uri', 'fd': 'AssetFileDescriptor', 'signal': 'ICancellationSignal', 'callingPkg': 'String', 'mode': 'String'}
            if mycase("CALL_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                method = data.readString()
                stringArg = data.readString()
                args = data.readBundle()
                return self.callFunction("call", callingPkg, method, stringArg, args)
                # {'stringArg': 'String', 'args': 'Bundle', 'callingPkg': 'String', 'method': 'String', 'responseBundle': 'Bundle'}
            if mycase("GET_STREAM_TYPES_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                url = self.creatorResolver("android.net.Uri", data)
                mimeTypeFilter = data.readString()
                return self.callFunction("getStreamTypes", url, mimeTypeFilter)
                # {'url': 'Uri', 'mimeTypeFilter': 'String', 'types': 'String'}
            if mycase("OPEN_TYPED_ASSET_FILE_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                mimeType = data.readString()
                opts = data.readBundle()
                signal = self.interfaceResolver("ICancellationSignal", data.readStrongBinder())
                return self.callFunction("openTypedAssetFile", callingPkg, url, mimeType, opts, signal)
                # {'mimeType': 'String', 'url': 'Uri', 'signal': 'ICancellationSignal', 'fd': 'AssetFileDescriptor', 'callingPkg': 'String', 'opts': 'Bundle'}
            if mycase("CREATE_CANCELATION_SIGNAL_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                return self.callFunction("createCancellationSignal")
                # {'cancellationSignal': 'ICancellationSignal'}
            if mycase("CANONICALIZE_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                return self.callFunction("canonicalize", callingPkg, url)
                # {'url': 'Uri', 'callingPkg': 'String', 'out': 'Uri'}
            if mycase("UNCANONICALIZE_TRANSACTION"):
                data.enforceInterface(IContentProvider.descriptor)
                callingPkg = data.readString()
                url = self.creatorResolver("android.net.Uri", data)
                return self.callFunction("uncanonicalize", callingPkg, url)
                # {'url': 'Uri', 'callingPkg': 'String', 'out': 'Uri'}
