from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBatteryStats:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.app.IBatteryStats"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.app.IBatteryStats"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_noteStartSensor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("noteStartSensor", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_noteStopSensor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("noteStopSensor", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_noteStartVideo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteStartVideo", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteStopVideo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteStopVideo", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteStartAudio"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteStartAudio", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteStopAudio"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteStopAudio", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteResetVideo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteResetVideo")
                # {}
            if mycase("TRANSACTION_noteResetAudio"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteResetAudio")
                # {}
            if mycase("TRANSACTION_getStatistics"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getStatistics")
                # {'_result': 'byte'}
            if mycase("TRANSACTION_getStatisticsStream"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getStatisticsStream")
                # {'_result': 'android.os.ParcelFileDescriptor'}
            if mycase("TRANSACTION_computeBatteryTimeRemaining"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("computeBatteryTimeRemaining")
                # {'_result': 'long'}
            if mycase("TRANSACTION_computeChargeTimeRemaining"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("computeChargeTimeRemaining")
                # {'_result': 'long'}
            if mycase("TRANSACTION_noteEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("noteEvent", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_noteSyncStart"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("noteSyncStart", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_noteSyncFinish"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("noteSyncFinish", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_noteJobStart"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("noteJobStart", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_noteJobFinish"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("noteJobFinish", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_noteStartWakelock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                _arg5 = (0 != data.readInt())
                return self.callFunction("noteStartWakelock", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int', '_arg5': 'boolean'}
            if mycase("TRANSACTION_noteStopWakelock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                return self.callFunction("noteStopWakelock", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int'}
            if mycase("TRANSACTION_noteStartWakelockFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                _arg5 = (0 != data.readInt())
                return self.callFunction("noteStartWakelockFromSource", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.os.WorkSource', '_arg1': 'int', '_arg4': 'int', '_arg5': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteChangeWakelockFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg5 = None
                _arg6 = data.readInt()
                _arg7 = data.readString()
                _arg8 = data.readString()
                _arg9 = data.readInt()
                _arg10 = (0 != data.readInt())
                return self.callFunction("noteChangeWakelockFromSource", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9, _arg10)
                # {'_arg8': 'java.lang.String', '_arg9': 'int', '_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.os.WorkSource', '_arg1': 'int', '_arg6': 'int', '_arg7': 'java.lang.String', '_arg4': 'int', '_arg5': 'android.os.WorkSource', 'ELSE:I': {}, '_arg10': 'boolean', 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteStopWakelockFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                return self.callFunction("noteStopWakelockFromSource", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.os.WorkSource', '_arg1': 'int', '_arg4': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteVibratorOn"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                return self.callFunction("noteVibratorOn", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'long'}
            if mycase("TRANSACTION_noteVibratorOff"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteVibratorOff", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteFlashlightOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteFlashlightOn")
                # {}
            if mycase("TRANSACTION_noteFlashlightOff"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteFlashlightOff")
                # {}
            if mycase("TRANSACTION_noteStartGps"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteStartGps", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteStopGps"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteStopGps", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteScreenState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteScreenState", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteScreenBrightness"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteScreenBrightness", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteUserActivity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("noteUserActivity", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_noteInteractive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("noteInteractive", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_noteConnectivityChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("noteConnectivityChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_noteMobileRadioPowerState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                return self.callFunction("noteMobileRadioPowerState", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'long'}
            if mycase("TRANSACTION_notePhoneOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("notePhoneOn")
                # {}
            if mycase("TRANSACTION_notePhoneOff"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("notePhoneOff")
                # {}
            if mycase("TRANSACTION_notePhoneSignalStrength"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telephony.SignalStrength", data)
                else:
                    _arg0 = None
                return self.callFunction("notePhoneSignalStrength", _arg0)
                # {'_arg0': 'android.telephony.SignalStrength', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notePhoneDataConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("notePhoneDataConnectionState", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_notePhoneState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("notePhoneState", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteWifiOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteWifiOn")
                # {}
            if mycase("TRANSACTION_noteWifiOff"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteWifiOff")
                # {}
            if mycase("TRANSACTION_noteWifiRunning"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteWifiRunning", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiRunningChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg1 = None
                return self.callFunction("noteWifiRunningChanged", _arg0, _arg1)
                # {'_arg0': 'android.os.WorkSource', '_arg1': 'android.os.WorkSource', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiStopped"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteWifiStopped", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("noteWifiState", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_noteWifiSupplicantStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("noteWifiSupplicantStateChanged", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_noteWifiRssiChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteWifiRssiChanged", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteBluetoothOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteBluetoothOn")
                # {}
            if mycase("TRANSACTION_noteBluetoothOff"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteBluetoothOff")
                # {}
            if mycase("TRANSACTION_noteBluetoothState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteBluetoothState", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteFullWifiLockAcquired"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteFullWifiLockAcquired", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteFullWifiLockReleased"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteFullWifiLockReleased", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteWifiScanStarted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteWifiScanStarted", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteWifiScanStopped"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteWifiScanStopped", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteWifiMulticastEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteWifiMulticastEnabled", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteWifiMulticastDisabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("noteWifiMulticastDisabled", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_noteFullWifiLockAcquiredFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteFullWifiLockAcquiredFromSource", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteFullWifiLockReleasedFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteFullWifiLockReleasedFromSource", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiScanStartedFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteWifiScanStartedFromSource", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiScanStoppedFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteWifiScanStoppedFromSource", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiBatchedScanStartedFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("noteWifiBatchedScanStartedFromSource", _arg0, _arg1)
                # {'_arg0': 'android.os.WorkSource', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiBatchedScanStoppedFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteWifiBatchedScanStoppedFromSource", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiMulticastEnabledFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteWifiMulticastEnabledFromSource", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteWifiMulticastDisabledFromSource"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("noteWifiMulticastDisabledFromSource", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_noteNetworkInterfaceType"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("noteNetworkInterfaceType", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_noteNetworkStatsEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("noteNetworkStatsEnabled")
                # {}
            if mycase("TRANSACTION_setBatteryState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                return self.callFunction("setBatteryState", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int', '_arg5': 'int'}
            if mycase("TRANSACTION_getAwakeTimeBattery"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAwakeTimeBattery")
                # {'_result': 'long'}
            if mycase("TRANSACTION_getAwakeTimePlugged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAwakeTimePlugged")
                # {'_result': 'long'}
