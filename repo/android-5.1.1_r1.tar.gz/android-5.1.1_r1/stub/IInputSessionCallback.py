from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputSessionCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.view.IInputSessionCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.view.IInputSessionCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sessionCreated"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodSession", data.readStrongBinder())
                return self.callFunction("sessionCreated", _arg0)
                # {'_arg0': 'com.android.internal.view.IInputMethodSession'}
