from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRemoteCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.IRemoteCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.IRemoteCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sendResult"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("sendResult", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
