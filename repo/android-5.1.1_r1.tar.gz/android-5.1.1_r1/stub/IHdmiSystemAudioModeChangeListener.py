from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IHdmiSystemAudioModeChangeListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.hdmi.IHdmiSystemAudioModeChangeListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.hdmi.IHdmiSystemAudioModeChangeListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onStatusChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onStatusChanged", _arg0)
                # {'_arg0': 'boolean'}
