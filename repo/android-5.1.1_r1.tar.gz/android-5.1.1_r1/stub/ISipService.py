from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISipService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.sip.ISipService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.sip.ISipService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_open"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.sip.SipProfile", data)
                else:
                    _arg0 = None
                return self.callFunction("open", _arg0)
                # {'_arg0': 'android.net.sip.SipProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_open3"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.sip.SipProfile", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg1 = None
                _arg2 = self.interfaceResolver("android.net.sip.ISipSessionListener", data.readStrongBinder())
                return self.callFunction("open3", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.net.sip.ISipSessionListener', '_arg0': 'android.net.sip.SipProfile', '_arg1': 'android.app.PendingIntent', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("close", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_isOpened"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isOpened", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_isRegistered"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isRegistered", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_setRegistrationListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.net.sip.ISipSessionListener", data.readStrongBinder())
                return self.callFunction("setRegistrationListener", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.net.sip.ISipSessionListener'}
            if mycase("TRANSACTION_createSession"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.sip.SipProfile", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.net.sip.ISipSessionListener", data.readStrongBinder())
                return self.callFunction("createSession", _arg0, _arg1)
                # {'_result': 'android.net.sip.ISipSession', '_arg0': 'android.net.sip.SipProfile', '_arg1': 'android.net.sip.ISipSessionListener', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPendingSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPendingSession", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.net.sip.ISipSession'}
            if mycase("TRANSACTION_getListOfProfiles"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getListOfProfiles")
                # {'_result': 'android.net.sip.SipProfile'}
