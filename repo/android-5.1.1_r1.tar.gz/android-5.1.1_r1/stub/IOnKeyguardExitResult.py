from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IOnKeyguardExitResult:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IOnKeyguardExitResult"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IOnKeyguardExitResult"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onKeyguardExitResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onKeyguardExitResult", _arg0)
                # {'_arg0': 'boolean'}
