from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccessibilityInteractionConnectionCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.accessibility.IAccessibilityInteractionConnectionCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.accessibility.IAccessibilityInteractionConnectionCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setFindAccessibilityNodeInfoResult"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.accessibility.AccessibilityNodeInfo", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setFindAccessibilityNodeInfoResult", _arg0, _arg1)
                # {'_arg0': 'android.view.accessibility.AccessibilityNodeInfo', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setFindAccessibilityNodeInfosResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.view.accessibility.AccessibilityNodeInfo")
                _arg1 = data.readInt()
                return self.callFunction("setFindAccessibilityNodeInfosResult", _arg0, _arg1)
                # {'_arg0': 'java.util.List<android.view.accessibility.AccessibilityNodeInfo>', '_arg1': 'int'}
            if mycase("TRANSACTION_setPerformAccessibilityActionResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("setPerformAccessibilityActionResult", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
