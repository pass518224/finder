from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPackageInstallObserver2:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IPackageInstallObserver2"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IPackageInstallObserver2"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onUserActionRequired"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                return self.callFunction("onUserActionRequired", _arg0)
                # {'_arg0': 'android.content.Intent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPackageInstalled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("onPackageInstalled", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
