from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGeocodeProvider:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.IGeocodeProvider"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.IGeocodeProvider"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getFromLocation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readDouble()
                _arg1 = data.readDouble()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.location.GeocoderParams", data)
                else:
                    _arg3 = None
                _arg4 = list()
                return self.callFunction("getFromLocation", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'java.lang.String', '_arg2': 'int', '_arg3': 'android.location.GeocoderParams', '_arg0': 'double', '_arg1': 'double', '_arg4': 'java.util.List<android.location.Address>', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getFromLocationName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readDouble()
                _arg2 = data.readDouble()
                _arg3 = data.readDouble()
                _arg4 = data.readDouble()
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.location.GeocoderParams", data)
                else:
                    _arg6 = None
                _arg7 = list()
                return self.callFunction("getFromLocationName", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_result': 'java.lang.String', '_arg2': 'double', '_arg3': 'double', '_arg0': 'java.lang.String', '_arg1': 'double', '_arg6': 'android.location.GeocoderParams', '_arg7': 'java.util.List<android.location.Address>', '_arg4': 'double', '_arg5': 'int', 'ELSE:': {}, 'IF': {}}
