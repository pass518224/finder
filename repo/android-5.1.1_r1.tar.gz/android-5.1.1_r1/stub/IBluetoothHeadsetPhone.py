from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothHeadsetPhone:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothHeadsetPhone"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothHeadsetPhone"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_answerCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("answerCall")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_hangupCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hangupCall")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_sendDtmf"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("sendDtmf", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_processChld"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("processChld", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getNetworkOperator"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNetworkOperator")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getSubscriberNumber"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSubscriberNumber")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_listCurrentCalls"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("listCurrentCalls")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_queryPhoneState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("queryPhoneState")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_updateBtHandsfreeAfterRadioTechnologyChange"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("updateBtHandsfreeAfterRadioTechnologyChange")
                # {}
            if mycase("TRANSACTION_cdmaSwapSecondCallState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("cdmaSwapSecondCallState")
                # {}
            if mycase("TRANSACTION_cdmaSetSecondCallState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("cdmaSetSecondCallState", _arg0)
                # {'_arg0': 'boolean'}
