from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.input.IInputManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.input.IInputManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getInputDevice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getInputDevice", _arg0)
                # {'_arg0': 'int', '_result': 'android.view.InputDevice'}
            if mycase("TRANSACTION_getInputDeviceIds"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getInputDeviceIds")
                # {'_result': 'int'}
            if mycase("TRANSACTION_hasKeys"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.createIntArray()
                _arg3_length = data.readInt()
                if (_arg3_length < 0):
                    _arg3 = None
                else:
                    _arg3 = [None for _i in range(_arg3_length)] # boolean
                return self.callFunction("hasKeys", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'boolean', '_arg0': 'int', '_arg1': 'int', '_arg3_length': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_tryPointerSpeed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("tryPointerSpeed", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_injectInputEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.InputEvent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("injectInputEvent", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.view.InputEvent', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getTouchCalibrationForInputDevice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getTouchCalibrationForInputDevice", _arg0, _arg1)
                # {'_result': 'android.hardware.input.TouchCalibration', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setTouchCalibrationForInputDevice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.hardware.input.TouchCalibration", data)
                else:
                    _arg2 = None
                return self.callFunction("setTouchCalibrationForInputDevice", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.hardware.input.TouchCalibration', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getKeyboardLayouts"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getKeyboardLayouts")
                # {'_result': 'android.hardware.input.KeyboardLayout'}
            if mycase("TRANSACTION_getKeyboardLayout"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getKeyboardLayout", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.hardware.input.KeyboardLayout'}
            if mycase("TRANSACTION_getCurrentKeyboardLayoutForInputDevice"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.input.InputDeviceIdentifier", data)
                else:
                    _arg0 = None
                return self.callFunction("getCurrentKeyboardLayoutForInputDevice", _arg0)
                # {'_arg0': 'android.hardware.input.InputDeviceIdentifier', '_result': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setCurrentKeyboardLayoutForInputDevice"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.input.InputDeviceIdentifier", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("setCurrentKeyboardLayoutForInputDevice", _arg0, _arg1)
                # {'_arg0': 'android.hardware.input.InputDeviceIdentifier', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getKeyboardLayoutsForInputDevice"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.input.InputDeviceIdentifier", data)
                else:
                    _arg0 = None
                return self.callFunction("getKeyboardLayoutsForInputDevice", _arg0)
                # {'_arg0': 'android.hardware.input.InputDeviceIdentifier', '_result': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addKeyboardLayoutForInputDevice"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.input.InputDeviceIdentifier", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("addKeyboardLayoutForInputDevice", _arg0, _arg1)
                # {'_arg0': 'android.hardware.input.InputDeviceIdentifier', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeKeyboardLayoutForInputDevice"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.input.InputDeviceIdentifier", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("removeKeyboardLayoutForInputDevice", _arg0, _arg1)
                # {'_arg0': 'android.hardware.input.InputDeviceIdentifier', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_registerInputDevicesChangedListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.input.IInputDevicesChangedListener", data.readStrongBinder())
                return self.callFunction("registerInputDevicesChangedListener", _arg0)
                # {'_arg0': 'android.hardware.input.IInputDevicesChangedListener'}
            if mycase("TRANSACTION_vibrate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createLongArray()
                _arg2 = data.readInt()
                _arg3 = data.readStrongBinder()
                return self.callFunction("vibrate", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'android.os.IBinder', '_arg0': 'int', '_arg1': 'long'}
            if mycase("TRANSACTION_cancelVibrate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readStrongBinder()
                return self.callFunction("cancelVibrate", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.IBinder'}
