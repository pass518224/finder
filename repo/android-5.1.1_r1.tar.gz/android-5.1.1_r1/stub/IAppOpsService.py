from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAppOpsService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.app.IAppOpsService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.app.IAppOpsService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_checkOperation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("checkOperation", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int', '_result': 'int'}
            if mycase("TRANSACTION_noteOperation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("noteOperation", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int', '_result': 'int'}
            if mycase("TRANSACTION_startOperation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                return self.callFunction("startOperation", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'android.os.IBinder', '_arg1': 'int', '_result': 'int'}
            if mycase("TRANSACTION_finishOperation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                return self.callFunction("finishOperation", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_startWatchingMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = self.interfaceResolver("com.android.internal.app.IAppOpsCallback", data.readStrongBinder())
                return self.callFunction("startWatchingMode", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.internal.app.IAppOpsCallback', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_stopWatchingMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.app.IAppOpsCallback", data.readStrongBinder())
                return self.callFunction("stopWatchingMode", _arg0)
                # {'_arg0': 'com.android.internal.app.IAppOpsCallback'}
            if mycase("TRANSACTION_getToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("getToken", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'android.os.IBinder'}
            if mycase("TRANSACTION_checkPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("checkPackage", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getPackagesForOps"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createIntArray()
                return self.callFunction("getPackagesForOps", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.app.AppOpsManager.PackageOps>'}
            if mycase("TRANSACTION_getOpsForPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.createIntArray()
                return self.callFunction("getOpsForPackage", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_result': 'java.util.List<android.app.AppOpsManager.PackageOps>'}
            if mycase("TRANSACTION_setMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                return self.callFunction("setMode", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_resetAllModes"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("resetAllModes", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_checkAudioOperation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                return self.callFunction("checkAudioOperation", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int', '_result': 'int'}
            if mycase("TRANSACTION_setAudioRestriction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.createStringArray()
                return self.callFunction("setAudioRestriction", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg4': 'java.lang.String'}
            if mycase("TRANSACTION_setUserRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setUserRestrictions", _arg0, _arg1)
                # {'_arg0': 'android.os.Bundle', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("removeUser", _arg0)
                # {'_arg0': 'int'}
