from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBackupAgent:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IBackupAgent"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IBackupAgent"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_doBackup"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.app.backup.IBackupManager", data.readStrongBinder())
                return self.callFunction("doBackup", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.os.ParcelFileDescriptor', '_arg3': 'int', '_arg0': 'android.os.ParcelFileDescriptor', '_arg1': 'android.os.ParcelFileDescriptor', '_arg4': 'android.app.backup.IBackupManager', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_doRestore"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = self.interfaceResolver("android.app.backup.IBackupManager", data.readStrongBinder())
                return self.callFunction("doRestore", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.os.ParcelFileDescriptor', '_arg3': 'int', '_arg0': 'android.os.ParcelFileDescriptor', '_arg1': 'int', '_arg4': 'android.app.backup.IBackupManager', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_doFullBackup"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = self.interfaceResolver("android.app.backup.IBackupManager", data.readStrongBinder())
                return self.callFunction("doFullBackup", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.app.backup.IBackupManager', '_arg0': 'android.os.ParcelFileDescriptor', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_doRestoreFile"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                _arg4 = data.readString()
                _arg5 = data.readLong()
                _arg6 = data.readLong()
                _arg7 = data.readInt()
                _arg8 = self.interfaceResolver("android.app.backup.IBackupManager", data.readStrongBinder())
                return self.callFunction("doRestoreFile", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'android.app.backup.IBackupManager', '_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'android.os.ParcelFileDescriptor', '_arg1': 'long', '_arg6': 'long', '_arg7': 'int', '_arg4': 'java.lang.String', '_arg5': 'long', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_doRestoreFinished"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.app.backup.IBackupManager", data.readStrongBinder())
                return self.callFunction("doRestoreFinished", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.app.backup.IBackupManager'}
            if mycase("TRANSACTION_fail"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("fail", _arg0)
                # {'_arg0': 'java.lang.String'}
