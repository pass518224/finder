from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IActiveSessionsListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.session.IActiveSessionsListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.session.IActiveSessionsListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onActiveSessionsChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.media.session.MediaSession.Token")
                return self.callFunction("onActiveSessionsChanged", _arg0)
                # {'_arg0': 'java.util.List<android.media.session.MediaSession.Token>'}
