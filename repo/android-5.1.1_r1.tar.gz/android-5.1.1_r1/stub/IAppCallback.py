from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAppCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.nfc.IAppCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.nfc.IAppCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_createBeamShareData"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("createBeamShareData")
                # {'_result': 'android.nfc.BeamShareData'}
            if mycase("TRANSACTION_onNdefPushComplete"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onNdefPushComplete")
                # {}
            if mycase("TRANSACTION_onTagDiscovered"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.nfc.Tag", data)
                else:
                    _arg0 = None
                return self.callFunction("onTagDiscovered", _arg0)
                # {'_arg0': 'android.nfc.Tag', 'ELSE:': {}, 'IF': {}}
