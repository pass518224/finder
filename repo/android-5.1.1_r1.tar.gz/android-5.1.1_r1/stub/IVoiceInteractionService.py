from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVoiceInteractionService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.voice.IVoiceInteractionService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.voice.IVoiceInteractionService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_ready"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("ready")
                # {}
            if mycase("TRANSACTION_soundModelsChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("soundModelsChanged")
                # {}
            if mycase("TRANSACTION_shutdown"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("shutdown")
                # {}
