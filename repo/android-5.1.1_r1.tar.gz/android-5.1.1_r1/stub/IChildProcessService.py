from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IChildProcessService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "org.chromium.content.common.IChildProcessService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "org.chromium.content.common.IChildProcessService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setupConnection"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("org.chromium.content.common.IChildProcessCallback", data.readStrongBinder())
                return self.callFunction("setupConnection", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.os.Bundle', '_arg1': 'org.chromium.content.common.IChildProcessCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_crashIntentionallyForTesting"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("crashIntentionallyForTesting")
                # {}
