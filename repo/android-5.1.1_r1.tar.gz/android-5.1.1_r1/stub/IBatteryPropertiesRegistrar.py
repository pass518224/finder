from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBatteryPropertiesRegistrar:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.IBatteryPropertiesRegistrar"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.IBatteryPropertiesRegistrar"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.os.IBatteryPropertiesListener", data.readStrongBinder())
                return self.callFunction("registerListener", _arg0)
                # {'_arg0': 'android.os.IBatteryPropertiesListener'}
            if mycase("TRANSACTION_unregisterListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.os.IBatteryPropertiesListener", data.readStrongBinder())
                return self.callFunction("unregisterListener", _arg0)
                # {'_arg0': 'android.os.IBatteryPropertiesListener'}
            if mycase("TRANSACTION_getProperty"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.newInstance("android.os.BatteryProperty", )
                return self.callFunction("getProperty", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'android.os.BatteryProperty'}
