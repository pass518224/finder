from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsStreamMediaSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsStreamMediaSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsStreamMediaSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("close")
                # {}
