from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPackageStatsObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IPackageStatsObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IPackageStatsObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onGetStatsCompleted"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.PackageStats", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("onGetStatsCompleted", _arg0, _arg1)
                # {'_arg0': 'android.content.pm.PackageStats', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
