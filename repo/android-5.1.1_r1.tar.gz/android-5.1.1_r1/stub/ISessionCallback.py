from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISessionCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.session.ISessionCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.session.ISessionCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ResultReceiver", data)
                else:
                    _arg2 = None
                return self.callFunction("onCommand", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.ResultReceiver', '_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onMediaButton"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ResultReceiver", data)
                else:
                    _arg2 = None
                return self.callFunction("onMediaButton", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.ResultReceiver', '_arg0': 'android.content.Intent', '_arg1': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPlay"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onPlay")
                # {}
            if mycase("TRANSACTION_onPlayFromMediaId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("onPlayFromMediaId", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPlayFromSearch"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("onPlayFromSearch", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onSkipToTrack"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("onSkipToTrack", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_onPause"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onPause")
                # {}
            if mycase("TRANSACTION_onStop"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onStop")
                # {}
            if mycase("TRANSACTION_onNext"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onNext")
                # {}
            if mycase("TRANSACTION_onPrevious"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onPrevious")
                # {}
            if mycase("TRANSACTION_onFastForward"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onFastForward")
                # {}
            if mycase("TRANSACTION_onRewind"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onRewind")
                # {}
            if mycase("TRANSACTION_onSeekTo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("onSeekTo", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_onRate"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.Rating", data)
                else:
                    _arg0 = None
                return self.callFunction("onRate", _arg0)
                # {'_arg0': 'android.media.Rating', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onCustomAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("onCustomAction", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onAdjustVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onAdjustVolume", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onSetVolumeTo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onSetVolumeTo", _arg0)
                # {'_arg0': 'int'}
