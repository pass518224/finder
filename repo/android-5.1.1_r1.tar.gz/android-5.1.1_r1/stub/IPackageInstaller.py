from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPackageInstaller:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IPackageInstaller"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IPackageInstaller"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_createSession"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.pm.PackageInstaller.SessionParams", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("createSession", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'int', '_arg0': 'android.content.pm.PackageInstaller.SessionParams', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateSessionAppIcon"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Bitmap", data)
                else:
                    _arg1 = None
                return self.callFunction("updateSessionAppIcon", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.graphics.Bitmap', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateSessionAppLabel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("updateSessionAppLabel", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_abandonSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("abandonSession", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_openSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("openSession", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.pm.IPackageInstallerSession'}
            if mycase("TRANSACTION_getSessionInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getSessionInfo", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.pm.PackageInstaller.SessionInfo'}
            if mycase("TRANSACTION_getAllSessions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getAllSessions", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.pm.ParceledListSlice'}
            if mycase("TRANSACTION_getMySessions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getMySessions", _arg0, _arg1)
                # {'_result': 'android.content.pm.ParceledListSlice', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_registerCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.pm.IPackageInstallerCallback", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("registerCallback", _arg0, _arg1)
                # {'_arg0': 'android.content.pm.IPackageInstallerCallback', '_arg1': 'int'}
            if mycase("TRANSACTION_unregisterCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.pm.IPackageInstallerCallback", data.readStrongBinder())
                return self.callFunction("unregisterCallback", _arg0)
                # {'_arg0': 'android.content.pm.IPackageInstallerCallback'}
            if mycase("TRANSACTION_uninstall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.IntentSender", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                return self.callFunction("uninstall", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.content.IntentSender', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPermissionsResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setPermissionsResult", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
