from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRttManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.wifi.IRttManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.wifi.IRttManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getMessenger"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMessenger")
                # {'_result': 'android.os.Messenger'}
