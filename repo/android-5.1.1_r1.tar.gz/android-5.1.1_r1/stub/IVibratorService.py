from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVibratorService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.IVibratorService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.IVibratorService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_hasVibrator"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasVibrator")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_vibrate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readLong()
                _arg3 = data.readInt()
                _arg4 = data.readStrongBinder()
                return self.callFunction("vibrate", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'long', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'android.os.IBinder'}
            if mycase("TRANSACTION_vibratePattern"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.createLongArray()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readStrongBinder()
                return self.callFunction("vibratePattern", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'long', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'int', '_arg5': 'android.os.IBinder'}
            if mycase("TRANSACTION_cancelVibrate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("cancelVibrate", _arg0)
                # {'_arg0': 'android.os.IBinder'}
