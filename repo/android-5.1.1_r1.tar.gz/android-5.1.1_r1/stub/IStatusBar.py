from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IStatusBar:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.statusbar.IStatusBar"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.statusbar.IStatusBar"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setIcon"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.internal.statusbar.StatusBarIcon", data)
                else:
                    _arg1 = None
                return self.callFunction("setIcon", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'com.android.internal.statusbar.StatusBarIcon', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeIcon"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("removeIcon", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_disable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("disable", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_animateExpandNotificationsPanel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("animateExpandNotificationsPanel")
                # {}
            if mycase("TRANSACTION_animateExpandSettingsPanel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("animateExpandSettingsPanel")
                # {}
            if mycase("TRANSACTION_animateCollapsePanels"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("animateCollapsePanels")
                # {}
            if mycase("TRANSACTION_setSystemUiVisibility"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setSystemUiVisibility", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_topAppWindowChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("topAppWindowChanged", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setImeWindowStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = (0 != data.readInt())
                return self.callFunction("setImeWindowStatus", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'boolean', '_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_setWindowState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setWindowState", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_buzzBeepBlinked"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("buzzBeepBlinked")
                # {}
            if mycase("TRANSACTION_notificationLightOff"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("notificationLightOff")
                # {}
            if mycase("TRANSACTION_notificationLightPulse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("notificationLightPulse", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_showRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("showRecentApps", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_hideRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("hideRecentApps", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_toggleRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("toggleRecentApps")
                # {}
            if mycase("TRANSACTION_preloadRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("preloadRecentApps")
                # {}
            if mycase("TRANSACTION_cancelPreloadRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("cancelPreloadRecentApps")
                # {}
            if mycase("TRANSACTION_showScreenPinningRequest"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("showScreenPinningRequest")
                # {}
