from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IParcelFileDescriptorFactory:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.os.IParcelFileDescriptorFactory"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.os.IParcelFileDescriptorFactory"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_open"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("open", _arg0, _arg1)
                # {'_result': 'android.os.ParcelFileDescriptor', '_arg0': 'java.lang.String', '_arg1': 'int'}
