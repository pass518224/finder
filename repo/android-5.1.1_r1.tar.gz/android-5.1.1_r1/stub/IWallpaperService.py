from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWallpaperService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.wallpaper.IWallpaperService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.wallpaper.IWallpaperService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_attach"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.wallpaper.IWallpaperConnection", data.readStrongBinder())
                _arg1 = data.readStrongBinder()
                _arg2 = data.readInt()
                _arg3 = (0 != data.readInt())
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg6 = None
                return self.callFunction("attach", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'boolean', '_arg0': 'android.service.wallpaper.IWallpaperConnection', '_arg1': 'android.os.IBinder', '_arg6': 'android.graphics.Rect', '_arg4': 'int', '_arg5': 'int', 'ELSE:': {}, 'IF': {}}
