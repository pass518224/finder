from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IKeyguardStateCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.policy.IKeyguardStateCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.policy.IKeyguardStateCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onShowingStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onShowingStateChanged", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onSimSecureStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onSimSecureStateChanged", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onInputRestrictedStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onInputRestrictedStateChanged", _arg0)
                # {'_arg0': 'boolean'}
