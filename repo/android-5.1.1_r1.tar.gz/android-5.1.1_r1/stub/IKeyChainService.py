from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IKeyChainService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.security.IKeyChainService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.security.IKeyChainService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_requestPrivateKey"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("requestPrivateKey", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getCertificate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getCertificate", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'byte'}
            if mycase("TRANSACTION_installCaCertificate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                return self.callFunction("installCaCertificate", _arg0)
                # {'_arg0': 'byte'}
            if mycase("TRANSACTION_installKeyPair"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                _arg1 = data.createByteArray()
                _arg2 = data.readString()
                return self.callFunction("installKeyPair", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'byte', '_arg1': 'byte', '_result': 'boolean'}
            if mycase("TRANSACTION_deleteCaCertificate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("deleteCaCertificate", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_reset"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("reset")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getUserCaAliases"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getUserCaAliases")
                # {'_result': 'android.content.pm.ParceledListSlice'}
            if mycase("TRANSACTION_getSystemCaAliases"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSystemCaAliases")
                # {'_result': 'android.content.pm.ParceledListSlice'}
            if mycase("TRANSACTION_containsCaAlias"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("containsCaAlias", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_getEncodedCaCertificate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("getEncodedCaCertificate", _arg0, _arg1)
                # {'_result': 'byte', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getCaCertificateChainAliases"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("getCaCertificateChainAliases", _arg0, _arg1)
                # {'_result': 'java.util.List<java.lang.String>', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setGrant"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setGrant", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_hasGrant"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("hasGrant", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'java.lang.String'}
