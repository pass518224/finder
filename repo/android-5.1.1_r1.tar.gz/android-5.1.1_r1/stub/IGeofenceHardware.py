from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGeofenceHardware:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.location.IGeofenceHardware"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.location.IGeofenceHardware"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setGpsGeofenceHardware"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsGeofenceHardware", data.readStrongBinder())
                return self.callFunction("setGpsGeofenceHardware", _arg0)
                # {'_arg0': 'android.location.IGpsGeofenceHardware'}
            if mycase("TRANSACTION_setFusedGeofenceHardware"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IFusedGeofenceHardware", data.readStrongBinder())
                return self.callFunction("setFusedGeofenceHardware", _arg0)
                # {'_arg0': 'android.location.IFusedGeofenceHardware'}
            if mycase("TRANSACTION_getMonitoringTypes"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMonitoringTypes")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getStatusOfMonitoringType"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getStatusOfMonitoringType", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_addCircularFence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.hardware.location.GeofenceHardwareRequestParcelable", data)
                else:
                    _arg1 = None
                _arg2 = self.interfaceResolver("android.hardware.location.IGeofenceHardwareCallback", data.readStrongBinder())
                return self.callFunction("addCircularFence", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.hardware.location.IGeofenceHardwareCallback', '_arg0': 'int', '_arg1': 'android.hardware.location.GeofenceHardwareRequestParcelable', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("removeGeofence", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_pauseGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("pauseGeofence", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_resumeGeofence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("resumeGeofence", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_registerForMonitorStateChangeCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.hardware.location.IGeofenceHardwareMonitorCallback", data.readStrongBinder())
                return self.callFunction("registerForMonitorStateChangeCallback", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'android.hardware.location.IGeofenceHardwareMonitorCallback'}
            if mycase("TRANSACTION_unregisterForMonitorStateChangeCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.hardware.location.IGeofenceHardwareMonitorCallback", data.readStrongBinder())
                return self.callFunction("unregisterForMonitorStateChangeCallback", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'android.hardware.location.IGeofenceHardwareMonitorCallback'}
