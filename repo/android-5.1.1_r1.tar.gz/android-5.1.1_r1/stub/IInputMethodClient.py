from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputMethodClient:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.view.IInputMethodClient"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.view.IInputMethodClient"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setUsingInputMethod"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setUsingInputMethod", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onBindMethod"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("com.android.internal.view.InputBindResult", data)
                else:
                    _arg0 = None
                return self.callFunction("onBindMethod", _arg0)
                # {'_arg0': 'com.android.internal.view.InputBindResult', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onUnbindMethod"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onUnbindMethod", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setActive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setActive", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setUserActionNotificationSequenceNumber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setUserActionNotificationSequenceNumber", _arg0)
                # {'_arg0': 'int'}
