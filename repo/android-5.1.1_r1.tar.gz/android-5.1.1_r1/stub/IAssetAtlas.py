from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAssetAtlas:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IAssetAtlas"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IAssetAtlas"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_isCompatible"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isCompatible", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getBuffer"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getBuffer")
                # {'_result': 'android.view.GraphicBuffer'}
            if mycase("TRANSACTION_getMap"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMap")
                # {'_result': 'long'}
