from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrintSpooler:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IPrintSpooler"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IPrintSpooler"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_removeObsoletePrintJobs"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("removeObsoletePrintJobs")
                # {}
            if mycase("TRANSACTION_getPrintJobInfos"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrintSpoolerCallbacks", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                return self.callFunction("getPrintJobInfos", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.print.IPrintSpoolerCallbacks', '_arg1': 'android.content.ComponentName', '_arg4': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPrintJobInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.print.IPrintSpoolerCallbacks", data.readStrongBinder())
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("getPrintJobInfo", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.print.PrintJobId', '_arg1': 'android.print.IPrintSpoolerCallbacks', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createPrintJob"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("createPrintJob", _arg0)
                # {'_arg0': 'android.print.PrintJobInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPrintJobState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = self.interfaceResolver("android.print.IPrintSpoolerCallbacks", data.readStrongBinder())
                _arg4 = data.readInt()
                return self.callFunction("setPrintJobState", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.print.IPrintSpoolerCallbacks', '_arg0': 'android.print.PrintJobId', '_arg1': 'int', '_arg4': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPrintJobTag"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = self.interfaceResolver("android.print.IPrintSpoolerCallbacks", data.readStrongBinder())
                _arg3 = data.readInt()
                return self.callFunction("setPrintJobTag", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'android.print.IPrintSpoolerCallbacks', '_arg3': 'int', '_arg0': 'android.print.PrintJobId', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_writePrintJobData"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg1 = None
                return self.callFunction("writePrintJobData", _arg0, _arg1)
                # {'_arg0': 'android.os.ParcelFileDescriptor', '_arg1': 'android.print.PrintJobId', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_setClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.print.IPrintSpoolerClient", data.readStrongBinder())
                return self.callFunction("setClient", _arg0)
                # {'_arg0': 'android.print.IPrintSpoolerClient'}
            if mycase("TRANSACTION_setPrintJobCancelling"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobId", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("setPrintJobCancelling", _arg0, _arg1)
                # {'_arg0': 'android.print.PrintJobId', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
