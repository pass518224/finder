from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IDreamService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.dreams.IDreamService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.dreams.IDreamService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_attach"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = (0 != data.readInt())
                return self.callFunction("attach", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'boolean'}
            if mycase("TRANSACTION_detach"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("detach")
                # {}
            if mycase("TRANSACTION_wakeUp"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("wakeUp")
                # {}
