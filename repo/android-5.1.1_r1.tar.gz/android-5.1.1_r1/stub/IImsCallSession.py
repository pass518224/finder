from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsCallSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsCallSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsCallSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("close")
                # {}
            if mycase("TRANSACTION_getCallId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCallId")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getCallProfile"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCallProfile")
                # {'_result': 'com.android.ims.ImsCallProfile'}
            if mycase("TRANSACTION_getLocalCallProfile"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLocalCallProfile")
                # {'_result': 'com.android.ims.ImsCallProfile'}
            if mycase("TRANSACTION_getRemoteCallProfile"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getRemoteCallProfile")
                # {'_result': 'com.android.ims.ImsCallProfile'}
            if mycase("TRANSACTION_getProperty"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getProperty", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_getState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_isInCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isInCall")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSessionListener", data.readStrongBinder())
                return self.callFunction("setListener", _arg0)
                # {'_arg0': 'com.android.ims.internal.IImsCallSessionListener'}
            if mycase("TRANSACTION_setMute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setMute", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_start"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("start", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startConference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("startConference", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_accept"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsStreamMediaProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("accept", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'com.android.ims.ImsStreamMediaProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_reject"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("reject", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_terminate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("terminate", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_hold"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("com.android.ims.ImsStreamMediaProfile", data)
                else:
                    _arg0 = None
                return self.callFunction("hold", _arg0)
                # {'_arg0': 'com.android.ims.ImsStreamMediaProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_resume"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("com.android.ims.ImsStreamMediaProfile", data)
                else:
                    _arg0 = None
                return self.callFunction("resume", _arg0)
                # {'_arg0': 'com.android.ims.ImsStreamMediaProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_merge"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("merge")
                # {}
            if mycase("TRANSACTION_update"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsStreamMediaProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("update", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'com.android.ims.ImsStreamMediaProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_extendToConference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                return self.callFunction("extendToConference", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_inviteParticipants"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                return self.callFunction("inviteParticipants", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_removeParticipants"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                return self.callFunction("removeParticipants", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_sendDtmf"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Message", data)
                else:
                    _arg1 = None
                return self.callFunction("sendDtmf", _arg0, _arg1)
                # {'_arg0': 'char', '_arg1': 'android.os.Message', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startDtmf"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = None
                return self.callFunction("startDtmf", _arg0)
                # {'_arg0': 'char'}
            if mycase("TRANSACTION_stopDtmf"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopDtmf")
                # {}
            if mycase("TRANSACTION_sendUssd"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("sendUssd", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_getVideoCallProvider"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVideoCallProvider")
                # {'_result': 'com.android.ims.internal.IImsVideoCallProvider'}
            if mycase("TRANSACTION_isMultiparty"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isMultiparty")
                # {'_result': 'boolean'}
