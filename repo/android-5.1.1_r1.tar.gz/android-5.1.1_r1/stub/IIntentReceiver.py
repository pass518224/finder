from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IIntentReceiver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.IIntentReceiver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.IIntentReceiver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_performReceive"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                _arg4 = (0 != data.readInt())
                _arg5 = (0 != data.readInt())
                _arg6 = data.readInt()
                return self.callFunction("performReceive", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.os.Bundle', '_arg0': 'android.content.Intent', '_arg1': 'int', '_arg6': 'int', '_arg4': 'boolean', '_arg5': 'boolean', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
