from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IUsageStatsManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.usage.IUsageStatsManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.usage.IUsageStatsManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_queryUsageStats"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readLong()
                _arg3 = data.readString()
                return self.callFunction("queryUsageStats", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'long', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'long', '_result': 'android.content.pm.ParceledListSlice'}
            if mycase("TRANSACTION_queryConfigurationStats"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readLong()
                _arg3 = data.readString()
                return self.callFunction("queryConfigurationStats", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'long', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'long', '_result': 'android.content.pm.ParceledListSlice'}
            if mycase("TRANSACTION_queryEvents"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readLong()
                _arg2 = data.readString()
                return self.callFunction("queryEvents", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'long', '_arg1': 'long', '_result': 'android.app.usage.UsageEvents'}
