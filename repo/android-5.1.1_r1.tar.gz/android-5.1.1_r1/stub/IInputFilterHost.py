from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputFilterHost:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IInputFilterHost"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IInputFilterHost"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sendInputEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.InputEvent", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("sendInputEvent", _arg0, _arg1)
                # {'_arg0': 'android.view.InputEvent', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
