from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ILocationProvider:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.location.ILocationProvider"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.location.ILocationProvider"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_enable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enable")
                # {}
            if mycase("TRANSACTION_disable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disable")
                # {}
            if mycase("TRANSACTION_setRequest"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("com.android.internal.location.ProviderRequest", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg1 = None
                return self.callFunction("setRequest", _arg0, _arg1)
                # {'_arg0': 'com.android.internal.location.ProviderRequest', '_arg1': 'android.os.WorkSource', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_getProperties"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getProperties")
                # {'_result': 'com.android.internal.location.ProviderProperties'}
            if mycase("TRANSACTION_getStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.newInstance("android.os.Bundle", )
                return self.callFunction("getStatus", _arg0)
                # {'_arg0': 'android.os.Bundle', '_result': 'int'}
            if mycase("TRANSACTION_getStatusUpdateTime"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getStatusUpdateTime")
                # {'_result': 'long'}
            if mycase("TRANSACTION_sendExtraCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("sendExtraCommand", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
