from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAudioService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IAudioService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IAudioService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_adjustSuggestedStreamVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                return self.callFunction("adjustSuggestedStreamVolume", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_adjustStreamVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                return self.callFunction("adjustStreamVolume", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_adjustMasterVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("adjustMasterVolume", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setStreamVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                return self.callFunction("setStreamVolume", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setRemoteStreamVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setRemoteStreamVolume", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setMasterVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("setMasterVolume", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setStreamSolo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readStrongBinder()
                return self.callFunction("setStreamSolo", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.IBinder', '_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setStreamMute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readStrongBinder()
                return self.callFunction("setStreamMute", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.IBinder', '_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_isStreamMute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isStreamMute", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_forceRemoteSubmixFullVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readStrongBinder()
                return self.callFunction("forceRemoteSubmixFullVolume", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_setMasterMute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readStrongBinder()
                return self.callFunction("setMasterMute", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.os.IBinder', '_arg0': 'boolean', '_arg1': 'int'}
            if mycase("TRANSACTION_isMasterMute"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isMasterMute")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getStreamVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getStreamVolume", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getMasterVolume"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMasterVolume")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getStreamMaxVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getStreamMaxVolume", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getMasterMaxVolume"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMasterMaxVolume")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getLastAudibleStreamVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getLastAudibleStreamVolume", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getLastAudibleMasterVolume"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLastAudibleMasterVolume")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setMicrophoneMute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readString()
                return self.callFunction("setMicrophoneMute", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setRingerModeExternal"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("setRingerModeExternal", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setRingerModeInternal"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("setRingerModeInternal", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getRingerModeExternal"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getRingerModeExternal")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getRingerModeInternal"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getRingerModeInternal")
                # {'_result': 'int'}
            if mycase("TRANSACTION_isValidRingerMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isValidRingerMode", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setVibrateSetting"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setVibrateSetting", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getVibrateSetting"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getVibrateSetting", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_shouldVibrate"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("shouldVibrate", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readStrongBinder()
                return self.callFunction("setMode", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_getMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMode")
                # {'_result': 'int'}
            if mycase("TRANSACTION_playSoundEffect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("playSoundEffect", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_playSoundEffectVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readFloat()
                return self.callFunction("playSoundEffectVolume", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'float'}
            if mycase("TRANSACTION_loadSoundEffects"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("loadSoundEffects")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_unloadSoundEffects"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("unloadSoundEffects")
                # {}
            if mycase("TRANSACTION_reloadAudioSettings"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("reloadAudioSettings")
                # {}
            if mycase("TRANSACTION_avrcpSupportsAbsoluteVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("avrcpSupportsAbsoluteVolume", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setSpeakerphoneOn"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setSpeakerphoneOn", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_isSpeakerphoneOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isSpeakerphoneOn")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setBluetoothScoOn"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setBluetoothScoOn", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_isBluetoothScoOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isBluetoothScoOn")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setBluetoothA2dpOn"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setBluetoothA2dpOn", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_isBluetoothA2dpOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isBluetoothA2dpOn")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_requestAudioFocus"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.AudioAttributes", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readStrongBinder()
                _arg3 = self.interfaceResolver("android.media.IAudioFocusDispatcher", data.readStrongBinder())
                _arg4 = data.readString()
                _arg5 = data.readString()
                _arg6 = data.readInt()
                _arg7 = self.interfaceResolver("android.media.audiopolicy.IAudioPolicyCallback", data.readStrongBinder())
                return self.callFunction("requestAudioFocus", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_result': 'int', '_arg2': 'android.os.IBinder', '_arg3': 'android.media.IAudioFocusDispatcher', '_arg0': 'android.media.AudioAttributes', '_arg1': 'int', '_arg6': 'int', '_arg7': 'android.media.audiopolicy.IAudioPolicyCallback', '_arg4': 'java.lang.String', '_arg5': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_abandonAudioFocus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IAudioFocusDispatcher", data.readStrongBinder())
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.media.AudioAttributes", data)
                else:
                    _arg2 = None
                return self.callFunction("abandonAudioFocus", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'android.media.AudioAttributes', '_arg0': 'android.media.IAudioFocusDispatcher', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterAudioFocusClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("unregisterAudioFocusClient", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_getCurrentAudioFocus"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentAudioFocus")
                # {'_result': 'int'}
            if mycase("TRANSACTION_registerRemoteControlDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IRemoteControlDisplay", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("registerRemoteControlDisplay", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.media.IRemoteControlDisplay', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_registerRemoteController"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IRemoteControlDisplay", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg3 = None
                return self.callFunction("registerRemoteController", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'android.content.ComponentName', '_arg0': 'android.media.IRemoteControlDisplay', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterRemoteControlDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IRemoteControlDisplay", data.readStrongBinder())
                return self.callFunction("unregisterRemoteControlDisplay", _arg0)
                # {'_arg0': 'android.media.IRemoteControlDisplay'}
            if mycase("TRANSACTION_remoteControlDisplayUsesBitmapSize"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IRemoteControlDisplay", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("remoteControlDisplayUsesBitmapSize", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.media.IRemoteControlDisplay', '_arg1': 'int'}
            if mycase("TRANSACTION_remoteControlDisplayWantsPlaybackPositionSync"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IRemoteControlDisplay", data.readStrongBinder())
                _arg1 = (0 != data.readInt())
                return self.callFunction("remoteControlDisplayWantsPlaybackPositionSync", _arg0, _arg1)
                # {'_arg0': 'android.media.IRemoteControlDisplay', '_arg1': 'boolean'}
            if mycase("TRANSACTION_startBluetoothSco"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("startBluetoothSco", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_startBluetoothScoVirtualCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("startBluetoothScoVirtualCall", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_stopBluetoothSco"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("stopBluetoothSco", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_forceVolumeControlStream"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readStrongBinder()
                return self.callFunction("forceVolumeControlStream", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_setRingtonePlayer"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IRingtonePlayer", data.readStrongBinder())
                return self.callFunction("setRingtonePlayer", _arg0)
                # {'_arg0': 'android.media.IRingtonePlayer'}
            if mycase("TRANSACTION_getRingtonePlayer"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getRingtonePlayer")
                # {'_result': 'android.media.IRingtonePlayer'}
            if mycase("TRANSACTION_getMasterStreamType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMasterStreamType")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setWiredDeviceConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("setWiredDeviceConnectionState", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setBluetoothA2dpDeviceConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setBluetoothA2dpDeviceConnectionState", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'int', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startWatchingRoutes"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IAudioRoutesObserver", data.readStrongBinder())
                return self.callFunction("startWatchingRoutes", _arg0)
                # {'_arg0': 'android.media.IAudioRoutesObserver', '_result': 'android.media.AudioRoutesInfo'}
            if mycase("TRANSACTION_isCameraSoundForced"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isCameraSoundForced")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setVolumeController"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IVolumeController", data.readStrongBinder())
                return self.callFunction("setVolumeController", _arg0)
                # {'_arg0': 'android.media.IVolumeController'}
            if mycase("TRANSACTION_notifyVolumeControllerVisible"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IVolumeController", data.readStrongBinder())
                _arg1 = (0 != data.readInt())
                return self.callFunction("notifyVolumeControllerVisible", _arg0, _arg1)
                # {'_arg0': 'android.media.IVolumeController', '_arg1': 'boolean'}
            if mycase("TRANSACTION_isStreamAffectedByRingerMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isStreamAffectedByRingerMode", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_disableSafeMediaVolume"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disableSafeMediaVolume")
                # {}
            if mycase("TRANSACTION_setHdmiSystemAudioSupported"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setHdmiSystemAudioSupported", _arg0)
                # {'_arg0': 'boolean', '_result': 'int'}
            if mycase("TRANSACTION_isHdmiSystemAudioSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isHdmiSystemAudioSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_registerAudioPolicy"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.audiopolicy.AudioPolicyConfig", data)
                else:
                    _arg0 = None
                _arg1 = self.interfaceResolver("android.media.audiopolicy.IAudioPolicyCallback", data.readStrongBinder())
                _arg2 = (0 != data.readInt())
                return self.callFunction("registerAudioPolicy", _arg0, _arg1, _arg2)
                # {'_result': 'java.lang.String', '_arg2': 'boolean', '_arg0': 'android.media.audiopolicy.AudioPolicyConfig', '_arg1': 'android.media.audiopolicy.IAudioPolicyCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterAudioPolicyAsync"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.audiopolicy.IAudioPolicyCallback", data.readStrongBinder())
                return self.callFunction("unregisterAudioPolicyAsync", _arg0)
                # {'_arg0': 'android.media.audiopolicy.IAudioPolicyCallback'}
            if mycase("TRANSACTION_setFocusPropertiesForPolicy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.media.audiopolicy.IAudioPolicyCallback", data.readStrongBinder())
                return self.callFunction("setFocusPropertiesForPolicy", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'android.media.audiopolicy.IAudioPolicyCallback'}
