from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsEcbmListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsEcbmListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsEcbmListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_enteredECBM"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enteredECBM")
                # {}
            if mycase("TRANSACTION_exitedECBM"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("exitedECBM")
                # {}
