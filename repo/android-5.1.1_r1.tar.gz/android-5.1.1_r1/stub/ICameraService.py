from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICameraService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.ICameraService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.ICameraService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getNumberOfCameras"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNumberOfCameras")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getCameraInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.newInstance("android.hardware.CameraInfo", )
                return self.callFunction("getCameraInfo", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'android.hardware.CameraInfo'}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.ICameraClient", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                _arg4 = self.newInstance("android.hardware.camera2.utils.BinderHolder", )
                return self.callFunction("connect", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'int', '_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'android.hardware.ICameraClient', '_arg1': 'int', '_arg4': 'android.hardware.camera2.utils.BinderHolder'}
            if mycase("TRANSACTION_connectPro"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.IProCameraCallbacks", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                _arg4 = self.newInstance("android.hardware.camera2.utils.BinderHolder", )
                return self.callFunction("connectPro", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'int', '_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'android.hardware.IProCameraCallbacks', '_arg1': 'int', '_arg4': 'android.hardware.camera2.utils.BinderHolder'}
            if mycase("TRANSACTION_connectDevice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.camera2.ICameraDeviceCallbacks", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readInt()
                _arg4 = self.newInstance("android.hardware.camera2.utils.BinderHolder", )
                return self.callFunction("connectDevice", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'int', '_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'android.hardware.camera2.ICameraDeviceCallbacks', '_arg1': 'int', '_arg4': 'android.hardware.camera2.utils.BinderHolder'}
            if mycase("TRANSACTION_addListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.ICameraServiceListener", data.readStrongBinder())
                return self.callFunction("addListener", _arg0)
                # {'_arg0': 'android.hardware.ICameraServiceListener', '_result': 'int'}
            if mycase("TRANSACTION_removeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.ICameraServiceListener", data.readStrongBinder())
                return self.callFunction("removeListener", _arg0)
                # {'_arg0': 'android.hardware.ICameraServiceListener', '_result': 'int'}
            if mycase("TRANSACTION_getCameraCharacteristics"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.newInstance("android.hardware.camera2.impl.CameraMetadataNative", )
                return self.callFunction("getCameraCharacteristics", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'android.hardware.camera2.impl.CameraMetadataNative'}
            if mycase("TRANSACTION_getCameraVendorTagDescriptor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.newInstance("android.hardware.camera2.utils.BinderHolder", )
                return self.callFunction("getCameraVendorTagDescriptor", _arg0)
                # {'_arg0': 'android.hardware.camera2.utils.BinderHolder', '_result': 'int'}
            if mycase("TRANSACTION_getLegacyParameters"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1_length = data.readInt()
                if (_arg1_length < 0):
                    _arg1 = None
                else:
                    _arg1 = [None for _i in range(_arg1_length)] # java.lang.String
                return self.callFunction("getLegacyParameters", _arg0, _arg1)
                # {'_result': 'int', '_arg1_length': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_supportsCameraApi"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("supportsCameraApi", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_connectLegacy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.ICameraClient", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                _arg5 = self.newInstance("android.hardware.camera2.utils.BinderHolder", )
                return self.callFunction("connectLegacy", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'int', '_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'android.hardware.ICameraClient', '_arg1': 'int', '_arg4': 'int', '_arg5': 'android.hardware.camera2.utils.BinderHolder'}
