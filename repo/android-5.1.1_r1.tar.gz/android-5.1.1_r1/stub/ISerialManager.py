from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISerialManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.ISerialManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.ISerialManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getSerialPorts"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSerialPorts")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_openSerialPort"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("openSerialPort", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.os.ParcelFileDescriptor'}
