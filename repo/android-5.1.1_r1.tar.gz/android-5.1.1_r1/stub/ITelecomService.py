from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITelecomService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telecom.ITelecomService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telecom.ITelecomService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_showInCallScreen"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("showInCallScreen", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_getDefaultOutgoingPhoneAccount"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getDefaultOutgoingPhoneAccount", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.telecom.PhoneAccountHandle'}
            if mycase("TRANSACTION_getUserSelectedOutgoingPhoneAccount"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getUserSelectedOutgoingPhoneAccount")
                # {'_result': 'android.telecom.PhoneAccountHandle'}
            if mycase("TRANSACTION_setUserSelectedOutgoingPhoneAccount"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                return self.callFunction("setUserSelectedOutgoingPhoneAccount", _arg0)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCallCapablePhoneAccounts"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCallCapablePhoneAccounts")
                # {'_result': 'java.util.List<android.telecom.PhoneAccountHandle>'}
            if mycase("TRANSACTION_getPhoneAccountsSupportingScheme"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPhoneAccountsSupportingScheme", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.util.List<android.telecom.PhoneAccountHandle>'}
            if mycase("TRANSACTION_getPhoneAccountsForPackage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPhoneAccountsForPackage", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.util.List<android.telecom.PhoneAccountHandle>'}
            if mycase("TRANSACTION_getPhoneAccount"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                return self.callFunction("getPhoneAccount", _arg0)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', '_result': 'android.telecom.PhoneAccount', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAllPhoneAccountsCount"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllPhoneAccountsCount")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getAllPhoneAccounts"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllPhoneAccounts")
                # {'_result': 'java.util.List<android.telecom.PhoneAccount>'}
            if mycase("TRANSACTION_getAllPhoneAccountHandles"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllPhoneAccountHandles")
                # {'_result': 'java.util.List<android.telecom.PhoneAccountHandle>'}
            if mycase("TRANSACTION_getSimCallManager"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSimCallManager")
                # {'_result': 'android.telecom.PhoneAccountHandle'}
            if mycase("TRANSACTION_setSimCallManager"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                return self.callFunction("setSimCallManager", _arg0)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getSimCallManagers"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSimCallManagers")
                # {'_result': 'java.util.List<android.telecom.PhoneAccountHandle>'}
            if mycase("TRANSACTION_registerPhoneAccount"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccount", data)
                else:
                    _arg0 = None
                return self.callFunction("registerPhoneAccount", _arg0)
                # {'_arg0': 'android.telecom.PhoneAccount', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterPhoneAccount"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                return self.callFunction("unregisterPhoneAccount", _arg0)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearAccounts"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("clearAccounts", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_isVoiceMailNumber"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("isVoiceMailNumber", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.telecom.PhoneAccountHandle', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_hasVoiceMailNumber"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                return self.callFunction("hasVoiceMailNumber", _arg0)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getLine1Number"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                return self.callFunction("getLine1Number", _arg0)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', '_result': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getDefaultPhoneApp"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultPhoneApp")
                # {'_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_silenceRinger"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("silenceRinger")
                # {}
            if mycase("TRANSACTION_isInCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isInCall")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isRinging"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isRinging")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getCallState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCallState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_endCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("endCall")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_acceptRingingCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("acceptRingingCall")
                # {}
            if mycase("TRANSACTION_cancelMissedCallsNotification"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("cancelMissedCallsNotification")
                # {}
            if mycase("TRANSACTION_handlePinMmi"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("handlePinMmi", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_handlePinMmiForPhoneAccount"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("handlePinMmiForPhoneAccount", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.telecom.PhoneAccountHandle', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAdnUriForPhoneAccount"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                return self.callFunction("getAdnUriForPhoneAccount", _arg0)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', '_result': 'android.net.Uri', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isTtySupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isTtySupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getCurrentTtyMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentTtyMode")
                # {'_result': 'int'}
            if mycase("TRANSACTION_addNewIncomingCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("addNewIncomingCall", _arg0, _arg1)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_addNewUnknownCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("addNewUnknownCall", _arg0, _arg1)
                # {'_arg0': 'android.telecom.PhoneAccountHandle', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
