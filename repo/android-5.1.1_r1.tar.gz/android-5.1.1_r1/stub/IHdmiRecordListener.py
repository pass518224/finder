from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IHdmiRecordListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.hdmi.IHdmiRecordListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.hdmi.IHdmiRecordListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getOneTouchRecordSource"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getOneTouchRecordSource", _arg0)
                # {'_arg0': 'int', '_result': 'byte'}
            if mycase("TRANSACTION_onOneTouchRecordResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onOneTouchRecordResult", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onTimerRecordingResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onTimerRecordingResult", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onClearTimerRecordingResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onClearTimerRecordingResult", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
