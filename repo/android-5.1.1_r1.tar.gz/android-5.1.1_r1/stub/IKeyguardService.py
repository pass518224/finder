from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IKeyguardService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.policy.IKeyguardService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.policy.IKeyguardService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setOccluded"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setOccluded", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_addStateMonitorCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.policy.IKeyguardStateCallback", data.readStrongBinder())
                return self.callFunction("addStateMonitorCallback", _arg0)
                # {'_arg0': 'com.android.internal.policy.IKeyguardStateCallback'}
            if mycase("TRANSACTION_verifyUnlock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.policy.IKeyguardExitCallback", data.readStrongBinder())
                return self.callFunction("verifyUnlock", _arg0)
                # {'_arg0': 'com.android.internal.policy.IKeyguardExitCallback'}
            if mycase("TRANSACTION_keyguardDone"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("keyguardDone", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_dismiss"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dismiss")
                # {}
            if mycase("TRANSACTION_onDreamingStarted"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDreamingStarted")
                # {}
            if mycase("TRANSACTION_onDreamingStopped"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDreamingStopped")
                # {}
            if mycase("TRANSACTION_onScreenTurnedOff"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onScreenTurnedOff", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onScreenTurnedOn"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.policy.IKeyguardShowCallback", data.readStrongBinder())
                return self.callFunction("onScreenTurnedOn", _arg0)
                # {'_arg0': 'com.android.internal.policy.IKeyguardShowCallback'}
            if mycase("TRANSACTION_setKeyguardEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setKeyguardEnabled", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onSystemReady"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onSystemReady")
                # {}
            if mycase("TRANSACTION_doKeyguardTimeout"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("doKeyguardTimeout", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setCurrentUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setCurrentUser", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onBootCompleted"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onBootCompleted")
                # {}
            if mycase("TRANSACTION_startKeyguardExitAnimation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readLong()
                return self.callFunction("startKeyguardExitAnimation", _arg0, _arg1)
                # {'_arg0': 'long', '_arg1': 'long'}
            if mycase("TRANSACTION_onActivityDrawn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onActivityDrawn")
                # {}
