from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IServiceManager:
    pass
    descriptor = "android.os.IServiceManager"
class OnTransact(IServiceManager, Stub):
    def onTransact(self, code, data, reply):
        for mycase in Switch(code):
            if mycase("GET_SERVICE_TRANSACTION"):
                data.enforceInterface(IServiceManager.descriptor)
                name = data.readString()
                return self.callFunction("getService", name)
                # {'name': 'String', 'service': 'IBinder'}
            if mycase("CHECK_SERVICE_TRANSACTION"):
                data.enforceInterface(IServiceManager.descriptor)
                name = data.readString()
                return self.callFunction("checkService", name)
                # {'name': 'String', 'service': 'IBinder'}
            if mycase("ADD_SERVICE_TRANSACTION"):
                data.enforceInterface(IServiceManager.descriptor)
                name = data.readString()
                service = data.readStrongBinder()
                allowIsolated = (data.readInt() != 0)
                return self.callFunction("addService", name, service, allowIsolated)
                # {'name': 'String', 'service': 'IBinder', 'allowIsolated': 'boolean'}
            if mycase("LIST_SERVICES_TRANSACTION"):
                data.enforceInterface(IServiceManager.descriptor)
                return self.callFunction("listServices")
                # {'list': 'String'}
            if mycase("SET_PERMISSION_CONTROLLER_TRANSACTION"):
                data.enforceInterface(IServiceManager.descriptor)
                controller = self.interfaceResolver("IPermissionController", data.readStrongBinder())
                return self.callFunction("setPermissionController", controller)
                # {'controller': 'IPermissionController'}
