from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrintSpoolerCallbacks:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IPrintSpoolerCallbacks"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IPrintSpoolerCallbacks"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onGetPrintJobInfosResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.print.PrintJobInfo")
                _arg1 = data.readInt()
                return self.callFunction("onGetPrintJobInfosResult", _arg0, _arg1)
                # {'_arg0': 'java.util.List<android.print.PrintJobInfo>', '_arg1': 'int'}
            if mycase("TRANSACTION_onCancelPrintJobResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("onCancelPrintJobResult", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
            if mycase("TRANSACTION_onSetPrintJobStateResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("onSetPrintJobStateResult", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
            if mycase("TRANSACTION_onSetPrintJobTagResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("onSetPrintJobTagResult", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
            if mycase("TRANSACTION_onGetPrintJobInfoResult"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobInfo", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("onGetPrintJobInfoResult", _arg0, _arg1)
                # {'_arg0': 'android.print.PrintJobInfo', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
