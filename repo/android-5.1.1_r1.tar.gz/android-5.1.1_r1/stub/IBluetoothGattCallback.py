from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothGattCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothGattCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothGattCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onClientRegistered"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onClientRegistered", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onClientConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                _arg3 = data.readString()
                return self.callFunction("onClientConnectionState", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'boolean', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onScanResult"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.le.ScanResult", data)
                else:
                    _arg0 = None
                return self.callFunction("onScanResult", _arg0)
                # {'_arg0': 'android.bluetooth.le.ScanResult', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onBatchScanResults"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.bluetooth.le.ScanResult")
                return self.callFunction("onBatchScanResults", _arg0)
                # {'_arg0': 'java.util.List<android.bluetooth.le.ScanResult>'}
            if mycase("TRANSACTION_onGetService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg3 = None
                return self.callFunction("onGetService", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'android.os.ParcelUuid', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onGetIncludedService"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                return self.callFunction("onGetIncludedService", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'android.os.ParcelUuid', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'android.os.ParcelUuid', '_arg4': 'int', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onGetCharacteristic"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg5 = None
                _arg6 = data.readInt()
                return self.callFunction("onGetCharacteristic", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'android.os.ParcelUuid', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'int', '_arg4': 'int', '_arg5': 'android.os.ParcelUuid', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onGetDescriptor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg5 = None
                _arg6 = data.readInt()
                if (0 != data.readInt()):
                    _arg7 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg7 = None
                return self.callFunction("onGetDescriptor", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'int', '_arg3': 'android.os.ParcelUuid', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'int', '_arg7': 'android.os.ParcelUuid', '_arg4': 'int', '_arg5': 'android.os.ParcelUuid', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onSearchComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("onSearchComplete", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_onCharacteristicRead"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.createByteArray()
                return self.callFunction("onCharacteristicRead", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'android.os.ParcelUuid', '_arg7': 'byte', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onCharacteristicWrite"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                return self.callFunction("onCharacteristicWrite", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'android.os.ParcelUuid', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onExecuteWrite"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("onExecuteWrite", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_onDescriptorRead"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg8 = None
                _arg9 = data.createByteArray()
                return self.callFunction("onDescriptorRead", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9)
                # {'_arg8': 'android.os.ParcelUuid', '_arg9': 'byte', '_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'android.os.ParcelUuid', '_arg7': 'int', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onDescriptorWrite"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg6 = None
                _arg7 = data.readInt()
                if (0 != data.readInt()):
                    _arg8 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg8 = None
                return self.callFunction("onDescriptorWrite", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'android.os.ParcelUuid', '_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'android.os.ParcelUuid', '_arg7': 'int', '_arg4': 'android.os.ParcelUuid', '_arg5': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onNotify"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg5 = None
                _arg6 = data.createByteArray()
                return self.callFunction("onNotify", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'android.os.ParcelUuid', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg6': 'byte', '_arg4': 'int', '_arg5': 'android.os.ParcelUuid', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onReadRemoteRssi"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("onReadRemoteRssi", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_onMultiAdvertiseCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.bluetooth.le.AdvertiseSettings", data)
                else:
                    _arg2 = None
                return self.callFunction("onMultiAdvertiseCallback", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.bluetooth.le.AdvertiseSettings', '_arg0': 'int', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onConfigureMTU"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("onConfigureMTU", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_onFoundOrLost"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.bluetooth.le.ScanResult", data)
                else:
                    _arg1 = None
                return self.callFunction("onFoundOrLost", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'android.bluetooth.le.ScanResult', 'ELSE:': {}, 'IF': {}}
