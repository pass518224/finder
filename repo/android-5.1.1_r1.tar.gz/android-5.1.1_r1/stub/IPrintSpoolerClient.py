from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPrintSpoolerClient:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IPrintSpoolerClient"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IPrintSpoolerClient"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onPrintJobQueued"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("onPrintJobQueued", _arg0)
                # {'_arg0': 'android.print.PrintJobInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onAllPrintJobsForServiceHandled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("onAllPrintJobsForServiceHandled", _arg0)
                # {'_arg0': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onAllPrintJobsHandled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onAllPrintJobsHandled")
                # {}
            if mycase("TRANSACTION_onPrintJobStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintJobInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("onPrintJobStateChanged", _arg0)
                # {'_arg0': 'android.print.PrintJobInfo', 'ELSE:': {}, 'IF': {}}
