from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITrustManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.trust.ITrustManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.trust.ITrustManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_reportUnlockAttempt"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("reportUnlockAttempt", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
            if mycase("TRANSACTION_reportEnabledTrustAgentsChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("reportEnabledTrustAgentsChanged", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_reportRequireCredentialEntry"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("reportRequireCredentialEntry", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_registerTrustListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.app.trust.ITrustListener", data.readStrongBinder())
                return self.callFunction("registerTrustListener", _arg0)
                # {'_arg0': 'android.app.trust.ITrustListener'}
            if mycase("TRANSACTION_unregisterTrustListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.app.trust.ITrustListener", data.readStrongBinder())
                return self.callFunction("unregisterTrustListener", _arg0)
                # {'_arg0': 'android.app.trust.ITrustListener'}
            if mycase("TRANSACTION_reportKeyguardShowingChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("reportKeyguardShowingChanged")
                # {}
            if mycase("TRANSACTION_isDeviceLocked"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isDeviceLocked", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
