from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVideoCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telecom.IVideoCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telecom.IVideoCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_receiveSessionModifyRequest"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.VideoProfile", data)
                else:
                    _arg0 = None
                return self.callFunction("receiveSessionModifyRequest", _arg0)
                # {'_arg0': 'android.telecom.VideoProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_receiveSessionModifyResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telecom.VideoProfile", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.telecom.VideoProfile", data)
                else:
                    _arg2 = None
                return self.callFunction("receiveSessionModifyResponse", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.telecom.VideoProfile', '_arg0': 'int', '_arg1': 'android.telecom.VideoProfile', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_handleCallSessionEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("handleCallSessionEvent", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_changePeerDimensions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("changePeerDimensions", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_changeCallDataUsage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("changeCallDataUsage", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_changeCameraCapabilities"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.telecom.CameraCapabilities", data)
                else:
                    _arg0 = None
                return self.callFunction("changeCameraCapabilities", _arg0)
                # {'_arg0': 'android.telecom.CameraCapabilities', 'ELSE:': {}, 'IF': {}}
