from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVoiceInteractionManagerService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.app.IVoiceInteractionManagerService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.app.IVoiceInteractionManagerService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_startSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.voice.IVoiceInteractionService", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("startSession", _arg0, _arg1)
                # {'_arg0': 'android.service.voice.IVoiceInteractionService', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deliverNewSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = self.interfaceResolver("android.service.voice.IVoiceInteractionSession", data.readStrongBinder())
                _arg2 = self.interfaceResolver("com.android.internal.app.IVoiceInteractor", data.readStrongBinder())
                return self.callFunction("deliverNewSession", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.internal.app.IVoiceInteractor', '_arg0': 'android.os.IBinder', '_arg1': 'android.service.voice.IVoiceInteractionSession', '_result': 'boolean'}
            if mycase("TRANSACTION_startVoiceActivity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                return self.callFunction("startVoiceActivity", _arg0, _arg1, _arg2)
                # {'_result': 'int', '_arg2': 'java.lang.String', '_arg0': 'android.os.IBinder', '_arg1': 'android.content.Intent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_finish"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("finish", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_getKeyphraseSoundModel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("getKeyphraseSoundModel", _arg0, _arg1)
                # {'_result': 'android.hardware.soundtrigger.SoundTrigger.KeyphraseSoundModel', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_updateKeyphraseSoundModel"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.soundtrigger.SoundTrigger.KeyphraseSoundModel", data)
                else:
                    _arg0 = None
                return self.callFunction("updateKeyphraseSoundModel", _arg0)
                # {'_arg0': 'android.hardware.soundtrigger.SoundTrigger.KeyphraseSoundModel', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deleteKeyphraseSoundModel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("deleteKeyphraseSoundModel", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getDspModuleProperties"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.voice.IVoiceInteractionService", data.readStrongBinder())
                return self.callFunction("getDspModuleProperties", _arg0)
                # {'_arg0': 'android.service.voice.IVoiceInteractionService', '_result': 'android.hardware.soundtrigger.SoundTrigger.ModuleProperties'}
            if mycase("TRANSACTION_isEnrolledForKeyphrase"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.voice.IVoiceInteractionService", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("isEnrolledForKeyphrase", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.service.voice.IVoiceInteractionService', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_startRecognition"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.voice.IVoiceInteractionService", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = self.interfaceResolver("android.hardware.soundtrigger.IRecognitionStatusCallback", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.hardware.soundtrigger.SoundTrigger.RecognitionConfig", data)
                else:
                    _arg4 = None
                return self.callFunction("startRecognition", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'int', '_arg2': 'java.lang.String', '_arg3': 'android.hardware.soundtrigger.IRecognitionStatusCallback', '_arg0': 'android.service.voice.IVoiceInteractionService', '_arg1': 'int', '_arg4': 'android.hardware.soundtrigger.SoundTrigger.RecognitionConfig', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopRecognition"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.voice.IVoiceInteractionService", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = self.interfaceResolver("android.hardware.soundtrigger.IRecognitionStatusCallback", data.readStrongBinder())
                return self.callFunction("stopRecognition", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.hardware.soundtrigger.IRecognitionStatusCallback', '_arg0': 'android.service.voice.IVoiceInteractionService', '_arg1': 'int', '_result': 'int'}
