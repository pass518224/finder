from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INotificationSideChannel:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.support.v4.app.INotificationSideChannel"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.support.v4.app.INotificationSideChannel"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_notify"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.app.Notification", data)
                else:
                    _arg3 = None
                return self.callFunction("notify", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.app.Notification', '_arg0': 'java.lang.String', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_cancel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("cancel", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_cancelAll"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("cancelAll", _arg0)
                # {'_arg0': 'java.lang.String'}
