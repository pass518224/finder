from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetworkActivityListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.INetworkActivityListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.INetworkActivityListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onNetworkActive"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onNetworkActive")
                # {}
