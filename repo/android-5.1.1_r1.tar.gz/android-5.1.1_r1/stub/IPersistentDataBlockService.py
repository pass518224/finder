from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPersistentDataBlockService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.persistentdata.IPersistentDataBlockService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.persistentdata.IPersistentDataBlockService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_write"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                return self.callFunction("write", _arg0)
                # {'_arg0': 'byte', '_result': 'int'}
            if mycase("TRANSACTION_read"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("read")
                # {'_result': 'byte'}
            if mycase("TRANSACTION_wipe"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("wipe")
                # {}
            if mycase("TRANSACTION_getDataBlockSize"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDataBlockSize")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getMaximumDataBlockSize"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMaximumDataBlockSize")
                # {'_result': 'long'}
            if mycase("TRANSACTION_setOemUnlockEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setOemUnlockEnabled", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_getOemUnlockEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getOemUnlockEnabled")
                # {'_result': 'boolean'}
