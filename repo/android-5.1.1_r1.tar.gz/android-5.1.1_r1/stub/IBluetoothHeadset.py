from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothHeadset:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothHeadset"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothHeadset"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("connect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("disconnect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getConnectedDevices"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConnectedDevices")
                # {'_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_getDevicesMatchingConnectionStates"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createIntArray()
                return self.callFunction("getDevicesMatchingConnectionStates", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_getConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getConnectionState", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPriority"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setPriority", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPriority"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getPriority", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startVoiceRecognition"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("startVoiceRecognition", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopVoiceRecognition"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("stopVoiceRecognition", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isAudioConnected"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("isAudioConnected", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendVendorSpecificResultCode"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("sendVendorSpecificResultCode", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'java.lang.String', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getBatteryUsageHint"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getBatteryUsageHint", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_acceptIncomingConnect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("acceptIncomingConnect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_rejectIncomingConnect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("rejectIncomingConnect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAudioState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getAudioState", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isAudioOn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isAudioOn")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_connectAudio"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("connectAudio")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_disconnectAudio"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnectAudio")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_startScoUsingVirtualVoiceCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("startScoUsingVirtualVoiceCall", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopScoUsingVirtualVoiceCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("stopScoUsingVirtualVoiceCall", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_phoneStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                return self.callFunction("phoneStateChanged", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int'}
            if mycase("TRANSACTION_clccResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = (0 != data.readInt())
                _arg5 = data.readString()
                _arg6 = data.readInt()
                return self.callFunction("clccResponse", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg6': 'int', '_arg4': 'boolean', '_arg5': 'java.lang.String'}
            if mycase("TRANSACTION_enableWBS"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enableWBS")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_disableWBS"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disableWBS")
                # {'_result': 'boolean'}
