from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothProfileServiceConnection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothProfileServiceConnection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothProfileServiceConnection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onServiceConnected"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readStrongBinder()
                return self.callFunction("onServiceConnected", _arg0, _arg1)
                # {'_arg0': 'android.content.ComponentName', '_arg1': 'android.os.IBinder', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onServiceDisconnected"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("onServiceDisconnected", _arg0)
                # {'_arg0': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
