from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IHdmiVendorCommandListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.hdmi.IHdmiVendorCommandListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.hdmi.IHdmiVendorCommandListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.createByteArray()
                _arg3 = (0 != data.readInt())
                return self.callFunction("onReceived", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'byte', '_arg3': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onControlStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("onControlStateChanged", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
