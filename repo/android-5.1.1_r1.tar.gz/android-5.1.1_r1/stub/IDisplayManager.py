from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IDisplayManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.display.IDisplayManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.display.IDisplayManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getDisplayInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getDisplayInfo", _arg0)
                # {'_arg0': 'int', '_result': 'android.view.DisplayInfo'}
            if mycase("TRANSACTION_getDisplayIds"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDisplayIds")
                # {'_result': 'int'}
            if mycase("TRANSACTION_registerCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.display.IDisplayManagerCallback", data.readStrongBinder())
                return self.callFunction("registerCallback", _arg0)
                # {'_arg0': 'android.hardware.display.IDisplayManagerCallback'}
            if mycase("TRANSACTION_startWifiDisplayScan"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("startWifiDisplayScan")
                # {}
            if mycase("TRANSACTION_stopWifiDisplayScan"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopWifiDisplayScan")
                # {}
            if mycase("TRANSACTION_connectWifiDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("connectWifiDisplay", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_disconnectWifiDisplay"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnectWifiDisplay")
                # {}
            if mycase("TRANSACTION_renameWifiDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("renameWifiDisplay", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_forgetWifiDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("forgetWifiDisplay", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_pauseWifiDisplay"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("pauseWifiDisplay")
                # {}
            if mycase("TRANSACTION_resumeWifiDisplay"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("resumeWifiDisplay")
                # {}
            if mycase("TRANSACTION_getWifiDisplayStatus"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWifiDisplayStatus")
                # {'_result': 'android.hardware.display.WifiDisplayStatus'}
            if mycase("TRANSACTION_createVirtualDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.display.IVirtualDisplayCallback", data.readStrongBinder())
                _arg1 = self.interfaceResolver("android.media.projection.IMediaProjection", data.readStrongBinder())
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readInt()
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                if (0 != data.readInt()):
                    _arg7 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg7 = None
                _arg8 = data.readInt()
                return self.callFunction("createVirtualDisplay", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'int', '_result': 'int', '_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.hardware.display.IVirtualDisplayCallback', '_arg1': 'android.media.projection.IMediaProjection', '_arg6': 'int', '_arg7': 'android.view.Surface', '_arg4': 'int', '_arg5': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_resizeVirtualDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.display.IVirtualDisplayCallback", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("resizeVirtualDisplay", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.hardware.display.IVirtualDisplayCallback', '_arg1': 'int'}
            if mycase("TRANSACTION_setVirtualDisplaySurface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.display.IVirtualDisplayCallback", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg1 = None
                return self.callFunction("setVirtualDisplaySurface", _arg0, _arg1)
                # {'_arg0': 'android.hardware.display.IVirtualDisplayCallback', '_arg1': 'android.view.Surface', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_releaseVirtualDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.display.IVirtualDisplayCallback", data.readStrongBinder())
                return self.callFunction("releaseVirtualDisplay", _arg0)
                # {'_arg0': 'android.hardware.display.IVirtualDisplayCallback'}
