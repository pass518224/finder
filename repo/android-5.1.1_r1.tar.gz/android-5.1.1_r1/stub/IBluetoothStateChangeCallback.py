from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothStateChangeCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothStateChangeCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothStateChangeCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onBluetoothStateChange"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onBluetoothStateChange", _arg0)
                # {'_arg0': 'boolean'}
