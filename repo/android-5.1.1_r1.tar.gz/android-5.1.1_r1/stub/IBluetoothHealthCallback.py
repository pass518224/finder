from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothHealthCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothHealthCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothHealthCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onHealthAppConfigurationStatusChange"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothHealthAppConfiguration", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("onHealthAppConfigurationStatusChange", _arg0, _arg1)
                # {'_arg0': 'android.bluetooth.BluetoothHealthAppConfiguration', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onHealthChannelStateChange"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothHealthAppConfiguration", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                return self.callFunction("onHealthChannelStateChange", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.bluetooth.BluetoothHealthAppConfiguration', '_arg1': 'android.bluetooth.BluetoothDevice', '_arg4': 'android.os.ParcelFileDescriptor', '_arg5': 'int', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
