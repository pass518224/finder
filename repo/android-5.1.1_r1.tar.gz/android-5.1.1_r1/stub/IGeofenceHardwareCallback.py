from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGeofenceHardwareCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.location.IGeofenceHardwareCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.location.IGeofenceHardwareCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onGeofenceTransition"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.location.Location", data)
                else:
                    _arg2 = None
                _arg3 = data.readLong()
                _arg4 = data.readInt()
                return self.callFunction("onGeofenceTransition", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.location.Location', '_arg3': 'long', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onGeofenceAdd"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onGeofenceAdd", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onGeofenceRemove"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onGeofenceRemove", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onGeofencePause"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onGeofencePause", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_onGeofenceResume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onGeofenceResume", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
