from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetworkStatsSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.INetworkStatsSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.INetworkStatsSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getSummaryForNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkTemplate", data)
                else:
                    _arg0 = None
                _arg1 = data.readLong()
                _arg2 = data.readLong()
                return self.callFunction("getSummaryForNetwork", _arg0, _arg1, _arg2)
                # {'_result': 'android.net.NetworkStats', '_arg2': 'long', '_arg0': 'android.net.NetworkTemplate', '_arg1': 'long', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getHistoryForNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkTemplate", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getHistoryForNetwork", _arg0, _arg1)
                # {'_result': 'android.net.NetworkStatsHistory', '_arg0': 'android.net.NetworkTemplate', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getSummaryForAllUid"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkTemplate", data)
                else:
                    _arg0 = None
                _arg1 = data.readLong()
                _arg2 = data.readLong()
                _arg3 = (0 != data.readInt())
                return self.callFunction("getSummaryForAllUid", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'android.net.NetworkStats', '_arg2': 'long', '_arg3': 'boolean', '_arg0': 'android.net.NetworkTemplate', '_arg1': 'long', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getHistoryForUid"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkTemplate", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                return self.callFunction("getHistoryForUid", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'android.net.NetworkStatsHistory', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.net.NetworkTemplate', '_arg1': 'int', '_arg4': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("close")
                # {}
