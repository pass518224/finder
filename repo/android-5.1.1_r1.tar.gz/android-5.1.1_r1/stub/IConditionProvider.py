from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IConditionProvider:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.notification.IConditionProvider"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.notification.IConditionProvider"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onConnected"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onConnected")
                # {}
            if mycase("TRANSACTION_onRequestConditions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onRequestConditions", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onSubscribe"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                return self.callFunction("onSubscribe", _arg0)
                # {'_arg0': 'android.net.Uri', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onUnsubscribe"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                return self.callFunction("onUnsubscribe", _arg0)
                # {'_arg0': 'android.net.Uri', 'ELSE:': {}, 'IF': {}}
