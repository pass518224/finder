from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IStopUserCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IStopUserCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IStopUserCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_userStopped"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("userStopped", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_userStopAborted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("userStopAborted", _arg0)
                # {'_arg0': 'int'}
