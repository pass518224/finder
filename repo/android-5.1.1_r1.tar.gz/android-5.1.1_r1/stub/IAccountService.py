from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAccountService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.emailcommon.service.IAccountService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.emailcommon.service.IAccountService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getAccountColor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("getAccountColor", _arg0)
                # {'_arg0': 'long', '_result': 'int'}
            if mycase("TRANSACTION_getConfigurationData"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getConfigurationData", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.os.Bundle'}
            if mycase("TRANSACTION_getDeviceId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDeviceId")
                # {'_result': 'java.lang.String'}
