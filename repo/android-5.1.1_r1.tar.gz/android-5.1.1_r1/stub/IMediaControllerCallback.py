from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaControllerCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.support.v4.media.session.IMediaControllerCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.support.v4.media.session.IMediaControllerCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("onEvent", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onSessionDestroyed"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onSessionDestroyed")
                # {}
            if mycase("TRANSACTION_onPlaybackStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.support.v4.media.session.PlaybackStateCompat", data)
                else:
                    _arg0 = None
                return self.callFunction("onPlaybackStateChanged", _arg0)
                # {'_arg0': 'android.support.v4.media.session.PlaybackStateCompat', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onMetadataChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.support.v4.media.MediaMetadataCompat", data)
                else:
                    _arg0 = None
                return self.callFunction("onMetadataChanged", _arg0)
                # {'_arg0': 'android.support.v4.media.MediaMetadataCompat', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onQueueChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArrayList("android.support.v4.media.session.MediaSessionCompat.QueueItem")
                return self.callFunction("onQueueChanged", _arg0)
                # {'_arg0': 'java.util.List<android.support.v4.media.session.MediaSessionCompat.QueueItem>'}
            if mycase("TRANSACTION_onQueueTitleChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                return self.callFunction("onQueueTitleChanged", _arg0)
                # {'_arg0': 'java.lang.CharSequence', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onExtrasChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("onExtrasChanged", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onVolumeInfoChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.support.v4.media.session.ParcelableVolumeInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("onVolumeInfoChanged", _arg0)
                # {'_arg0': 'android.support.v4.media.session.ParcelableVolumeInfo', 'ELSE:': {}, 'IF': {}}
