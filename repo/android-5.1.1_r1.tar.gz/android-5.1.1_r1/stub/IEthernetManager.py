from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IEthernetManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.IEthernetManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.IEthernetManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConfiguration")
                # {'_result': 'android.net.IpConfiguration'}
            if mycase("TRANSACTION_setConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.IpConfiguration", data)
                else:
                    _arg0 = None
                return self.callFunction("setConfiguration", _arg0)
                # {'_arg0': 'android.net.IpConfiguration', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isAvailable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isAvailable")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_addListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.IEthernetServiceListener", data.readStrongBinder())
                return self.callFunction("addListener", _arg0)
                # {'_arg0': 'android.net.IEthernetServiceListener'}
            if mycase("TRANSACTION_removeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.IEthernetServiceListener", data.readStrongBinder())
                return self.callFunction("removeListener", _arg0)
                # {'_arg0': 'android.net.IEthernetServiceListener'}
