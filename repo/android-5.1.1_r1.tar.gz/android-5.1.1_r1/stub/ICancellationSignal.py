from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICancellationSignal:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.ICancellationSignal"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.ICancellationSignal"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_cancel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("cancel")
                # {}
