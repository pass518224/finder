from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaHTTPConnection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IMediaHTTPConnection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IMediaHTTPConnection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("connect", _arg0, _arg1)
                # {'_result': 'android.os.IBinder', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnect")
                # {}
            if mycase("TRANSACTION_readAt"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readInt()
                return self.callFunction("readAt", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'long', '_arg1': 'int'}
            if mycase("TRANSACTION_getSize"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSize")
                # {'_result': 'long'}
            if mycase("TRANSACTION_getMIMEType"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMIMEType")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getUri"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getUri")
                # {'_result': 'java.lang.String'}
