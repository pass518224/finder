from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IDreamManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.dreams.IDreamManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.dreams.IDreamManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_dream"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dream")
                # {}
            if mycase("TRANSACTION_awaken"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("awaken")
                # {}
            if mycase("TRANSACTION_setDreamComponents"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.content.ComponentName")
                return self.callFunction("setDreamComponents", _arg0)
                # {'_arg0': 'android.content.ComponentName'}
            if mycase("TRANSACTION_getDreamComponents"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDreamComponents")
                # {'_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_getDefaultDreamComponent"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultDreamComponent")
                # {'_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_testDream"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("testDream", _arg0)
                # {'_arg0': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isDreaming"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isDreaming")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_finishSelf"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = (0 != data.readInt())
                return self.callFunction("finishSelf", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'boolean'}
            if mycase("TRANSACTION_startDozing"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("startDozing", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_stopDozing"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("stopDozing", _arg0)
                # {'_arg0': 'android.os.IBinder'}
