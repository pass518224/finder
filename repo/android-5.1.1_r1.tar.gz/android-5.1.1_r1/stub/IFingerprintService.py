from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IFingerprintService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.fingerprint.IFingerprintService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.fingerprint.IFingerprintService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_enroll"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                return self.callFunction("enroll", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'long'}
            if mycase("TRANSACTION_enrollCancel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("enrollCancel", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_remove"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("remove", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_startListening"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = self.interfaceResolver("android.service.fingerprint.IFingerprintServiceReceiver", data.readStrongBinder())
                _arg2 = data.readInt()
                return self.callFunction("startListening", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'android.service.fingerprint.IFingerprintServiceReceiver'}
            if mycase("TRANSACTION_stopListening"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("stopListening", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
