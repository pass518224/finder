from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INotificationListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.notification.INotificationListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.notification.INotificationListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onListenerConnected"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.service.notification.NotificationRankingUpdate", data)
                else:
                    _arg0 = None
                return self.callFunction("onListenerConnected", _arg0)
                # {'_arg0': 'android.service.notification.NotificationRankingUpdate', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onNotificationPosted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.IStatusBarNotificationHolder", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.service.notification.NotificationRankingUpdate", data)
                else:
                    _arg1 = None
                return self.callFunction("onNotificationPosted", _arg0, _arg1)
                # {'_arg0': 'android.service.notification.IStatusBarNotificationHolder', '_arg1': 'android.service.notification.NotificationRankingUpdate', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onNotificationRemoved"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.notification.IStatusBarNotificationHolder", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.service.notification.NotificationRankingUpdate", data)
                else:
                    _arg1 = None
                return self.callFunction("onNotificationRemoved", _arg0, _arg1)
                # {'_arg0': 'android.service.notification.IStatusBarNotificationHolder', '_arg1': 'android.service.notification.NotificationRankingUpdate', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onNotificationRankingUpdate"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.service.notification.NotificationRankingUpdate", data)
                else:
                    _arg0 = None
                return self.callFunction("onNotificationRankingUpdate", _arg0)
                # {'_arg0': 'android.service.notification.NotificationRankingUpdate', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onListenerHintsChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onListenerHintsChanged", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onInterruptionFilterChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onInterruptionFilterChanged", _arg0)
                # {'_arg0': 'int'}
