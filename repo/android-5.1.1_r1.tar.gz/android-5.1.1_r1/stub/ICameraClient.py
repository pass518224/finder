from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICameraClient:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.ICameraClient"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.ICameraClient"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
