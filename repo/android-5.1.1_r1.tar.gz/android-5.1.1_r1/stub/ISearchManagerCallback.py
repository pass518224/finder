from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISearchManagerCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.ISearchManagerCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.ISearchManagerCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onDismiss"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onDismiss")
                # {}
            if mycase("TRANSACTION_onCancel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onCancel")
                # {}
