from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INfcUnlockHandler:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.nfc.INfcUnlockHandler"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.nfc.INfcUnlockHandler"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onUnlockAttempted"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.nfc.Tag", data)
                else:
                    _arg0 = None
                return self.callFunction("onUnlockAttempted", _arg0)
                # {'_arg0': 'android.nfc.Tag', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
