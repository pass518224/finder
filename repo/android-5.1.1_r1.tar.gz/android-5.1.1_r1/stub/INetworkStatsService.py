from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetworkStatsService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.INetworkStatsService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.INetworkStatsService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_openSession"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("openSession")
                # {'_result': 'android.net.INetworkStatsSession'}
            if mycase("TRANSACTION_getNetworkTotalBytes"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkTemplate", data)
                else:
                    _arg0 = None
                _arg1 = data.readLong()
                _arg2 = data.readLong()
                return self.callFunction("getNetworkTotalBytes", _arg0, _arg1, _arg2)
                # {'_result': 'long', '_arg2': 'long', '_arg0': 'android.net.NetworkTemplate', '_arg1': 'long', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getDataLayerSnapshotForUid"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getDataLayerSnapshotForUid", _arg0)
                # {'_arg0': 'int', '_result': 'android.net.NetworkStats'}
            if mycase("TRANSACTION_getMobileIfaces"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMobileIfaces")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_incrementOperationCount"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("incrementOperationCount", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setUidForeground"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setUidForeground", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_forceUpdateIfaces"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("forceUpdateIfaces")
                # {}
            if mycase("TRANSACTION_forceUpdate"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("forceUpdate")
                # {}
            if mycase("TRANSACTION_advisePersistThreshold"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("advisePersistThreshold", _arg0)
                # {'_arg0': 'long'}
