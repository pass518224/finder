from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IActivityContainer:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IActivityContainer"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IActivityContainer"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_attachToDisplay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("attachToDisplay", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setSurface"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("setSurface", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.view.Surface', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startActivity"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                return self.callFunction("startActivity", _arg0)
                # {'_arg0': 'android.content.Intent', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startActivityIntentSender"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.IIntentSender", data.readStrongBinder())
                return self.callFunction("startActivityIntentSender", _arg0)
                # {'_arg0': 'android.content.IIntentSender', '_result': 'int'}
            if mycase("TRANSACTION_checkEmbeddedAllowed"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                return self.callFunction("checkEmbeddedAllowed", _arg0)
                # {'_arg0': 'android.content.Intent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_checkEmbeddedAllowedIntentSender"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.IIntentSender", data.readStrongBinder())
                return self.callFunction("checkEmbeddedAllowedIntentSender", _arg0)
                # {'_arg0': 'android.content.IIntentSender'}
            if mycase("TRANSACTION_getDisplayId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDisplayId")
                # {'_result': 'int'}
            if mycase("TRANSACTION_injectEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.InputEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("injectEvent", _arg0)
                # {'_arg0': 'android.view.InputEvent', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_release"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("release")
                # {}
