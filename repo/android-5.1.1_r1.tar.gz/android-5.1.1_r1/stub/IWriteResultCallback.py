from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWriteResultCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.IWriteResultCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.IWriteResultCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onWriteStarted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.os.ICancellationSignal", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("onWriteStarted", _arg0, _arg1)
                # {'_arg0': 'android.os.ICancellationSignal', '_arg1': 'int'}
            if mycase("TRANSACTION_onWriteFinished"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.print.PageRange")
                _arg1 = data.readInt()
                return self.callFunction("onWriteFinished", _arg0, _arg1)
                # {'_arg0': 'android.print.PageRange', '_arg1': 'int'}
            if mycase("TRANSACTION_onWriteFailed"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("onWriteFailed", _arg0, _arg1)
                # {'_arg0': 'java.lang.CharSequence', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onWriteCanceled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onWriteCanceled", _arg0)
                # {'_arg0': 'int'}
