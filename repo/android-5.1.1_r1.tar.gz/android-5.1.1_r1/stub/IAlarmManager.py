from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IAlarmManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IAlarmManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IAlarmManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_set"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readLong()
                _arg2 = data.readLong()
                _arg3 = data.readLong()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg4 = None
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg5 = None
                if (0 != data.readInt()):
                    _arg6 = self.creatorResolver("android.app.AlarmManager.AlarmClockInfo", data)
                else:
                    _arg6 = None
                return self.callFunction("set", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'long', '_arg3': 'long', '_arg0': 'int', '_arg1': 'long', '_arg6': 'android.app.AlarmManager.AlarmClockInfo', '_arg4': 'android.app.PendingIntent', '_arg5': 'android.os.WorkSource', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setTime"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("setTime", _arg0)
                # {'_arg0': 'long', '_result': 'boolean'}
            if mycase("TRANSACTION_setTimeZone"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setTimeZone", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_remove"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg0 = None
                return self.callFunction("remove", _arg0)
                # {'_arg0': 'android.app.PendingIntent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getNextAlarmClock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getNextAlarmClock", _arg0)
                # {'_arg0': 'int', '_result': 'android.app.AlarmManager.AlarmClockInfo'}
