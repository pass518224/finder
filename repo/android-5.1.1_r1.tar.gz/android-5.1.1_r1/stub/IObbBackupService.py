from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IObbBackupService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.backup.IObbBackupService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.backup.IObbBackupService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_backupObbs"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("android.app.backup.IBackupManager", data.readStrongBinder())
                return self.callFunction("backupObbs", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'android.app.backup.IBackupManager', '_arg0': 'java.lang.String', '_arg1': 'android.os.ParcelFileDescriptor', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_restoreObbFile"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg1 = None
                _arg2 = data.readLong()
                _arg3 = data.readInt()
                _arg4 = data.readString()
                _arg5 = data.readLong()
                _arg6 = data.readLong()
                _arg7 = data.readInt()
                _arg8 = self.interfaceResolver("android.app.backup.IBackupManager", data.readStrongBinder())
                return self.callFunction("restoreObbFile", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8)
                # {'_arg8': 'android.app.backup.IBackupManager', '_arg2': 'long', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.os.ParcelFileDescriptor', '_arg6': 'long', '_arg7': 'int', '_arg4': 'java.lang.String', '_arg5': 'long', 'ELSE:': {}, 'IF': {}}
