from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICamera:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.ICamera"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.ICamera"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnect")
                # {}
