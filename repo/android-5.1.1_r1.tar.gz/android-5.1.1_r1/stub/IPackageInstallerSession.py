from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IPackageInstallerSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.pm.IPackageInstallerSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.pm.IPackageInstallerSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setClientProgress"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readFloat()
                return self.callFunction("setClientProgress", _arg0)
                # {'_arg0': 'float'}
            if mycase("TRANSACTION_addClientProgress"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readFloat()
                return self.callFunction("addClientProgress", _arg0)
                # {'_arg0': 'float'}
            if mycase("TRANSACTION_getNames"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNames")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_openWrite"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readLong()
                _arg2 = data.readLong()
                return self.callFunction("openWrite", _arg0, _arg1, _arg2)
                # {'_arg2': 'long', '_arg0': 'java.lang.String', '_arg1': 'long', '_result': 'android.os.ParcelFileDescriptor'}
            if mycase("TRANSACTION_openRead"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("openRead", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.os.ParcelFileDescriptor'}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("close")
                # {}
            if mycase("TRANSACTION_commit"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.IntentSender", data)
                else:
                    _arg0 = None
                return self.callFunction("commit", _arg0)
                # {'_arg0': 'android.content.IntentSender', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_abandon"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("abandon")
                # {}
