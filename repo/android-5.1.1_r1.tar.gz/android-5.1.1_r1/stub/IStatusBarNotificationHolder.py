from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IStatusBarNotificationHolder:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.notification.IStatusBarNotificationHolder"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.notification.IStatusBarNotificationHolder"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_get"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("get")
                # {'_result': 'android.service.notification.StatusBarNotification'}
