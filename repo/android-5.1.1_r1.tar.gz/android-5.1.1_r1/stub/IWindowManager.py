from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWindowManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IWindowManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IWindowManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_startViewServer"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("startViewServer", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_stopViewServer"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopViewServer")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isViewServerRunning"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isViewServerRunning")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_openSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IWindowSessionCallback", data.readStrongBinder())
                _arg1 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                _arg2 = self.interfaceResolver("com.android.internal.view.IInputContext", data.readStrongBinder())
                return self.callFunction("openSession", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.internal.view.IInputContext', '_arg0': 'android.view.IWindowSessionCallback', '_arg1': 'com.android.internal.view.IInputMethodClient', '_result': 'android.view.IWindowSession'}
            if mycase("TRANSACTION_inputMethodClientHasFocus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.view.IInputMethodClient", data.readStrongBinder())
                return self.callFunction("inputMethodClientHasFocus", _arg0)
                # {'_arg0': 'com.android.internal.view.IInputMethodClient', '_result': 'boolean'}
            if mycase("TRANSACTION_getInitialDisplaySize"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.newInstance("android.graphics.Point", )
                return self.callFunction("getInitialDisplaySize", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.graphics.Point'}
            if mycase("TRANSACTION_getBaseDisplaySize"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.newInstance("android.graphics.Point", )
                return self.callFunction("getBaseDisplaySize", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.graphics.Point'}
            if mycase("TRANSACTION_setForcedDisplaySize"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setForcedDisplaySize", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_clearForcedDisplaySize"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("clearForcedDisplaySize", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getInitialDisplayDensity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getInitialDisplayDensity", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getBaseDisplayDensity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getBaseDisplayDensity", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_setForcedDisplayDensity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setForcedDisplayDensity", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_clearForcedDisplayDensity"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("clearForcedDisplayDensity", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setOverscan"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                return self.callFunction("setOverscan", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int', '_arg4': 'int'}
            if mycase("TRANSACTION_pauseKeyDispatching"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("pauseKeyDispatching", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_resumeKeyDispatching"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("resumeKeyDispatching", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_setEventDispatching"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setEventDispatching", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_addWindowToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("addWindowToken", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_removeWindowToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("removeWindowToken", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_addAppToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.view.IApplicationToken", data.readStrongBinder())
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = (0 != data.readInt())
                _arg6 = (0 != data.readInt())
                _arg7 = data.readInt()
                _arg8 = data.readInt()
                _arg9 = (0 != data.readInt())
                _arg10 = (0 != data.readInt())
                return self.callFunction("addAppToken", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9, _arg10)
                # {'_arg8': 'int', '_arg9': 'boolean', '_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'android.view.IApplicationToken', '_arg6': 'boolean', '_arg7': 'int', '_arg4': 'int', '_arg5': 'boolean', '_arg10': 'boolean'}
            if mycase("TRANSACTION_setAppGroupId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("setAppGroupId", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_setAppOrientation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IApplicationToken", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("setAppOrientation", _arg0, _arg1)
                # {'_arg0': 'android.view.IApplicationToken', '_arg1': 'int'}
            if mycase("TRANSACTION_getAppOrientation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IApplicationToken", data.readStrongBinder())
                return self.callFunction("getAppOrientation", _arg0)
                # {'_arg0': 'android.view.IApplicationToken', '_result': 'int'}
            if mycase("TRANSACTION_setFocusedApp"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setFocusedApp", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'boolean'}
            if mycase("TRANSACTION_prepareAppTransition"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("prepareAppTransition", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getPendingAppTransition"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPendingAppTransition")
                # {'_result': 'int'}
            if mycase("TRANSACTION_overridePendingAppTransition"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("android.os.IRemoteCallback", data.readStrongBinder())
                return self.callFunction("overridePendingAppTransition", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'android.os.IRemoteCallback', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_overridePendingAppTransitionScaleUp"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("overridePendingAppTransitionScaleUp", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_overridePendingAppTransitionThumb"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.graphics.Bitmap", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("android.os.IRemoteCallback", data.readStrongBinder())
                _arg4 = (0 != data.readInt())
                return self.callFunction("overridePendingAppTransitionThumb", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'android.os.IRemoteCallback', '_arg0': 'android.graphics.Bitmap', '_arg1': 'int', '_arg4': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_overridePendingAppTransitionAspectScaledThumb"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.graphics.Bitmap", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = self.interfaceResolver("android.os.IRemoteCallback", data.readStrongBinder())
                _arg6 = (0 != data.readInt())
                return self.callFunction("overridePendingAppTransitionAspectScaledThumb", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.graphics.Bitmap', '_arg1': 'int', '_arg6': 'boolean', '_arg4': 'int', '_arg5': 'android.os.IRemoteCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_overridePendingAppTransitionInPlace"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("overridePendingAppTransitionInPlace", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_executeAppTransition"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("executeAppTransition")
                # {}
            if mycase("TRANSACTION_setAppStartingWindow"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.content.res.CompatibilityInfo", data)
                else:
                    _arg3 = None
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg4 = None
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readInt()
                _arg8 = data.readInt()
                _arg9 = data.readStrongBinder()
                _arg10 = (0 != data.readInt())
                return self.callFunction("setAppStartingWindow", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9, _arg10)
                # {'_arg8': 'int', '_arg9': 'android.os.IBinder', '_arg2': 'int', '_arg3': 'android.content.res.CompatibilityInfo', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String', '_arg6': 'int', '_arg7': 'int', '_arg4': 'java.lang.CharSequence', '_arg5': 'int', 'ELSE:I': {}, '_arg10': 'boolean', 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAppWillBeHidden"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("setAppWillBeHidden", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_setAppVisibility"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setAppVisibility", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'boolean'}
            if mycase("TRANSACTION_startAppFreezingScreen"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                return self.callFunction("startAppFreezingScreen", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_stopAppFreezingScreen"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = (0 != data.readInt())
                return self.callFunction("stopAppFreezingScreen", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'boolean'}
            if mycase("TRANSACTION_removeAppToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("removeAppToken", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_updateOrientationFromAppTokens"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.res.Configuration", data)
                else:
                    _arg0 = None
                _arg1 = data.readStrongBinder()
                return self.callFunction("updateOrientationFromAppTokens", _arg0, _arg1)
                # {'_result': 'android.content.res.Configuration', '_arg0': 'android.content.res.Configuration', '_arg1': 'android.os.IBinder', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setNewConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.res.Configuration", data)
                else:
                    _arg0 = None
                return self.callFunction("setNewConfiguration", _arg0)
                # {'_arg0': 'android.content.res.Configuration', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startFreezingScreen"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("startFreezingScreen", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_stopFreezingScreen"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopFreezingScreen")
                # {}
            if mycase("TRANSACTION_disableKeyguard"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                return self.callFunction("disableKeyguard", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_reenableKeyguard"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("reenableKeyguard", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_exitKeyguardSecurely"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IOnKeyguardExitResult", data.readStrongBinder())
                return self.callFunction("exitKeyguardSecurely", _arg0)
                # {'_arg0': 'android.view.IOnKeyguardExitResult'}
            if mycase("TRANSACTION_isKeyguardLocked"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isKeyguardLocked")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isKeyguardSecure"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isKeyguardSecure")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_inKeyguardRestrictedInputMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("inKeyguardRestrictedInputMode")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_dismissKeyguard"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dismissKeyguard")
                # {}
            if mycase("TRANSACTION_keyguardGoingAway"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("keyguardGoingAway", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_closeSystemDialogs"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("closeSystemDialogs", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_getAnimationScale"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getAnimationScale", _arg0)
                # {'_arg0': 'int', '_result': 'float'}
            if mycase("TRANSACTION_getAnimationScales"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAnimationScales")
                # {'_result': 'float'}
            if mycase("TRANSACTION_setAnimationScale"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readFloat()
                return self.callFunction("setAnimationScale", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'float'}
            if mycase("TRANSACTION_setAnimationScales"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createFloatArray()
                return self.callFunction("setAnimationScales", _arg0)
                # {'_arg0': 'float'}
            if mycase("TRANSACTION_getCurrentAnimatorScale"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCurrentAnimatorScale")
                # {'_result': 'float'}
            if mycase("TRANSACTION_setInTouchMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setInTouchMode", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_showStrictModeViolation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("showStrictModeViolation", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setStrictModeVisualIndicatorPreference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setStrictModeVisualIndicatorPreference", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setScreenCaptureDisabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setScreenCaptureDisabled", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_updateRotation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("updateRotation", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getRotation"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getRotation")
                # {'_result': 'int'}
            if mycase("TRANSACTION_watchRotation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IRotationWatcher", data.readStrongBinder())
                return self.callFunction("watchRotation", _arg0)
                # {'_arg0': 'android.view.IRotationWatcher', '_result': 'int'}
            if mycase("TRANSACTION_removeRotationWatcher"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.view.IRotationWatcher", data.readStrongBinder())
                return self.callFunction("removeRotationWatcher", _arg0)
                # {'_arg0': 'android.view.IRotationWatcher'}
            if mycase("TRANSACTION_getPreferredOptionsPanelGravity"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPreferredOptionsPanelGravity")
                # {'_result': 'int'}
            if mycase("TRANSACTION_freezeRotation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("freezeRotation", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_thawRotation"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("thawRotation")
                # {}
            if mycase("TRANSACTION_isRotationFrozen"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isRotationFrozen")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_screenshotApplications"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = (0 != data.readInt())
                return self.callFunction("screenshotApplications", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'android.graphics.Bitmap', '_arg2': 'int', '_arg3': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'int', '_arg4': 'boolean'}
            if mycase("TRANSACTION_statusBarVisibilityChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("statusBarVisibilityChanged", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_hasNavigationBar"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasNavigationBar")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_lockNow"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("lockNow", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isSafeModeEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isSafeModeEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_enableScreenIfNeeded"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enableScreenIfNeeded")
                # {}
            if mycase("TRANSACTION_clearWindowContentFrameStats"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("clearWindowContentFrameStats", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'boolean'}
            if mycase("TRANSACTION_getWindowContentFrameStats"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("getWindowContentFrameStats", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'android.view.WindowContentFrameStats'}
