from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISpellCheckerSessionListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.textservice.ISpellCheckerSessionListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.textservice.ISpellCheckerSessionListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onGetSuggestions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.view.textservice.SuggestionsInfo")
                return self.callFunction("onGetSuggestions", _arg0)
                # {'_arg0': 'android.view.textservice.SuggestionsInfo'}
            if mycase("TRANSACTION_onGetSentenceSuggestions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.view.textservice.SentenceSuggestionsInfo")
                return self.callFunction("onGetSentenceSuggestions", _arg0)
                # {'_arg0': 'android.view.textservice.SentenceSuggestionsInfo'}
