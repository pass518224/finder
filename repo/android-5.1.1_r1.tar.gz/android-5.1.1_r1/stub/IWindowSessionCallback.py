from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWindowSessionCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.view.IWindowSessionCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.view.IWindowSessionCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onAnimatorScaleChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readFloat()
                return self.callFunction("onAnimatorScaleChanged", _arg0)
                # {'_arg0': 'float'}
