from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISearchManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.ISearchManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.ISearchManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getSearchableInfo"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                return self.callFunction("getSearchableInfo", _arg0)
                # {'_arg0': 'android.content.ComponentName', '_result': 'android.app.SearchableInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getSearchablesInGlobalSearch"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSearchablesInGlobalSearch")
                # {'_result': 'java.util.List<android.app.SearchableInfo>'}
            if mycase("TRANSACTION_getGlobalSearchActivities"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getGlobalSearchActivities")
                # {'_result': 'java.util.List<android.content.pm.ResolveInfo>'}
            if mycase("TRANSACTION_getGlobalSearchActivity"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getGlobalSearchActivity")
                # {'_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_getWebSearchActivity"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWebSearchActivity")
                # {'_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_getAssistIntent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getAssistIntent", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.ComponentName'}
            if mycase("TRANSACTION_launchAssistAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("launchAssistAction", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_result': 'boolean'}
