from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWifiManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.wifi.IWifiManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.wifi.IWifiManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getSupportedFeatures"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSupportedFeatures")
                # {'_result': 'int'}
            if mycase("TRANSACTION_reportActivityInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("reportActivityInfo")
                # {'_result': 'android.net.wifi.WifiActivityEnergyInfo'}
            if mycase("TRANSACTION_getConfiguredNetworks"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConfiguredNetworks")
                # {'_result': 'java.util.List<android.net.wifi.WifiConfiguration>'}
            if mycase("TRANSACTION_getPrivilegedConfiguredNetworks"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPrivilegedConfiguredNetworks")
                # {'_result': 'java.util.List<android.net.wifi.WifiConfiguration>'}
            if mycase("TRANSACTION_addOrUpdateNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.wifi.WifiConfiguration", data)
                else:
                    _arg0 = None
                return self.callFunction("addOrUpdateNetwork", _arg0)
                # {'_arg0': 'android.net.wifi.WifiConfiguration', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("removeNetwork", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_enableNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("enableNetwork", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_disableNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("disableNetwork", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_pingSupplicant"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("pingSupplicant")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getChannelList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getChannelList")
                # {'_result': 'java.util.List<android.net.wifi.WifiChannel>'}
            if mycase("TRANSACTION_startScan"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.wifi.ScanSettings", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg1 = None
                return self.callFunction("startScan", _arg0, _arg1)
                # {'_arg0': 'android.net.wifi.ScanSettings', '_arg1': 'android.os.WorkSource', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_startLocationRestrictedScan"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg0 = None
                return self.callFunction("startLocationRestrictedScan", _arg0)
                # {'_arg0': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getScanResults"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getScanResults", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.util.List<android.net.wifi.ScanResult>'}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disconnect")
                # {}
            if mycase("TRANSACTION_reconnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("reconnect")
                # {}
            if mycase("TRANSACTION_reassociate"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("reassociate")
                # {}
            if mycase("TRANSACTION_getConnectionInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConnectionInfo")
                # {'_result': 'android.net.wifi.WifiInfo'}
            if mycase("TRANSACTION_setWifiEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setWifiEnabled", _arg0)
                # {'_arg0': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_getWifiEnabledState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWifiEnabledState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setCountryCode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setCountryCode", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setFrequencyBand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setFrequencyBand", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getFrequencyBand"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getFrequencyBand")
                # {'_result': 'int'}
            if mycase("TRANSACTION_isDualBandSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isDualBandSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_saveConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("saveConfiguration")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getDhcpInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDhcpInfo")
                # {'_result': 'android.net.DhcpInfo'}
            if mycase("TRANSACTION_isScanAlwaysAvailable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isScanAlwaysAvailable")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_acquireWifiLock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg3 = None
                return self.callFunction("acquireWifiLock", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'java.lang.String', '_arg3': 'android.os.WorkSource', '_arg0': 'android.os.IBinder', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_updateWifiLockWorkSource"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg1 = None
                return self.callFunction("updateWifiLockWorkSource", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'android.os.WorkSource', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_releaseWifiLock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("releaseWifiLock", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'boolean'}
            if mycase("TRANSACTION_initializeMulticastFiltering"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("initializeMulticastFiltering")
                # {}
            if mycase("TRANSACTION_isMulticastEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isMulticastEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_acquireMulticastLock"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                return self.callFunction("acquireMulticastLock", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_releaseMulticastLock"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("releaseMulticastLock")
                # {}
            if mycase("TRANSACTION_setWifiApEnabled"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.wifi.WifiConfiguration", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("setWifiApEnabled", _arg0, _arg1)
                # {'_arg0': 'android.net.wifi.WifiConfiguration', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getWifiApEnabledState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWifiApEnabledState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getWifiApConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWifiApConfiguration")
                # {'_result': 'android.net.wifi.WifiConfiguration'}
            if mycase("TRANSACTION_setWifiApConfiguration"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.wifi.WifiConfiguration", data)
                else:
                    _arg0 = None
                return self.callFunction("setWifiApConfiguration", _arg0)
                # {'_arg0': 'android.net.wifi.WifiConfiguration', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startWifi"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("startWifi")
                # {}
            if mycase("TRANSACTION_stopWifi"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopWifi")
                # {}
            if mycase("TRANSACTION_addToBlacklist"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("addToBlacklist", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_clearBlacklist"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearBlacklist")
                # {}
            if mycase("TRANSACTION_getWifiServiceMessenger"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getWifiServiceMessenger")
                # {'_result': 'android.os.Messenger'}
            if mycase("TRANSACTION_getConfigFile"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConfigFile")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_enableTdls"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("enableTdls", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_enableTdlsWithMacAddress"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("enableTdlsWithMacAddress", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_requestBatchedScan"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.wifi.BatchedScanSettings", data)
                else:
                    _arg0 = None
                _arg1 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.WorkSource", data)
                else:
                    _arg2 = None
                return self.callFunction("requestBatchedScan", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.os.WorkSource', '_arg0': 'android.net.wifi.BatchedScanSettings', '_arg1': 'android.os.IBinder', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopBatchedScan"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.wifi.BatchedScanSettings", data)
                else:
                    _arg0 = None
                return self.callFunction("stopBatchedScan", _arg0)
                # {'_arg0': 'android.net.wifi.BatchedScanSettings', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getBatchedScanResults"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getBatchedScanResults", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'java.util.List<android.net.wifi.BatchedScanResult>'}
            if mycase("TRANSACTION_isBatchedScanSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isBatchedScanSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_pollBatchedScan"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("pollBatchedScan")
                # {}
            if mycase("TRANSACTION_getWpsNfcConfigurationToken"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getWpsNfcConfigurationToken", _arg0)
                # {'_arg0': 'int', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_enableVerboseLogging"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("enableVerboseLogging", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getVerboseLoggingLevel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVerboseLoggingLevel")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getAggressiveHandover"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAggressiveHandover")
                # {'_result': 'int'}
            if mycase("TRANSACTION_enableAggressiveHandover"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("enableAggressiveHandover", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getAllowScansWithTraffic"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllowScansWithTraffic")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setAllowScansWithTraffic"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setAllowScansWithTraffic", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_getConnectionStatistics"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConnectionStatistics")
                # {'_result': 'android.net.wifi.WifiConnectionStatistics'}
            if mycase("TRANSACTION_disableEphemeralNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("disableEphemeralNetwork", _arg0)
                # {'_arg0': 'java.lang.String'}
