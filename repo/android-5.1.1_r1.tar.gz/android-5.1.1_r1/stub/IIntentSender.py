from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IIntentSender:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.IIntentSender"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.IIntentSender"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_send"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                _arg3 = self.interfaceResolver("android.content.IIntentReceiver", data.readStrongBinder())
                _arg4 = data.readString()
                return self.callFunction("send", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'int', '_arg2': 'java.lang.String', '_arg3': 'android.content.IIntentReceiver', '_arg0': 'int', '_arg1': 'android.content.Intent', '_arg4': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
