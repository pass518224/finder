from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRecognitionStatusCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.soundtrigger.IRecognitionStatusCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.soundtrigger.IRecognitionStatusCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onDetected"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.hardware.soundtrigger.SoundTrigger.KeyphraseRecognitionEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("onDetected", _arg0)
                # {'_arg0': 'android.hardware.soundtrigger.SoundTrigger.KeyphraseRecognitionEvent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onError"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onError", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onRecognitionPaused"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onRecognitionPaused")
                # {}
            if mycase("TRANSACTION_onRecognitionResumed"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onRecognitionResumed")
                # {}
