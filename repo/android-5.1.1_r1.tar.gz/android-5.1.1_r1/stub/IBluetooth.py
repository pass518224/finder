from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetooth:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetooth"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetooth"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_isEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_enable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enable")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_enableNoAutoConnect"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("enableNoAutoConnect")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_disable"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("disable")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getAddress"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAddress")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getUuids"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getUuids")
                # {'_result': 'android.os.ParcelUuid'}
            if mycase("TRANSACTION_setName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setName", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_getName"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getName")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getScanMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getScanMode")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setScanMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setScanMode", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getDiscoverableTimeout"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDiscoverableTimeout")
                # {'_result': 'int'}
            if mycase("TRANSACTION_setDiscoverableTimeout"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setDiscoverableTimeout", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_startDiscovery"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("startDiscovery")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_cancelDiscovery"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("cancelDiscovery")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isDiscovering"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isDiscovering")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getAdapterConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAdapterConnectionState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getProfileConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getProfileConnectionState", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getBondedDevices"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getBondedDevices")
                # {'_result': 'android.bluetooth.BluetoothDevice'}
            if mycase("TRANSACTION_createBond"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("createBond", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_cancelBondProcess"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("cancelBondProcess", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeBond"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("removeBond", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getBondState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getBondState", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getConnectionState", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getRemoteName"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getRemoteName", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getRemoteType"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getRemoteType", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getRemoteAlias"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getRemoteAlias", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setRemoteAlias"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("setRemoteAlias", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getRemoteClass"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getRemoteClass", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getRemoteUuids"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getRemoteUuids", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'android.os.ParcelUuid', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_fetchRemoteUuids"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("fetchRemoteUuids", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_fetchRemoteMasInstances"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("fetchRemoteMasInstances", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPin"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                _arg3 = data.createByteArray()
                return self.callFunction("setPin", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'byte', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPasskey"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                _arg3 = data.createByteArray()
                return self.callFunction("setPasskey", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'boolean', '_arg2': 'int', '_arg3': 'byte', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPairingConfirmation"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("setPairingConfirmation", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPhonebookAccessPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getPhonebookAccessPermission", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPhonebookAccessPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setPhonebookAccessPermission", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getMessageAccessPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getMessageAccessPermission", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setMessageAccessPermission"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setMessageAccessPermission", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendConnectionStateChange"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("sendConnectionStateChange", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_registerCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.bluetooth.IBluetoothCallback", data.readStrongBinder())
                return self.callFunction("registerCallback", _arg0)
                # {'_arg0': 'android.bluetooth.IBluetoothCallback'}
            if mycase("TRANSACTION_unregisterCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.bluetooth.IBluetoothCallback", data.readStrongBinder())
                return self.callFunction("unregisterCallback", _arg0)
                # {'_arg0': 'android.bluetooth.IBluetoothCallback'}
            if mycase("TRANSACTION_connectSocket"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                return self.callFunction("connectSocket", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'android.os.ParcelFileDescriptor', '_arg2': 'android.os.ParcelUuid', '_arg3': 'int', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', '_arg4': 'int', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createSocketChannel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ParcelUuid", data)
                else:
                    _arg2 = None
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                return self.callFunction("createSocketChannel", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'android.os.ParcelFileDescriptor', '_arg2': 'android.os.ParcelUuid', '_arg3': 'int', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_configHciSnoopLog"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("configHciSnoopLog", _arg0)
                # {'_arg0': 'boolean', '_result': 'boolean'}
            if mycase("TRANSACTION_isMultiAdvertisementSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isMultiAdvertisementSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isPeripheralModeSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isPeripheralModeSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isOffloadedFilteringSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isOffloadedFilteringSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isOffloadedScanBatchingSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isOffloadedScanBatchingSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_isActivityAndEnergyReportingSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isActivityAndEnergyReportingSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getActivityEnergyInfoFromController"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActivityEnergyInfoFromController")
                # {}
            if mycase("TRANSACTION_reportActivityInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("reportActivityInfo")
                # {'_result': 'android.bluetooth.BluetoothActivityEnergyInfo'}
            if mycase("TRANSACTION_dump"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dump")
                # {'_result': 'java.lang.String'}
