from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGpsStatusListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.IGpsStatusListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.IGpsStatusListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onGpsStarted"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onGpsStarted")
                # {}
            if mycase("TRANSACTION_onGpsStopped"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onGpsStopped")
                # {}
            if mycase("TRANSACTION_onFirstFix"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onFirstFix", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onSvStatusChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createIntArray()
                _arg2 = data.createFloatArray()
                _arg3 = data.createFloatArray()
                _arg4 = data.createFloatArray()
                _arg5 = data.readInt()
                _arg6 = data.readInt()
                _arg7 = data.readInt()
                return self.callFunction("onSvStatusChanged", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7)
                # {'_arg2': 'float', '_arg3': 'float', '_arg0': 'int', '_arg1': 'int', '_arg6': 'int', '_arg7': 'int', '_arg4': 'float', '_arg5': 'int'}
            if mycase("TRANSACTION_onNmeaReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                _arg1 = data.readString()
                return self.callFunction("onNmeaReceived", _arg0, _arg1)
                # {'_arg0': 'long', '_arg1': 'java.lang.String'}
