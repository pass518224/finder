from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaHTTPService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IMediaHTTPService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IMediaHTTPService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_makeHTTPConnection"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("makeHTTPConnection")
                # {'_result': 'android.media.IMediaHTTPConnection'}
