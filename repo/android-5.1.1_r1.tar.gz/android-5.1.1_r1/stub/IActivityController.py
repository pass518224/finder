from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IActivityController:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.IActivityController"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.IActivityController"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_activityStarting"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.Intent", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("activityStarting", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.content.Intent', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_activityResuming"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("activityResuming", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_appCrashed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readLong()
                _arg5 = data.readString()
                return self.callFunction("appCrashed", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'boolean', '_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'int', '_arg4': 'long', '_arg5': 'java.lang.String'}
            if mycase("TRANSACTION_appEarlyNotResponding"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("appEarlyNotResponding", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'int'}
            if mycase("TRANSACTION_appNotResponding"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("appNotResponding", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'int'}
            if mycase("TRANSACTION_systemNotResponding"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("systemNotResponding", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
