from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISipSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.sip.ISipSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.sip.ISipSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getLocalIp"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLocalIp")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getLocalProfile"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLocalProfile")
                # {'_result': 'android.net.sip.SipProfile'}
            if mycase("TRANSACTION_getPeerProfile"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPeerProfile")
                # {'_result': 'android.net.sip.SipProfile'}
            if mycase("TRANSACTION_getState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getState")
                # {'_result': 'int'}
            if mycase("TRANSACTION_isInCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isInCall")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getCallId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCallId")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_setListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSessionListener", data.readStrongBinder())
                return self.callFunction("setListener", _arg0)
                # {'_arg0': 'android.net.sip.ISipSessionListener'}
            if mycase("TRANSACTION_register"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("register", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_unregister"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("unregister")
                # {}
            if mycase("TRANSACTION_makeCall"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.sip.SipProfile", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("makeCall", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.net.sip.SipProfile', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_answerCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("answerCall", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_endCall"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("endCall")
                # {}
            if mycase("TRANSACTION_changeCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("changeCall", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
