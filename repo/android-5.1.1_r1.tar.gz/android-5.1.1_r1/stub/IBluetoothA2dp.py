from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBluetoothA2dp:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.bluetooth.IBluetoothA2dp"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.bluetooth.IBluetoothA2dp"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("connect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("disconnect", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getConnectedDevices"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getConnectedDevices")
                # {'_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_getDevicesMatchingConnectionStates"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createIntArray()
                return self.callFunction("getDevicesMatchingConnectionStates", _arg0)
                # {'_arg0': 'int', '_result': 'java.util.List<android.bluetooth.BluetoothDevice>'}
            if mycase("TRANSACTION_getConnectionState"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getConnectionState", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setPriority"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setPriority", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'android.bluetooth.BluetoothDevice', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPriority"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("getPriority", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_isAvrcpAbsoluteVolumeSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isAvrcpAbsoluteVolumeSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_adjustAvrcpAbsoluteVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("adjustAvrcpAbsoluteVolume", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setAvrcpAbsoluteVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setAvrcpAbsoluteVolume", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_isA2dpPlaying"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.bluetooth.BluetoothDevice", data)
                else:
                    _arg0 = None
                return self.callFunction("isA2dpPlaying", _arg0)
                # {'_arg0': 'android.bluetooth.BluetoothDevice', '_result': 'boolean', 'ELSE:': {}, 'IF': {}}
