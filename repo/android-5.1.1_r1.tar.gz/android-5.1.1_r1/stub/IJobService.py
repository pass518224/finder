from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IJobService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.job.IJobService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.job.IJobService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_startJob"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.app.job.JobParameters", data)
                else:
                    _arg0 = None
                return self.callFunction("startJob", _arg0)
                # {'_arg0': 'android.app.job.JobParameters', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopJob"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.app.job.JobParameters", data)
                else:
                    _arg0 = None
                return self.callFunction("stopJob", _arg0)
                # {'_arg0': 'android.app.job.JobParameters', 'ELSE:': {}, 'IF': {}}
