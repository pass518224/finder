from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWallpaperConnection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.wallpaper.IWallpaperConnection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.wallpaper.IWallpaperConnection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_attachEngine"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.wallpaper.IWallpaperEngine", data.readStrongBinder())
                return self.callFunction("attachEngine", _arg0)
                # {'_arg0': 'android.service.wallpaper.IWallpaperEngine'}
            if mycase("TRANSACTION_engineShown"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.wallpaper.IWallpaperEngine", data.readStrongBinder())
                return self.callFunction("engineShown", _arg0)
                # {'_arg0': 'android.service.wallpaper.IWallpaperEngine'}
            if mycase("TRANSACTION_setWallpaper"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setWallpaper", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.os.ParcelFileDescriptor'}
