from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITvInputHardwareCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.tv.ITvInputHardwareCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.tv.ITvInputHardwareCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onReleased"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onReleased")
                # {}
            if mycase("TRANSACTION_onStreamConfigChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.media.tv.TvStreamConfig")
                return self.callFunction("onStreamConfigChanged", _arg0)
                # {'_arg0': 'android.media.tv.TvStreamConfig'}
