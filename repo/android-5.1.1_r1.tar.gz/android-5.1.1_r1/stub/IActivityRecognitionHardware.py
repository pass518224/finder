from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IActivityRecognitionHardware:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.location.IActivityRecognitionHardware"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.location.IActivityRecognitionHardware"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getSupportedActivities"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSupportedActivities")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_isActivitySupported"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isActivitySupported", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_registerSink"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.location.IActivityRecognitionHardwareSink", data.readStrongBinder())
                return self.callFunction("registerSink", _arg0)
                # {'_arg0': 'android.hardware.location.IActivityRecognitionHardwareSink', '_result': 'boolean'}
            if mycase("TRANSACTION_unregisterSink"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.location.IActivityRecognitionHardwareSink", data.readStrongBinder())
                return self.callFunction("unregisterSink", _arg0)
                # {'_arg0': 'android.hardware.location.IActivityRecognitionHardwareSink', '_result': 'boolean'}
            if mycase("TRANSACTION_enableActivityEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readLong()
                return self.callFunction("enableActivityEvent", _arg0, _arg1, _arg2)
                # {'_arg2': 'long', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_disableActivityEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("disableActivityEvent", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_flush"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("flush")
                # {'_result': 'boolean'}
