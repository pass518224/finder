from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITransientNotification:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.app.ITransientNotification"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.app.ITransientNotification"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_show"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("show")
                # {}
            if mycase("TRANSACTION_hide"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hide")
                # {}
