from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputContextCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.view.IInputContextCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.view.IInputContextCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setTextBeforeCursor"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setTextBeforeCursor", _arg0, _arg1)
                # {'_arg0': 'java.lang.CharSequence', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setTextAfterCursor"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setTextAfterCursor", _arg0, _arg1)
                # {'_arg0': 'java.lang.CharSequence', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setCursorCapsMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setCursorCapsMode", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setExtractedText"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.inputmethod.ExtractedText", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setExtractedText", _arg0, _arg1)
                # {'_arg0': 'android.view.inputmethod.ExtractedText', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setSelectedText"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setSelectedText", _arg0, _arg1)
                # {'_arg0': 'java.lang.CharSequence', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setRequestUpdateCursorAnchorInfoResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                return self.callFunction("setRequestUpdateCursorAnchorInfoResult", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'int'}
