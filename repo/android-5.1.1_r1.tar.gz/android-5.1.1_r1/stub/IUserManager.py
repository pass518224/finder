from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IUserManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.IUserManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.IUserManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_createUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("createUser", _arg0, _arg1)
                # {'_result': 'android.content.pm.UserInfo', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_createProfileForUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("createProfileForUser", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int', '_result': 'android.content.pm.UserInfo'}
            if mycase("TRANSACTION_setUserEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setUserEnabled", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_removeUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("removeUser", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_setUserName"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("setUserName", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setUserIcon"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Bitmap", data)
                else:
                    _arg1 = None
                return self.callFunction("setUserIcon", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.graphics.Bitmap', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getUserIcon"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getUserIcon", _arg0)
                # {'_arg0': 'int', '_result': 'android.graphics.Bitmap'}
            if mycase("TRANSACTION_getUsers"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("getUsers", _arg0)
                # {'_arg0': 'boolean', '_result': 'java.util.List<android.content.pm.UserInfo>'}
            if mycase("TRANSACTION_getProfiles"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("getProfiles", _arg0, _arg1)
                # {'_result': 'java.util.List<android.content.pm.UserInfo>', '_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getProfileParent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getProfileParent", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.pm.UserInfo'}
            if mycase("TRANSACTION_getUserInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getUserInfo", _arg0)
                # {'_arg0': 'int', '_result': 'android.content.pm.UserInfo'}
            if mycase("TRANSACTION_isRestricted"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isRestricted")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getUserSerialNumber"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getUserSerialNumber", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getUserHandle"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getUserHandle", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getUserRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getUserRestrictions", _arg0)
                # {'_arg0': 'int', '_result': 'android.os.Bundle'}
            if mycase("TRANSACTION_hasUserRestriction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("hasUserRestriction", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setUserRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setUserRestrictions", _arg0, _arg1)
                # {'_arg0': 'android.os.Bundle', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setApplicationRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("setApplicationRestrictions", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getApplicationRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getApplicationRestrictions", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.os.Bundle'}
            if mycase("TRANSACTION_getApplicationRestrictionsForUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("getApplicationRestrictionsForUser", _arg0, _arg1)
                # {'_result': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setRestrictionsChallenge"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setRestrictionsChallenge", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_checkRestrictionsChallenge"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("checkRestrictionsChallenge", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_hasRestrictionsChallenge"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasRestrictionsChallenge")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_removeRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("removeRestrictions")
                # {}
            if mycase("TRANSACTION_setDefaultGuestRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("setDefaultGuestRestrictions", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getDefaultGuestRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultGuestRestrictions")
                # {'_result': 'android.os.Bundle'}
            if mycase("TRANSACTION_markGuestForDeletion"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("markGuestForDeletion", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
