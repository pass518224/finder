from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IDisplayManagerCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.display.IDisplayManagerCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.display.IDisplayManagerCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onDisplayEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("onDisplayEvent", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
