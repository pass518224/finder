from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaProjection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.projection.IMediaProjection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.projection.IMediaProjection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_start"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.projection.IMediaProjectionCallback", data.readStrongBinder())
                return self.callFunction("start", _arg0)
                # {'_arg0': 'android.media.projection.IMediaProjectionCallback'}
            if mycase("TRANSACTION_stop"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stop")
                # {}
            if mycase("TRANSACTION_canProjectAudio"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("canProjectAudio")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_canProjectVideo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("canProjectVideo")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_canProjectSecureVideo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("canProjectSecureVideo")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_applyVirtualDisplayFlags"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("applyVirtualDisplayFlags", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_registerCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.projection.IMediaProjectionCallback", data.readStrongBinder())
                return self.callFunction("registerCallback", _arg0)
                # {'_arg0': 'android.media.projection.IMediaProjectionCallback'}
            if mycase("TRANSACTION_unregisterCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.projection.IMediaProjectionCallback", data.readStrongBinder())
                return self.callFunction("unregisterCallback", _arg0)
                # {'_arg0': 'android.media.projection.IMediaProjectionCallback'}
