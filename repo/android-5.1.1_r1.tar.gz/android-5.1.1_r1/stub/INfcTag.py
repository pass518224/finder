from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INfcTag:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.nfc.INfcTag"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.nfc.INfcTag"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_close"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("close", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("connect", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_reconnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("reconnect", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getTechList"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getTechList", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_isNdef"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isNdef", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_isPresent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isPresent", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_transceive"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createByteArray()
                _arg2 = (0 != data.readInt())
                return self.callFunction("transceive", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'int', '_arg1': 'byte', '_result': 'android.nfc.TransceiveResult'}
            if mycase("TRANSACTION_ndefRead"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("ndefRead", _arg0)
                # {'_arg0': 'int', '_result': 'android.nfc.NdefMessage'}
            if mycase("TRANSACTION_ndefWrite"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.nfc.NdefMessage", data)
                else:
                    _arg1 = None
                return self.callFunction("ndefWrite", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'android.nfc.NdefMessage', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_ndefMakeReadOnly"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("ndefMakeReadOnly", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_ndefIsWritable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("ndefIsWritable", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_formatNdef"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createByteArray()
                return self.callFunction("formatNdef", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'byte'}
            if mycase("TRANSACTION_rediscover"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("rediscover", _arg0)
                # {'_arg0': 'int', '_result': 'android.nfc.Tag'}
            if mycase("TRANSACTION_setTimeout"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setTimeout", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getTimeout"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getTimeout", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_resetTimeouts"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("resetTimeouts")
                # {}
            if mycase("TRANSACTION_canMakeReadOnly"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("canMakeReadOnly", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getMaxTransceiveLength"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getMaxTransceiveLength", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getExtendedLengthApdusSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getExtendedLengthApdusSupported")
                # {'_result': 'boolean'}
