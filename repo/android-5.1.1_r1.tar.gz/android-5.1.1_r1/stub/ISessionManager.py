from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISessionManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.session.ISessionManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.session.ISessionManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_createSession"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.media.session.ISessionCallback", data.readStrongBinder())
                _arg2 = data.readString()
                _arg3 = data.readInt()
                return self.callFunction("createSession", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'android.media.session.ISessionCallback', '_result': 'android.media.session.ISession'}
            if mycase("TRANSACTION_getSessions"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("getSessions", _arg0, _arg1)
                # {'_result': 'java.util.List<android.os.IBinder>', '_arg0': 'android.content.ComponentName', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dispatchMediaKeyEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.KeyEvent", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("dispatchMediaKeyEvent", _arg0, _arg1)
                # {'_arg0': 'android.view.KeyEvent', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dispatchAdjustVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("dispatchAdjustVolume", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_addSessionsListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.session.IActiveSessionsListener", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.content.ComponentName", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("addSessionsListener", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.media.session.IActiveSessionsListener', '_arg1': 'android.content.ComponentName', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeSessionsListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.session.IActiveSessionsListener", data.readStrongBinder())
                return self.callFunction("removeSessionsListener", _arg0)
                # {'_arg0': 'android.media.session.IActiveSessionsListener'}
            if mycase("TRANSACTION_setRemoteVolumeController"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IRemoteVolumeController", data.readStrongBinder())
                return self.callFunction("setRemoteVolumeController", _arg0)
                # {'_arg0': 'android.media.IRemoteVolumeController'}
            if mycase("TRANSACTION_isGlobalPriorityActive"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isGlobalPriorityActive")
                # {'_result': 'boolean'}
