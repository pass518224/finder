from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaBrowserService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.media.IMediaBrowserService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.media.IMediaBrowserService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_connect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                _arg2 = self.interfaceResolver("android.service.media.IMediaBrowserServiceCallbacks", data.readStrongBinder())
                return self.callFunction("connect", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.service.media.IMediaBrowserServiceCallbacks', '_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.service.media.IMediaBrowserServiceCallbacks", data.readStrongBinder())
                return self.callFunction("disconnect", _arg0)
                # {'_arg0': 'android.service.media.IMediaBrowserServiceCallbacks'}
            if mycase("TRANSACTION_addSubscription"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.service.media.IMediaBrowserServiceCallbacks", data.readStrongBinder())
                return self.callFunction("addSubscription", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.service.media.IMediaBrowserServiceCallbacks'}
            if mycase("TRANSACTION_removeSubscription"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("android.service.media.IMediaBrowserServiceCallbacks", data.readStrongBinder())
                return self.callFunction("removeSubscription", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.service.media.IMediaBrowserServiceCallbacks'}
