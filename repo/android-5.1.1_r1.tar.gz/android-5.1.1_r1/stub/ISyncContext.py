from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISyncContext:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.ISyncContext"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.ISyncContext"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sendHeartbeat"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("sendHeartbeat")
                # {}
            if mycase("TRANSACTION_onFinished"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.SyncResult", data)
                else:
                    _arg0 = None
                return self.callFunction("onFinished", _arg0)
                # {'_arg0': 'android.content.SyncResult', 'ELSE:': {}, 'IF': {}}
