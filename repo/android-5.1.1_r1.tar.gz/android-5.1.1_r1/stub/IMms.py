from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMms:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telephony.IMms"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telephony.IMms"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_sendMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg2 = None
                _arg3 = data.readString()
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg4 = None
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg5 = None
                return self.callFunction("sendMessage", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'android.net.Uri', '_arg3': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'android.os.Bundle', '_arg5': 'android.app.PendingIntent', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_downloadMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg3 = None
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg4 = None
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg5 = None
                return self.callFunction("downloadMessage", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.net.Uri', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'android.os.Bundle', '_arg5': 'android.app.PendingIntent', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getCarrierConfigValues"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getCarrierConfigValues", _arg0)
                # {'_arg0': 'int', '_result': 'android.os.Bundle'}
            if mycase("TRANSACTION_importTextMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                _arg4 = data.readLong()
                _arg5 = (0 != data.readInt())
                _arg6 = (0 != data.readInt())
                return self.callFunction("importTextMessage", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_result': 'android.net.Uri', '_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg6': 'boolean', '_arg4': 'long', '_arg5': 'boolean'}
            if mycase("TRANSACTION_importMultimediaMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                _arg3 = data.readLong()
                _arg4 = (0 != data.readInt())
                _arg5 = (0 != data.readInt())
                return self.callFunction("importMultimediaMessage", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_result': 'android.net.Uri', '_arg2': 'java.lang.String', '_arg3': 'long', '_arg0': 'java.lang.String', '_arg1': 'android.net.Uri', '_arg4': 'boolean', '_arg5': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deleteStoredMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg1 = None
                return self.callFunction("deleteStoredMessage", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'android.net.Uri', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deleteStoredConversation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readLong()
                return self.callFunction("deleteStoredConversation", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'long'}
            if mycase("TRANSACTION_updateStoredMessageStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.content.ContentValues", data)
                else:
                    _arg2 = None
                return self.callFunction("updateStoredMessageStatus", _arg0, _arg1, _arg2)
                # {'_result': 'boolean', '_arg2': 'android.content.ContentValues', '_arg0': 'java.lang.String', '_arg1': 'android.net.Uri', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_archiveStoredConversation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readLong()
                _arg2 = (0 != data.readInt())
                return self.callFunction("archiveStoredConversation", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'long', '_result': 'boolean'}
            if mycase("TRANSACTION_addTextMessageDraft"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("addTextMessageDraft", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_result': 'android.net.Uri'}
            if mycase("TRANSACTION_addMultimediaMessageDraft"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg1 = None
                return self.callFunction("addMultimediaMessageDraft", _arg0, _arg1)
                # {'_result': 'android.net.Uri', '_arg0': 'java.lang.String', '_arg1': 'android.net.Uri', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_sendStoredMessage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                if (0 != data.readInt()):
                    _arg4 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg4 = None
                return self.callFunction("sendStoredMessage", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'android.net.Uri', '_arg3': 'android.os.Bundle', '_arg0': 'int', '_arg1': 'java.lang.String', '_arg4': 'android.app.PendingIntent', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setAutoPersisting"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setAutoPersisting", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getAutoPersisting"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAutoPersisting")
                # {'_result': 'boolean'}
