from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ILayoutResultCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.print.ILayoutResultCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.print.ILayoutResultCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onLayoutStarted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.os.ICancellationSignal", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("onLayoutStarted", _arg0, _arg1)
                # {'_arg0': 'android.os.ICancellationSignal', '_arg1': 'int'}
            if mycase("TRANSACTION_onLayoutFinished"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.print.PrintDocumentInfo", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                _arg2 = data.readInt()
                return self.callFunction("onLayoutFinished", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.print.PrintDocumentInfo', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onLayoutFailed"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("onLayoutFailed", _arg0, _arg1)
                # {'_arg0': 'java.lang.CharSequence', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onLayoutCanceled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onLayoutCanceled", _arg0)
                # {'_arg0': 'int'}
