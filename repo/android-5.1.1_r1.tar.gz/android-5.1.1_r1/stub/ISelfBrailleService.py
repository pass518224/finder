from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISelfBrailleService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.googlecode.eyesfree.braille.selfbraille.ISelfBrailleService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.googlecode.eyesfree.braille.selfbraille.ISelfBrailleService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_write"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.googlecode.eyesfree.braille.selfbraille.WriteData", data)
                else:
                    _arg1 = None
                return self.callFunction("write", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'com.googlecode.eyesfree.braille.selfbraille.WriteData', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_disconnect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("disconnect", _arg0)
                # {'_arg0': 'android.os.IBinder'}
