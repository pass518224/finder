from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IStatusBarService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.statusbar.IStatusBarService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.statusbar.IStatusBarService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_expandNotificationsPanel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("expandNotificationsPanel")
                # {}
            if mycase("TRANSACTION_collapsePanels"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("collapsePanels")
                # {}
            if mycase("TRANSACTION_disable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readStrongBinder()
                _arg2 = data.readString()
                return self.callFunction("disable", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'android.os.IBinder'}
            if mycase("TRANSACTION_setIcon"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readString()
                return self.callFunction("setIcon", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg4': 'java.lang.String'}
            if mycase("TRANSACTION_setIconVisibility"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setIconVisibility", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_removeIcon"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removeIcon", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_topAppWindowChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("topAppWindowChanged", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setImeWindowStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = (0 != data.readInt())
                return self.callFunction("setImeWindowStatus", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'boolean', '_arg0': 'android.os.IBinder', '_arg1': 'int'}
            if mycase("TRANSACTION_expandSettingsPanel"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("expandSettingsPanel")
                # {}
            if mycase("TRANSACTION_setCurrentUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setCurrentUser", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_registerStatusBar"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.statusbar.IStatusBar", data.readStrongBinder())
                _arg1 = self.newInstance("com.android.internal.statusbar.StatusBarIconList", )
                _arg2_length = data.readInt()
                if (_arg2_length < 0):
                    _arg2 = None
                else:
                    _arg2 = [None for _i in range(_arg2_length)] # 
                _arg3 = list()
                return self.callFunction("registerStatusBar", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.util.List<android.os.IBinder>', '_arg0': 'com.android.internal.statusbar.IStatusBar', '_arg1': 'com.android.internal.statusbar.StatusBarIconList', '_arg2_length': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPanelRevealed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("onPanelRevealed", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onPanelHidden"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onPanelHidden")
                # {}
            if mycase("TRANSACTION_clearNotificationEffects"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearNotificationEffects")
                # {}
            if mycase("TRANSACTION_onNotificationClick"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("onNotificationClick", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_onNotificationActionClick"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("onNotificationActionClick", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_onNotificationError"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                _arg4 = data.readInt()
                _arg5 = data.readString()
                _arg6 = data.readInt()
                return self.callFunction("onNotificationError", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg6': 'int', '_arg4': 'int', '_arg5': 'java.lang.String'}
            if mycase("TRANSACTION_onClearAllNotifications"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onClearAllNotifications", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onNotificationClear"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readInt()
                _arg3 = data.readInt()
                return self.callFunction("onNotificationClear", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'int', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_onNotificationVisibilityChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                _arg1 = data.createStringArray()
                return self.callFunction("onNotificationVisibilityChanged", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_onNotificationExpansionChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                _arg2 = (0 != data.readInt())
                return self.callFunction("onNotificationExpansionChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setSystemUiVisibility"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("setSystemUiVisibility", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setWindowState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setWindowState", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_showRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("showRecentApps", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_hideRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("hideRecentApps", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_toggleRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("toggleRecentApps")
                # {}
            if mycase("TRANSACTION_preloadRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("preloadRecentApps")
                # {}
            if mycase("TRANSACTION_cancelPreloadRecentApps"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("cancelPreloadRecentApps")
                # {}
