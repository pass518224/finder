from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITvInputSession:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.tv.ITvInputSession"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.tv.ITvInputSession"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_release"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("release")
                # {}
            if mycase("TRANSACTION_setMain"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setMain", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setSurface"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.Surface", data)
                else:
                    _arg0 = None
                return self.callFunction("setSurface", _arg0)
                # {'_arg0': 'android.view.Surface', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_dispatchSurfaceChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("dispatchSurfaceChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readFloat()
                return self.callFunction("setVolume", _arg0)
                # {'_arg0': 'float'}
            if mycase("TRANSACTION_tune"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("tune", _arg0, _arg1)
                # {'_arg0': 'android.net.Uri', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_setCaptionEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setCaptionEnabled", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_selectTrack"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readString()
                return self.callFunction("selectTrack", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_appPrivateCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("appPrivateCommand", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createOverlayView"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg1 = None
                return self.callFunction("createOverlayView", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_relayoutOverlayView"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.graphics.Rect", data)
                else:
                    _arg0 = None
                return self.callFunction("relayoutOverlayView", _arg0)
                # {'_arg0': 'android.graphics.Rect', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeOverlayView"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("removeOverlayView")
                # {}
            if mycase("TRANSACTION_requestUnblockContent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("requestUnblockContent", _arg0)
                # {'_arg0': 'java.lang.String'}
