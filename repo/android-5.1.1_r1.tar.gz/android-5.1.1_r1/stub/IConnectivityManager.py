from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IConnectivityManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.IConnectivityManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.IConnectivityManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getActiveNetworkInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveNetworkInfo")
                # {'_result': 'android.net.NetworkInfo'}
            if mycase("TRANSACTION_getActiveNetworkInfoForUid"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getActiveNetworkInfoForUid", _arg0)
                # {'_arg0': 'int', '_result': 'android.net.NetworkInfo'}
            if mycase("TRANSACTION_getNetworkInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getNetworkInfo", _arg0)
                # {'_arg0': 'int', '_result': 'android.net.NetworkInfo'}
            if mycase("TRANSACTION_getNetworkInfoForNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Network", data)
                else:
                    _arg0 = None
                return self.callFunction("getNetworkInfoForNetwork", _arg0)
                # {'_arg0': 'android.net.Network', '_result': 'android.net.NetworkInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAllNetworkInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllNetworkInfo")
                # {'_result': 'android.net.NetworkInfo'}
            if mycase("TRANSACTION_getNetworkForType"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getNetworkForType", _arg0)
                # {'_arg0': 'int', '_result': 'android.net.Network'}
            if mycase("TRANSACTION_getAllNetworks"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllNetworks")
                # {'_result': 'android.net.Network'}
            if mycase("TRANSACTION_getDefaultNetworkCapabilitiesForUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getDefaultNetworkCapabilitiesForUser", _arg0)
                # {'_arg0': 'int', '_result': 'android.net.NetworkCapabilities'}
            if mycase("TRANSACTION_getProvisioningOrActiveNetworkInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getProvisioningOrActiveNetworkInfo")
                # {'_result': 'android.net.NetworkInfo'}
            if mycase("TRANSACTION_isNetworkSupported"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("isNetworkSupported", _arg0)
                # {'_arg0': 'int', '_result': 'boolean'}
            if mycase("TRANSACTION_getActiveLinkProperties"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveLinkProperties")
                # {'_result': 'android.net.LinkProperties'}
            if mycase("TRANSACTION_getLinkPropertiesForType"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getLinkPropertiesForType", _arg0)
                # {'_arg0': 'int', '_result': 'android.net.LinkProperties'}
            if mycase("TRANSACTION_getLinkProperties"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Network", data)
                else:
                    _arg0 = None
                return self.callFunction("getLinkProperties", _arg0)
                # {'_arg0': 'android.net.Network', '_result': 'android.net.LinkProperties', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getNetworkCapabilities"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Network", data)
                else:
                    _arg0 = None
                return self.callFunction("getNetworkCapabilities", _arg0)
                # {'_arg0': 'android.net.Network', '_result': 'android.net.NetworkCapabilities', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getAllNetworkState"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getAllNetworkState")
                # {'_result': 'android.net.NetworkState'}
            if mycase("TRANSACTION_getActiveNetworkQuotaInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveNetworkQuotaInfo")
                # {'_result': 'android.net.NetworkQuotaInfo'}
            if mycase("TRANSACTION_isActiveNetworkMetered"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isActiveNetworkMetered")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_requestRouteToHostAddress"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createByteArray()
                return self.callFunction("requestRouteToHostAddress", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'int', '_arg1': 'byte'}
            if mycase("TRANSACTION_tether"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("tether", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_untether"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("untether", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_getLastTetherError"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getLastTetherError", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_isTetheringSupported"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isTetheringSupported")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getTetherableIfaces"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTetherableIfaces")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getTetheredIfaces"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTetheredIfaces")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getTetheringErroredIfaces"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTetheringErroredIfaces")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getTetheredDhcpRanges"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTetheredDhcpRanges")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getTetherableUsbRegexs"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTetherableUsbRegexs")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getTetherableWifiRegexs"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTetherableWifiRegexs")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getTetherableBluetoothRegexs"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getTetherableBluetoothRegexs")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_setUsbTethering"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setUsbTethering", _arg0)
                # {'_arg0': 'boolean', '_result': 'int'}
            if mycase("TRANSACTION_reportInetCondition"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("reportInetCondition", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_reportBadNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Network", data)
                else:
                    _arg0 = None
                return self.callFunction("reportBadNetwork", _arg0)
                # {'_arg0': 'android.net.Network', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getGlobalProxy"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getGlobalProxy")
                # {'_result': 'android.net.ProxyInfo'}
            if mycase("TRANSACTION_setGlobalProxy"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.ProxyInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("setGlobalProxy", _arg0)
                # {'_arg0': 'android.net.ProxyInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getDefaultProxy"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDefaultProxy")
                # {'_result': 'android.net.ProxyInfo'}
            if mycase("TRANSACTION_setDataDependency"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setDataDependency", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_prepareVpn"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("prepareVpn", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_setVpnPackageAuthorization"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setVpnPackageAuthorization", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_establishVpn"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("com.android.internal.net.VpnConfig", data)
                else:
                    _arg0 = None
                return self.callFunction("establishVpn", _arg0)
                # {'_arg0': 'com.android.internal.net.VpnConfig', '_result': 'android.os.ParcelFileDescriptor', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getVpnConfig"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVpnConfig")
                # {'_result': 'com.android.internal.net.VpnConfig'}
            if mycase("TRANSACTION_startLegacyVpn"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("com.android.internal.net.VpnProfile", data)
                else:
                    _arg0 = None
                return self.callFunction("startLegacyVpn", _arg0)
                # {'_arg0': 'com.android.internal.net.VpnProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getLegacyVpnInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLegacyVpnInfo")
                # {'_result': 'com.android.internal.net.LegacyVpnInfo'}
            if mycase("TRANSACTION_updateLockdownVpn"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("updateLockdownVpn")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_captivePortalCheckCompleted"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkInfo", data)
                else:
                    _arg0 = None
                _arg1 = (0 != data.readInt())
                return self.callFunction("captivePortalCheckCompleted", _arg0, _arg1)
                # {'_arg0': 'android.net.NetworkInfo', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_supplyMessenger"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Messenger", data)
                else:
                    _arg1 = None
                return self.callFunction("supplyMessenger", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.Messenger', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_findConnectionTypeForIface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("findConnectionTypeForIface", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_checkMobileProvisioning"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("checkMobileProvisioning", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_getMobileProvisioningUrl"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMobileProvisioningUrl")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getMobileRedirectedProvisioningUrl"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getMobileRedirectedProvisioningUrl")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_setProvisioningNotificationVisible"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("setProvisioningNotificationVisible", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'boolean', '_arg1': 'int'}
            if mycase("TRANSACTION_setAirplaneMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setAirplaneMode", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_registerNetworkFactory"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Messenger", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("registerNetworkFactory", _arg0, _arg1)
                # {'_arg0': 'android.os.Messenger', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_unregisterNetworkFactory"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Messenger", data)
                else:
                    _arg0 = None
                return self.callFunction("unregisterNetworkFactory", _arg0)
                # {'_arg0': 'android.os.Messenger', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_registerNetworkAgent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Messenger", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.NetworkInfo", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.net.LinkProperties", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.net.NetworkCapabilities", data)
                else:
                    _arg3 = None
                _arg4 = data.readInt()
                if (0 != data.readInt()):
                    _arg5 = self.creatorResolver("android.net.NetworkMisc", data)
                else:
                    _arg5 = None
                return self.callFunction("registerNetworkAgent", _arg0, _arg1, _arg2, _arg3, _arg4, _arg5)
                # {'_arg2': 'android.net.LinkProperties', '_arg3': 'android.net.NetworkCapabilities', '_arg0': 'android.os.Messenger', '_arg1': 'android.net.NetworkInfo', '_arg4': 'int', '_arg5': 'android.net.NetworkMisc', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_requestNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkCapabilities", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Messenger", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                _arg3 = data.readStrongBinder()
                _arg4 = data.readInt()
                return self.callFunction("requestNetwork", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'android.net.NetworkRequest', '_arg2': 'int', '_arg3': 'android.os.IBinder', '_arg0': 'android.net.NetworkCapabilities', '_arg1': 'android.os.Messenger', '_arg4': 'int', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_pendingRequestForNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkCapabilities", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg1 = None
                return self.callFunction("pendingRequestForNetwork", _arg0, _arg1)
                # {'_result': 'android.net.NetworkRequest', '_arg0': 'android.net.NetworkCapabilities', '_arg1': 'android.app.PendingIntent', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_releasePendingNetworkRequest"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg0 = None
                return self.callFunction("releasePendingNetworkRequest", _arg0)
                # {'_arg0': 'android.app.PendingIntent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_listenForNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkCapabilities", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Messenger", data)
                else:
                    _arg1 = None
                _arg2 = data.readStrongBinder()
                return self.callFunction("listenForNetwork", _arg0, _arg1, _arg2)
                # {'_result': 'android.net.NetworkRequest', '_arg2': 'android.os.IBinder', '_arg0': 'android.net.NetworkCapabilities', '_arg1': 'android.os.Messenger', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_pendingListenForNetwork"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkCapabilities", data)
                else:
                    _arg0 = None
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.app.PendingIntent", data)
                else:
                    _arg1 = None
                return self.callFunction("pendingListenForNetwork", _arg0, _arg1)
                # {'_arg0': 'android.net.NetworkCapabilities', '_arg1': 'android.app.PendingIntent', 'ELSE:': {}, 'IFI': {}, 'ELSE:I': {}, 'IF': {}}
            if mycase("TRANSACTION_releaseNetworkRequest"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.NetworkRequest", data)
                else:
                    _arg0 = None
                return self.callFunction("releaseNetworkRequest", _arg0)
                # {'_arg0': 'android.net.NetworkRequest', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getRestoreDefaultNetworkDelay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getRestoreDefaultNetworkDelay", _arg0)
                # {'_arg0': 'int', '_result': 'int'}
            if mycase("TRANSACTION_addVpnAddress"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("addVpnAddress", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_removeVpnAddress"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("removeVpnAddress", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setUnderlyingNetworksForVpn"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createTypedArray("android.net.Network")
                return self.callFunction("setUnderlyingNetworksForVpn", _arg0)
                # {'_arg0': 'android.net.Network', '_result': 'boolean'}
