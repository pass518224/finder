from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVoiceInteractorCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.app.IVoiceInteractorCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.app.IVoiceInteractorCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_deliverConfirmationResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorRequest", data.readStrongBinder())
                _arg1 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("deliverConfirmationResult", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'com.android.internal.app.IVoiceInteractorRequest', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deliverCompleteVoiceResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorRequest", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("deliverCompleteVoiceResult", _arg0, _arg1)
                # {'_arg0': 'com.android.internal.app.IVoiceInteractorRequest', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deliverAbortVoiceResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorRequest", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("deliverAbortVoiceResult", _arg0, _arg1)
                # {'_arg0': 'com.android.internal.app.IVoiceInteractorRequest', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deliverCommandResult"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorRequest", data.readStrongBinder())
                _arg1 = (0 != data.readInt())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg2 = None
                return self.callFunction("deliverCommandResult", _arg0, _arg1, _arg2)
                # {'_arg2': 'android.os.Bundle', '_arg0': 'com.android.internal.app.IVoiceInteractorRequest', '_arg1': 'boolean', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deliverCancel"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorRequest", data.readStrongBinder())
                return self.callFunction("deliverCancel", _arg0)
                # {'_arg0': 'com.android.internal.app.IVoiceInteractorRequest'}
