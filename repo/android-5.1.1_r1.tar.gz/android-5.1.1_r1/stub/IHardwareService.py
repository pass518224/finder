from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IHardwareService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.IHardwareService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.IHardwareService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getFlashlightEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getFlashlightEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setFlashlightEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setFlashlightEnabled", _arg0)
                # {'_arg0': 'boolean'}
