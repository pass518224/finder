from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITextToSpeechService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.speech.tts.ITextToSpeechService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.speech.tts.ITextToSpeechService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_speak"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                _arg4 = data.readString()
                return self.callFunction("speak", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'int', '_arg2': 'int', '_arg3': 'android.os.Bundle', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.CharSequence', '_arg4': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_synthesizeToFileDescriptor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg1 = None
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.os.ParcelFileDescriptor", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                _arg4 = data.readString()
                return self.callFunction("synthesizeToFileDescriptor", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'int', '_arg2': 'android.os.ParcelFileDescriptor', '_arg3': 'android.os.Bundle', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.CharSequence', '_arg4': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_playAudio"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.Uri", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                _arg4 = data.readString()
                return self.callFunction("playAudio", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_result': 'int', '_arg2': 'int', '_arg3': 'android.os.Bundle', '_arg0': 'android.os.IBinder', '_arg1': 'android.net.Uri', '_arg4': 'java.lang.String', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_playSilence"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readLong()
                _arg2 = data.readInt()
                _arg3 = data.readString()
                return self.callFunction("playSilence", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'java.lang.String', '_arg0': 'android.os.IBinder', '_arg1': 'long', '_result': 'int'}
            if mycase("TRANSACTION_isSpeaking"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isSpeaking")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_stop"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("stop", _arg0)
                # {'_arg0': 'android.os.IBinder', '_result': 'int'}
            if mycase("TRANSACTION_getLanguage"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getLanguage")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getClientDefaultLanguage"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getClientDefaultLanguage")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_isLanguageAvailable"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("isLanguageAvailable", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_getFeaturesForLanguage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("getFeaturesForLanguage", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_result': 'java.lang.String'}
            if mycase("TRANSACTION_loadLanguage"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                return self.callFunction("loadLanguage", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String', '_result': 'int'}
            if mycase("TRANSACTION_setCallback"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = self.interfaceResolver("android.speech.tts.ITextToSpeechCallback", data.readStrongBinder())
                return self.callFunction("setCallback", _arg0, _arg1)
                # {'_arg0': 'android.os.IBinder', '_arg1': 'android.speech.tts.ITextToSpeechCallback'}
            if mycase("TRANSACTION_getVoices"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getVoices")
                # {'_result': 'java.util.List<android.speech.tts.Voice>'}
            if mycase("TRANSACTION_loadVoice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                _arg1 = data.readString()
                return self.callFunction("loadVoice", _arg0, _arg1)
                # {'_result': 'int', '_arg0': 'android.os.IBinder', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_getDefaultVoiceNameFor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                return self.callFunction("getDefaultVoiceNameFor", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_result': 'java.lang.String'}
