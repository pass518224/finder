from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetworkManagementEventObserver:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.INetworkManagementEventObserver"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.INetworkManagementEventObserver"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_interfaceStatusChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("interfaceStatusChanged", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_interfaceLinkStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("interfaceLinkStateChanged", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_interfaceAdded"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("interfaceAdded", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_interfaceRemoved"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("interfaceRemoved", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_addressUpdated"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.LinkAddress", data)
                else:
                    _arg1 = None
                return self.callFunction("addressUpdated", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.net.LinkAddress', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_addressRemoved"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.LinkAddress", data)
                else:
                    _arg1 = None
                return self.callFunction("addressRemoved", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.net.LinkAddress', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_limitReached"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("limitReached", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_interfaceClassDataActivityChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readLong()
                return self.callFunction("interfaceClassDataActivityChanged", _arg0, _arg1, _arg2)
                # {'_arg2': 'long', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_interfaceDnsServerInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readLong()
                _arg2 = data.createStringArray()
                return self.callFunction("interfaceDnsServerInfo", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'long'}
            if mycase("TRANSACTION_routeUpdated"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.RouteInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("routeUpdated", _arg0)
                # {'_arg0': 'android.net.RouteInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_routeRemoved"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.RouteInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("routeRemoved", _arg0)
                # {'_arg0': 'android.net.RouteInfo', 'ELSE:': {}, 'IF': {}}
