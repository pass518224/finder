from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ITrustAgentServiceCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.service.trust.ITrustAgentServiceCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.service.trust.ITrustAgentServiceCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_grantTrust"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                _arg1 = data.readLong()
                _arg2 = (0 != data.readInt())
                return self.callFunction("grantTrust", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'java.lang.CharSequence', '_arg1': 'long', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_revokeTrust"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("revokeTrust")
                # {}
            if mycase("TRANSACTION_setManagingTrust"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setManagingTrust", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_onConfigureCompleted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = data.readStrongBinder()
                return self.callFunction("onConfigureCompleted", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'android.os.IBinder'}
