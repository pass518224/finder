from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInputContext:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.view.IInputContext"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.view.IInputContext"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getTextBeforeCursor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("com.android.internal.view.IInputContextCallback", data.readStrongBinder())
                return self.callFunction("getTextBeforeCursor", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'com.android.internal.view.IInputContextCallback', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getTextAfterCursor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("com.android.internal.view.IInputContextCallback", data.readStrongBinder())
                return self.callFunction("getTextAfterCursor", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'com.android.internal.view.IInputContextCallback', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getCursorCapsMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = self.interfaceResolver("com.android.internal.view.IInputContextCallback", data.readStrongBinder())
                return self.callFunction("getCursorCapsMode", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.internal.view.IInputContextCallback', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getExtractedText"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.inputmethod.ExtractedTextRequest", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = self.interfaceResolver("com.android.internal.view.IInputContextCallback", data.readStrongBinder())
                return self.callFunction("getExtractedText", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'com.android.internal.view.IInputContextCallback', '_arg0': 'android.view.inputmethod.ExtractedTextRequest', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_deleteSurroundingText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("deleteSurroundingText", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setComposingText"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("setComposingText", _arg0, _arg1)
                # {'_arg0': 'java.lang.CharSequence', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_finishComposingText"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("finishComposingText")
                # {}
            if mycase("TRANSACTION_commitText"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg0 = None
                _arg1 = data.readInt()
                return self.callFunction("commitText", _arg0, _arg1)
                # {'_arg0': 'java.lang.CharSequence', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_commitCompletion"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.inputmethod.CompletionInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("commitCompletion", _arg0)
                # {'_arg0': 'android.view.inputmethod.CompletionInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_commitCorrection"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.inputmethod.CorrectionInfo", data)
                else:
                    _arg0 = None
                return self.callFunction("commitCorrection", _arg0)
                # {'_arg0': 'android.view.inputmethod.CorrectionInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setSelection"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setSelection", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_performEditorAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("performEditorAction", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_performContextMenuAction"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("performContextMenuAction", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_beginBatchEdit"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("beginBatchEdit")
                # {}
            if mycase("TRANSACTION_endBatchEdit"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("endBatchEdit")
                # {}
            if mycase("TRANSACTION_reportFullscreenMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("reportFullscreenMode", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_sendKeyEvent"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.view.KeyEvent", data)
                else:
                    _arg0 = None
                return self.callFunction("sendKeyEvent", _arg0)
                # {'_arg0': 'android.view.KeyEvent', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearMetaKeyStates"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("clearMetaKeyStates", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_performPrivateCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("performPrivateCommand", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setComposingRegion"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("setComposingRegion", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getSelectedText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = self.interfaceResolver("com.android.internal.view.IInputContextCallback", data.readStrongBinder())
                return self.callFunction("getSelectedText", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.internal.view.IInputContextCallback', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_requestUpdateCursorAnchorInfo"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = self.interfaceResolver("com.android.internal.view.IInputContextCallback", data.readStrongBinder())
                return self.callFunction("requestUpdateCursorAnchorInfo", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.internal.view.IInputContextCallback', '_arg0': 'int', '_arg1': 'int'}
