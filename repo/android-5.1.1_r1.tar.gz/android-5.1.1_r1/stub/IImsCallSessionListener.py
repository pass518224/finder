from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IImsCallSessionListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.ims.internal.IImsCallSessionListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.ims.internal.IImsCallSessionListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_callSessionProgressing"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsStreamMediaProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionProgressing", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsStreamMediaProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionStarted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionStarted", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionStartFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionStartFailed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionTerminated"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionTerminated", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionHeld"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionHeld", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionHoldFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionHoldFailed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionHoldReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionHoldReceived", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionResumed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionResumed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionResumeFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionResumeFailed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionResumeReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionResumeReceived", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionMergeStarted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                _arg1 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg2 = None
                return self.callFunction("callSessionMergeStarted", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsCallProfile', '_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.internal.IImsCallSession', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionMergeComplete"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                return self.callFunction("callSessionMergeComplete", _arg0)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession'}
            if mycase("TRANSACTION_callSessionMergeFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionMergeFailed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionUpdated"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionUpdated", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionUpdateFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionUpdateFailed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionUpdateReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionUpdateReceived", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsCallProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionConferenceExtended"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                _arg1 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg2 = None
                return self.callFunction("callSessionConferenceExtended", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsCallProfile', '_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.internal.IImsCallSession', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionConferenceExtendFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionConferenceExtendFailed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionConferenceExtendReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                _arg1 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("com.android.ims.ImsCallProfile", data)
                else:
                    _arg2 = None
                return self.callFunction("callSessionConferenceExtendReceived", _arg0, _arg1, _arg2)
                # {'_arg2': 'com.android.ims.ImsCallProfile', '_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.internal.IImsCallSession', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionInviteParticipantsRequestDelivered"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                return self.callFunction("callSessionInviteParticipantsRequestDelivered", _arg0)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession'}
            if mycase("TRANSACTION_callSessionInviteParticipantsRequestFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionInviteParticipantsRequestFailed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionRemoveParticipantsRequestDelivered"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                return self.callFunction("callSessionRemoveParticipantsRequestDelivered", _arg0)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession'}
            if mycase("TRANSACTION_callSessionRemoveParticipantsRequestFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionRemoveParticipantsRequestFailed", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsReasonInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionConferenceStateUpdated"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("com.android.ims.ImsConferenceState", data)
                else:
                    _arg1 = None
                return self.callFunction("callSessionConferenceStateUpdated", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'com.android.ims.ImsConferenceState', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionUssdMessageReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("callSessionUssdMessageReceived", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'int'}
            if mycase("TRANSACTION_callSessionHandover"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg3 = None
                return self.callFunction("callSessionHandover", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'com.android.ims.ImsReasonInfo', '_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionHandoverFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("com.android.ims.ImsReasonInfo", data)
                else:
                    _arg3 = None
                return self.callFunction("callSessionHandoverFailed", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'com.android.ims.ImsReasonInfo', '_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'int', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_callSessionTtyModeReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("com.android.ims.internal.IImsCallSession", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("callSessionTtyModeReceived", _arg0, _arg1)
                # {'_arg0': 'com.android.ims.internal.IImsCallSession', '_arg1': 'int'}
