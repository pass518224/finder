from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IObbActionListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "IObbActionListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "IObbActionListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onObbResult"):
                data.enforceInterface(DESCRIPTOR)
                filename = data.readString()
                nonce = data.readInt()
                status = data.readInt()
                return self.callFunction("onObbResult", filename, nonce, status)
                # {'nonce': 'int', 'status': 'int', 'filename': 'String'}
