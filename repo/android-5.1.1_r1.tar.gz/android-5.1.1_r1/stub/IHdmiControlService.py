from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IHdmiControlService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.hdmi.IHdmiControlService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.hdmi.IHdmiControlService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getSupportedTypes"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSupportedTypes")
                # {'_result': 'int'}
            if mycase("TRANSACTION_getActiveSource"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getActiveSource")
                # {'_result': 'android.hardware.hdmi.HdmiDeviceInfo'}
            if mycase("TRANSACTION_oneTouchPlay"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiControlCallback", data.readStrongBinder())
                return self.callFunction("oneTouchPlay", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiControlCallback'}
            if mycase("TRANSACTION_queryDisplayStatus"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiControlCallback", data.readStrongBinder())
                return self.callFunction("queryDisplayStatus", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiControlCallback'}
            if mycase("TRANSACTION_addHotplugEventListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiHotplugEventListener", data.readStrongBinder())
                return self.callFunction("addHotplugEventListener", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiHotplugEventListener'}
            if mycase("TRANSACTION_removeHotplugEventListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiHotplugEventListener", data.readStrongBinder())
                return self.callFunction("removeHotplugEventListener", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiHotplugEventListener'}
            if mycase("TRANSACTION_addDeviceEventListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiDeviceEventListener", data.readStrongBinder())
                return self.callFunction("addDeviceEventListener", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiDeviceEventListener'}
            if mycase("TRANSACTION_deviceSelect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.hardware.hdmi.IHdmiControlCallback", data.readStrongBinder())
                return self.callFunction("deviceSelect", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.hardware.hdmi.IHdmiControlCallback'}
            if mycase("TRANSACTION_portSelect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = self.interfaceResolver("android.hardware.hdmi.IHdmiControlCallback", data.readStrongBinder())
                return self.callFunction("portSelect", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.hardware.hdmi.IHdmiControlCallback'}
            if mycase("TRANSACTION_sendKeyEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("sendKeyEvent", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_getPortInfo"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getPortInfo")
                # {'_result': 'java.util.List<android.hardware.hdmi.HdmiPortInfo>'}
            if mycase("TRANSACTION_canChangeSystemAudioMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("canChangeSystemAudioMode")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_getSystemAudioMode"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getSystemAudioMode")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setSystemAudioMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = self.interfaceResolver("android.hardware.hdmi.IHdmiControlCallback", data.readStrongBinder())
                return self.callFunction("setSystemAudioMode", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'android.hardware.hdmi.IHdmiControlCallback'}
            if mycase("TRANSACTION_addSystemAudioModeChangeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiSystemAudioModeChangeListener", data.readStrongBinder())
                return self.callFunction("addSystemAudioModeChangeListener", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiSystemAudioModeChangeListener'}
            if mycase("TRANSACTION_removeSystemAudioModeChangeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiSystemAudioModeChangeListener", data.readStrongBinder())
                return self.callFunction("removeSystemAudioModeChangeListener", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiSystemAudioModeChangeListener'}
            if mycase("TRANSACTION_setArcMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setArcMode", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setProhibitMode"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setProhibitMode", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setSystemAudioVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("setSystemAudioVolume", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setSystemAudioMute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setSystemAudioMute", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setInputChangeListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiInputChangeListener", data.readStrongBinder())
                return self.callFunction("setInputChangeListener", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiInputChangeListener'}
            if mycase("TRANSACTION_getInputDevices"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getInputDevices")
                # {'_result': 'java.util.List<android.hardware.hdmi.HdmiDeviceInfo>'}
            if mycase("TRANSACTION_getDeviceList"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDeviceList")
                # {'_result': 'java.util.List<android.hardware.hdmi.HdmiDeviceInfo>'}
            if mycase("TRANSACTION_sendVendorCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.createByteArray()
                _arg3 = (0 != data.readInt())
                return self.callFunction("sendVendorCommand", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'byte', '_arg3': 'boolean', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_addVendorCommandListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiVendorCommandListener", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("addVendorCommandListener", _arg0, _arg1)
                # {'_arg0': 'android.hardware.hdmi.IHdmiVendorCommandListener', '_arg1': 'int'}
            if mycase("TRANSACTION_sendStandby"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                return self.callFunction("sendStandby", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_setHdmiRecordListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiRecordListener", data.readStrongBinder())
                return self.callFunction("setHdmiRecordListener", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiRecordListener'}
            if mycase("TRANSACTION_startOneTouchRecord"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createByteArray()
                return self.callFunction("startOneTouchRecord", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'byte'}
            if mycase("TRANSACTION_stopOneTouchRecord"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("stopOneTouchRecord", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_startTimerRecording"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.createByteArray()
                return self.callFunction("startTimerRecording", _arg0, _arg1, _arg2)
                # {'_arg2': 'byte', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_clearTimerRecording"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.createByteArray()
                return self.callFunction("clearTimerRecording", _arg0, _arg1, _arg2)
                # {'_arg2': 'byte', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_sendMhlVendorCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                _arg3 = data.createByteArray()
                return self.callFunction("sendMhlVendorCommand", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'int', '_arg3': 'byte', '_arg0': 'int', '_arg1': 'int'}
            if mycase("TRANSACTION_addHdmiMhlVendorCommandListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.hdmi.IHdmiMhlVendorCommandListener", data.readStrongBinder())
                return self.callFunction("addHdmiMhlVendorCommandListener", _arg0)
                # {'_arg0': 'android.hardware.hdmi.IHdmiMhlVendorCommandListener'}
