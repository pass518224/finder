from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IProxyPortListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.net.IProxyPortListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.net.IProxyPortListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setProxyPort"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setProxyPort", _arg0)
                # {'_arg0': 'int'}
