from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IBulkCursor:
    pass
    descriptor = "android.content.IBulkCursor"
class OnTransact(IBulkCursor, Stub):
    def onTransact(self, code, data, reply):
        for mycase in Switch(code):
            if mycase("GET_CURSOR_WINDOW_TRANSACTION"):
                data.enforceInterface(IBulkCursor.descriptor)
                startPos = data.readInt()
                return self.callFunction("getWindow", startPos)
                # {'startPos': 'int', 'window': 'CursorWindow'}
            if mycase("DEACTIVATE_TRANSACTION"):
                data.enforceInterface(IBulkCursor.descriptor)
                return self.callFunction("deactivate")
                # {}
            if mycase("CLOSE_TRANSACTION"):
                data.enforceInterface(IBulkCursor.descriptor)
                return self.callFunction("close")
                # {}
            if mycase("REQUERY_TRANSACTION"):
                data.enforceInterface(IBulkCursor.descriptor)
                observer = self.interfaceResolver("IContentObserver", data.readStrongBinder())
                return self.callFunction("requery", observer)
                # {'count': 'int', 'observer': 'IContentObserver'}
            if mycase("ON_MOVE_TRANSACTION"):
                data.enforceInterface(IBulkCursor.descriptor)
                position = data.readInt()
                return self.callFunction("onMove", position)
                # {'position': 'int'}
            if mycase("GET_EXTRAS_TRANSACTION"):
                data.enforceInterface(IBulkCursor.descriptor)
                return self.callFunction("getExtras")
                # {'extras': 'Bundle'}
            if mycase("RESPOND_TRANSACTION"):
                data.enforceInterface(IBulkCursor.descriptor)
                extras = data.readBundle()
                return self.callFunction("respond", extras)
                # {'extras': 'Bundle', 'returnExtras': 'Bundle'}
