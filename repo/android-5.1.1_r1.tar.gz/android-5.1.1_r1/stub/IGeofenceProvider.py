from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGeofenceProvider:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.IGeofenceProvider"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.IGeofenceProvider"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setGeofenceHardware"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.hardware.location.IGeofenceHardware", data.readStrongBinder())
                return self.callFunction("setGeofenceHardware", _arg0)
                # {'_arg0': 'android.hardware.location.IGeofenceHardware'}
