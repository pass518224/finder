from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IWebViewUpdateService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.webkit.IWebViewUpdateService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.webkit.IWebViewUpdateService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_notifyRelroCreationCompleted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                _arg1 = (0 != data.readInt())
                return self.callFunction("notifyRelroCreationCompleted", _arg0, _arg1)
                # {'_arg0': 'boolean', '_arg1': 'boolean'}
            if mycase("TRANSACTION_waitForRelroCreationCompleted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("waitForRelroCreationCompleted", _arg0)
                # {'_arg0': 'boolean'}
