from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMediaRouterService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IMediaRouterService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IMediaRouterService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerClientAsUser"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IMediaRouterClient", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("registerClientAsUser", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.media.IMediaRouterClient', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_unregisterClient"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IMediaRouterClient", data.readStrongBinder())
                return self.callFunction("unregisterClient", _arg0)
                # {'_arg0': 'android.media.IMediaRouterClient'}
            if mycase("TRANSACTION_getState"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IMediaRouterClient", data.readStrongBinder())
                return self.callFunction("getState", _arg0)
                # {'_arg0': 'android.media.IMediaRouterClient', '_result': 'android.media.MediaRouterClientState'}
            if mycase("TRANSACTION_setDiscoveryRequest"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IMediaRouterClient", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setDiscoveryRequest", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.media.IMediaRouterClient', '_arg1': 'int'}
            if mycase("TRANSACTION_setSelectedRoute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IMediaRouterClient", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setSelectedRoute", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'android.media.IMediaRouterClient', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_requestSetVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IMediaRouterClient", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("requestSetVolume", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.media.IMediaRouterClient', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_requestUpdateVolume"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.media.IMediaRouterClient", data.readStrongBinder())
                _arg1 = data.readString()
                _arg2 = data.readInt()
                return self.callFunction("requestUpdateVolume", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'android.media.IMediaRouterClient', '_arg1': 'java.lang.String'}
