from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IClipboard:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.IClipboard"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.IClipboard"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_setPrimaryClip"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.content.ClipData", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("setPrimaryClip", _arg0, _arg1)
                # {'_arg0': 'android.content.ClipData', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getPrimaryClip"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPrimaryClip", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.content.ClipData'}
            if mycase("TRANSACTION_getPrimaryClipDescription"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getPrimaryClipDescription", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.content.ClipDescription'}
            if mycase("TRANSACTION_hasPrimaryClip"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("hasPrimaryClip", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_addPrimaryClipChangedListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.IOnPrimaryClipChangedListener", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("addPrimaryClipChangedListener", _arg0, _arg1)
                # {'_arg0': 'android.content.IOnPrimaryClipChangedListener', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_removePrimaryClipChangedListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.content.IOnPrimaryClipChangedListener", data.readStrongBinder())
                return self.callFunction("removePrimaryClipChangedListener", _arg0)
                # {'_arg0': 'android.content.IOnPrimaryClipChangedListener'}
            if mycase("TRANSACTION_hasClipboardText"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("hasClipboardText", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
