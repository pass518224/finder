from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ISipSessionListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.net.sip.ISipSessionListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.net.sip.ISipSessionListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onCalling"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                return self.callFunction("onCalling", _arg0)
                # {'_arg0': 'android.net.sip.ISipSession'}
            if mycase("TRANSACTION_onRinging"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.sip.SipProfile", data)
                else:
                    _arg1 = None
                _arg2 = data.readString()
                return self.callFunction("onRinging", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.net.sip.ISipSession', '_arg1': 'android.net.sip.SipProfile', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onRingingBack"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                return self.callFunction("onRingingBack", _arg0)
                # {'_arg0': 'android.net.sip.ISipSession'}
            if mycase("TRANSACTION_onCallEstablished"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("onCallEstablished", _arg0, _arg1)
                # {'_arg0': 'android.net.sip.ISipSession', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_onCallEnded"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                return self.callFunction("onCallEnded", _arg0)
                # {'_arg0': 'android.net.sip.ISipSession'}
            if mycase("TRANSACTION_onCallBusy"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                return self.callFunction("onCallBusy", _arg0)
                # {'_arg0': 'android.net.sip.ISipSession'}
            if mycase("TRANSACTION_onCallTransferring"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                _arg1 = data.readString()
                return self.callFunction("onCallTransferring", _arg0, _arg1)
                # {'_arg0': 'android.net.sip.ISipSession', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_onError"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("onError", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.net.sip.ISipSession', '_arg1': 'int'}
            if mycase("TRANSACTION_onCallChangeFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("onCallChangeFailed", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.net.sip.ISipSession', '_arg1': 'int'}
            if mycase("TRANSACTION_onRegistering"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                return self.callFunction("onRegistering", _arg0)
                # {'_arg0': 'android.net.sip.ISipSession'}
            if mycase("TRANSACTION_onRegistrationDone"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                _arg1 = data.readInt()
                return self.callFunction("onRegistrationDone", _arg0, _arg1)
                # {'_arg0': 'android.net.sip.ISipSession', '_arg1': 'int'}
            if mycase("TRANSACTION_onRegistrationFailed"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                _arg1 = data.readInt()
                _arg2 = data.readString()
                return self.callFunction("onRegistrationFailed", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'android.net.sip.ISipSession', '_arg1': 'int'}
            if mycase("TRANSACTION_onRegistrationTimeout"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.sip.ISipSession", data.readStrongBinder())
                return self.callFunction("onRegistrationTimeout", _arg0)
                # {'_arg0': 'android.net.sip.ISipSession'}
