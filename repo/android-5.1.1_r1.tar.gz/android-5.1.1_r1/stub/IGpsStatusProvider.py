from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IGpsStatusProvider:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.IGpsStatusProvider"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.IGpsStatusProvider"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_addGpsStatusListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsStatusListener", data.readStrongBinder())
                return self.callFunction("addGpsStatusListener", _arg0)
                # {'_arg0': 'android.location.IGpsStatusListener'}
            if mycase("TRANSACTION_removeGpsStatusListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.IGpsStatusListener", data.readStrongBinder())
                return self.callFunction("removeGpsStatusListener", _arg0)
                # {'_arg0': 'android.location.IGpsStatusListener'}
