from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class ICountryDetector:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.location.ICountryDetector"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.location.ICountryDetector"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_detectCountry"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("detectCountry")
                # {'_result': 'android.location.Country'}
            if mycase("TRANSACTION_addCountryListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.ICountryListener", data.readStrongBinder())
                return self.callFunction("addCountryListener", _arg0)
                # {'_arg0': 'android.location.ICountryListener'}
            if mycase("TRANSACTION_removeCountryListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.location.ICountryListener", data.readStrongBinder())
                return self.callFunction("removeCountryListener", _arg0)
                # {'_arg0': 'android.location.ICountryListener'}
