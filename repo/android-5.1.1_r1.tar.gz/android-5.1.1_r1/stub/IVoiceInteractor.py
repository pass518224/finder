from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IVoiceInteractor:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.app.IVoiceInteractor"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.app.IVoiceInteractor"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_startConfirmation"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorCallback", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("startConfirmation", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'com.android.internal.app.IVoiceInteractorRequest', '_arg2': 'java.lang.CharSequence', '_arg3': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'com.android.internal.app.IVoiceInteractorCallback', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startCompleteVoice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorCallback", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("startCompleteVoice", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'com.android.internal.app.IVoiceInteractorRequest', '_arg2': 'java.lang.CharSequence', '_arg3': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'com.android.internal.app.IVoiceInteractorCallback', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startAbortVoice"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorCallback", data.readStrongBinder())
                if (0 != data.readInt()):
                    _arg2 = self.creatorResolver("android.text.TextUtils.CHAR_SEQUENCE_CREATO", data)
                else:
                    _arg2 = None
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("startAbortVoice", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'com.android.internal.app.IVoiceInteractorRequest', '_arg2': 'java.lang.CharSequence', '_arg3': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'com.android.internal.app.IVoiceInteractorCallback', 'ELSE:I': {}, 'IFI': {}, 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_startCommand"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = self.interfaceResolver("com.android.internal.app.IVoiceInteractorCallback", data.readStrongBinder())
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg3 = None
                return self.callFunction("startCommand", _arg0, _arg1, _arg2, _arg3)
                # {'_result': 'com.android.internal.app.IVoiceInteractorRequest', '_arg2': 'java.lang.String', '_arg3': 'android.os.Bundle', '_arg0': 'java.lang.String', '_arg1': 'com.android.internal.app.IVoiceInteractorCallback', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_supportsCommands"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createStringArray()
                return self.callFunction("supportsCommands", _arg0, _arg1)
                # {'_result': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
