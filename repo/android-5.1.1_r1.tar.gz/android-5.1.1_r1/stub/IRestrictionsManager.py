from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRestrictionsManager:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.IRestrictionsManager"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.IRestrictionsManager"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_getApplicationRestrictions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getApplicationRestrictions", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.os.Bundle'}
            if mycase("TRANSACTION_hasRestrictionsProvider"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasRestrictionsProvider")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_requestPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                if (0 != data.readInt()):
                    _arg3 = self.creatorResolver("android.os.PersistableBundle", data)
                else:
                    _arg3 = None
                return self.callFunction("requestPermission", _arg0, _arg1, _arg2, _arg3)
                # {'_arg2': 'java.lang.String', '_arg3': 'android.os.PersistableBundle', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_notifyPermissionResponse"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.PersistableBundle", data)
                else:
                    _arg1 = None
                return self.callFunction("notifyPermissionResponse", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.os.PersistableBundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_createLocalApprovalIntent"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("createLocalApprovalIntent")
                # {'_result': 'android.content.Intent'}
