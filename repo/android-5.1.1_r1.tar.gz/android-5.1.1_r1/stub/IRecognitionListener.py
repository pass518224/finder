from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRecognitionListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.speech.IRecognitionListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.speech.IRecognitionListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onReadyForSpeech"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("onReadyForSpeech", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onBeginningOfSpeech"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onBeginningOfSpeech")
                # {}
            if mycase("TRANSACTION_onRmsChanged"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readFloat()
                return self.callFunction("onRmsChanged", _arg0)
                # {'_arg0': 'float'}
            if mycase("TRANSACTION_onBufferReceived"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createByteArray()
                return self.callFunction("onBufferReceived", _arg0)
                # {'_arg0': 'byte'}
            if mycase("TRANSACTION_onEndOfSpeech"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onEndOfSpeech")
                # {}
            if mycase("TRANSACTION_onError"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("onError", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_onResults"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("onResults", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onPartialResults"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg0 = None
                return self.callFunction("onPartialResults", _arg0)
                # {'_arg0': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_onEvent"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.os.Bundle", data)
                else:
                    _arg1 = None
                return self.callFunction("onEvent", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.os.Bundle', 'ELSE:': {}, 'IF': {}}
