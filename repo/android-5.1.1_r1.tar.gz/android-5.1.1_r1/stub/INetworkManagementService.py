from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class INetworkManagementService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.INetworkManagementService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.INetworkManagementService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_registerObserver"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.INetworkManagementEventObserver", data.readStrongBinder())
                return self.callFunction("registerObserver", _arg0)
                # {'_arg0': 'android.net.INetworkManagementEventObserver'}
            if mycase("TRANSACTION_unregisterObserver"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.net.INetworkManagementEventObserver", data.readStrongBinder())
                return self.callFunction("unregisterObserver", _arg0)
                # {'_arg0': 'android.net.INetworkManagementEventObserver'}
            if mycase("TRANSACTION_listInterfaces"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("listInterfaces")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_getInterfaceConfig"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getInterfaceConfig", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.net.InterfaceConfiguration'}
            if mycase("TRANSACTION_setInterfaceConfig"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.InterfaceConfiguration", data)
                else:
                    _arg1 = None
                return self.callFunction("setInterfaceConfig", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'android.net.InterfaceConfiguration', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_clearInterfaceAddresses"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("clearInterfaceAddresses", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setInterfaceDown"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setInterfaceDown", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setInterfaceUp"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("setInterfaceUp", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setInterfaceIpv6PrivacyExtensions"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setInterfaceIpv6PrivacyExtensions", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_disableIpv6"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("disableIpv6", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_enableIpv6"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("enableIpv6", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setInterfaceIpv6NdOffload"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setInterfaceIpv6NdOffload", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_getRoutes"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("getRoutes", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'android.net.RouteInfo'}
            if mycase("TRANSACTION_addRoute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.RouteInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("addRoute", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.net.RouteInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_removeRoute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.RouteInfo", data)
                else:
                    _arg1 = None
                return self.callFunction("removeRoute", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.net.RouteInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setMtu"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("setMtu", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_shutdown"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("shutdown")
                # {}
            if mycase("TRANSACTION_getIpForwardingEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getIpForwardingEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setIpForwardingEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setIpForwardingEnabled", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_startTethering"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createStringArray()
                return self.callFunction("startTethering", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_stopTethering"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("stopTethering")
                # {}
            if mycase("TRANSACTION_isTetheringStarted"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isTetheringStarted")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_tetherInterface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("tetherInterface", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_untetherInterface"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("untetherInterface", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_listTetheredInterfaces"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("listTetheredInterfaces")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_setDnsForwarders"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.Network", data)
                else:
                    _arg0 = None
                _arg1 = data.createStringArray()
                return self.callFunction("setDnsForwarders", _arg0, _arg1)
                # {'_arg0': 'android.net.Network', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getDnsForwarders"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getDnsForwarders")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_enableNat"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("enableNat", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_disableNat"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("disableNat", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_listTtys"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("listTtys")
                # {'_result': 'java.lang.String'}
            if mycase("TRANSACTION_attachPppd"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                _arg2 = data.readString()
                _arg3 = data.readString()
                _arg4 = data.readString()
                return self.callFunction("attachPppd", _arg0, _arg1, _arg2, _arg3, _arg4)
                # {'_arg2': 'java.lang.String', '_arg3': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'java.lang.String', '_arg4': 'java.lang.String'}
            if mycase("TRANSACTION_detachPppd"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("detachPppd", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_wifiFirmwareReload"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("wifiFirmwareReload", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_startAccessPoint"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.wifi.WifiConfiguration", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("startAccessPoint", _arg0, _arg1)
                # {'_arg0': 'android.net.wifi.WifiConfiguration', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_stopAccessPoint"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("stopAccessPoint", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setAccessPoint"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.net.wifi.WifiConfiguration", data)
                else:
                    _arg0 = None
                _arg1 = data.readString()
                return self.callFunction("setAccessPoint", _arg0, _arg1)
                # {'_arg0': 'android.net.wifi.WifiConfiguration', '_arg1': 'java.lang.String', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_getNetworkStatsSummaryDev"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNetworkStatsSummaryDev")
                # {'_result': 'android.net.NetworkStats'}
            if mycase("TRANSACTION_getNetworkStatsSummaryXt"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNetworkStatsSummaryXt")
                # {'_result': 'android.net.NetworkStats'}
            if mycase("TRANSACTION_getNetworkStatsDetail"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNetworkStatsDetail")
                # {'_result': 'android.net.NetworkStats'}
            if mycase("TRANSACTION_getNetworkStatsUidDetail"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("getNetworkStatsUidDetail", _arg0)
                # {'_arg0': 'int', '_result': 'android.net.NetworkStats'}
            if mycase("TRANSACTION_getNetworkStatsTethering"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getNetworkStatsTethering")
                # {'_result': 'android.net.NetworkStats'}
            if mycase("TRANSACTION_setInterfaceQuota"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readLong()
                return self.callFunction("setInterfaceQuota", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'long'}
            if mycase("TRANSACTION_removeInterfaceQuota"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removeInterfaceQuota", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setInterfaceAlert"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readLong()
                return self.callFunction("setInterfaceAlert", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'long'}
            if mycase("TRANSACTION_removeInterfaceAlert"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removeInterfaceAlert", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setGlobalAlert"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readLong()
                return self.callFunction("setGlobalAlert", _arg0)
                # {'_arg0': 'long'}
            if mycase("TRANSACTION_setUidNetworkRules"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setUidNetworkRules", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_isBandwidthControlEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isBandwidthControlEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_addIdleTimer"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.readInt()
                return self.callFunction("addIdleTimer", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_removeIdleTimer"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removeIdleTimer", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_setDnsServersForNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createStringArray()
                _arg2 = data.readString()
                return self.callFunction("setDnsServersForNetwork", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'int', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_flushNetworkDnsCache"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("flushNetworkDnsCache", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_setFirewallEnabled"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("setFirewallEnabled", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_isFirewallEnabled"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isFirewallEnabled")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_setFirewallInterfaceRule"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setFirewallInterfaceRule", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setFirewallEgressSourceRule"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setFirewallEgressSourceRule", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_setFirewallEgressDestRule"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = (0 != data.readInt())
                return self.callFunction("setFirewallEgressDestRule", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_setFirewallUidRule"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                return self.callFunction("setFirewallUidRule", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_addVpnUidRanges"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createTypedArray("android.net.UidRange")
                return self.callFunction("addVpnUidRanges", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.net.UidRange'}
            if mycase("TRANSACTION_removeVpnUidRanges"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = data.createTypedArray("android.net.UidRange")
                return self.callFunction("removeVpnUidRanges", _arg0, _arg1)
                # {'_arg0': 'int', '_arg1': 'android.net.UidRange'}
            if mycase("TRANSACTION_startClatd"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("startClatd", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_stopClatd"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("stopClatd", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_isClatdStarted"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("isClatdStarted", _arg0)
                # {'_arg0': 'java.lang.String', '_result': 'boolean'}
            if mycase("TRANSACTION_registerNetworkActivityListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.os.INetworkActivityListener", data.readStrongBinder())
                return self.callFunction("registerNetworkActivityListener", _arg0)
                # {'_arg0': 'android.os.INetworkActivityListener'}
            if mycase("TRANSACTION_unregisterNetworkActivityListener"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = self.interfaceResolver("android.os.INetworkActivityListener", data.readStrongBinder())
                return self.callFunction("unregisterNetworkActivityListener", _arg0)
                # {'_arg0': 'android.os.INetworkActivityListener'}
            if mycase("TRANSACTION_isNetworkActive"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("isNetworkActive")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_createPhysicalNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("createPhysicalNetwork", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_createVirtualNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                _arg1 = (0 != data.readInt())
                _arg2 = (0 != data.readInt())
                return self.callFunction("createVirtualNetwork", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'int', '_arg1': 'boolean'}
            if mycase("TRANSACTION_removeNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("removeNetwork", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_addInterfaceToNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("addInterfaceToNetwork", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_removeInterfaceFromNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("removeInterfaceFromNetwork", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_addLegacyRouteForNetId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.net.RouteInfo", data)
                else:
                    _arg1 = None
                _arg2 = data.readInt()
                return self.callFunction("addLegacyRouteForNetId", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'int', '_arg1': 'android.net.RouteInfo', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_setDefaultNetId"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setDefaultNetId", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_clearDefaultNetId"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("clearDefaultNetId")
                # {}
            if mycase("TRANSACTION_setPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createIntArray()
                return self.callFunction("setPermission", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_clearPermission"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.createIntArray()
                return self.callFunction("clearPermission", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_allowProtect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("allowProtect", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_denyProtect"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("denyProtect", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_addInterfaceToLocalNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.createTypedArrayList("android.net.RouteInfo")
                return self.callFunction("addInterfaceToLocalNetwork", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.util.List<android.net.RouteInfo>'}
            if mycase("TRANSACTION_removeInterfaceFromLocalNetwork"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("removeInterfaceFromLocalNetwork", _arg0)
                # {'_arg0': 'java.lang.String'}
