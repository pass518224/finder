from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IInCallAdapter:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.telecom.IInCallAdapter"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.telecom.IInCallAdapter"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_answerCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                return self.callFunction("answerCall", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_rejectCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                _arg2 = data.readString()
                return self.callFunction("rejectCall", _arg0, _arg1, _arg2)
                # {'_arg2': 'java.lang.String', '_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_disconnectCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("disconnectCall", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_holdCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("holdCall", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_unholdCall"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("unholdCall", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_mute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("mute", _arg0)
                # {'_arg0': 'boolean'}
            if mycase("TRANSACTION_setAudioRoute"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readInt()
                return self.callFunction("setAudioRoute", _arg0)
                # {'_arg0': 'int'}
            if mycase("TRANSACTION_playDtmfTone"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = None
                return self.callFunction("playDtmfTone", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'char'}
            if mycase("TRANSACTION_stopDtmfTone"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("stopDtmfTone", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_postDialContinue"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = (0 != data.readInt())
                return self.callFunction("postDialContinue", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'boolean'}
            if mycase("TRANSACTION_phoneAccountSelected"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                if (0 != data.readInt()):
                    _arg1 = self.creatorResolver("android.telecom.PhoneAccountHandle", data)
                else:
                    _arg1 = None
                _arg2 = (0 != data.readInt())
                return self.callFunction("phoneAccountSelected", _arg0, _arg1, _arg2)
                # {'_arg2': 'boolean', '_arg0': 'java.lang.String', '_arg1': 'android.telecom.PhoneAccountHandle', 'ELSE:': {}, 'IF': {}}
            if mycase("TRANSACTION_conference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readString()
                return self.callFunction("conference", _arg0, _arg1)
                # {'_arg0': 'java.lang.String', '_arg1': 'java.lang.String'}
            if mycase("TRANSACTION_splitFromConference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("splitFromConference", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_mergeConference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("mergeConference", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_swapConference"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                return self.callFunction("swapConference", _arg0)
                # {'_arg0': 'java.lang.String'}
            if mycase("TRANSACTION_turnOnProximitySensor"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("turnOnProximitySensor")
                # {}
            if mycase("TRANSACTION_turnOffProximitySensor"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = (0 != data.readInt())
                return self.callFunction("turnOffProximitySensor", _arg0)
                # {'_arg0': 'boolean'}
