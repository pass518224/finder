from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IConsumerIrService:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.hardware.IConsumerIrService"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.hardware.IConsumerIrService"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_hasIrEmitter"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("hasIrEmitter")
                # {'_result': 'boolean'}
            if mycase("TRANSACTION_transmit"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readString()
                _arg1 = data.readInt()
                _arg2 = data.createIntArray()
                return self.callFunction("transmit", _arg0, _arg1, _arg2)
                # {'_arg2': 'int', '_arg0': 'java.lang.String', '_arg1': 'int'}
            if mycase("TRANSACTION_getCarrierFrequencies"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("getCarrierFrequencies")
                # {'_result': 'int'}
