from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IOnPrimaryClipChangedListener:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.content.IOnPrimaryClipChangedListener"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.content.IOnPrimaryClipChangedListener"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_dispatchPrimaryClipChanged"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("dispatchPrimaryClipChanged")
                # {}
