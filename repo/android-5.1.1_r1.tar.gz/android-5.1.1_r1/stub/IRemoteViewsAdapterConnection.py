from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRemoteViewsAdapterConnection:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "com.android.internal.widget.IRemoteViewsAdapterConnection"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "com.android.internal.widget.IRemoteViewsAdapterConnection"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onServiceConnected"):
                data.enforceInterface(DESCRIPTOR)
                _arg0 = data.readStrongBinder()
                return self.callFunction("onServiceConnected", _arg0)
                # {'_arg0': 'android.os.IBinder'}
            if mycase("TRANSACTION_onServiceDisconnected"):
                data.enforceInterface(DESCRIPTOR)
                return self.callFunction("onServiceDisconnected")
                # {}
