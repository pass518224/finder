from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IMessenger:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.os.IMessenger"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.os.IMessenger"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_send"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.os.Message", data)
                else:
                    _arg0 = None
                return self.callFunction("send", _arg0)
                # {'_arg0': 'android.os.Message', 'ELSE:': {}, 'IF': {}}
