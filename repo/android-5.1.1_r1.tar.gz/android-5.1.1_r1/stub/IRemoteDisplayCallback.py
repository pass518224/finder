from lib.Switch import Switch 
from lib.Stub import Stub 
from lib.JavaUtils import * 
class IRemoteDisplayCallback:
    pass
class OnTransact(Stub):
    DESCRIPTOR = "android.media.IRemoteDisplayCallback"
    def onTransact(self, code, data, reply):
        DESCRIPTOR = "android.media.IRemoteDisplayCallback"
        for mycase in Switch(code):
            if mycase("INTERFACE_TRANSACTION"):
                reply.writeString(DESCRIPTOR)
                return True
                # {}
            if mycase("TRANSACTION_onStateChanged"):
                data.enforceInterface(DESCRIPTOR)
                if (0 != data.readInt()):
                    _arg0 = self.creatorResolver("android.media.RemoteDisplayState", data)
                else:
                    _arg0 = None
                return self.callFunction("onStateChanged", _arg0)
                # {'_arg0': 'android.media.RemoteDisplayState', 'ELSE:': {}, 'IF': {}}
