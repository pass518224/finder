class Enumeration(object):
    @classmethod
    def hasMoreElements(_SELF):
        pass
    @classmethod
    def nextElement(_SELF):
        pass
