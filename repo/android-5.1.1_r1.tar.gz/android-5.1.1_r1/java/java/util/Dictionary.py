class Dictionary(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def elements(_SELF):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def keys(_SELF):
        pass
    @classmethod
    def put(_SELF, key, value):
        pass
    @classmethod
    def remove(_SELF, key):
        pass
    @classmethod
    def size(_SELF):
        pass
