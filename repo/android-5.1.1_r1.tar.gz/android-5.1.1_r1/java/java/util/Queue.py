class Queue(object):
    @classmethod
    def add(_SELF, e):
        pass
    @classmethod
    def offer(_SELF, e):
        pass
    @classmethod
    def remove(_SELF):
        pass
    @classmethod
    def poll(_SELF):
        pass
    @classmethod
    def element(_SELF):
        pass
    @classmethod
    def peek(_SELF):
        pass
