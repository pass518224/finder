class Scanner(object):
    NL = "\n|\r\n|\r|\u0085|\u2028|\u2029"
    DEFAULT_DELIMITER = None
    BOOLEAN_PATTERN = None
    LINE_TERMINATOR = None
    MULTI_LINE_TERMINATOR = None
    LINE_PATTERN = None
    ANY_PATTERN = None
    DEFAULT_RADIX = 10
    input = None
    buffer = None
    delimiter = None
    matcher = None
    currentRadix = None
    locale = None
    findStartIndex = 0
    preStartIndex = None
    bufferLength = 0
    closed = False
    lastIOException = None
    matchSuccessful = False
    decimalFormat = None
    inputExhausted = False
    cachedNextValue = None
    cachedNextIndex = 1
    cachedFloatPattern = None
    cachedIntegerPatternRadix = 1
    cachedIntegerPattern = None
    
    @classmethod
    def nextByte(self, *args):
        fname = "Oed_nextByte__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def hasNext(self, *args):
        fname = "Oed_hasNext__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def hasNextLong(self, *args):
        fname = "Oed_hasNextLong__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def skip(self, *args):
        fname = "Oed_skip__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def useDelimiter(self, *args):
        fname = "Oed_useDelimiter__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def nextLong(self, *args):
        fname = "Oed_nextLong__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def hasNextBigInteger(self, *args):
        fname = "Oed_hasNextBigInteger__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def next(self, *args):
        fname = "Oed_next__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def findWithinHorizon(self, *args):
        fname = "Oed_findWithinHorizon__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def nextInt(self, *args):
        fname = "Oed_nextInt__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def hasNextInt(self, *args):
        fname = "Oed_hasNextInt__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def hasNextShort(self, *args):
        fname = "Oed_hasNextShort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def nextBigInteger(self, *args):
        fname = "Oed_nextBigInteger__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def hasNextByte(self, *args):
        fname = "Oed_hasNextByte__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def findInLine(self, *args):
        fname = "Oed_findInLine__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def nextShort(self, *args):
        fname = "Oed_nextShort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____File(_SELF, src):
        pass
    @classmethod
    def Oed___init____File__str(_SELF, src, charsetName):
        pass
    @classmethod
    def Oed___init____str(_SELF, src):
        pass
    @classmethod
    def Oed___init____InputStream(_SELF, src):
        pass
    @classmethod
    def Oed___init____InputStream__str(_SELF, src, charsetName):
        pass
    @classmethod
    def Oed___init____Readable(_SELF, src):
        pass
    @classmethod
    def Oed___init____ReadableByteChannel(_SELF, src):
        pass
    @classmethod
    def Oed___init____ReadableByteChannel__str(_SELF, src, charsetName):
        pass
    @classmethod
    def initialize(_SELF, input):
        pass
    @classmethod
    def close(_SELF):
        pass
    @classmethod
    def delimiter(_SELF):
        pass
    @classmethod
    def Oed_findInLine__Pattern(_SELF, pattern):
        pass
    @classmethod
    def Oed_findInLine__str(_SELF, pattern):
        pass
    @classmethod
    def Oed_findWithinHorizon__Pattern__int(_SELF, pattern, horizon):
        pass
    @classmethod
    def Oed_findWithinHorizon__str__int(_SELF, pattern, horizon):
        pass
    @classmethod
    def Oed_hasNext__(_SELF):
        pass
    @classmethod
    def Oed_hasNext__Pattern(_SELF, pattern):
        pass
    @classmethod
    def Oed_hasNext__str(_SELF, pattern):
        pass
    @classmethod
    def hasNextBigDecimal(_SELF):
        pass
    @classmethod
    def Oed_hasNextBigInteger__(_SELF):
        pass
    @classmethod
    def Oed_hasNextBigInteger__int(_SELF, radix):
        pass
    @classmethod
    def hasNextBoolean(_SELF):
        pass
    @classmethod
    def Oed_hasNextByte__(_SELF):
        pass
    @classmethod
    def Oed_hasNextByte__int(_SELF, radix):
        pass
    @classmethod
    def hasNextDouble(_SELF):
        pass
    @classmethod
    def hasNextFloat(_SELF):
        pass
    @classmethod
    def Oed_hasNextInt__(_SELF):
        pass
    @classmethod
    def Oed_hasNextInt__int(_SELF, radix):
        pass
    @classmethod
    def hasNextLine(_SELF):
        pass
    @classmethod
    def Oed_hasNextLong__(_SELF):
        pass
    @classmethod
    def Oed_hasNextLong__int(_SELF, radix):
        pass
    @classmethod
    def Oed_hasNextShort__(_SELF):
        pass
    @classmethod
    def Oed_hasNextShort__int(_SELF, radix):
        pass
    @classmethod
    def ioException(_SELF):
        pass
    @classmethod
    def locale(_SELF):
        pass
    @classmethod
    def setLocale(_SELF, locale):
        pass
    @classmethod
    def match(_SELF):
        pass
    @classmethod
    def Oed_next__(_SELF):
        pass
    @classmethod
    def Oed_next__Pattern(_SELF, pattern):
        pass
    @classmethod
    def Oed_next__str(_SELF, pattern):
        pass
    @classmethod
    def nextBigDecimal(_SELF):
        pass
    @classmethod
    def Oed_nextBigInteger__(_SELF):
        pass
    @classmethod
    def Oed_nextBigInteger__int(_SELF, radix):
        pass
    @classmethod
    def nextBoolean(_SELF):
        pass
    @classmethod
    def Oed_nextByte__(_SELF):
        pass
    @classmethod
    def Oed_nextByte__int(_SELF, radix):
        pass
    @classmethod
    def nextDouble(_SELF):
        pass
    @classmethod
    def nextFloat(_SELF):
        pass
    @classmethod
    def Oed_nextInt__(_SELF):
        pass
    @classmethod
    def Oed_nextInt__int(_SELF, radix):
        pass
    @classmethod
    def nextLine(_SELF):
        pass
    @classmethod
    def Oed_nextLong__(_SELF):
        pass
    @classmethod
    def Oed_nextLong__int(_SELF, radix):
        pass
    @classmethod
    def Oed_nextShort__(_SELF):
        pass
    @classmethod
    def Oed_nextShort__int(_SELF, radix):
        pass
    @classmethod
    def radix(_SELF):
        pass
    @classmethod
    def Oed_skip__Pattern(_SELF, pattern):
        pass
    @classmethod
    def Oed_skip__str(_SELF, pattern):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def Oed_useDelimiter__Pattern(_SELF, pattern):
        pass
    @classmethod
    def Oed_useDelimiter__str(_SELF, pattern):
        pass
    @classmethod
    def useLocale(_SELF, l):
        pass
    @classmethod
    def useRadix(_SELF, radix):
        pass
    @classmethod
    def checkRadix(_SELF, radix):
        pass
    @classmethod
    def remove(_SELF):
        pass
    @classmethod
    def checkOpen(_SELF):
        pass
    @classmethod
    def checkNotNull(_SELF, pattern):
        pass
    @classmethod
    def resetMatcher(_SELF):
        pass
    @classmethod
    def prepareForScan(_SELF):
        pass
    @classmethod
    def recoverPreviousStatus(_SELF):
        pass
    @classmethod
    def getIntegerPattern(_SELF, radix):
        pass
    @classmethod
    def getFloatPattern(_SELF):
        pass
    @classmethod
    def getNumeral(_SELF, digit, nonZeroDigit):
        pass
    @classmethod
    def addPositiveSign(_SELF, unsignedNumeral):
        pass
    @classmethod
    def addNegativeSign(_SELF, unsignedNumeral):
        pass
    @classmethod
    def removeLocaleInfoFromFloat(_SELF, floatString):
        pass
    @classmethod
    def removeLocaleInfo(_SELF, token, type):
        pass
    @classmethod
    def removeLocaleSign(_SELF, tokenBuilder):
        pass
    @classmethod
    def setTokenRegion(_SELF):
        pass
    @classmethod
    def findPreDelimiter(_SELF):
        pass
    @classmethod
    def setHeadTokenRegion(_SELF, findIndex):
        pass
    @classmethod
    def findDelimiterAfter(_SELF):
        pass
    @classmethod
    def readMore(_SELF):
        pass
    @classmethod
    def expandBuffer(_SELF):
        pass
    @classmethod
    def reset(_SELF):
        pass
