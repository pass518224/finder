class Grego(object):
    MIN_MILLIS = 184303902528000000L
    MAX_MILLIS = 183882168921600000L
    MILLIS_PER_SECOND = 1000
    MILLIS_PER_MINUTE = None
    MILLIS_PER_HOUR = None
    MILLIS_PER_DAY = None
    JULIAN_1_CE = 1721426
    JULIAN_1970_CE = 2440588
    MONTH_LENGTH = None
    DAYS_BEFORE = None
    
    @classmethod
    def floorDivide(self, *args):
        fname = "Oed_floorDivide__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def isLeapYear(_SELF, year):
        pass
    @classmethod
    def monthLength(_SELF, year, month):
        pass
    @classmethod
    def previousMonthLength(_SELF, year, month):
        pass
    @classmethod
    def fieldsToDay(_SELF, year, month, dom):
        pass
    @classmethod
    def dayOfWeek(_SELF, day):
        pass
    @classmethod
    def dayToFields(_SELF, day, fields):
        pass
    @classmethod
    def timeToFields(_SELF, time, fields):
        pass
    @classmethod
    def Oed_floorDivide__int__int(_SELF, numerator, denominator):
        pass
    @classmethod
    def Oed_floorDivide__int__int__list(_SELF, numerator, denominator, remainder):
        pass
    @classmethod
    def getDayOfWeekInMonth(_SELF, year, month, dayOfMonth):
        pass
