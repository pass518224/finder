class Currency(object):
    serialVersionUID = 158308464356906721L
    codesToCurrencies = None
    localesToCurrencies = None
    currencyCode = None
    
    @classmethod
    def getSymbol(self, *args):
        fname = "Oed_getSymbol__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getDisplayName(self, *args):
        fname = "Oed_getDisplayName__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getInstance(self, *args):
        fname = "Oed_getInstance__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, currencyCode):
        pass
    @classmethod
    def Oed_getInstance__str(_SELF, currencyCode):
        pass
    @classmethod
    def Oed_getInstance__Locale(_SELF, locale):
        pass
    @classmethod
    def getAvailableCurrencies(_SELF):
        pass
    @classmethod
    def getCurrencyCode(_SELF):
        pass
    @classmethod
    def Oed_getDisplayName__(_SELF):
        pass
    @classmethod
    def Oed_getDisplayName__Locale(_SELF, locale):
        pass
    @classmethod
    def Oed_getSymbol__(_SELF):
        pass
    @classmethod
    def Oed_getSymbol__Locale(_SELF, locale):
        pass
    @classmethod
    def getDefaultFractionDigits(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def readResolve(_SELF):
        pass
