class PropertyResourceBundle(object):
    resources = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____InputStream(_SELF, stream):
        pass
    @classmethod
    def Oed___init____Reader(_SELF, reader):
        pass
    @classmethod
    def handleKeySet(_SELF):
        pass
    @classmethod
    def getLocalKeys(_SELF):
        pass
    @classmethod
    def getKeys(_SELF):
        pass
    @classmethod
    def handleGetObject(_SELF, key):
        pass
