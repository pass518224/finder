class MissingFormatWidthException(object):
    serialVersionUID = 15560123L
    s = None
    @classmethod
    def __init__(_SELF, s):
        pass
    @classmethod
    def getFormatSpecifier(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
