class EnumSet(object):
    serialVersionUID = 1009687484059888093L
    elementClass = None
    class SerializationProxy(object):
        serialVersionUID = 362491234563181265L
        elementType = None
        elements = None
        @classmethod
        def readResolve(_SELF):
            pass
    
    @classmethod
    def of(self, *args):
        fname = "Oed_of__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def copyOf(self, *args):
        fname = "Oed_copyOf__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, cls):
        pass
    @classmethod
    def noneOf(_SELF, elementType):
        pass
    @classmethod
    def allOf(_SELF, elementType):
        pass
    @classmethod
    def Oed_copyOf__EnumSet(_SELF, s):
        pass
    @classmethod
    def Oed_copyOf__Collection(_SELF, c):
        pass
    @classmethod
    def complementOf(_SELF, s):
        pass
    @classmethod
    def complement(_SELF):
        pass
    @classmethod
    def Oed_of__E(_SELF, e):
        pass
    @classmethod
    def Oed_of__E__E(_SELF, e1, e2):
        pass
    @classmethod
    def Oed_of__E__E__E(_SELF, e1, e2, e3):
        pass
    @classmethod
    def Oed_of__E__E__E__E(_SELF, e1, e2, e3, e4):
        pass
    @classmethod
    def Oed_of__E__E__E__E__E(_SELF, e1, e2, e3, e4, e5):
        pass
    @classmethod
    def Oed_of__E__E(_SELF, start, others):
        pass
    @classmethod
    def range(_SELF, start, end):
        pass
    @classmethod
    def setRange(_SELF, start, end):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def isValidType(_SELF, cls):
        pass
    @classmethod
    def writeReplace(_SELF):
        pass
