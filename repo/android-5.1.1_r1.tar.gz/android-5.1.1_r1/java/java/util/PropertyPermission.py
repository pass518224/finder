class PropertyPermission(object):
    @classmethod
    def __init__(_SELF, name, actions):
        pass
    @classmethod
    def getActions(_SELF):
        pass
    @classmethod
    def implies(_SELF, permission):
        pass
