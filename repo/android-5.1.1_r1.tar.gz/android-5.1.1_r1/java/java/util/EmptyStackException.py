class EmptyStackException(object):
    serialVersionUID = 5084686378493302095L
    @classmethod
    def __init__(_SELF):
        pass
