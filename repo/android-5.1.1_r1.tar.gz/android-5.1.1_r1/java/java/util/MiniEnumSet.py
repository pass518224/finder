class MiniEnumSet(object):
    MAX_ELEMENTS = 64
    size = None
    enums = None
    bits = None
    class MiniEnumSetIterator(object):
        currentBits = None
        mask = None
        last = None
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    @classmethod
    def __init__(_SELF, elementType, enums):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def add(_SELF, element):
        pass
    @classmethod
    def addAll(_SELF, collection):
        pass
    @classmethod
    def contains(_SELF, object):
        pass
    @classmethod
    def containsAll(_SELF, collection):
        pass
    @classmethod
    def removeAll(_SELF, collection):
        pass
    @classmethod
    def retainAll(_SELF, collection):
        pass
    @classmethod
    def remove(_SELF, object):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def complement(_SELF):
        pass
    @classmethod
    def setRange(_SELF, start, end):
        pass
