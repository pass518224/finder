class Deque(object):
    @classmethod
    def addFirst(_SELF, e):
        pass
    @classmethod
    def addLast(_SELF, e):
        pass
    @classmethod
    def offerFirst(_SELF, e):
        pass
    @classmethod
    def offerLast(_SELF, e):
        pass
    @classmethod
    def removeFirst(_SELF):
        pass
    @classmethod
    def removeLast(_SELF):
        pass
    @classmethod
    def pollFirst(_SELF):
        pass
    @classmethod
    def pollLast(_SELF):
        pass
    @classmethod
    def getFirst(_SELF):
        pass
    @classmethod
    def getLast(_SELF):
        pass
    @classmethod
    def peekFirst(_SELF):
        pass
    @classmethod
    def peekLast(_SELF):
        pass
    @classmethod
    def removeFirstOccurrence(_SELF, o):
        pass
    @classmethod
    def removeLastOccurrence(_SELF, o):
        pass
    @classmethod
    def add(_SELF, e):
        pass
    @classmethod
    def offer(_SELF, e):
        pass
    @classmethod
    def Oed_remove__(_SELF):
        pass
    @classmethod
    def poll(_SELF):
        pass
    @classmethod
    def element(_SELF):
        pass
    @classmethod
    def peek(_SELF):
        pass
    @classmethod
    def push(_SELF, e):
        pass
    @classmethod
    def pop(_SELF):
        pass
    @classmethod
    def Oed_remove__Object(_SELF, o):
        pass
    @classmethod
    def contains(_SELF, o):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def descendingIterator(_SELF):
        pass
