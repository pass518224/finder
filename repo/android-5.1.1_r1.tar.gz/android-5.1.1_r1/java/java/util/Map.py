class Map(object):
    class Entry(object):
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def getKey(_SELF):
            pass
        @classmethod
        def getValue(_SELF):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def setValue(_SELF, object):
            pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def containsKey(_SELF, key):
        pass
    @classmethod
    def containsValue(_SELF, value):
        pass
    @classmethod
    def entrySet(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def keySet(_SELF):
        pass
    @classmethod
    def put(_SELF, key, value):
        pass
    @classmethod
    def putAll(_SELF, map):
        pass
    @classmethod
    def remove(_SELF, key):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def values(_SELF):
        pass
