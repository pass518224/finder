class ResourceBundle(object):
    UNDER_SCORE = "_"
    EMPTY_STRING = ""
    parent = None
    locale = None
    lastLoadTime = 0
    MISSING = None
    MISSINGBASE = None
    cache = None
    cacheLocale = None
    class Control(object):
        listDefault = None
        listClass = None
        listProperties = None
        JAVACLASS = "java.class"
        JAVAPROPERTIES = "java.properties"
        FORMAT_DEFAULT = None
        FORMAT_CLASS = None
        FORMAT_PROPERTIES = None
        TTL_DONT_CACHE = 1L
        TTL_NO_EXPIRATION_CONTROL = 2L
        FORMAT_PROPERTIES_CONTROL = None
        FORMAT_CLASS_CONTROL = None
        FORMAT_DEFAULT_CONTROL = None
        format = None
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def getControl(_SELF, formats):
            pass
        @classmethod
        def getNoFallbackControl(_SELF, formats):
            pass
        @classmethod
        def getCandidateLocales(_SELF, baseName, locale):
            pass
        @classmethod
        def getFormats(_SELF, baseName):
            pass
        @classmethod
        def getFallbackLocale(_SELF, baseName, locale):
            pass
        @classmethod
        def newBundle(_SELF, baseName, locale, format, loader, reload):
            pass
        @classmethod
        def getTimeToLive(_SELF, baseName, locale):
            pass
        @classmethod
        def needsReload(_SELF, baseName, locale, format, loader, bundle, loadTime):
            pass
        @classmethod
        def toBundleName(_SELF, baseName, locale):
            pass
        @classmethod
        def toResourceName(_SELF, bundleName, suffix):
            pass
    
    @classmethod
    def getBundle(self, *args):
        fname = "Oed_getBundle__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def clearCache(self, *args):
        fname = "Oed_clearCache__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def Oed_getBundle__str(_SELF, bundleName):
        pass
    @classmethod
    def Oed_getBundle__str__Locale(_SELF, bundleName, locale):
        pass
    @classmethod
    def Oed_getBundle__str__Locale__ClassLoader(_SELF, bundleName, locale, loader):
        pass
    @classmethod
    def missingResourceException(_SELF, className, key):
        pass
    @classmethod
    def Oed_getBundle__str__Control(_SELF, baseName, control):
        pass
    @classmethod
    def Oed_getBundle__str__Locale__Control(_SELF, baseName, targetLocale, control):
        pass
    @classmethod
    def getLoader(_SELF):
        pass
    @classmethod
    def Oed_getBundle__str__Locale__ClassLoader__Control(_SELF, baseName, targetLocale, loader, control):
        pass
    @classmethod
    def processGetBundle(_SELF, baseName, targetLocale, loader, control, expired, result):
        pass
    @classmethod
    def getKeys(_SELF):
        pass
    @classmethod
    def getLocale(_SELF):
        pass
    @classmethod
    def getObject(_SELF, key):
        pass
    @classmethod
    def getString(_SELF, key):
        pass
    @classmethod
    def getStringArray(_SELF, key):
        pass
    @classmethod
    def handleGetBundle(_SELF, loadBase, base, locale, loader):
        pass
    @classmethod
    def getLoaderCache(_SELF, cacheKey):
        pass
    @classmethod
    def handleGetObject(_SELF, key):
        pass
    @classmethod
    def setParent(_SELF, bundle):
        pass
    @classmethod
    def strip(_SELF, locale):
        pass
    @classmethod
    def setLocale(_SELF, locale):
        pass
    @classmethod
    def Oed_clearCache__(_SELF):
        pass
    @classmethod
    def Oed_clearCache__ClassLoader(_SELF, loader):
        pass
    @classmethod
    def containsKey(_SELF, key):
        pass
    @classmethod
    def keySet(_SELF):
        pass
    @classmethod
    def handleKeySet(_SELF):
        pass
class SimpleControl(object):
    @classmethod
    def __init__(_SELF, format):
        pass
ResourceBundle.SimpleControl = SimpleControl
class NoFallbackControl(object):
    NOFALLBACK_FORMAT_PROPERTIES_CONTROL = None
    NOFALLBACK_FORMAT_CLASS_CONTROL = None
    NOFALLBACK_FORMAT_DEFAULT_CONTROL = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____str(_SELF, format):
        pass
    @classmethod
    def Oed___init____List(_SELF, list):
        pass
    @classmethod
    def getFallbackLocale(_SELF, baseName, locale):
        pass
ResourceBundle.NoFallbackControl = NoFallbackControl
class MissingBundle(object):
    @classmethod
    def getKeys(_SELF):
        pass
    @classmethod
    def handleGetObject(_SELF, name):
        pass
ResourceBundle.MissingBundle = MissingBundle
