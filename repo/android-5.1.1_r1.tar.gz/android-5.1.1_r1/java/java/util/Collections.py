class Collections(object):
    class ANONY_ipduyunobjruovbb(object):
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    EMPTY_ITERATOR = None
    class ANONY_ychlhtoeklwextce(object):
        @classmethod
        def hasMoreElements(_SELF):
            pass
        @classmethod
        def nextElement(_SELF):
            pass
    EMPTY_ENUMERATION = None
    class CopiesList(object):
        serialVersionUID = 2739099268398711800L
        n = None
        element = None
        @classmethod
        def __init__(_SELF, length, object):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def get(_SELF, location):
            pass
    class EmptyList(object):
        serialVersionUID = 8842843931221139166L
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def get(_SELF, location):
            pass
        @classmethod
        def readResolve(_SELF):
            pass
    class EmptySet(object):
        serialVersionUID = 1582296315990362920L
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def readResolve(_SELF):
            pass
    class EmptyMap(object):
        serialVersionUID = 6428348081105594320L
        @classmethod
        def containsKey(_SELF, key):
            pass
        @classmethod
        def containsValue(_SELF, value):
            pass
        @classmethod
        def entrySet(_SELF):
            pass
        @classmethod
        def get(_SELF, key):
            pass
        @classmethod
        def keySet(_SELF):
            pass
        @classmethod
        def values(_SELF):
            pass
        @classmethod
        def readResolve(_SELF):
            pass
    EMPTY_LIST = None
    EMPTY_SET = None
    EMPTY_MAP = None
    class ReverseComparator(object):
        INSTANCE = None
        serialVersionUID = 7207038068494060240L
        @classmethod
        def compare(_SELF, o1, o2):
            pass
        @classmethod
        def readResolve(_SELF):
            pass
    class ReverseComparator2(object):
        serialVersionUID = 4374092139857L
        cmp = None
        @classmethod
        def __init__(_SELF, comparator):
            pass
        @classmethod
        def compare(_SELF, o1, o2):
            pass
        @classmethod
        def equals(_SELF, o):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
    class SingletonSet(object):
        serialVersionUID = 3193687207550431679L
        element = None
        @classmethod
        def __init__(_SELF, object):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def iterator(_SELF):
            pass
    class SingletonList(object):
        serialVersionUID = 3093736618740652951L
        element = None
        @classmethod
        def __init__(_SELF, object):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def get(_SELF, location):
            pass
        @classmethod
        def size(_SELF):
            pass
    class SingletonMap(object):
        serialVersionUID = 6979724477215052911L
        k = None
        v = None
        @classmethod
        def __init__(_SELF, key, value):
            pass
        @classmethod
        def containsKey(_SELF, key):
            pass
        @classmethod
        def containsValue(_SELF, value):
            pass
        @classmethod
        def get(_SELF, key):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def entrySet(_SELF):
            pass
    class SynchronizedCollection(object):
        serialVersionUID = 3053995032091335093L
        c = None
        mutex = None
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        
        @classmethod
        def __init__(self, *args):
            fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def Oed___init____Collection(_SELF, collection):
            pass
        @classmethod
        def Oed___init____Collection__Object(_SELF, collection, mutex):
            pass
        @classmethod
        def add(_SELF, object):
            pass
        @classmethod
        def addAll(_SELF, collection):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def containsAll(_SELF, collection):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def remove(_SELF, object):
            pass
        @classmethod
        def removeAll(_SELF, collection):
            pass
        @classmethod
        def retainAll(_SELF, collection):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, array):
            pass
        @classmethod
        def writeObject(_SELF, stream):
            pass
    class SynchronizedMap(object):
        serialVersionUID = 1978198479659022715L
        m = None
        mutex = None
        
        @classmethod
        def __init__(self, *args):
            fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def Oed___init____Map(_SELF, map):
            pass
        @classmethod
        def Oed___init____Map__Object(_SELF, map, mutex):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def containsKey(_SELF, key):
            pass
        @classmethod
        def containsValue(_SELF, value):
            pass
        @classmethod
        def entrySet(_SELF):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def get(_SELF, key):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def keySet(_SELF):
            pass
        @classmethod
        def put(_SELF, key, value):
            pass
        @classmethod
        def putAll(_SELF, map):
            pass
        @classmethod
        def remove(_SELF, key):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def values(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def writeObject(_SELF, stream):
            pass
    class UnmodifiableCollection(object):
        serialVersionUID = 1820017752578914078L
        c = None
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def __init__(_SELF, collection):
            pass
        @classmethod
        def add(_SELF, object):
            pass
        @classmethod
        def addAll(_SELF, collection):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def containsAll(_SELF, collection):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def remove(_SELF, object):
            pass
        @classmethod
        def removeAll(_SELF, collection):
            pass
        @classmethod
        def retainAll(_SELF, collection):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, array):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    class UnmodifiableMap(object):
        serialVersionUID = 1034234728574286014L
        m = None
        @classmethod
        def __init__(_SELF, map):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def containsKey(_SELF, key):
            pass
        @classmethod
        def containsValue(_SELF, value):
            pass
        @classmethod
        def entrySet(_SELF):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def get(_SELF, key):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def keySet(_SELF):
            pass
        @classmethod
        def put(_SELF, key, value):
            pass
        @classmethod
        def putAll(_SELF, map):
            pass
        @classmethod
        def remove(_SELF, key):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def values(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    class SetFromMap(object):
        serialVersionUID = 2454657854757543876L
        m = None
        backingSet = None
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def __init__(_SELF, map):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def add(_SELF, object):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def containsAll(_SELF, collection):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def remove(_SELF, object):
            pass
        @classmethod
        def retainAll(_SELF, collection):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, contents):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def readObject(_SELF, stream):
            pass
    class AsLIFOQueue(object):
        serialVersionUID = 1802017725587941708L
        q = None
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        
        @classmethod
        def remove(self, *args):
            fname = "Oed_remove__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def __init__(_SELF, deque):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def offer(_SELF, o):
            pass
        @classmethod
        def peek(_SELF):
            pass
        @classmethod
        def poll(_SELF):
            pass
        @classmethod
        def add(_SELF, o):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def element(_SELF):
            pass
        @classmethod
        def Oed_remove__(_SELF):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def containsAll(_SELF, collection):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def Oed_remove__Object(_SELF, object):
            pass
        @classmethod
        def removeAll(_SELF, collection):
            pass
        @classmethod
        def retainAll(_SELF, collection):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, contents):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    class CheckedCollection(object):
        serialVersionUID = 1578914078182001775L
        c = None
        type = None
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def __init__(_SELF, c, type):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def contains(_SELF, obj):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, arr):
            pass
        @classmethod
        def add(_SELF, obj):
            pass
        @classmethod
        def remove(_SELF, obj):
            pass
        @classmethod
        def containsAll(_SELF, c1):
            pass
        @classmethod
        def addAll(_SELF, c1):
            pass
        @classmethod
        def removeAll(_SELF, c1):
            pass
        @classmethod
        def retainAll(_SELF, c1):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    class CheckedListIterator(object):
        i = None
        type = None
        @classmethod
        def __init__(_SELF, i, type):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
        @classmethod
        def hasPrevious(_SELF):
            pass
        @classmethod
        def previous(_SELF):
            pass
        @classmethod
        def nextIndex(_SELF):
            pass
        @classmethod
        def previousIndex(_SELF):
            pass
        @classmethod
        def set(_SELF, obj):
            pass
        @classmethod
        def add(_SELF, obj):
            pass
    class CheckedMap(object):
        serialVersionUID = 5742860141034234728L
        m = None
        keyType = None
        valueType = None
        class CheckedEntry(object):
            e = None
            valueType = None
            @classmethod
            def __init__(_SELF, e, valueType):
                pass
            @classmethod
            def getKey(_SELF):
                pass
            @classmethod
            def getValue(_SELF):
                pass
            @classmethod
            def setValue(_SELF, obj):
                pass
            @classmethod
            def equals(_SELF, obj):
                pass
            @classmethod
            def hashCode(_SELF):
                pass
        class CheckedEntrySet(object):
            s = None
            valueType = None
            class CheckedEntryIterator(object):
                i = None
                valueType = None
                @classmethod
                def __init__(_SELF, i, valueType):
                    pass
                @classmethod
                def hasNext(_SELF):
                    pass
                @classmethod
                def remove(_SELF):
                    pass
                @classmethod
                def next(_SELF):
                    pass
            
            @classmethod
            def toArray(self, *args):
                fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
                func = getattr(self, fname)
                return func(*args)
            @classmethod
            def __init__(_SELF, s, valueType):
                pass
            @classmethod
            def iterator(_SELF):
                pass
            @classmethod
            def Oed_toArray__(_SELF):
                pass
            @classmethod
            def Oed_toArray__list(_SELF, array):
                pass
            @classmethod
            def retainAll(_SELF, c):
                pass
            @classmethod
            def removeAll(_SELF, c):
                pass
            @classmethod
            def containsAll(_SELF, c):
                pass
            @classmethod
            def addAll(_SELF, c):
                pass
            @classmethod
            def remove(_SELF, o):
                pass
            @classmethod
            def contains(_SELF, o):
                pass
            @classmethod
            def add(_SELF, o):
                pass
            @classmethod
            def isEmpty(_SELF):
                pass
            @classmethod
            def clear(_SELF):
                pass
            @classmethod
            def size(_SELF):
                pass
            @classmethod
            def hashCode(_SELF):
                pass
            @classmethod
            def equals(_SELF, object):
                pass
        @classmethod
        def __init__(_SELF, m, keyType, valueType):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def containsKey(_SELF, key):
            pass
        @classmethod
        def containsValue(_SELF, value):
            pass
        @classmethod
        def get(_SELF, key):
            pass
        @classmethod
        def put(_SELF, key, value):
            pass
        @classmethod
        def remove(_SELF, key):
            pass
        @classmethod
        def putAll(_SELF, map):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def keySet(_SELF):
            pass
        @classmethod
        def values(_SELF):
            pass
        @classmethod
        def entrySet(_SELF):
            pass
        @classmethod
        def equals(_SELF, obj):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    
    @classmethod
    def sort(self, *args):
        fname = "Oed_sort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def shuffle(self, *args):
        fname = "Oed_shuffle__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def min(self, *args):
        fname = "Oed_min__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def max(self, *args):
        fname = "Oed_max__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def binarySearch(self, *args):
        fname = "Oed_binarySearch__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def reverseOrder(self, *args):
        fname = "Oed_reverseOrder__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def secondaryHash(self, *args):
        fname = "Oed_secondaryHash__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def Oed_binarySearch__List__T(_SELF, list, object):
        pass
    @classmethod
    def Oed_binarySearch__List__T__Comparator(_SELF, list, object, comparator):
        pass
    @classmethod
    def copy(_SELF, destination, source):
        pass
    @classmethod
    def enumeration(_SELF, collection):
        pass
    @classmethod
    def fill(_SELF, list, object):
        pass
    @classmethod
    def Oed_max__Collection(_SELF, collection):
        pass
    @classmethod
    def Oed_max__Collection__Comparator(_SELF, collection, comparator):
        pass
    @classmethod
    def Oed_min__Collection(_SELF, collection):
        pass
    @classmethod
    def Oed_min__Collection__Comparator(_SELF, collection, comparator):
        pass
    @classmethod
    def nCopies(_SELF, length, object):
        pass
    @classmethod
    def reverse(_SELF, list):
        pass
    @classmethod
    def Oed_reverseOrder__(_SELF):
        pass
    @classmethod
    def Oed_reverseOrder__Comparator(_SELF, c):
        pass
    @classmethod
    def Oed_shuffle__List(_SELF, list):
        pass
    @classmethod
    def Oed_shuffle__List__Random(_SELF, list, random):
        pass
    @classmethod
    def singleton(_SELF, object):
        pass
    @classmethod
    def singletonList(_SELF, object):
        pass
    @classmethod
    def singletonMap(_SELF, key, value):
        pass
    @classmethod
    def Oed_sort__List(_SELF, list):
        pass
    @classmethod
    def Oed_sort__List__Comparator(_SELF, list, comparator):
        pass
    @classmethod
    def swap(_SELF, list, index1, index2):
        pass
    @classmethod
    def replaceAll(_SELF, list, obj, obj2):
        pass
    @classmethod
    def rotate(_SELF, lst, dist):
        pass
    @classmethod
    def indexOfSubList(_SELF, list, sublist):
        pass
    @classmethod
    def lastIndexOfSubList(_SELF, list, sublist):
        pass
    @classmethod
    def list(_SELF, enumeration):
        pass
    @classmethod
    def synchronizedCollection(_SELF, collection):
        pass
    @classmethod
    def synchronizedList(_SELF, list):
        pass
    @classmethod
    def synchronizedMap(_SELF, map):
        pass
    @classmethod
    def synchronizedSet(_SELF, set):
        pass
    @classmethod
    def synchronizedSortedMap(_SELF, map):
        pass
    @classmethod
    def synchronizedSortedSet(_SELF, set):
        pass
    @classmethod
    def unmodifiableCollection(_SELF, collection):
        pass
    @classmethod
    def unmodifiableList(_SELF, list):
        pass
    @classmethod
    def unmodifiableMap(_SELF, map):
        pass
    @classmethod
    def unmodifiableSet(_SELF, set):
        pass
    @classmethod
    def unmodifiableSortedMap(_SELF, map):
        pass
    @classmethod
    def unmodifiableSortedSet(_SELF, set):
        pass
    @classmethod
    def frequency(_SELF, c, o):
        pass
    @classmethod
    def emptyList(_SELF):
        pass
    @classmethod
    def emptySet(_SELF):
        pass
    @classmethod
    def emptyMap(_SELF):
        pass
    @classmethod
    def emptyEnumeration(_SELF):
        pass
    @classmethod
    def emptyIterator(_SELF):
        pass
    @classmethod
    def emptyListIterator(_SELF):
        pass
    @classmethod
    def checkedCollection(_SELF, c, type):
        pass
    @classmethod
    def checkedMap(_SELF, m, keyType, valueType):
        pass
    @classmethod
    def checkedList(_SELF, list, type):
        pass
    @classmethod
    def checkedSet(_SELF, s, type):
        pass
    @classmethod
    def checkedSortedMap(_SELF, m, keyType, valueType):
        pass
    @classmethod
    def checkedSortedSet(_SELF, s, type):
        pass
    @classmethod
    def addAll(_SELF, c, a):
        pass
    @classmethod
    def disjoint(_SELF, c1, c2):
        pass
    @classmethod
    def checkType(_SELF, obj, type):
        pass
    @classmethod
    def newSetFromMap(_SELF, map):
        pass
    @classmethod
    def asLifoQueue(_SELF, deque):
        pass
    @classmethod
    def Oed_secondaryHash__Object(_SELF, key):
        pass
    @classmethod
    def secondaryIdentityHash(_SELF, key):
        pass
    @classmethod
    def Oed_secondaryHash__int(_SELF, h):
        pass
    @classmethod
    def roundUpToPowerOfTwo(_SELF, i):
        pass
class UnmodifiableList(object):
    serialVersionUID = 283967356065247728L
    list = None
    
    @classmethod
    def listIterator(self, *args):
        fname = "Oed_listIterator__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, l):
        pass
    @classmethod
    def add(_SELF, location, object):
        pass
    @classmethod
    def addAll(_SELF, location, collection):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def get(_SELF, location):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def indexOf(_SELF, object):
        pass
    @classmethod
    def lastIndexOf(_SELF, object):
        pass
    @classmethod
    def Oed_listIterator__(_SELF):
        pass
    @classmethod
    def Oed_listIterator__int(_SELF, location):
        pass
    @classmethod
    def remove(_SELF, location):
        pass
    @classmethod
    def set(_SELF, location, object):
        pass
    @classmethod
    def subList(_SELF, start, end):
        pass
    @classmethod
    def readResolve(_SELF):
        pass
Collections.UnmodifiableList = UnmodifiableList
class SynchronizedList(object):
    serialVersionUID = 7754090372962971524L
    list = None
    
    @classmethod
    def listIterator(self, *args):
        fname = "Oed_listIterator__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____List(_SELF, l):
        pass
    @classmethod
    def Oed___init____List__Object(_SELF, l, mutex):
        pass
    @classmethod
    def add(_SELF, location, object):
        pass
    @classmethod
    def addAll(_SELF, location, collection):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def get(_SELF, location):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def indexOf(_SELF, object):
        pass
    @classmethod
    def lastIndexOf(_SELF, object):
        pass
    @classmethod
    def Oed_listIterator__(_SELF):
        pass
    @classmethod
    def Oed_listIterator__int(_SELF, location):
        pass
    @classmethod
    def remove(_SELF, location):
        pass
    @classmethod
    def set(_SELF, location, object):
        pass
    @classmethod
    def subList(_SELF, start, end):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readResolve(_SELF):
        pass
Collections.SynchronizedList = SynchronizedList
class SynchronizedRandomAccessList(object):
    serialVersionUID = 1530674583602358482L
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____List(_SELF, l):
        pass
    @classmethod
    def Oed___init____List__Object(_SELF, l, mutex):
        pass
    @classmethod
    def subList(_SELF, start, end):
        pass
    @classmethod
    def writeReplace(_SELF):
        pass
Collections.SynchronizedRandomAccessList = SynchronizedRandomAccessList
class CheckedList(object):
    serialVersionUID = 65247728283967356L
    l = None
    
    @classmethod
    def listIterator(self, *args):
        fname = "Oed_listIterator__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, l, type):
        pass
    @classmethod
    def addAll(_SELF, index, c1):
        pass
    @classmethod
    def get(_SELF, index):
        pass
    @classmethod
    def set(_SELF, index, obj):
        pass
    @classmethod
    def add(_SELF, index, obj):
        pass
    @classmethod
    def remove(_SELF, index):
        pass
    @classmethod
    def indexOf(_SELF, obj):
        pass
    @classmethod
    def lastIndexOf(_SELF, obj):
        pass
    @classmethod
    def Oed_listIterator__(_SELF):
        pass
    @classmethod
    def Oed_listIterator__int(_SELF, index):
        pass
    @classmethod
    def subList(_SELF, fromIndex, toIndex):
        pass
    @classmethod
    def equals(_SELF, obj):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
Collections.CheckedList = CheckedList
class CheckedRandomAccessList(object):
    serialVersionUID = 1638200125423088369L
    @classmethod
    def __init__(_SELF, l, type):
        pass
Collections.CheckedRandomAccessList = CheckedRandomAccessList
class UnmodifiableRandomAccessList(object):
    serialVersionUID = 2542308836966382001L
    @classmethod
    def __init__(_SELF, l):
        pass
    @classmethod
    def subList(_SELF, start, end):
        pass
    @classmethod
    def writeReplace(_SELF):
        pass
Collections.UnmodifiableRandomAccessList = UnmodifiableRandomAccessList
class CheckedSortedMap(object):
    serialVersionUID = 1599671320688067438L
    sm = None
    @classmethod
    def __init__(_SELF, m, keyType, valueType):
        pass
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def subMap(_SELF, fromKey, toKey):
        pass
    @classmethod
    def headMap(_SELF, toKey):
        pass
    @classmethod
    def tailMap(_SELF, fromKey):
        pass
    @classmethod
    def firstKey(_SELF):
        pass
    @classmethod
    def lastKey(_SELF):
        pass
Collections.CheckedSortedMap = CheckedSortedMap
class UnmodifiableSet(object):
    serialVersionUID = 9215047833775013803L
    @classmethod
    def __init__(_SELF, set):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
Collections.UnmodifiableSet = UnmodifiableSet
class UnmodifiableSortedSet(object):
    serialVersionUID = 4929149591599911165L
    ss = None
    @classmethod
    def __init__(_SELF, set):
        pass
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def first(_SELF):
        pass
    @classmethod
    def headSet(_SELF, before):
        pass
    @classmethod
    def last(_SELF):
        pass
    @classmethod
    def subSet(_SELF, start, end):
        pass
    @classmethod
    def tailSet(_SELF, after):
        pass
Collections.UnmodifiableSortedSet = UnmodifiableSortedSet
class SynchronizedSet(object):
    serialVersionUID = 487447009682186044L
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____Set(_SELF, set):
        pass
    @classmethod
    def Oed___init____Set__Object(_SELF, set, mutex):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
Collections.SynchronizedSet = SynchronizedSet
class SynchronizedSortedMap(object):
    serialVersionUID = 8798146769416483793L
    sm = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____SortedMap(_SELF, map):
        pass
    @classmethod
    def Oed___init____SortedMap__Object(_SELF, map, mutex):
        pass
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def firstKey(_SELF):
        pass
    @classmethod
    def headMap(_SELF, endKey):
        pass
    @classmethod
    def lastKey(_SELF):
        pass
    @classmethod
    def subMap(_SELF, startKey, endKey):
        pass
    @classmethod
    def tailMap(_SELF, startKey):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
Collections.SynchronizedSortedMap = SynchronizedSortedMap
class SynchronizedSortedSet(object):
    serialVersionUID = 8695801310862127406L
    ss = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____SortedSet(_SELF, set):
        pass
    @classmethod
    def Oed___init____SortedSet__Object(_SELF, set, mutex):
        pass
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def first(_SELF):
        pass
    @classmethod
    def headSet(_SELF, end):
        pass
    @classmethod
    def last(_SELF):
        pass
    @classmethod
    def subSet(_SELF, start, end):
        pass
    @classmethod
    def tailSet(_SELF, start):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
Collections.SynchronizedSortedSet = SynchronizedSortedSet
class UnmodifiableSortedMap(object):
    serialVersionUID = 8806743815996713206L
    sm = None
    @classmethod
    def __init__(_SELF, map):
        pass
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def firstKey(_SELF):
        pass
    @classmethod
    def headMap(_SELF, before):
        pass
    @classmethod
    def lastKey(_SELF):
        pass
    @classmethod
    def subMap(_SELF, start, end):
        pass
    @classmethod
    def tailMap(_SELF, after):
        pass
Collections.UnmodifiableSortedMap = UnmodifiableSortedMap
class UnmodifiableEntrySet(object):
    serialVersionUID = 7854390611657943733L
    class UnmodifiableMapEntry(object):
        mapEntry = None
        @classmethod
        def __init__(_SELF, entry):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def getKey(_SELF):
            pass
        @classmethod
        def getValue(_SELF):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def setValue(_SELF, object):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    
    @classmethod
    def toArray(self, *args):
        fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, set):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def Oed_toArray__(_SELF):
        pass
    @classmethod
    def Oed_toArray__list(_SELF, contents):
        pass
Collections.UnmodifiableMap.UnmodifiableEntrySet = UnmodifiableEntrySet
class CheckedSet(object):
    serialVersionUID = 4694047833775013803L
    @classmethod
    def __init__(_SELF, s, type):
        pass
    @classmethod
    def equals(_SELF, obj):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
Collections.CheckedSet = CheckedSet
class CheckedSortedSet(object):
    serialVersionUID = 1599911165492914959L
    ss = None
    @classmethod
    def __init__(_SELF, s, type):
        pass
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def subSet(_SELF, fromElement, toElement):
        pass
    @classmethod
    def headSet(_SELF, toElement):
        pass
    @classmethod
    def tailSet(_SELF, fromElement):
        pass
    @classmethod
    def first(_SELF):
        pass
    @classmethod
    def last(_SELF):
        pass
Collections.CheckedSortedSet = CheckedSortedSet
