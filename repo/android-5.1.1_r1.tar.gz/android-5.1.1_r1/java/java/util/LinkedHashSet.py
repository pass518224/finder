class LinkedHashSet(object):
    serialVersionUID = 2851667679971038690L
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, capacity):
        pass
    @classmethod
    def Oed___init____int__float(_SELF, capacity, loadFactor):
        pass
    @classmethod
    def Oed___init____Collection(_SELF, collection):
        pass
    @classmethod
    def createBackingMap(_SELF, capacity, loadFactor):
        pass
