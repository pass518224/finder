class IllegalFormatConversionException(object):
    serialVersionUID = 17000126L
    c = None
    arg = None
    @classmethod
    def __init__(_SELF, c, arg):
        pass
    @classmethod
    def getArgumentClass(_SELF):
        pass
    @classmethod
    def getConversion(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
