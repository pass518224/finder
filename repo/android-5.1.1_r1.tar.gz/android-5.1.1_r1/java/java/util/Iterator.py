class Iterator(object):
    @classmethod
    def hasNext(_SELF):
        pass
    @classmethod
    def next(_SELF):
        pass
    @classmethod
    def remove(_SELF):
        pass
