class FormattableFlags(object):
    LEFT_JUSTIFY = 1
    UPPERCASE = 2
    ALTERNATE = 4
    @classmethod
    def __init__(_SELF):
        pass
