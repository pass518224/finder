class Properties(object):
    serialVersionUID = 4112578634029874840L
    builder = None
    PROP_DTD_NAME = "http://java.sun.com/dtd/properties.dtd"
    PROP_DTD = None
    defaults = None
    NONE = 0
    SLASH = 1
    UNICODE = 2
    CONTINUE = 3
    KEY_DONE = 4
    IGNORE = 5
    
    @classmethod
    def load(self, *args):
        fname = "Oed_load__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getProperty(self, *args):
        fname = "Oed_getProperty__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def storeToXML(self, *args):
        fname = "Oed_storeToXML__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def list(self, *args):
        fname = "Oed_list__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def store(self, *args):
        fname = "Oed_store__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____Properties(_SELF, properties):
        pass
    @classmethod
    def dumpString(_SELF, buffer, string, key):
        pass
    @classmethod
    def Oed_getProperty__str(_SELF, name):
        pass
    @classmethod
    def Oed_getProperty__str__str(_SELF, name, defaultValue):
        pass
    @classmethod
    def Oed_list__PrintStream(_SELF, out):
        pass
    @classmethod
    def Oed_list__PrintWriter(_SELF, out):
        pass
    @classmethod
    def listToAppendable(_SELF, out):
        pass
    @classmethod
    def Oed_load__InputStream(_SELF, _in):
        pass
    @classmethod
    def Oed_load__Reader(_SELF, _in):
        pass
    @classmethod
    def propertyNames(_SELF):
        pass
    @classmethod
    def stringPropertyNames(_SELF):
        pass
    @classmethod
    def selectProperties(_SELF, selectProperties, isStringOnly):
        pass
    @classmethod
    def save(_SELF, out, comment):
        pass
    @classmethod
    def setProperty(_SELF, name, value):
        pass
    @classmethod
    def Oed_store__OutputStream__str(_SELF, out, comment):
        pass
    @classmethod
    def Oed_store__Writer__str(_SELF, writer, comment):
        pass
    @classmethod
    def loadFromXML(_SELF, _in):
        pass
    @classmethod
    def Oed_storeToXML__OutputStream__str(_SELF, os, comment):
        pass
    @classmethod
    def Oed_storeToXML__OutputStream__str__str(_SELF, os, comment, encoding):
        pass
    @classmethod
    def substitutePredefinedEntries(_SELF, s):
        pass
