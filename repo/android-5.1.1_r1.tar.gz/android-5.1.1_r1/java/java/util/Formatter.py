class Formatter(object):
    ZEROS = None
    class BigDecimalLayoutForm:
        SCIENTIFIC = "SCIENTIFIC"
        DECIMAL_FLOAT = "DECIMAL_FLOAT"
    out = None
    locale = None
    arg = None
    closed = False
    formatToken = None
    lastIOException = None
    localeData = None
    class CachedDecimalFormat(object):
        decimalFormat = None
        currentLocaleData = None
        currentPattern = None
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def update(_SELF, localeData, pattern):
            pass
    class ANONY_cmtauvxmlymgymwq(object):
        @classmethod
        def initialValue(_SELF):
            pass
    cachedDecimalFormat = None
    class FormatToken(object):
        LAST_ARGUMENT_INDEX = 2
        UNSET = 1
        FLAGS_UNSET = 0
        DEFAULT_PRECISION = 6
        FLAG_ZERO = None
        argIndex = None
        flagComma = None
        flagMinus = None
        flagParenthesis = None
        flagPlus = None
        flagSharp = None
        flagSpace = None
        flagZero = None
        conversionType = None
        dateSuffix = None
        precision = None
        width = None
        strFlags = None
        @classmethod
        def isDefault(_SELF):
            pass
        @classmethod
        def isPrecisionSet(_SELF):
            pass
        @classmethod
        def getArgIndex(_SELF):
            pass
        @classmethod
        def setArgIndex(_SELF, index):
            pass
        @classmethod
        def getWidth(_SELF):
            pass
        @classmethod
        def setWidth(_SELF, width):
            pass
        @classmethod
        def getPrecision(_SELF):
            pass
        @classmethod
        def setPrecision(_SELF, precise):
            pass
        @classmethod
        def getStrFlags(_SELF):
            pass
        @classmethod
        def setFlag(_SELF, ch):
            pass
        @classmethod
        def getConversionType(_SELF):
            pass
        @classmethod
        def setConversionType(_SELF, c):
            pass
        @classmethod
        def getDateSuffix(_SELF):
            pass
        @classmethod
        def setDateSuffix(_SELF, c):
            pass
        @classmethod
        def requireArgument(_SELF):
            pass
        @classmethod
        def checkFlags(_SELF, arg):
            pass
        @classmethod
        def unknownFormatConversionException(_SELF):
            pass
    class FormatSpecifierParser(object):
        format = None
        length = None
        startIndex = None
        i = None
        @classmethod
        def __init__(_SELF, format):
            pass
        @classmethod
        def parseFormatToken(_SELF, offset):
            pass
        @classmethod
        def getFormatSpecifierText(_SELF):
            pass
        @classmethod
        def peek(_SELF):
            pass
        @classmethod
        def advance(_SELF):
            pass
        @classmethod
        def unknownFormatConversionException(_SELF):
            pass
        @classmethod
        def parseArgumentIndexAndFlags(_SELF, token):
            pass
        @classmethod
        def parseWidth(_SELF, token, width):
            pass
        @classmethod
        def parsePrecision(_SELF, token):
            pass
        @classmethod
        def parseConversionType(_SELF, token):
            pass
        @classmethod
        def nextInt(_SELF):
            pass
        @classmethod
        def failNextInt(_SELF):
            pass
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def format(self, *args):
        fname = "Oed_format__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def getDecimalFormat(_SELF, pattern):
        pass
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____Appendable(_SELF, a):
        pass
    @classmethod
    def Oed___init____Locale(_SELF, l):
        pass
    @classmethod
    def Oed___init____Appendable__Locale(_SELF, a, l):
        pass
    @classmethod
    def Oed___init____str(_SELF, fileName):
        pass
    @classmethod
    def Oed___init____str__str(_SELF, fileName, csn):
        pass
    @classmethod
    def Oed___init____str__str__Locale(_SELF, fileName, csn, l):
        pass
    @classmethod
    def Oed___init____File(_SELF, file):
        pass
    @classmethod
    def Oed___init____File__str(_SELF, file, csn):
        pass
    @classmethod
    def Oed___init____File__str__Locale(_SELF, file, csn, l):
        pass
    @classmethod
    def Oed___init____OutputStream(_SELF, os):
        pass
    @classmethod
    def Oed___init____OutputStream__str(_SELF, os, csn):
        pass
    @classmethod
    def Oed___init____OutputStream__str__Locale(_SELF, os, csn, l):
        pass
    @classmethod
    def Oed___init____PrintStream(_SELF, ps):
        pass
    @classmethod
    def checkNotClosed(_SELF):
        pass
    @classmethod
    def locale(_SELF):
        pass
    @classmethod
    def out(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def flush(_SELF):
        pass
    @classmethod
    def close(_SELF):
        pass
    @classmethod
    def ioException(_SELF):
        pass
    @classmethod
    def Oed_format__str__Object(_SELF, format, args):
        pass
    @classmethod
    def Oed_format__Locale__str__Object(_SELF, l, format, args):
        pass
    @classmethod
    def doFormat(_SELF, format, args):
        pass
    @classmethod
    def outputCharSequence(_SELF, cs, start, end):
        pass
    @classmethod
    def getArgument(_SELF, args, index, fsp, lastArgument, hasLastArgumentSet):
        pass
    @classmethod
    def transform(_SELF, token, argument):
        pass
    @classmethod
    def badArgumentType(_SELF):
        pass
    @classmethod
    def localizeDigits(_SELF, s):
        pass
    @classmethod
    def insertGrouping(_SELF, s):
        pass
    @classmethod
    def transformFromBoolean(_SELF):
        pass
    @classmethod
    def transformFromHashCode(_SELF):
        pass
    @classmethod
    def transformFromString(_SELF):
        pass
    @classmethod
    def transformFromCharacter(_SELF):
        pass
    @classmethod
    def transformFromPercent(_SELF):
        pass
    @classmethod
    def padding(_SELF, source, startIndex):
        pass
    @classmethod
    def toStringBuilder(_SELF, cs):
        pass
    @classmethod
    def wrapParentheses(_SELF, result):
        pass
    @classmethod
    def transformFromInteger(_SELF):
        pass
    @classmethod
    def transformFromNull(_SELF):
        pass
    @classmethod
    def transformFromBigInteger(_SELF):
        pass
    @classmethod
    def transformFromDateTime(_SELF):
        pass
    @classmethod
    def appendT(_SELF, result, conversion, calendar):
        pass
    @classmethod
    def to12Hour(_SELF, hour):
        pass
    @classmethod
    def appendLocalized(_SELF, result, value, width):
        pass
    @classmethod
    def transformFromSpecialNumber(_SELF, d):
        pass
    @classmethod
    def transformFromFloat(_SELF):
        pass
    @classmethod
    def startsWithMinusSign(_SELF, cs, minusSign):
        pass
    @classmethod
    def transformE(_SELF, result):
        pass
    @classmethod
    def transformG(_SELF, result):
        pass
    @classmethod
    def transformF(_SELF, result):
        pass
    @classmethod
    def transformA(_SELF, result):
        pass
