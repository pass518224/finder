class IllegalFormatCodePointException(object):
    serialVersionUID = 19080630L
    c = None
    @classmethod
    def __init__(_SELF, c):
        pass
    @classmethod
    def getCodePoint(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
