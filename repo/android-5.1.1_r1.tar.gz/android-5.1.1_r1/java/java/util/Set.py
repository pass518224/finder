class Set(object):
    @classmethod
    def add(_SELF, object):
        pass
    @classmethod
    def addAll(_SELF, collection):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def contains(_SELF, object):
        pass
    @classmethod
    def containsAll(_SELF, collection):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def remove(_SELF, object):
        pass
    @classmethod
    def removeAll(_SELF, collection):
        pass
    @classmethod
    def retainAll(_SELF, collection):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def Oed_toArray__(_SELF):
        pass
    @classmethod
    def Oed_toArray__list(_SELF, array):
        pass
