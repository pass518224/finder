class SimpleTimeZone(object):
    serialVersionUID = 403250971215465050L
    rawOffset = None
    startYear = None
    startMonth = None
    startDay = None
    startDayOfWeek = None
    startTime = None
    endMonth = None
    endDay = None
    endDayOfWeek = None
    endTime = None
    startMode = None
    endMode = None
    DOM_MODE = 1
    DOW_IN_MONTH_MODE = 2
    DOW_GE_DOM_MODE = 3
    DOW_LE_DOM_MODE = 4
    UTC_TIME = 2
    STANDARD_TIME = 1
    WALL_TIME = 0
    useDaylight = None
    dstSavings = 3600000
    serialPersistentFields = None
    
    @classmethod
    def setStartRule(self, *args):
        fname = "Oed_setStartRule__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def setEndRule(self, *args):
        fname = "Oed_setEndRule__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getOffset(self, *args):
        fname = "Oed_getOffset__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____int__str(_SELF, offset, name):
        pass
    @classmethod
    def Oed___init____int__str__int__int__int__int__int__int__int__int(_SELF, offset, name, startMonth, startDay, startDayOfWeek, startTime, endMonth, endDay, endDayOfWeek, endTime):
        pass
    @classmethod
    def Oed___init____int__str__int__int__int__int__int__int__int__int__int(_SELF, offset, name, startMonth, startDay, startDayOfWeek, startTime, endMonth, endDay, endDayOfWeek, endTime, daylightSavings):
        pass
    @classmethod
    def Oed___init____int__str__int__int__int__int__int__int__int__int__int__int__int(_SELF, offset, name, startMonth, startDay, startDayOfWeek, startTime, startTimeMode, endMonth, endDay, endDayOfWeek, endTime, endTimeMode, daylightSavings):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def getDSTSavings(_SELF):
        pass
    @classmethod
    def Oed_getOffset__int__int__int__int__int__int(_SELF, era, year, month, day, dayOfWeek, time):
        pass
    @classmethod
    def Oed_getOffset__int(_SELF, time):
        pass
    @classmethod
    def getRawOffset(_SELF):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def hasSameRules(_SELF, zone):
        pass
    @classmethod
    def inDaylightTime(_SELF, time):
        pass
    @classmethod
    def isLeapYear(_SELF, year):
        pass
    @classmethod
    def mod7(_SELF, num1):
        pass
    @classmethod
    def setDSTSavings(_SELF, milliseconds):
        pass
    @classmethod
    def checkRange(_SELF, month, dayOfWeek, time):
        pass
    @classmethod
    def checkDay(_SELF, month, day):
        pass
    @classmethod
    def setEndMode(_SELF):
        pass
    @classmethod
    def Oed_setEndRule__int__int__int(_SELF, month, dayOfMonth, time):
        pass
    @classmethod
    def Oed_setEndRule__int__int__int__int(_SELF, month, day, dayOfWeek, time):
        pass
    @classmethod
    def Oed_setEndRule__int__int__int__int__bool(_SELF, month, day, dayOfWeek, time, after):
        pass
    @classmethod
    def setRawOffset(_SELF, offset):
        pass
    @classmethod
    def setStartMode(_SELF):
        pass
    @classmethod
    def Oed_setStartRule__int__int__int(_SELF, month, dayOfMonth, time):
        pass
    @classmethod
    def Oed_setStartRule__int__int__int__int(_SELF, month, day, dayOfWeek, time):
        pass
    @classmethod
    def Oed_setStartRule__int__int__int__int__bool(_SELF, month, day, dayOfWeek, time, after):
        pass
    @classmethod
    def setStartYear(_SELF, year):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def useDaylightTime(_SELF):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
