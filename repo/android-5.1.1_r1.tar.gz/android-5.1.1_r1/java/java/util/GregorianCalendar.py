class GregorianCalendar(object):
    serialVersionUID = 8125100834729963327L
    BC = 0
    AD = 1
    defaultGregorianCutover = 12219292800000l
    gregorianCutover = None
    changeYear = 1582
    julianSkew = None
    DaysInMonth = None
    DaysInYear = None
    maximums = None
    minimums = None
    leastMaximums = None
    currentYearSkew = 10
    lastYearSkew = 0
    
    @classmethod
    def daysInMonth(self, *args):
        fname = "Oed_daysInMonth__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def daysInYear(self, *args):
        fname = "Oed_daysInYear__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def roll(self, *args):
        fname = "Oed_roll__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int__int__int(_SELF, year, month, day):
        pass
    @classmethod
    def Oed___init____int__int__int__int__int(_SELF, year, month, day, hour, minute):
        pass
    @classmethod
    def Oed___init____int__int__int__int__int__int(_SELF, year, month, day, hour, minute, second):
        pass
    @classmethod
    def Oed___init____int(_SELF, milliseconds):
        pass
    @classmethod
    def Oed___init____Locale(_SELF, locale):
        pass
    @classmethod
    def Oed___init____TimeZone(_SELF, timezone):
        pass
    @classmethod
    def Oed___init____TimeZone__Locale(_SELF, timezone, locale):
        pass
    @classmethod
    def Oed___init____bool(_SELF, ignored):
        pass
    @classmethod
    def add(_SELF, field, value):
        pass
    @classmethod
    def fullFieldsCalc(_SELF):
        pass
    @classmethod
    def computeFields(_SELF):
        pass
    @classmethod
    def computeTime(_SELF):
        pass
    @classmethod
    def computeYearAndDay(_SELF, dayCount, localTime):
        pass
    @classmethod
    def daysFromBaseYear(_SELF, year):
        pass
    @classmethod
    def Oed_daysInMonth__(_SELF):
        pass
    @classmethod
    def Oed_daysInMonth__bool__int(_SELF, leapYear, month):
        pass
    @classmethod
    def Oed_daysInYear__int(_SELF, year):
        pass
    @classmethod
    def Oed_daysInYear__bool__int(_SELF, leapYear, month):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def getActualMaximum(_SELF, field):
        pass
    @classmethod
    def getActualMinimum(_SELF, field):
        pass
    @classmethod
    def getGreatestMinimum(_SELF, field):
        pass
    @classmethod
    def getGregorianChange(_SELF):
        pass
    @classmethod
    def getLeastMaximum(_SELF, field):
        pass
    @classmethod
    def getMaximum(_SELF, field):
        pass
    @classmethod
    def getMinimum(_SELF, field):
        pass
    @classmethod
    def getOffset(_SELF, localTime):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def isLeapYear(_SELF, year):
        pass
    @classmethod
    def julianError(_SELF):
        pass
    @classmethod
    def mod(_SELF, value, mod):
        pass
    @classmethod
    def mod7(_SELF, num1):
        pass
    @classmethod
    def Oed_roll__int__int(_SELF, field, value):
        pass
    @classmethod
    def Oed_roll__int__bool(_SELF, field, increment):
        pass
    @classmethod
    def setGregorianChange(_SELF, date):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
