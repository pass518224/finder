class HashSet(object):
    serialVersionUID = 5024744406713321676L
    backingMap = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, capacity):
        pass
    @classmethod
    def Oed___init____int__float(_SELF, capacity, loadFactor):
        pass
    @classmethod
    def Oed___init____Collection(_SELF, collection):
        pass
    @classmethod
    def Oed___init____HashMap(_SELF, backingMap):
        pass
    @classmethod
    def add(_SELF, object):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def contains(_SELF, object):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def remove(_SELF, object):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
    @classmethod
    def createBackingMap(_SELF, capacity, loadFactor):
        pass
