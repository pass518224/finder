class DualPivotQuicksort(object):
    INSERTION_SORT_THRESHOLD = 32
    COUNTING_SORT_THRESHOLD_FOR_BYTE = 128
    COUNTING_SORT_THRESHOLD_FOR_SHORT_OR_CHAR = 32768
    NUM_SHORT_VALUES = None
    NUM_CHAR_VALUES = None
    NUM_BYTE_VALUES = None
    
    @classmethod
    def sort(self, *args):
        fname = "Oed_sort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def doSort(self, *args):
        fname = "Oed_doSort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def sortNegZeroAndNaN(self, *args):
        fname = "Oed_sortNegZeroAndNaN__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def findAnyZero(self, *args):
        fname = "Oed_findAnyZero__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def dualPivotQuicksort(self, *args):
        fname = "Oed_dualPivotQuicksort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def Oed_sort__list(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, a, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_doSort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_dualPivotQuicksort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_sort__list(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, a, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_doSort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_dualPivotQuicksort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_sort__list(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, a, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_doSort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_dualPivotQuicksort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_sort__list(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, a, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_doSort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_dualPivotQuicksort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_sort__list(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, a, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_doSort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_dualPivotQuicksort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_sort__list(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, a, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_sortNegZeroAndNaN__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_findAnyZero__list__int__int(_SELF, a, low, high):
        pass
    @classmethod
    def Oed_doSort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_dualPivotQuicksort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_sort__list(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, a, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_sortNegZeroAndNaN__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_findAnyZero__list__int__int(_SELF, a, low, high):
        pass
    @classmethod
    def Oed_doSort__list__int__int(_SELF, a, left, right):
        pass
    @classmethod
    def Oed_dualPivotQuicksort__list__int__int(_SELF, a, left, right):
        pass
