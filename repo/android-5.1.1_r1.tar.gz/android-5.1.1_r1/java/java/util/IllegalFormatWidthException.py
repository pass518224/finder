class IllegalFormatWidthException(object):
    serialVersionUID = 16660902L
    w = None
    @classmethod
    def __init__(_SELF, w):
        pass
    @classmethod
    def getWidth(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
