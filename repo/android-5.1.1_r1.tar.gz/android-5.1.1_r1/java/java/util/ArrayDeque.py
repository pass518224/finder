class ArrayDeque(object):
    elements = None
    head = None
    tail = None
    MIN_INITIAL_CAPACITY = 8
    class DeqIterator(object):
        cursor = None
        fence = None
        lastRet = 1
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    class DescendingIterator(object):
        cursor = None
        fence = None
        lastRet = 1
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    serialVersionUID = 2340985798034038923L
    
    @classmethod
    def toArray(self, *args):
        fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def remove(self, *args):
        fname = "Oed_remove__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def allocateElements(_SELF, numElements):
        pass
    @classmethod
    def doubleCapacity(_SELF):
        pass
    @classmethod
    def copyElements(_SELF, a):
        pass
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, numElements):
        pass
    @classmethod
    def Oed___init____Collection(_SELF, c):
        pass
    @classmethod
    def addFirst(_SELF, e):
        pass
    @classmethod
    def addLast(_SELF, e):
        pass
    @classmethod
    def offerFirst(_SELF, e):
        pass
    @classmethod
    def offerLast(_SELF, e):
        pass
    @classmethod
    def removeFirst(_SELF):
        pass
    @classmethod
    def removeLast(_SELF):
        pass
    @classmethod
    def pollFirst(_SELF):
        pass
    @classmethod
    def pollLast(_SELF):
        pass
    @classmethod
    def getFirst(_SELF):
        pass
    @classmethod
    def getLast(_SELF):
        pass
    @classmethod
    def peekFirst(_SELF):
        pass
    @classmethod
    def peekLast(_SELF):
        pass
    @classmethod
    def removeFirstOccurrence(_SELF, o):
        pass
    @classmethod
    def removeLastOccurrence(_SELF, o):
        pass
    @classmethod
    def add(_SELF, e):
        pass
    @classmethod
    def offer(_SELF, e):
        pass
    @classmethod
    def Oed_remove__(_SELF):
        pass
    @classmethod
    def poll(_SELF):
        pass
    @classmethod
    def element(_SELF):
        pass
    @classmethod
    def peek(_SELF):
        pass
    @classmethod
    def push(_SELF, e):
        pass
    @classmethod
    def pop(_SELF):
        pass
    @classmethod
    def checkInvariants(_SELF):
        pass
    @classmethod
    def delete(_SELF, i):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def descendingIterator(_SELF):
        pass
    @classmethod
    def contains(_SELF, o):
        pass
    @classmethod
    def Oed_remove__Object(_SELF, o):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def Oed_toArray__(_SELF):
        pass
    @classmethod
    def Oed_toArray__list(_SELF, a):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def writeObject(_SELF, s):
        pass
    @classmethod
    def readObject(_SELF, s):
        pass
