class DuplicateFormatFlagsException(object):
    serialVersionUID = 18890531L
    flags = None
    @classmethod
    def __init__(_SELF, f):
        pass
    @classmethod
    def getFlags(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
