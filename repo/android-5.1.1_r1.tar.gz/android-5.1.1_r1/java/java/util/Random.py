class Random(object):
    serialVersionUID = 3905348978240129619L
    multiplier = 0x5deece66dL
    haveNextNextGaussian = None
    seed = None
    nextNextGaussian = None
    seedBase = 0
    
    @classmethod
    def nextInt(self, *args):
        fname = "Oed_nextInt__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, seed):
        pass
    @classmethod
    def next(_SELF, bits):
        pass
    @classmethod
    def nextBoolean(_SELF):
        pass
    @classmethod
    def nextBytes(_SELF, buf):
        pass
    @classmethod
    def nextDouble(_SELF):
        pass
    @classmethod
    def nextFloat(_SELF):
        pass
    @classmethod
    def nextGaussian(_SELF):
        pass
    @classmethod
    def Oed_nextInt__(_SELF):
        pass
    @classmethod
    def Oed_nextInt__int(_SELF, n):
        pass
    @classmethod
    def nextLong(_SELF):
        pass
    @classmethod
    def setSeed(_SELF, seed):
        pass
