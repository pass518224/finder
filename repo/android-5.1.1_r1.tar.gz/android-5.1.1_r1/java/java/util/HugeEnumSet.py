class HugeEnumSet(object):
    BIT_IN_LONG = 64
    enums = None
    bits = None
    size = None
    class HugeEnumSetIterator(object):
        currentBits = None
        index = None
        mask = None
        last = None
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def computeNextElement(_SELF):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    @classmethod
    def __init__(_SELF, elementType, enums):
        pass
    @classmethod
    def add(_SELF, element):
        pass
    @classmethod
    def addAll(_SELF, collection):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def complement(_SELF):
        pass
    @classmethod
    def contains(_SELF, object):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def containsAll(_SELF, collection):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def remove(_SELF, object):
        pass
    @classmethod
    def removeAll(_SELF, collection):
        pass
    @classmethod
    def retainAll(_SELF, collection):
        pass
    @classmethod
    def setRange(_SELF, start, end):
        pass
