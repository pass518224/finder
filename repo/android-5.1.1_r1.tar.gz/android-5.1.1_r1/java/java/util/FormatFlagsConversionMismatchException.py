class FormatFlagsConversionMismatchException(object):
    serialVersionUID = 19120414L
    f = None
    c = None
    @classmethod
    def __init__(_SELF, f, c):
        pass
    @classmethod
    def getFlags(_SELF):
        pass
    @classmethod
    def getConversion(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
