class ServiceLoader(object):
    service = None
    classLoader = None
    services = None
    class ServiceIterator(object):
        classLoader = None
        service = None
        services = None
        isRead = False
        queue = None
        @classmethod
        def __init__(_SELF, sl):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def readClass(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
        @classmethod
        def checkValidJavaClassName(_SELF, className):
            pass
    
    @classmethod
    def load(self, *args):
        fname = "Oed_load__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, service, classLoader):
        pass
    @classmethod
    def reload(_SELF):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def Oed_load__Class__ClassLoader(_SELF, service, classLoader):
        pass
    @classmethod
    def internalLoad(_SELF):
        pass
    @classmethod
    def Oed_load__Class(_SELF, service):
        pass
    @classmethod
    def loadInstalled(_SELF, service):
        pass
    @classmethod
    def loadFromSystemProperty(_SELF, service):
        pass
    @classmethod
    def __str__(_SELF):
        pass
