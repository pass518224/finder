class Stack(object):
    serialVersionUID = 1224463164541339165L
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def empty(_SELF):
        pass
    @classmethod
    def peek(_SELF):
        pass
    @classmethod
    def pop(_SELF):
        pass
    @classmethod
    def push(_SELF, object):
        pass
    @classmethod
    def search(_SELF, o):
        pass
