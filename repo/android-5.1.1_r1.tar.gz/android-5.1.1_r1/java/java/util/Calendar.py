class Calendar(object):
    serialVersionUID = 1807547505821590642L
    areFieldsSet = None
    fields = None
    isSet = None
    isTimeSet = None
    time = None
    lastTimeFieldSet = None
    lastDateFieldSet = None
    lenient = None
    firstDayOfWeek = None
    minimalDaysInFirstWeek = None
    zone = None
    JANUARY = 0
    FEBRUARY = 1
    MARCH = 2
    APRIL = 3
    MAY = 4
    JUNE = 5
    JULY = 6
    AUGUST = 7
    SEPTEMBER = 8
    OCTOBER = 9
    NOVEMBER = 10
    DECEMBER = 11
    UNDECIMBER = 12
    SUNDAY = 1
    MONDAY = 2
    TUESDAY = 3
    WEDNESDAY = 4
    THURSDAY = 5
    FRIDAY = 6
    SATURDAY = 7
    ERA = 0
    YEAR = 1
    MONTH = 2
    WEEK_OF_YEAR = 3
    WEEK_OF_MONTH = 4
    DATE = 5
    DAY_OF_MONTH = 5
    DAY_OF_YEAR = 6
    DAY_OF_WEEK = 7
    DAY_OF_WEEK_IN_MONTH = 8
    AM_PM = 9
    HOUR = 10
    HOUR_OF_DAY = 11
    MINUTE = 12
    SECOND = 13
    MILLISECOND = 14
    ZONE_OFFSET = 15
    DST_OFFSET = 16
    FIELD_COUNT = 17
    AM = 0
    PM = 1
    ALL_STYLES = 0
    SHORT = 1
    LONG = 2
    FIELD_NAMES = None
    serialPersistentFields = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def set(self, *args):
        fname = "Oed_set__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def clear(self, *args):
        fname = "Oed_clear__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getInstance(self, *args):
        fname = "Oed_getInstance__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def roll(self, *args):
        fname = "Oed_roll__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____TimeZone(_SELF, timezone):
        pass
    @classmethod
    def Oed___init____TimeZone__Locale(_SELF, timezone, locale):
        pass
    @classmethod
    def add(_SELF, field, value):
        pass
    @classmethod
    def after(_SELF, calendar):
        pass
    @classmethod
    def before(_SELF, calendar):
        pass
    @classmethod
    def Oed_clear__(_SELF):
        pass
    @classmethod
    def Oed_clear__int(_SELF, field):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def complete(_SELF):
        pass
    @classmethod
    def computeFields(_SELF):
        pass
    @classmethod
    def computeTime(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def get(_SELF, field):
        pass
    @classmethod
    def getActualMaximum(_SELF, field):
        pass
    @classmethod
    def getActualMinimum(_SELF, field):
        pass
    @classmethod
    def getAvailableLocales(_SELF):
        pass
    @classmethod
    def getFirstDayOfWeek(_SELF):
        pass
    @classmethod
    def getGreatestMinimum(_SELF, field):
        pass
    @classmethod
    def Oed_getInstance__(_SELF):
        pass
    @classmethod
    def Oed_getInstance__Locale(_SELF, locale):
        pass
    @classmethod
    def Oed_getInstance__TimeZone(_SELF, timezone):
        pass
    @classmethod
    def Oed_getInstance__TimeZone__Locale(_SELF, timezone, locale):
        pass
    @classmethod
    def getLeastMaximum(_SELF, field):
        pass
    @classmethod
    def getMaximum(_SELF, field):
        pass
    @classmethod
    def getMinimalDaysInFirstWeek(_SELF):
        pass
    @classmethod
    def getMinimum(_SELF, field):
        pass
    @classmethod
    def getTime(_SELF):
        pass
    @classmethod
    def getTimeInMillis(_SELF):
        pass
    @classmethod
    def getTimeZone(_SELF):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def internalGet(_SELF, field):
        pass
    @classmethod
    def isLenient(_SELF):
        pass
    @classmethod
    def isSet(_SELF, field):
        pass
    @classmethod
    def Oed_roll__int__int(_SELF, field, value):
        pass
    @classmethod
    def Oed_roll__int__bool(_SELF, field, increment):
        pass
    @classmethod
    def Oed_set__int__int(_SELF, field, value):
        pass
    @classmethod
    def Oed_set__int__int__int(_SELF, year, month, day):
        pass
    @classmethod
    def Oed_set__int__int__int__int__int(_SELF, year, month, day, hourOfDay, minute):
        pass
    @classmethod
    def Oed_set__int__int__int__int__int__int(_SELF, year, month, day, hourOfDay, minute, second):
        pass
    @classmethod
    def setFirstDayOfWeek(_SELF, value):
        pass
    @classmethod
    def setLenient(_SELF, value):
        pass
    @classmethod
    def setMinimalDaysInFirstWeek(_SELF, value):
        pass
    @classmethod
    def setTime(_SELF, date):
        pass
    @classmethod
    def setTimeInMillis(_SELF, milliseconds):
        pass
    @classmethod
    def setTimeZone(_SELF, timezone):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def compareTo(_SELF, anotherCalendar):
        pass
    @classmethod
    def getDisplayName(_SELF, field, style, locale):
        pass
    @classmethod
    def getDisplayNameArray(_SELF, field, style, locale):
        pass
    @classmethod
    def checkStyle(_SELF, style):
        pass
    @classmethod
    def getDisplayNames(_SELF, field, style, locale):
        pass
    @classmethod
    def insertValuesInMap(_SELF, map, values):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
