class SortedMap(object):
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def firstKey(_SELF):
        pass
    @classmethod
    def headMap(_SELF, endKey):
        pass
    @classmethod
    def lastKey(_SELF):
        pass
    @classmethod
    def subMap(_SELF, startKey, endKey):
        pass
    @classmethod
    def tailMap(_SELF, startKey):
        pass
