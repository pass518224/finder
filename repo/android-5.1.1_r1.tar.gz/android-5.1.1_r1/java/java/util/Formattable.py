class Formattable(object):
    @classmethod
    def formatTo(_SELF, formatter, flags, width, precision):
        pass
