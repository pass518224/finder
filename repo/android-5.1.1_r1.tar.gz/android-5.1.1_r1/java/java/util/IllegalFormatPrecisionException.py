class IllegalFormatPrecisionException(object):
    serialVersionUID = 18711008L
    p = None
    @classmethod
    def __init__(_SELF, p):
        pass
    @classmethod
    def getPrecision(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
