class EnumMap(object):
    serialVersionUID = 458661240069192865L
    keyType = None
    keys = None
    values = None
    hasMapping = None
    mappingsCount = None
    enumSize = None
    entrySet = None
    class Entry(object):
        enumMap = None
        ordinal = None
        @classmethod
        def __init__(_SELF, theKey, theValue, em):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def getKey(_SELF):
            pass
        @classmethod
        def getValue(_SELF):
            pass
        @classmethod
        def setValue(_SELF, value):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def checkEntryStatus(_SELF):
            pass
    class EnumMapIterator(object):
        position = 0
        prePosition = 1
        enumMap = None
        type = None
        @classmethod
        def __init__(_SELF, value, em):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def checkStatus(_SELF):
            pass
    class EnumMapKeySet(object):
        enumMap = None
        @classmethod
        def __init__(_SELF, em):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def remove(_SELF, object):
            pass
        @classmethod
        def size(_SELF):
            pass
    class EnumMapValueCollection(object):
        enumMap = None
        @classmethod
        def __init__(_SELF, em):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def remove(_SELF, object):
            pass
        @classmethod
        def size(_SELF):
            pass
    class EnumMapEntrySet(object):
        enumMap = None
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def __init__(_SELF, em):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def remove(_SELF, object):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, array):
            pass
    
    @classmethod
    def initialization(self, *args):
        fname = "Oed_initialization__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____Class(_SELF, keyType):
        pass
    @classmethod
    def Oed___init____EnumMap(_SELF, map):
        pass
    @classmethod
    def Oed___init____Map(_SELF, map):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def containsKey(_SELF, key):
        pass
    @classmethod
    def containsValue(_SELF, value):
        pass
    @classmethod
    def entrySet(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def keySet(_SELF):
        pass
    @classmethod
    def put(_SELF, key, value):
        pass
    @classmethod
    def putAll(_SELF, map):
        pass
    @classmethod
    def remove(_SELF, key):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def values(_SELF):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def isValidKeyType(_SELF, key):
        pass
    @classmethod
    def Oed_initialization__EnumMap(_SELF, enumMap):
        pass
    @classmethod
    def Oed_initialization__Class(_SELF, type):
        pass
    @classmethod
    def putAllImpl(_SELF, map):
        pass
    @classmethod
    def putImpl(_SELF, key, value):
        pass
class EnumMapEntryIterator(object):
    @classmethod
    def __init__(_SELF, value, em):
        pass
    @classmethod
    def next(_SELF):
        pass
EnumMap.EnumMapEntryIterator = EnumMapEntryIterator
