class IllegalFormatFlagsException(object):
    serialVersionUID = 790824L
    flags = None
    @classmethod
    def __init__(_SELF, flags):
        pass
    @classmethod
    def getFlags(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
