class MissingResourceException(object):
    serialVersionUID = 4876345176062000401L
    className = None
    key = None
    @classmethod
    def __init__(_SELF, detailMessage, className, resourceName):
        pass
    @classmethod
    def getClassName(_SELF):
        pass
    @classmethod
    def getKey(_SELF):
        pass
