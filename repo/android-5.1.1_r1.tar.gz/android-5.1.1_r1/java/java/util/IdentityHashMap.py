class IdentityHashMap(object):
    serialVersionUID = 8188218128353913216L
    elementData = None
    size = None
    threshold = None
    DEFAULT_MAX_SIZE = 21
    loadFactor = 7500
    modCount = 0
    NULL_OBJECT = None
    class IdentityHashMapEntry(object):
        map = None
        @classmethod
        def __init__(_SELF, map, theKey, theValue):
            pass
        @classmethod
        def clone(_SELF):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def setValue(_SELF, object):
            pass
    class IdentityHashMapIterator(object):
        position = 0
        lastPosition = 0
        associatedMap = None
        expectedModCount = None
        type = None
        canRemove = False
        @classmethod
        def __init__(_SELF, value, hm):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def checkConcurrentMod(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    class IdentityHashMapEntrySet(object):
        associatedMap = None
        @classmethod
        def __init__(_SELF, hm):
            pass
        @classmethod
        def hashMap(_SELF):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def remove(_SELF, object):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def iterator(_SELF):
            pass
    
    @classmethod
    def getEntry(self, *args):
        fname = "Oed_getEntry__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, maxSize):
        pass
    @classmethod
    def getThreshold(_SELF, maxSize):
        pass
    @classmethod
    def computeElementArraySize(_SELF):
        pass
    @classmethod
    def newElementArray(_SELF, s):
        pass
    @classmethod
    def Oed___init____Map(_SELF, map):
        pass
    @classmethod
    def massageValue(_SELF, value):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def containsKey(_SELF, key):
        pass
    @classmethod
    def containsValue(_SELF, value):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def Oed_getEntry__Object(_SELF, key):
        pass
    @classmethod
    def Oed_getEntry__int(_SELF, index):
        pass
    @classmethod
    def findIndex(_SELF, key, array):
        pass
    @classmethod
    def getModuloHash(_SELF, key, length):
        pass
    @classmethod
    def put(_SELF, key, value):
        pass
    @classmethod
    def putAll(_SELF, map):
        pass
    @classmethod
    def rehash(_SELF):
        pass
    @classmethod
    def computeMaxSize(_SELF):
        pass
    @classmethod
    def remove(_SELF, key):
        pass
    @classmethod
    def entrySet(_SELF):
        pass
    @classmethod
    def keySet(_SELF):
        pass
    @classmethod
    def values(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
    @classmethod
    def putAllImpl(_SELF, map):
        pass
