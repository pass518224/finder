class List(object):
    @classmethod
    def Oed_add__int__E(_SELF, location, object):
        pass
    @classmethod
    def Oed_add__E(_SELF, object):
        pass
    @classmethod
    def Oed_addAll__int__Collection(_SELF, location, collection):
        pass
    @classmethod
    def Oed_addAll__Collection(_SELF, collection):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def contains(_SELF, object):
        pass
    @classmethod
    def containsAll(_SELF, collection):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def get(_SELF, location):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def indexOf(_SELF, object):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def lastIndexOf(_SELF, object):
        pass
    @classmethod
    def Oed_listIterator__(_SELF):
        pass
    @classmethod
    def Oed_listIterator__int(_SELF, location):
        pass
    @classmethod
    def Oed_remove__int(_SELF, location):
        pass
    @classmethod
    def Oed_remove__Object(_SELF, object):
        pass
    @classmethod
    def removeAll(_SELF, collection):
        pass
    @classmethod
    def retainAll(_SELF, collection):
        pass
    @classmethod
    def set(_SELF, location, object):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def subList(_SELF, start, end):
        pass
    @classmethod
    def Oed_toArray__(_SELF):
        pass
    @classmethod
    def Oed_toArray__list(_SELF, array):
        pass
