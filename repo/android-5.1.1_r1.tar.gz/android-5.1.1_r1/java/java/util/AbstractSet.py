class AbstractSet(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def removeAll(_SELF, collection):
        pass
