class PriorityQueue(object):
    serialVersionUID = 7720805057305804111L
    DEFAULT_CAPACITY = 11
    DEFAULT_INIT_CAPACITY_RATIO = 1.1
    DEFAULT_CAPACITY_RATIO = 2
    size = None
    comparator = None
    elements = None
    class PriorityIterator(object):
        currentIndex = 1
        allowRemove = False
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, initialCapacity):
        pass
    @classmethod
    def Oed___init____int__Comparator(_SELF, initialCapacity, comparator):
        pass
    @classmethod
    def Oed___init____Collection(_SELF, c):
        pass
    @classmethod
    def Oed___init____PriorityQueue(_SELF, c):
        pass
    @classmethod
    def Oed___init____SortedSet(_SELF, c):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def offer(_SELF, o):
        pass
    @classmethod
    def poll(_SELF):
        pass
    @classmethod
    def peek(_SELF):
        pass
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def remove(_SELF, o):
        pass
    @classmethod
    def add(_SELF, o):
        pass
    @classmethod
    def readObject(_SELF, _in):
        pass
    @classmethod
    def newElementArray(_SELF, capacity):
        pass
    @classmethod
    def writeObject(_SELF, out):
        pass
    @classmethod
    def getFromPriorityQueue(_SELF, c):
        pass
    @classmethod
    def getFromSortedSet(_SELF, c):
        pass
    @classmethod
    def removeAt(_SELF, index):
        pass
    @classmethod
    def compare(_SELF, o1, o2):
        pass
    @classmethod
    def siftUp(_SELF, childIndex):
        pass
    @classmethod
    def siftDown(_SELF, rootIndex):
        pass
    @classmethod
    def initSize(_SELF, c):
        pass
    @classmethod
    def growToSize(_SELF, size):
        pass
