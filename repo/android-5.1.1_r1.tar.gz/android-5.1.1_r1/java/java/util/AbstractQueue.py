class AbstractQueue(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def add(_SELF, e):
        pass
    @classmethod
    def remove(_SELF):
        pass
    @classmethod
    def element(_SELF):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def addAll(_SELF, c):
        pass
