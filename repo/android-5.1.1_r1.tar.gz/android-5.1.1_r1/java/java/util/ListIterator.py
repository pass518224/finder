class ListIterator(object):
    @classmethod
    def add(_SELF, object):
        pass
    @classmethod
    def hasNext(_SELF):
        pass
    @classmethod
    def hasPrevious(_SELF):
        pass
    @classmethod
    def next(_SELF):
        pass
    @classmethod
    def nextIndex(_SELF):
        pass
    @classmethod
    def previous(_SELF):
        pass
    @classmethod
    def previousIndex(_SELF):
        pass
    @classmethod
    def remove(_SELF):
        pass
    @classmethod
    def set(_SELF, object):
        pass
