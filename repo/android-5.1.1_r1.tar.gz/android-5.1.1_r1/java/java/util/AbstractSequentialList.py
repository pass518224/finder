class AbstractSequentialList(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def add(_SELF, location, object):
        pass
    @classmethod
    def addAll(_SELF, location, collection):
        pass
    @classmethod
    def get(_SELF, location):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def listIterator(_SELF, location):
        pass
    @classmethod
    def remove(_SELF, location):
        pass
    @classmethod
    def set(_SELF, location, object):
        pass
