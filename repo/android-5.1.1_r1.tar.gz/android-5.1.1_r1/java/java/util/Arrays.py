class Arrays(object):
    class ArrayList(object):
        serialVersionUID = 2764017481108945198L
        a = None
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def __init__(_SELF, storage):
            pass
        @classmethod
        def contains(_SELF, object):
            pass
        @classmethod
        def get(_SELF, location):
            pass
        @classmethod
        def indexOf(_SELF, object):
            pass
        @classmethod
        def lastIndexOf(_SELF, object):
            pass
        @classmethod
        def set(_SELF, location, object):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, contents):
            pass
    
    @classmethod
    def sort(self, *args):
        fname = "Oed_sort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def copyOfRange(self, *args):
        fname = "Oed_copyOfRange__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def equals(self, *args):
        fname = "Oed_equals__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def hashCode(self, *args):
        fname = "Oed_hashCode__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def toString(self, *args):
        fname = "Oed_toString__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def copyOf(self, *args):
        fname = "Oed_copyOf__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def binarySearch(self, *args):
        fname = "Oed_binarySearch__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def fill(self, *args):
        fname = "Oed_fill__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def asList(_SELF, array):
        pass
    @classmethod
    def Oed_binarySearch__list__bytes(_SELF, array, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__bytes(_SELF, array, startIndex, endIndex, value):
        pass
    @classmethod
    def Oed_binarySearch__list__char(_SELF, array, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__char(_SELF, array, startIndex, endIndex, value):
        pass
    @classmethod
    def Oed_binarySearch__list__float(_SELF, array, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__float(_SELF, array, startIndex, endIndex, value):
        pass
    @classmethod
    def Oed_binarySearch__list__float(_SELF, array, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__float(_SELF, array, startIndex, endIndex, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int(_SELF, array, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__int(_SELF, array, startIndex, endIndex, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int(_SELF, array, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__int(_SELF, array, startIndex, endIndex, value):
        pass
    @classmethod
    def Oed_binarySearch__list__Object(_SELF, array, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__Object(_SELF, array, startIndex, endIndex, value):
        pass
    @classmethod
    def Oed_binarySearch__list__T__Comparator(_SELF, array, value, comparator):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__T__Comparator(_SELF, array, startIndex, endIndex, value, comparator):
        pass
    @classmethod
    def Oed_binarySearch__list__short(_SELF, array, value):
        pass
    @classmethod
    def Oed_binarySearch__list__int__int__short(_SELF, array, startIndex, endIndex, value):
        pass
    @classmethod
    def checkBinarySearchBounds(_SELF, startIndex, endIndex, length):
        pass
    @classmethod
    def Oed_fill__list__bytes(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__bytes(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_fill__list__short(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__short(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_fill__list__char(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__char(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_fill__list__int(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__int(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_fill__list__int(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__int(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_fill__list__float(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__float(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_fill__list__float(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__float(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_fill__list__bool(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__bool(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_fill__list__Object(_SELF, array, value):
        pass
    @classmethod
    def Oed_fill__list__int__int__Object(_SELF, array, start, end, value):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def Oed_hashCode__list(_SELF, array):
        pass
    @classmethod
    def deepHashCode(_SELF, array):
        pass
    @classmethod
    def deepHashCodeElement(_SELF, element):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def Oed_equals__list__list(_SELF, array1, array2):
        pass
    @classmethod
    def deepEquals(_SELF, array1, array2):
        pass
    @classmethod
    def deepEqualsElements(_SELF, e1, e2):
        pass
    @classmethod
    def Oed_sort__list(_SELF, array):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, array, start, end):
        pass
    @classmethod
    def checkOffsetAndCount(_SELF, arrayLength, offset, count):
        pass
    @classmethod
    def checkStartAndEnd(_SELF, len, start, end):
        pass
    @classmethod
    def Oed_sort__list(_SELF, array):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, array, start, end):
        pass
    @classmethod
    def Oed_sort__list(_SELF, array):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, array, start, end):
        pass
    @classmethod
    def Oed_sort__list(_SELF, array):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, array, start, end):
        pass
    @classmethod
    def Oed_sort__list(_SELF, array):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, array, start, end):
        pass
    @classmethod
    def Oed_sort__list(_SELF, array):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, array, start, end):
        pass
    @classmethod
    def Oed_sort__list(_SELF, array):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, array, start, end):
        pass
    @classmethod
    def Oed_sort__list(_SELF, array):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, array, start, end):
        pass
    @classmethod
    def Oed_sort__list__int__int__Comparator(_SELF, array, start, end, comparator):
        pass
    @classmethod
    def Oed_sort__list__Comparator(_SELF, array, comparator):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def Oed___str____list(_SELF, array):
        pass
    @classmethod
    def deepToString(_SELF, array):
        pass
    @classmethod
    def deepToStringImpl(_SELF, array, origArrays, sb):
        pass
    @classmethod
    def deepToStringImplContains(_SELF, origArrays, array):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int(_SELF, original, newLength):
        pass
    @classmethod
    def Oed_copyOf__list__int__Class(_SELF, original, newLength, newType):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int(_SELF, original, start, end):
        pass
    @classmethod
    def Oed_copyOfRange__list__int__int__Class(_SELF, original, start, end, newType):
        pass
