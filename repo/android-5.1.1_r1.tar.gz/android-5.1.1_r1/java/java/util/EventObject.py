class EventObject(object):
    serialVersionUID = 5516075349620653480L
    source = None
    @classmethod
    def __init__(_SELF, source):
        pass
    @classmethod
    def getSource(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
