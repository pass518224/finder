class ConcurrentModificationException(object):
    serialVersionUID = 3666751008965953603L
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____str(_SELF, detailMessage):
        pass
    @classmethod
    def Oed___init____str__Throwable(_SELF, detailMessage, cause):
        pass
    @classmethod
    def Oed___init____Throwable(_SELF, cause):
        pass
