class IllegalFormatException(object):
    serialVersionUID = 18830826L
    @classmethod
    def __init__(_SELF):
        pass
