class Objects(object):
    
    @classmethod
    def requireNonNull(self, *args):
        fname = "Oed_requireNonNull__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def toString(self, *args):
        fname = "Oed_toString__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def compare(_SELF, a, b, c):
        pass
    @classmethod
    def deepEquals(_SELF, a, b):
        pass
    @classmethod
    def equals(_SELF, a, b):
        pass
    @classmethod
    def hash(_SELF, values):
        pass
    @classmethod
    def hashCode(_SELF, o):
        pass
    @classmethod
    def Oed_requireNonNull__T(_SELF, o):
        pass
    @classmethod
    def Oed_requireNonNull__T__str(_SELF, o, message):
        pass
    @classmethod
    def Oed___str____Object(_SELF, o):
        pass
    @classmethod
    def Oed___str____Object__str(_SELF, o, nullString):
        pass
