class NavigableMap(object):
    @classmethod
    def lowerEntry(_SELF, key):
        pass
    @classmethod
    def lowerKey(_SELF, key):
        pass
    @classmethod
    def floorEntry(_SELF, key):
        pass
    @classmethod
    def floorKey(_SELF, key):
        pass
    @classmethod
    def ceilingEntry(_SELF, key):
        pass
    @classmethod
    def ceilingKey(_SELF, key):
        pass
    @classmethod
    def higherEntry(_SELF, key):
        pass
    @classmethod
    def higherKey(_SELF, key):
        pass
    @classmethod
    def firstEntry(_SELF):
        pass
    @classmethod
    def lastEntry(_SELF):
        pass
    @classmethod
    def pollFirstEntry(_SELF):
        pass
    @classmethod
    def pollLastEntry(_SELF):
        pass
    @classmethod
    def descendingMap(_SELF):
        pass
    @classmethod
    def navigableKeySet(_SELF):
        pass
    @classmethod
    def descendingKeySet(_SELF):
        pass
    @classmethod
    def Oed_subMap__K__bool__K__bool(_SELF, fromKey, fromInclusive, toKey, toInclusive):
        pass
    @classmethod
    def Oed_headMap__K__bool(_SELF, toKey, inclusive):
        pass
    @classmethod
    def Oed_tailMap__K__bool(_SELF, fromKey, inclusive):
        pass
    @classmethod
    def Oed_subMap__K__K(_SELF, fromKey, toKey):
        pass
    @classmethod
    def Oed_headMap__K(_SELF, toKey):
        pass
    @classmethod
    def Oed_tailMap__K(_SELF, fromKey):
        pass
