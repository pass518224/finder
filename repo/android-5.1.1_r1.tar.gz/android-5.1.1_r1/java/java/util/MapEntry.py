class MapEntry(object):
    key = None
    value = None
    class Type(object):
        @classmethod
        def get(_SELF, entry):
            pass
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____K(_SELF, theKey):
        pass
    @classmethod
    def Oed___init____K__V(_SELF, theKey, theValue):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def getKey(_SELF):
        pass
    @classmethod
    def getValue(_SELF):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def setValue(_SELF, object):
        pass
    @classmethod
    def __str__(_SELF):
        pass
