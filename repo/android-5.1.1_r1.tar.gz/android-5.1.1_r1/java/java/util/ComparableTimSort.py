class ComparableTimSort(object):
    MIN_MERGE = 32
    a = None
    MIN_GALLOP = 7
    minGallop = None
    INITIAL_TMP_STORAGE_LENGTH = 256
    tmp = None
    stackSize = 0
    runBase = None
    runLen = None
    DEBUG = False
    
    @classmethod
    def sort(self, *args):
        fname = "Oed_sort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list(_SELF, a):
        pass
    @classmethod
    def Oed_sort__list__int__int(_SELF, a, lo, hi):
        pass
    @classmethod
    def binarySort(_SELF, a, lo, hi, start):
        pass
    @classmethod
    def countRunAndMakeAscending(_SELF, a, lo, hi):
        pass
    @classmethod
    def reverseRange(_SELF, a, lo, hi):
        pass
    @classmethod
    def minRunLength(_SELF, n):
        pass
    @classmethod
    def pushRun(_SELF, runBase, runLen):
        pass
    @classmethod
    def mergeCollapse(_SELF):
        pass
    @classmethod
    def mergeForceCollapse(_SELF):
        pass
    @classmethod
    def mergeAt(_SELF, i):
        pass
    @classmethod
    def gallopLeft(_SELF, key, a, base, len, hint):
        pass
    @classmethod
    def gallopRight(_SELF, key, a, base, len, hint):
        pass
    @classmethod
    def mergeLo(_SELF, base1, len1, base2, len2):
        pass
    @classmethod
    def mergeHi(_SELF, base1, len1, base2, len2):
        pass
    @classmethod
    def ensureCapacity(_SELF, minCapacity):
        pass
