class Timer(object):
    class TimerImpl(object):
        class TimerHeap(object):
            DEFAULT_HEAP_SIZE = 256
            timers = None
            size = 0
            deletedCancelledNumber = 0
            @classmethod
            def minimum(_SELF):
                pass
            @classmethod
            def isEmpty(_SELF):
                pass
            @classmethod
            def insert(_SELF, task):
                pass
            @classmethod
            def delete(_SELF, pos):
                pass
            @classmethod
            def upHeap(_SELF):
                pass
            @classmethod
            def downHeap(_SELF, pos):
                pass
            @classmethod
            def reset(_SELF):
                pass
            @classmethod
            def adjustMinimum(_SELF):
                pass
            @classmethod
            def deleteIfCancelled(_SELF):
                pass
            @classmethod
            def getTask(_SELF, task):
                pass
        cancelled = None
        finished = None
        tasks = None
        @classmethod
        def __init__(_SELF, name, isDaemon):
            pass
        @classmethod
        def run(_SELF):
            pass
        @classmethod
        def insertTask(_SELF, newTask):
            pass
        @classmethod
        def cancel(_SELF):
            pass
        @classmethod
        def purge(_SELF):
            pass
    class FinalizerHelper(object):
        impl = None
        @classmethod
        def __init__(_SELF, impl):
            pass
        @classmethod
        def finalize(_SELF):
            pass
    timerId = None
    impl = None
    finalizer = None
    
    @classmethod
    def scheduleAtFixedRate(self, *args):
        fname = "Oed_scheduleAtFixedRate__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def schedule(self, *args):
        fname = "Oed_schedule__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def nextId(_SELF):
        pass
    @classmethod
    def Oed___init____str__bool(_SELF, name, isDaemon):
        pass
    @classmethod
    def Oed___init____str(_SELF, name):
        pass
    @classmethod
    def Oed___init____bool(_SELF, isDaemon):
        pass
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def cancel(_SELF):
        pass
    @classmethod
    def purge(_SELF):
        pass
    @classmethod
    def Oed_schedule__TimerTask__Date(_SELF, task, when):
        pass
    @classmethod
    def Oed_schedule__TimerTask__int(_SELF, task, delay):
        pass
    @classmethod
    def Oed_schedule__TimerTask__int__int(_SELF, task, delay, period):
        pass
    @classmethod
    def Oed_schedule__TimerTask__Date__int(_SELF, task, when, period):
        pass
    @classmethod
    def Oed_scheduleAtFixedRate__TimerTask__int__int(_SELF, task, delay, period):
        pass
    @classmethod
    def Oed_scheduleAtFixedRate__TimerTask__Date__int(_SELF, task, when, period):
        pass
    @classmethod
    def scheduleImpl(_SELF, task, delay, period, fixed):
        pass
