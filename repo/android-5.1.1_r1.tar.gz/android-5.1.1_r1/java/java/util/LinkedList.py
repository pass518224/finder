class LinkedList(object):
    serialVersionUID = 876323262645176354L
    size = 0
    voidLink = None
    class Link(object):
        data = None
        previous = None
        next = None
        @classmethod
        def __init__(_SELF, o, p, n):
            pass
    class LinkIterator(object):
        pos = None
        expectedModCount = None
        list = None
        link = None
        lastLink = None
        @classmethod
        def __init__(_SELF, object, location):
            pass
        @classmethod
        def add(_SELF, object):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def hasPrevious(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def nextIndex(_SELF):
            pass
        @classmethod
        def previous(_SELF):
            pass
        @classmethod
        def previousIndex(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
        @classmethod
        def set(_SELF, object):
            pass
    class ReverseLinkIterator(object):
        expectedModCount = None
        list = None
        link = None
        canRemove = None
        @classmethod
        def __init__(_SELF, linkedList):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    
    @classmethod
    def toArray(self, *args):
        fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def add(self, *args):
        fname = "Oed_add__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def addAll(self, *args):
        fname = "Oed_addAll__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def remove(self, *args):
        fname = "Oed_remove__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____Collection(_SELF, collection):
        pass
    @classmethod
    def Oed_add__int__E(_SELF, location, object):
        pass
    @classmethod
    def Oed_add__E(_SELF, object):
        pass
    @classmethod
    def addLastImpl(_SELF, object):
        pass
    @classmethod
    def Oed_addAll__int__Collection(_SELF, location, collection):
        pass
    @classmethod
    def Oed_addAll__Collection(_SELF, collection):
        pass
    @classmethod
    def addFirst(_SELF, object):
        pass
    @classmethod
    def addFirstImpl(_SELF, object):
        pass
    @classmethod
    def addLast(_SELF, object):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def contains(_SELF, object):
        pass
    @classmethod
    def get(_SELF, location):
        pass
    @classmethod
    def getFirst(_SELF):
        pass
    @classmethod
    def getFirstImpl(_SELF):
        pass
    @classmethod
    def getLast(_SELF):
        pass
    @classmethod
    def indexOf(_SELF, object):
        pass
    @classmethod
    def lastIndexOf(_SELF, object):
        pass
    @classmethod
    def listIterator(_SELF, location):
        pass
    @classmethod
    def Oed_remove__int(_SELF, location):
        pass
    @classmethod
    def Oed_remove__Object(_SELF, object):
        pass
    @classmethod
    def removeFirst(_SELF):
        pass
    @classmethod
    def removeFirstImpl(_SELF):
        pass
    @classmethod
    def removeLast(_SELF):
        pass
    @classmethod
    def removeLastImpl(_SELF):
        pass
    @classmethod
    def descendingIterator(_SELF):
        pass
    @classmethod
    def offerFirst(_SELF, e):
        pass
    @classmethod
    def offerLast(_SELF, e):
        pass
    @classmethod
    def peekFirst(_SELF):
        pass
    @classmethod
    def peekLast(_SELF):
        pass
    @classmethod
    def pollFirst(_SELF):
        pass
    @classmethod
    def pollLast(_SELF):
        pass
    @classmethod
    def pop(_SELF):
        pass
    @classmethod
    def push(_SELF, e):
        pass
    @classmethod
    def removeFirstOccurrence(_SELF, o):
        pass
    @classmethod
    def removeLastOccurrence(_SELF, o):
        pass
    @classmethod
    def removeFirstOccurrenceImpl(_SELF, o):
        pass
    @classmethod
    def removeOneOccurrence(_SELF, o, iter):
        pass
    @classmethod
    def set(_SELF, location, object):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def offer(_SELF, o):
        pass
    @classmethod
    def poll(_SELF):
        pass
    @classmethod
    def Oed_remove__(_SELF):
        pass
    @classmethod
    def peek(_SELF):
        pass
    @classmethod
    def peekFirstImpl(_SELF):
        pass
    @classmethod
    def element(_SELF):
        pass
    @classmethod
    def Oed_toArray__(_SELF):
        pass
    @classmethod
    def Oed_toArray__list(_SELF, contents):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
