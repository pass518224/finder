class Locale(object):
    serialVersionUID = 9149081749638150636L
    CANADA = None
    CANADA_FRENCH = None
    CHINA = None
    CHINESE = None
    ENGLISH = None
    FRANCE = None
    FRENCH = None
    GERMAN = None
    GERMANY = None
    ITALIAN = None
    ITALY = None
    JAPAN = None
    JAPANESE = None
    KOREA = None
    KOREAN = None
    PRC = None
    ROOT = None
    SIMPLIFIED_CHINESE = None
    TAIWAN = None
    TRADITIONAL_CHINESE = None
    UK = None
    US = None
    PRIVATE_USE_EXTENSION = 'x'
    UNICODE_LOCALE_EXTENSION = 'u'
    UNDETERMINED_LANGUAGE = "und"
    defaultLocale = None
    class Builder(object):
        language = None
        region = None
        variant = None
        script = None
        attributes = None
        keywords = None
        extensions = None
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def setLanguage(_SELF, language):
            pass
        @classmethod
        def normalizeAndValidateLanguage(_SELF, language, strict):
            pass
        @classmethod
        def setLanguageTag(_SELF, languageTag):
            pass
        @classmethod
        def setRegion(_SELF, region):
            pass
        @classmethod
        def normalizeAndValidateRegion(_SELF, region, strict):
            pass
        @classmethod
        def setVariant(_SELF, variant):
            pass
        @classmethod
        def normalizeAndValidateVariant(_SELF, variant):
            pass
        @classmethod
        def isValidVariantSubtag(_SELF, subTag):
            pass
        @classmethod
        def setScript(_SELF, script):
            pass
        @classmethod
        def normalizeAndValidateScript(_SELF, script, strict):
            pass
        @classmethod
        def setLocale(_SELF, locale):
            pass
        @classmethod
        def addUnicodeLocaleAttribute(_SELF, attribute):
            pass
        @classmethod
        def removeUnicodeLocaleAttribute(_SELF, attribute):
            pass
        @classmethod
        def setExtension(_SELF, key, value):
            pass
        @classmethod
        def clearExtensions(_SELF):
            pass
        @classmethod
        def setUnicodeLocaleKeyword(_SELF, key, type):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def build(_SELF):
            pass
    countryCode = None
    languageCode = None
    variantCode = None
    scriptCode = None
    unicodeAttributes = None
    unicodeKeywords = None
    extensions = None
    hasValidatedFields = None
    cachedToStringResult = None
    cachedLanguageTag = None
    cachedIcuLocaleId = None
    serialPersistentFields = None
    GRANDFATHERED_LOCALES = None
    
    @classmethod
    def getDisplayScript(self, *args):
        fname = "Oed_getDisplayScript__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getDisplayCountry(self, *args):
        fname = "Oed_getDisplayCountry__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getDisplayVariant(self, *args):
        fname = "Oed_getDisplayVariant__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getDisplayLanguage(self, *args):
        fname = "Oed_getDisplayLanguage__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def forLanguageTag(self, *args):
        fname = "Oed_forLanguageTag__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getDisplayName(self, *args):
        fname = "Oed_getDisplayName__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed_forLanguageTag__str(_SELF, languageTag):
        pass
    @classmethod
    def Oed___init____bool__str__str(_SELF, hasValidatedFields, lowerCaseLanguageCode, upperCaseCountryCode):
        pass
    @classmethod
    def Oed___init____str(_SELF, language):
        pass
    @classmethod
    def Oed___init____str__str(_SELF, language, country):
        pass
    @classmethod
    def Oed___init____str__str__str__str__Set__Map__Map__bool(_SELF, language, country, variant, scriptCode, unicodeAttributes, unicodeKeywords, extensions, hasValidatedFields):
        pass
    @classmethod
    def Oed___init____str__str__str(_SELF, language, country, variant):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def getAvailableLocales(_SELF):
        pass
    @classmethod
    def getCountry(_SELF):
        pass
    @classmethod
    def getDefault(_SELF):
        pass
    @classmethod
    def Oed_getDisplayCountry__(_SELF):
        pass
    @classmethod
    def Oed_getDisplayCountry__Locale(_SELF, locale):
        pass
    @classmethod
    def Oed_getDisplayLanguage__(_SELF):
        pass
    @classmethod
    def Oed_getDisplayLanguage__Locale(_SELF, locale):
        pass
    @classmethod
    def Oed_getDisplayName__(_SELF):
        pass
    @classmethod
    def Oed_getDisplayName__Locale(_SELF, locale):
        pass
    @classmethod
    def Oed_getDisplayVariant__(_SELF):
        pass
    @classmethod
    def Oed_getDisplayVariant__Locale(_SELF, locale):
        pass
    @classmethod
    def getISO3Country(_SELF):
        pass
    @classmethod
    def getISO3Language(_SELF):
        pass
    @classmethod
    def getISOCountries(_SELF):
        pass
    @classmethod
    def getISOLanguages(_SELF):
        pass
    @classmethod
    def getLanguage(_SELF):
        pass
    @classmethod
    def getVariant(_SELF):
        pass
    @classmethod
    def getScript(_SELF):
        pass
    @classmethod
    def Oed_getDisplayScript__(_SELF):
        pass
    @classmethod
    def Oed_getDisplayScript__Locale(_SELF, locale):
        pass
    @classmethod
    def toLanguageTag(_SELF):
        pass
    @classmethod
    def makeLanguageTag(_SELF):
        pass
    @classmethod
    def splitIllformedVariant(_SELF, variant):
        pass
    @classmethod
    def concatenateRange(_SELF, array, start, end):
        pass
    @classmethod
    def getExtensionKeys(_SELF):
        pass
    @classmethod
    def getExtension(_SELF, extensionKey):
        pass
    @classmethod
    def getUnicodeLocaleType(_SELF, keyWord):
        pass
    @classmethod
    def getUnicodeLocaleAttributes(_SELF):
        pass
    @classmethod
    def getUnicodeLocaleKeys(_SELF):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def setDefault(_SELF, locale):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def toNewString(_SELF, languageCode, countryCode, variantCode, scriptCode, extensions):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
    @classmethod
    def readExtensions(_SELF, extensions):
        pass
    @classmethod
    def serializeExtensions(_SELF, extensionsMap):
        pass
    @classmethod
    def parseSerializedExtensions(_SELF, extString, outputMap):
        pass
    @classmethod
    def isUnM49AreaCode(_SELF, code):
        pass
    @classmethod
    def isAsciiAlphaNum(_SELF, string):
        pass
    @classmethod
    def isValidBcp47Alpha(_SELF, string, lowerBound, upperBound):
        pass
    @classmethod
    def isValidBcp47Alphanum(_SELF, attributeOrType, lowerBound, upperBound):
        pass
    @classmethod
    def titleCaseAsciiWord(_SELF, word):
        pass
    @classmethod
    def isValidTypeList(_SELF, lowerCaseTypeList):
        pass
    @classmethod
    def addUnicodeExtensionToExtensionsMap(_SELF, attributes, keywords, extensions):
        pass
    @classmethod
    def parseUnicodeExtension(_SELF, subtags, keywords, attributes):
        pass
    @classmethod
    def joinBcp47Subtags(_SELF, strings):
        pass
    @classmethod
    def adjustLanguageCode(_SELF, languageCode):
        pass
    @classmethod
    def convertGrandfatheredTag(_SELF, original):
        pass
    @classmethod
    def extractVariantSubtags(_SELF, subtags, startIndex, endIndex, normalizedVariants):
        pass
    @classmethod
    def extractExtensions(_SELF, subtags, startIndex, endIndex, extensions):
        pass
    @classmethod
    def Oed_forLanguageTag__str__bool(_SELF, tag, strict):
        pass
