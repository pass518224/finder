class ServiceConfigurationError(object):
    serialVersionUID = 74132770414881L
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____str(_SELF, message):
        pass
    @classmethod
    def Oed___init____str__Throwable(_SELF, message, cause):
        pass
