class ListResourceBundle(object):
    table = None
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def getContents(_SELF):
        pass
    @classmethod
    def getKeys(_SELF):
        pass
    @classmethod
    def handleGetObject(_SELF, key):
        pass
    @classmethod
    def initializeTable(_SELF):
        pass
    @classmethod
    def handleKeySet(_SELF):
        pass
