class HashMap(object):
    MINIMUM_CAPACITY = 4
    MAXIMUM_CAPACITY = None
    EMPTY_TABLE = None
    DEFAULT_LOAD_FACTOR = 0.75
    table = None
    entryForNullKey = None
    size = None
    modCount = None
    threshold = None
    keySet = None
    entrySet = None
    values = None
    class HashMapEntry(object):
        key = None
        value = None
        hash = None
        next = None
        @classmethod
        def __init__(_SELF, key, value, hash, next):
            pass
        @classmethod
        def getKey(_SELF):
            pass
        @classmethod
        def getValue(_SELF):
            pass
        @classmethod
        def setValue(_SELF, value):
            pass
        @classmethod
        def equals(_SELF, o):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    class HashIterator(object):
        nextIndex = None
        nextEntry = None
        lastEntryReturned = None
        expectedModCount = None
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def nextEntry(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    class KeySet(object):
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def contains(_SELF, o):
            pass
        @classmethod
        def remove(_SELF, o):
            pass
        @classmethod
        def clear(_SELF):
            pass
    class Values(object):
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def contains(_SELF, o):
            pass
        @classmethod
        def clear(_SELF):
            pass
    class EntrySet(object):
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def contains(_SELF, o):
            pass
        @classmethod
        def remove(_SELF, o):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def isEmpty(_SELF):
            pass
        @classmethod
        def clear(_SELF):
            pass
    serialVersionUID = 362498820763181265L
    serialPersistentFields = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, capacity):
        pass
    @classmethod
    def Oed___init____int__float(_SELF, capacity, loadFactor):
        pass
    @classmethod
    def Oed___init____Map(_SELF, map):
        pass
    @classmethod
    def constructorPutAll(_SELF, map):
        pass
    @classmethod
    def capacityForInitSize(_SELF, size):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def init(_SELF):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def containsKey(_SELF, key):
        pass
    @classmethod
    def containsValue(_SELF, value):
        pass
    @classmethod
    def put(_SELF, key, value):
        pass
    @classmethod
    def putValueForNullKey(_SELF, value):
        pass
    @classmethod
    def preModify(_SELF, e):
        pass
    @classmethod
    def constructorPut(_SELF, key, value):
        pass
    @classmethod
    def addNewEntry(_SELF, key, value, hash, index):
        pass
    @classmethod
    def addNewEntryForNullKey(_SELF, value):
        pass
    @classmethod
    def constructorNewEntry(_SELF, key, value, hash, first):
        pass
    @classmethod
    def putAll(_SELF, map):
        pass
    @classmethod
    def ensureCapacity(_SELF, numMappings):
        pass
    @classmethod
    def makeTable(_SELF, newCapacity):
        pass
    @classmethod
    def doubleCapacity(_SELF):
        pass
    @classmethod
    def remove(_SELF, key):
        pass
    @classmethod
    def removeNullKey(_SELF):
        pass
    @classmethod
    def postRemove(_SELF, e):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def keySet(_SELF):
        pass
    @classmethod
    def values(_SELF):
        pass
    @classmethod
    def entrySet(_SELF):
        pass
    @classmethod
    def containsMapping(_SELF, key, value):
        pass
    @classmethod
    def removeMapping(_SELF, key, value):
        pass
    @classmethod
    def newKeyIterator(_SELF):
        pass
    @classmethod
    def newValueIterator(_SELF):
        pass
    @classmethod
    def newEntryIterator(_SELF):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
class KeyIterator(object):
    @classmethod
    def next(_SELF):
        pass
HashMap.KeyIterator = KeyIterator
class ValueIterator(object):
    @classmethod
    def next(_SELF):
        pass
HashMap.ValueIterator = ValueIterator
class EntryIterator(object):
    @classmethod
    def next(_SELF):
        pass
HashMap.EntryIterator = EntryIterator
