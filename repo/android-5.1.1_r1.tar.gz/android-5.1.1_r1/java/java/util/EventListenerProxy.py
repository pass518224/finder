class EventListenerProxy(object):
    listener = None
    @classmethod
    def __init__(_SELF, listener):
        pass
    @classmethod
    def getListener(_SELF):
        pass
