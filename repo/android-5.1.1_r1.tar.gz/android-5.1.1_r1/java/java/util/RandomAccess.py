class RandomAccess(object):
    pass
