class MissingFormatArgumentException(object):
    serialVersionUID = 19190115L
    s = None
    @classmethod
    def __init__(_SELF, s):
        pass
    @classmethod
    def getFormatSpecifier(_SELF):
        pass
    @classmethod
    def getMessage(_SELF):
        pass
