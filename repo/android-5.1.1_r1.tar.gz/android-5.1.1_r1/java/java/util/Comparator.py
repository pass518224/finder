class Comparator(object):
    @classmethod
    def compare(_SELF, lhs, rhs):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
