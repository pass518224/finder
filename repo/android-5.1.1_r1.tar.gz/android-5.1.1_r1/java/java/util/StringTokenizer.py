class StringTokenizer(object):
    string = None
    delimiters = None
    returnDelimiters = None
    position = None
    
    @classmethod
    def nextToken(self, *args):
        fname = "Oed_nextToken__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____str(_SELF, string):
        pass
    @classmethod
    def Oed___init____str__str(_SELF, string, delimiters):
        pass
    @classmethod
    def Oed___init____str__str__bool(_SELF, string, delimiters, returnDelimiters):
        pass
    @classmethod
    def countTokens(_SELF):
        pass
    @classmethod
    def hasMoreElements(_SELF):
        pass
    @classmethod
    def hasMoreTokens(_SELF):
        pass
    @classmethod
    def nextElement(_SELF):
        pass
    @classmethod
    def Oed_nextToken__(_SELF):
        pass
    @classmethod
    def Oed_nextToken__str(_SELF, delims):
        pass
