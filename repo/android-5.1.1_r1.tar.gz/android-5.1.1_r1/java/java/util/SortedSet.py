class SortedSet(object):
    @classmethod
    def comparator(_SELF):
        pass
    @classmethod
    def first(_SELF):
        pass
    @classmethod
    def headSet(_SELF, end):
        pass
    @classmethod
    def last(_SELF):
        pass
    @classmethod
    def subSet(_SELF, start, end):
        pass
    @classmethod
    def tailSet(_SELF, start):
        pass
