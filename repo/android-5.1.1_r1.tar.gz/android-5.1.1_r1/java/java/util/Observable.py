class Observable(object):
    observers = None
    changed = False
    
    @classmethod
    def notifyObservers(self, *args):
        fname = "Oed_notifyObservers__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def addObserver(_SELF, observer):
        pass
    @classmethod
    def clearChanged(_SELF):
        pass
    @classmethod
    def countObservers(_SELF):
        pass
    @classmethod
    def deleteObserver(_SELF, observer):
        pass
    @classmethod
    def deleteObservers(_SELF):
        pass
    @classmethod
    def hasChanged(_SELF):
        pass
    @classmethod
    def Oed_notifyObservers__(_SELF):
        pass
    @classmethod
    def Oed_notifyObservers__Object(_SELF, data):
        pass
    @classmethod
    def setChanged(_SELF):
        pass
