class AbstractMap(object):
    keySet = None
    valuesCollection = None
    class SimpleImmutableEntry(object):
        serialVersionUID = 7138329143949025153L
        key = None
        value = None
        
        @classmethod
        def __init__(self, *args):
            fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def Oed___init____K__V(_SELF, theKey, theValue):
            pass
        @classmethod
        def Oed___init____Entry(_SELF, copyFrom):
            pass
        @classmethod
        def getKey(_SELF):
            pass
        @classmethod
        def getValue(_SELF):
            pass
        @classmethod
        def setValue(_SELF, object):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    class SimpleEntry(object):
        serialVersionUID = 8499721149061103585L
        key = None
        value = None
        
        @classmethod
        def __init__(self, *args):
            fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def Oed___init____K__V(_SELF, theKey, theValue):
            pass
        @classmethod
        def Oed___init____Entry(_SELF, copyFrom):
            pass
        @classmethod
        def getKey(_SELF):
            pass
        @classmethod
        def getValue(_SELF):
            pass
        @classmethod
        def setValue(_SELF, object):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def containsKey(_SELF, key):
        pass
    @classmethod
    def containsValue(_SELF, value):
        pass
    @classmethod
    def entrySet(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def keySet(_SELF):
        pass
    @classmethod
    def put(_SELF, key, value):
        pass
    @classmethod
    def putAll(_SELF, map):
        pass
    @classmethod
    def remove(_SELF, key):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def values(_SELF):
        pass
    @classmethod
    def clone(_SELF):
        pass
