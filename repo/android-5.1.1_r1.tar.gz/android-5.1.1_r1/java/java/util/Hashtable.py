class Hashtable(object):
    MINIMUM_CAPACITY = 4
    MAXIMUM_CAPACITY = None
    EMPTY_TABLE = None
    DEFAULT_LOAD_FACTOR = 0.75
    table = None
    size = None
    modCount = None
    threshold = None
    keySet = None
    entrySet = None
    values = None
    class HashtableEntry(object):
        key = None
        value = None
        hash = None
        next = None
        @classmethod
        def __init__(_SELF, key, value, hash, next):
            pass
        @classmethod
        def getKey(_SELF):
            pass
        @classmethod
        def getValue(_SELF):
            pass
        @classmethod
        def setValue(_SELF, value):
            pass
        @classmethod
        def equals(_SELF, o):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
    class HashIterator(object):
        nextIndex = None
        nextEntry = None
        lastEntryReturned = None
        expectedModCount = None
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def nextEntry(_SELF):
            pass
        @classmethod
        def nextEntryNotFailFast(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    CHARS_PER_ENTRY = 15
    class KeySet(object):
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def contains(_SELF, o):
            pass
        @classmethod
        def remove(_SELF, o):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def removeAll(_SELF, collection):
            pass
        @classmethod
        def retainAll(_SELF, collection):
            pass
        @classmethod
        def containsAll(_SELF, collection):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, a):
            pass
    class Values(object):
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def contains(_SELF, o):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def containsAll(_SELF, collection):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, a):
            pass
    class EntrySet(object):
        
        @classmethod
        def toArray(self, *args):
            fname = "Oed_toArray__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def iterator(_SELF):
            pass
        @classmethod
        def contains(_SELF, o):
            pass
        @classmethod
        def remove(_SELF, o):
            pass
        @classmethod
        def size(_SELF):
            pass
        @classmethod
        def clear(_SELF):
            pass
        @classmethod
        def removeAll(_SELF, collection):
            pass
        @classmethod
        def retainAll(_SELF, collection):
            pass
        @classmethod
        def containsAll(_SELF, collection):
            pass
        @classmethod
        def equals(_SELF, object):
            pass
        @classmethod
        def hashCode(_SELF):
            pass
        @classmethod
        def __str__(_SELF):
            pass
        @classmethod
        def Oed_toArray__(_SELF):
            pass
        @classmethod
        def Oed_toArray__list(_SELF, a):
            pass
    serialVersionUID = 1421746759512286392L
    serialPersistentFields = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, capacity):
        pass
    @classmethod
    def Oed___init____int__float(_SELF, capacity, loadFactor):
        pass
    @classmethod
    def Oed___init____Map(_SELF, map):
        pass
    @classmethod
    def constructorPutAll(_SELF, map):
        pass
    @classmethod
    def capacityForInitSize(_SELF, size):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def containsKey(_SELF, key):
        pass
    @classmethod
    def containsValue(_SELF, value):
        pass
    @classmethod
    def contains(_SELF, value):
        pass
    @classmethod
    def put(_SELF, key, value):
        pass
    @classmethod
    def constructorPut(_SELF, key, value):
        pass
    @classmethod
    def putAll(_SELF, map):
        pass
    @classmethod
    def ensureCapacity(_SELF, numMappings):
        pass
    @classmethod
    def rehash(_SELF):
        pass
    @classmethod
    def makeTable(_SELF, newCapacity):
        pass
    @classmethod
    def doubleCapacity(_SELF):
        pass
    @classmethod
    def remove(_SELF, key):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def keySet(_SELF):
        pass
    @classmethod
    def values(_SELF):
        pass
    @classmethod
    def entrySet(_SELF):
        pass
    @classmethod
    def keys(_SELF):
        pass
    @classmethod
    def elements(_SELF):
        pass
    @classmethod
    def containsMapping(_SELF, key, value):
        pass
    @classmethod
    def removeMapping(_SELF, key, value):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
class KeyEnumeration(object):
    @classmethod
    def hasMoreElements(_SELF):
        pass
    @classmethod
    def nextElement(_SELF):
        pass
Hashtable.KeyEnumeration = KeyEnumeration
class ValueEnumeration(object):
    @classmethod
    def hasMoreElements(_SELF):
        pass
    @classmethod
    def nextElement(_SELF):
        pass
Hashtable.ValueEnumeration = ValueEnumeration
class ValueIterator(object):
    @classmethod
    def next(_SELF):
        pass
Hashtable.ValueIterator = ValueIterator
class KeyIterator(object):
    @classmethod
    def next(_SELF):
        pass
Hashtable.KeyIterator = KeyIterator
class EntryIterator(object):
    @classmethod
    def next(_SELF):
        pass
Hashtable.EntryIterator = EntryIterator
