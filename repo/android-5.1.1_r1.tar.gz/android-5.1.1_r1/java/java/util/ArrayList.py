class ArrayList(object):
    def __init__(self, length=0):
        if  length > 0:
            self.list = [None]*length
        else:
            self.list = []

    def size(self):
        return len(self.list)

    def set(self, index, val):
        self.list[index] = val

    def add(self, item):
        self.list.append(item)

    def remove(self, index):
        del self.list[index]

