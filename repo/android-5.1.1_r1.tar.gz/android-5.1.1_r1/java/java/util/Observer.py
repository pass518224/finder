class Observer(object):
    @classmethod
    def update(_SELF, observable, data):
        pass
