class Date(object):
    serialVersionUID = 7523967970034938905L
    CREATION_YEAR = None
    milliseconds = None
    
    @classmethod
    def parse(self, *args):
        fname = "Oed_parse__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int__int__int(_SELF, year, month, day):
        pass
    @classmethod
    def Oed___init____int__int__int__int__int(_SELF, year, month, day, hour, minute):
        pass
    @classmethod
    def Oed___init____int__int__int__int__int__int(_SELF, year, month, day, hour, minute, second):
        pass
    @classmethod
    def Oed___init____int(_SELF, milliseconds):
        pass
    @classmethod
    def Oed___init____str(_SELF, string):
        pass
    @classmethod
    def after(_SELF, date):
        pass
    @classmethod
    def before(_SELF, date):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def compareTo(_SELF, date):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def getDate(_SELF):
        pass
    @classmethod
    def getDay(_SELF):
        pass
    @classmethod
    def getHours(_SELF):
        pass
    @classmethod
    def getMinutes(_SELF):
        pass
    @classmethod
    def getMonth(_SELF):
        pass
    @classmethod
    def getSeconds(_SELF):
        pass
    @classmethod
    def getTime(_SELF):
        pass
    @classmethod
    def getTimezoneOffset(_SELF):
        pass
    @classmethod
    def getYear(_SELF):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def Oed_parse__str__list(_SELF, string, array):
        pass
    @classmethod
    def parseError(_SELF, string):
        pass
    @classmethod
    def Oed_parse__str(_SELF, string):
        pass
    @classmethod
    def setDate(_SELF, day):
        pass
    @classmethod
    def setHours(_SELF, hour):
        pass
    @classmethod
    def setMinutes(_SELF, minute):
        pass
    @classmethod
    def setMonth(_SELF, month):
        pass
    @classmethod
    def setSeconds(_SELF, second):
        pass
    @classmethod
    def setTime(_SELF, milliseconds):
        pass
    @classmethod
    def setYear(_SELF, year):
        pass
    @classmethod
    def toGMTString(_SELF):
        pass
    @classmethod
    def toLocaleString(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def appendTwoDigits(_SELF, sb, n):
        pass
    @classmethod
    def UTC(_SELF, year, month, day, hour, minute, second):
        pass
    @classmethod
    def zone(_SELF, text):
        pass
    @classmethod
    def writeObject(_SELF, stream):
        pass
    @classmethod
    def readObject(_SELF, stream):
        pass
