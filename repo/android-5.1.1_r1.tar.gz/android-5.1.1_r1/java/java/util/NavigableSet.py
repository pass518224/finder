class NavigableSet(object):
    @classmethod
    def lower(_SELF, e):
        pass
    @classmethod
    def floor(_SELF, e):
        pass
    @classmethod
    def ceiling(_SELF, e):
        pass
    @classmethod
    def higher(_SELF, e):
        pass
    @classmethod
    def pollFirst(_SELF):
        pass
    @classmethod
    def pollLast(_SELF):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def descendingSet(_SELF):
        pass
    @classmethod
    def descendingIterator(_SELF):
        pass
    @classmethod
    def Oed_subSet__E__bool__E__bool(_SELF, fromElement, fromInclusive, toElement, toInclusive):
        pass
    @classmethod
    def Oed_headSet__E__bool(_SELF, toElement, inclusive):
        pass
    @classmethod
    def Oed_tailSet__E__bool(_SELF, fromElement, inclusive):
        pass
    @classmethod
    def Oed_subSet__E__E(_SELF, fromElement, toElement):
        pass
    @classmethod
    def Oed_headSet__E(_SELF, toElement):
        pass
    @classmethod
    def Oed_tailSet__E(_SELF, fromElement):
        pass
