class BitSet(object):
    serialVersionUID = 7997698588986878753L
    ALL_ONES = 0L
    bits = None
    longCount = None
    
    @classmethod
    def set(self, *args):
        fname = "Oed_set__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def get(self, *args):
        fname = "Oed_get__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def clear(self, *args):
        fname = "Oed_clear__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def valueOf(self, *args):
        fname = "Oed_valueOf__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def flip(self, *args):
        fname = "Oed_flip__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def shrinkSize(_SELF):
        pass
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, bitCount):
        pass
    @classmethod
    def Oed___init____list(_SELF, bits):
        pass
    @classmethod
    def arrayForBits(_SELF, bitCount):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def equals(_SELF, o):
        pass
    @classmethod
    def ensureCapacity(_SELF, desiredLongCount):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def Oed_get__int(_SELF, index):
        pass
    @classmethod
    def Oed_set__int(_SELF, index):
        pass
    @classmethod
    def Oed_clear__int(_SELF, index):
        pass
    @classmethod
    def Oed_flip__int(_SELF, index):
        pass
    @classmethod
    def checkIndex(_SELF, index):
        pass
    @classmethod
    def checkRange(_SELF, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_get__int__int(_SELF, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_set__int__bool(_SELF, index, state):
        pass
    @classmethod
    def Oed_set__int__int__bool(_SELF, fromIndex, toIndex, state):
        pass
    @classmethod
    def Oed_clear__(_SELF):
        pass
    @classmethod
    def Oed_set__int__int(_SELF, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_clear__int__int(_SELF, fromIndex, toIndex):
        pass
    @classmethod
    def Oed_flip__int__int(_SELF, fromIndex, toIndex):
        pass
    @classmethod
    def intersects(_SELF, bs):
        pass
    @classmethod
    def _and(_SELF, bs):
        pass
    @classmethod
    def andNot(_SELF, bs):
        pass
    @classmethod
    def _or(_SELF, bs):
        pass
    @classmethod
    def xor(_SELF, bs):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def length(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def nextSetBit(_SELF, index):
        pass
    @classmethod
    def nextClearBit(_SELF, index):
        pass
    @classmethod
    def previousSetBit(_SELF, index):
        pass
    @classmethod
    def previousClearBit(_SELF, index):
        pass
    @classmethod
    def isEmpty(_SELF):
        pass
    @classmethod
    def cardinality(_SELF):
        pass
    @classmethod
    def Oed_valueOf__list(_SELF, longs):
        pass
    @classmethod
    def Oed_valueOf__LongBuffer(_SELF, longBuffer):
        pass
    @classmethod
    def Oed_valueOf__list(_SELF, bytes):
        pass
    @classmethod
    def Oed_valueOf__ByteBuffer(_SELF, byteBuffer):
        pass
    @classmethod
    def toLongArray(_SELF):
        pass
    @classmethod
    def toByteArray(_SELF):
        pass
    @classmethod
    def readObject(_SELF, ois):
        pass
