class FormatterClosedException(object):
    serialVersionUID = 18111216L
    @classmethod
    def __init__(_SELF):
        pass
