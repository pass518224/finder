class AbstractList(object):
    modCount = None
    class SimpleListIterator(object):
        pos = 1
        expectedModCount = None
        lastPosition = 1
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    
    @classmethod
    def add(self, *args):
        fname = "Oed_add__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def listIterator(self, *args):
        fname = "Oed_listIterator__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def Oed_add__int__E(_SELF, location, object):
        pass
    @classmethod
    def Oed_add__E(_SELF, object):
        pass
    @classmethod
    def addAll(_SELF, location, collection):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def get(_SELF, location):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def indexOf(_SELF, object):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def lastIndexOf(_SELF, object):
        pass
    @classmethod
    def Oed_listIterator__(_SELF):
        pass
    @classmethod
    def Oed_listIterator__int(_SELF, location):
        pass
    @classmethod
    def remove(_SELF, location):
        pass
    @classmethod
    def removeRange(_SELF, start, end):
        pass
    @classmethod
    def set(_SELF, location, object):
        pass
    @classmethod
    def subList(_SELF, start, end):
        pass
class FullListIterator(object):
    @classmethod
    def __init__(_SELF, start):
        pass
    @classmethod
    def add(_SELF, object):
        pass
    @classmethod
    def hasPrevious(_SELF):
        pass
    @classmethod
    def nextIndex(_SELF):
        pass
    @classmethod
    def previous(_SELF):
        pass
    @classmethod
    def previousIndex(_SELF):
        pass
    @classmethod
    def set(_SELF, object):
        pass
AbstractList.FullListIterator = FullListIterator
class SubAbstractList(object):
    fullList = None
    offset = None
    size = None
    class SubAbstractListIterator(object):
        subList = None
        iterator = None
        start = None
        end = None
        @classmethod
        def __init__(_SELF, it, list, offset, length):
            pass
        @classmethod
        def add(_SELF, object):
            pass
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def hasPrevious(_SELF):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def nextIndex(_SELF):
            pass
        @classmethod
        def previous(_SELF):
            pass
        @classmethod
        def previousIndex(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
        @classmethod
        def set(_SELF, object):
            pass
    
    @classmethod
    def addAll(self, *args):
        fname = "Oed_addAll__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, list, start, end):
        pass
    @classmethod
    def add(_SELF, location, object):
        pass
    @classmethod
    def Oed_addAll__int__Collection(_SELF, location, collection):
        pass
    @classmethod
    def Oed_addAll__Collection(_SELF, collection):
        pass
    @classmethod
    def get(_SELF, location):
        pass
    @classmethod
    def iterator(_SELF):
        pass
    @classmethod
    def listIterator(_SELF, location):
        pass
    @classmethod
    def remove(_SELF, location):
        pass
    @classmethod
    def removeRange(_SELF, start, end):
        pass
    @classmethod
    def set(_SELF, location, object):
        pass
    @classmethod
    def size(_SELF):
        pass
    @classmethod
    def sizeChanged(_SELF, increment):
        pass
AbstractList.SubAbstractList = SubAbstractList
class SubAbstractListRandomAccess(object):
    @classmethod
    def __init__(_SELF, list, start, end):
        pass
AbstractList.SubAbstractListRandomAccess = SubAbstractListRandomAccess
