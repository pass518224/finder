class LinkedHashMap(object):
    header = None
    accessOrder = None
    class LinkedEntry(object):
        nxt = None
        prv = None
        
        @classmethod
        def __init__(self, *args):
            fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def Oed___init____(_SELF):
            pass
        @classmethod
        def Oed___init____K__V__int__HashMapEntry__LinkedEntry__LinkedEntry(_SELF, key, value, hash, next, nxt, prv):
            pass
    class LinkedHashIterator(object):
        next = None
        lastReturned = None
        expectedModCount = None
        @classmethod
        def hasNext(_SELF):
            pass
        @classmethod
        def nextEntry(_SELF):
            pass
        @classmethod
        def remove(_SELF):
            pass
    serialVersionUID = 3801124242820219131L
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____(_SELF):
        pass
    @classmethod
    def Oed___init____int(_SELF, initialCapacity):
        pass
    @classmethod
    def Oed___init____int__float(_SELF, initialCapacity, loadFactor):
        pass
    @classmethod
    def Oed___init____int__float__bool(_SELF, initialCapacity, loadFactor, accessOrder):
        pass
    @classmethod
    def Oed___init____Map(_SELF, map):
        pass
    @classmethod
    def init(_SELF):
        pass
    @classmethod
    def eldest(_SELF):
        pass
    @classmethod
    def addNewEntry(_SELF, key, value, hash, index):
        pass
    @classmethod
    def addNewEntryForNullKey(_SELF, value):
        pass
    @classmethod
    def constructorNewEntry(_SELF, key, value, hash, next):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def makeTail(_SELF, e):
        pass
    @classmethod
    def preModify(_SELF, e):
        pass
    @classmethod
    def postRemove(_SELF, e):
        pass
    @classmethod
    def containsValue(_SELF, value):
        pass
    @classmethod
    def clear(_SELF):
        pass
    @classmethod
    def newKeyIterator(_SELF):
        pass
    @classmethod
    def newValueIterator(_SELF):
        pass
    @classmethod
    def newEntryIterator(_SELF):
        pass
    @classmethod
    def removeEldestEntry(_SELF, eldest):
        pass
class KeyIterator(object):
    @classmethod
    def next(_SELF):
        pass
LinkedHashMap.KeyIterator = KeyIterator
class ValueIterator(object):
    @classmethod
    def next(_SELF):
        pass
LinkedHashMap.ValueIterator = ValueIterator
class EntryIterator(object):
    @classmethod
    def next(_SELF):
        pass
LinkedHashMap.EntryIterator = EntryIterator
