class StringPool(object):
    pool = None
    @classmethod
    def contentEquals(_SELF, s, chars, start, length):
        pass
    @classmethod
    def get(_SELF, array, start, length):
        pass
