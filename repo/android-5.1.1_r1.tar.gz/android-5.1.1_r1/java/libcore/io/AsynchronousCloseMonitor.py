class AsynchronousCloseMonitor(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def signalBlockedThreads(_SELF, fd):
        pass
