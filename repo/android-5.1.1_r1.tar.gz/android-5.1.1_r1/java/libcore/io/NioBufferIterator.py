class NioBufferIterator(object):
    address = None
    size = None
    swap = None
    position = None
    @classmethod
    def __init__(_SELF, address, size, swap):
        pass
    @classmethod
    def seek(_SELF, offset):
        pass
    @classmethod
    def skip(_SELF, byteCount):
        pass
    @classmethod
    def readByteArray(_SELF, dst, dstOffset, byteCount):
        pass
    @classmethod
    def readByte(_SELF):
        pass
    @classmethod
    def readInt(_SELF):
        pass
    @classmethod
    def readIntArray(_SELF, dst, dstOffset, intCount):
        pass
    @classmethod
    def readShort(_SELF):
        pass
