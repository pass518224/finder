class DeleteOnExit(object):
    instance = None
    files = None
    @classmethod
    def getInstance(_SELF):
        pass
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def addFile(_SELF, filename):
        pass
    @classmethod
    def run(_SELF):
        pass
