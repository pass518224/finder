class MemoryMappedFile(object):
    address = None
    size = None
    @classmethod
    def __init__(_SELF, address, size):
        pass
    @classmethod
    def mmapRO(_SELF, path):
        pass
    @classmethod
    def close(_SELF):
        pass
    @classmethod
    def bigEndianIterator(_SELF):
        pass
    @classmethod
    def littleEndianIterator(_SELF):
        pass
    @classmethod
    def size(_SELF):
        pass
