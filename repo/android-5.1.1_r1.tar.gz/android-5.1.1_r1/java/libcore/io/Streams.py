class Streams(object):
    skipBuffer = None
    
    @classmethod
    def readFully(self, *args):
        fname = "Oed_readFully__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def readSingleByte(_SELF, _in):
        pass
    @classmethod
    def writeSingleByte(_SELF, out, b):
        pass
    @classmethod
    def Oed_readFully__InputStream__list(_SELF, _in, dst):
        pass
    @classmethod
    def Oed_readFully__InputStream__list__int__int(_SELF, _in, dst, offset, byteCount):
        pass
    @classmethod
    def Oed_readFully__InputStream(_SELF, _in):
        pass
    @classmethod
    def readFullyNoClose(_SELF, _in):
        pass
    @classmethod
    def Oed_readFully__Reader(_SELF, reader):
        pass
    @classmethod
    def skipAll(_SELF, _in):
        pass
    @classmethod
    def skipByReading(_SELF, _in, byteCount):
        pass
    @classmethod
    def copy(_SELF, _in, out):
        pass
    @classmethod
    def readAsciiLine(_SELF, _in):
        pass
