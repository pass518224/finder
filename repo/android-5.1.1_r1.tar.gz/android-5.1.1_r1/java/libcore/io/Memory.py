class Memory(object):
    
    @classmethod
    def peekInt(self, *args):
        fname = "Oed_peekInt__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def pokeLong(self, *args):
        fname = "Oed_pokeLong__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def pokeShort(self, *args):
        fname = "Oed_pokeShort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def peekShort(self, *args):
        fname = "Oed_peekShort__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def peekLong(self, *args):
        fname = "Oed_peekLong__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def pokeInt(self, *args):
        fname = "Oed_pokeInt__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def unsafeBulkGet(_SELF, dst, dstOffset, byteCount, src, srcOffset, sizeofElements, swap):
        pass
    @classmethod
    def unsafeBulkPut(_SELF, dst, dstOffset, byteCount, src, srcOffset, sizeofElements, swap):
        pass
    @classmethod
    def Oed_peekInt__list__int__ByteOrder(_SELF, src, offset, order):
        pass
    @classmethod
    def Oed_peekLong__list__int__ByteOrder(_SELF, src, offset, order):
        pass
    @classmethod
    def Oed_peekShort__list__int__ByteOrder(_SELF, src, offset, order):
        pass
    @classmethod
    def Oed_pokeInt__list__int__int__ByteOrder(_SELF, dst, offset, value, order):
        pass
    @classmethod
    def Oed_pokeLong__list__int__int__ByteOrder(_SELF, dst, offset, value, order):
        pass
    @classmethod
    def Oed_pokeShort__list__int__short__ByteOrder(_SELF, dst, offset, value, order):
        pass
    @classmethod
    def memmove(_SELF, dstObject, dstOffset, srcObject, srcOffset, byteCount):
        pass
    @classmethod
    def peekByte(_SELF, address):
        pass
    @classmethod
    def Oed_peekInt__int__bool(_SELF, address, swap):
        pass
    @classmethod
    def peekIntNative(_SELF, address):
        pass
    @classmethod
    def Oed_peekLong__int__bool(_SELF, address, swap):
        pass
    @classmethod
    def peekLongNative(_SELF, address):
        pass
    @classmethod
    def Oed_peekShort__int__bool(_SELF, address, swap):
        pass
    @classmethod
    def peekShortNative(_SELF, address):
        pass
    @classmethod
    def peekByteArray(_SELF, address, dst, dstOffset, byteCount):
        pass
    @classmethod
    def peekCharArray(_SELF, address, dst, dstOffset, charCount, swap):
        pass
    @classmethod
    def peekDoubleArray(_SELF, address, dst, dstOffset, doubleCount, swap):
        pass
    @classmethod
    def peekFloatArray(_SELF, address, dst, dstOffset, floatCount, swap):
        pass
    @classmethod
    def peekIntArray(_SELF, address, dst, dstOffset, intCount, swap):
        pass
    @classmethod
    def peekLongArray(_SELF, address, dst, dstOffset, longCount, swap):
        pass
    @classmethod
    def peekShortArray(_SELF, address, dst, dstOffset, shortCount, swap):
        pass
    @classmethod
    def pokeByte(_SELF, address, value):
        pass
    @classmethod
    def Oed_pokeInt__int__int__bool(_SELF, address, value, swap):
        pass
    @classmethod
    def pokeIntNative(_SELF, address, value):
        pass
    @classmethod
    def Oed_pokeLong__int__int__bool(_SELF, address, value, swap):
        pass
    @classmethod
    def pokeLongNative(_SELF, address, value):
        pass
    @classmethod
    def Oed_pokeShort__int__short__bool(_SELF, address, value, swap):
        pass
    @classmethod
    def pokeShortNative(_SELF, address, value):
        pass
    @classmethod
    def pokeByteArray(_SELF, address, src, offset, count):
        pass
    @classmethod
    def pokeCharArray(_SELF, address, src, offset, count, swap):
        pass
    @classmethod
    def pokeDoubleArray(_SELF, address, src, offset, count, swap):
        pass
    @classmethod
    def pokeFloatArray(_SELF, address, src, offset, count, swap):
        pass
    @classmethod
    def pokeIntArray(_SELF, address, src, offset, count, swap):
        pass
    @classmethod
    def pokeLongArray(_SELF, address, src, offset, count, swap):
        pass
    @classmethod
    def pokeShortArray(_SELF, address, src, offset, count, swap):
        pass
