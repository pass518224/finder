class BlockGuardOs(object):
    
    @classmethod
    def write(self, *args):
        fname = "Oed_write__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def pwrite(self, *args):
        fname = "Oed_pwrite__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def read(self, *args):
        fname = "Oed_read__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def recvfrom(self, *args):
        fname = "Oed_recvfrom__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def sendto(self, *args):
        fname = "Oed_sendto__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def pread(self, *args):
        fname = "Oed_pread__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, os):
        pass
    @classmethod
    def tagSocket(_SELF, fd):
        pass
    @classmethod
    def untagSocket(_SELF, fd):
        pass
    @classmethod
    def accept(_SELF, fd, peerAddress):
        pass
    @classmethod
    def access(_SELF, path, mode):
        pass
    @classmethod
    def chmod(_SELF, path, mode):
        pass
    @classmethod
    def chown(_SELF, path, uid, gid):
        pass
    @classmethod
    def close(_SELF, fd):
        pass
    @classmethod
    def isLingerSocket(_SELF, fd):
        pass
    @classmethod
    def connect(_SELF, fd, address, port):
        pass
    @classmethod
    def fchmod(_SELF, fd, mode):
        pass
    @classmethod
    def fchown(_SELF, fd, uid, gid):
        pass
    @classmethod
    def fdatasync(_SELF, fd):
        pass
    @classmethod
    def fstat(_SELF, fd):
        pass
    @classmethod
    def fstatvfs(_SELF, fd):
        pass
    @classmethod
    def fsync(_SELF, fd):
        pass
    @classmethod
    def ftruncate(_SELF, fd, length):
        pass
    @classmethod
    def lchown(_SELF, path, uid, gid):
        pass
    @classmethod
    def link(_SELF, oldPath, newPath):
        pass
    @classmethod
    def lseek(_SELF, fd, offset, whence):
        pass
    @classmethod
    def lstat(_SELF, path):
        pass
    @classmethod
    def mkdir(_SELF, path, mode):
        pass
    @classmethod
    def mkfifo(_SELF, path, mode):
        pass
    @classmethod
    def open(_SELF, path, flags, mode):
        pass
    @classmethod
    def poll(_SELF, fds, timeoutMs):
        pass
    @classmethod
    def posix_fallocate(_SELF, fd, offset, length):
        pass
    @classmethod
    def Oed_pread__FileDescriptor__ByteBuffer__int(_SELF, fd, buffer, offset):
        pass
    @classmethod
    def Oed_pread__FileDescriptor__list__int__int__int(_SELF, fd, bytes, byteOffset, byteCount, offset):
        pass
    @classmethod
    def Oed_pwrite__FileDescriptor__ByteBuffer__int(_SELF, fd, buffer, offset):
        pass
    @classmethod
    def Oed_pwrite__FileDescriptor__list__int__int__int(_SELF, fd, bytes, byteOffset, byteCount, offset):
        pass
    @classmethod
    def Oed_read__FileDescriptor__ByteBuffer(_SELF, fd, buffer):
        pass
    @classmethod
    def Oed_read__FileDescriptor__list__int__int(_SELF, fd, bytes, byteOffset, byteCount):
        pass
    @classmethod
    def readlink(_SELF, path):
        pass
    @classmethod
    def readv(_SELF, fd, buffers, offsets, byteCounts):
        pass
    @classmethod
    def Oed_recvfrom__FileDescriptor__ByteBuffer__int__InetSocketAddress(_SELF, fd, buffer, flags, srcAddress):
        pass
    @classmethod
    def Oed_recvfrom__FileDescriptor__list__int__int__int__InetSocketAddress(_SELF, fd, bytes, byteOffset, byteCount, flags, srcAddress):
        pass
    @classmethod
    def remove(_SELF, path):
        pass
    @classmethod
    def rename(_SELF, oldPath, newPath):
        pass
    @classmethod
    def sendfile(_SELF, outFd, inFd, inOffset, byteCount):
        pass
    @classmethod
    def Oed_sendto__FileDescriptor__ByteBuffer__int__InetAddress__int(_SELF, fd, buffer, flags, inetAddress, port):
        pass
    @classmethod
    def Oed_sendto__FileDescriptor__list__int__int__int__InetAddress__int(_SELF, fd, bytes, byteOffset, byteCount, flags, inetAddress, port):
        pass
    @classmethod
    def socket(_SELF, domain, type, protocol):
        pass
    @classmethod
    def socketpair(_SELF, domain, type, protocol, fd1, fd2):
        pass
    @classmethod
    def stat(_SELF, path):
        pass
    @classmethod
    def statvfs(_SELF, path):
        pass
    @classmethod
    def symlink(_SELF, oldPath, newPath):
        pass
    @classmethod
    def Oed_write__FileDescriptor__ByteBuffer(_SELF, fd, buffer):
        pass
    @classmethod
    def Oed_write__FileDescriptor__list__int__int(_SELF, fd, bytes, byteOffset, byteCount):
        pass
    @classmethod
    def writev(_SELF, fd, buffers, offsets, byteCounts):
        pass
