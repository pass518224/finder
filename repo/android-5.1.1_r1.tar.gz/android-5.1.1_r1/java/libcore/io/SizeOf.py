class SizeOf(object):
    CHAR = 2
    DOUBLE = 8
    FLOAT = 4
    INT = 4
    LONG = 8
    SHORT = 2
    @classmethod
    def __init__(_SELF):
        pass
