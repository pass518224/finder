class StrictLineReader(object):
    CR = None
    LF = None
    _in = None
    charset = None
    buf = None
    pos = None
    end = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____InputStream(_SELF, _in):
        pass
    @classmethod
    def Oed___init____InputStream__int(_SELF, _in, capacity):
        pass
    @classmethod
    def Oed___init____InputStream__Charset(_SELF, _in, charset):
        pass
    @classmethod
    def Oed___init____InputStream__int__Charset(_SELF, _in, capacity, charset):
        pass
    @classmethod
    def close(_SELF):
        pass
    @classmethod
    def readLine(_SELF):
        pass
    @classmethod
    def readInt(_SELF):
        pass
    @classmethod
    def hasUnterminatedLine(_SELF):
        pass
    @classmethod
    def fillBuf(_SELF):
        pass
