class Posix(object):
    
    @classmethod
    def write(self, *args):
        fname = "Oed_write__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def pwrite(self, *args):
        fname = "Oed_pwrite__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def read(self, *args):
        fname = "Oed_read__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def recvfrom(self, *args):
        fname = "Oed_recvfrom__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def sendto(self, *args):
        fname = "Oed_sendto__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def pread(self, *args):
        fname = "Oed_pread__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def accept(_SELF, fd, peerAddress):
        pass
    @classmethod
    def access(_SELF, path, mode):
        pass
    @classmethod
    def android_getaddrinfo(_SELF, node, hints, netId):
        pass
    @classmethod
    def bind(_SELF, fd, address, port):
        pass
    @classmethod
    def chmod(_SELF, path, mode):
        pass
    @classmethod
    def chown(_SELF, path, uid, gid):
        pass
    @classmethod
    def close(_SELF, fd):
        pass
    @classmethod
    def connect(_SELF, fd, address, port):
        pass
    @classmethod
    def dup(_SELF, oldFd):
        pass
    @classmethod
    def dup2(_SELF, oldFd, newFd):
        pass
    @classmethod
    def environ(_SELF):
        pass
    @classmethod
    def execv(_SELF, filename, argv):
        pass
    @classmethod
    def execve(_SELF, filename, argv, envp):
        pass
    @classmethod
    def fchmod(_SELF, fd, mode):
        pass
    @classmethod
    def fchown(_SELF, fd, uid, gid):
        pass
    @classmethod
    def fcntlVoid(_SELF, fd, cmd):
        pass
    @classmethod
    def fcntlLong(_SELF, fd, cmd, arg):
        pass
    @classmethod
    def fcntlFlock(_SELF, fd, cmd, arg):
        pass
    @classmethod
    def fdatasync(_SELF, fd):
        pass
    @classmethod
    def fstat(_SELF, fd):
        pass
    @classmethod
    def fstatvfs(_SELF, fd):
        pass
    @classmethod
    def fsync(_SELF, fd):
        pass
    @classmethod
    def ftruncate(_SELF, fd, length):
        pass
    @classmethod
    def gai_strerror(_SELF, error):
        pass
    @classmethod
    def getegid(_SELF):
        pass
    @classmethod
    def geteuid(_SELF):
        pass
    @classmethod
    def getgid(_SELF):
        pass
    @classmethod
    def getenv(_SELF, name):
        pass
    @classmethod
    def getnameinfo(_SELF, address, flags):
        pass
    @classmethod
    def getpeername(_SELF, fd):
        pass
    @classmethod
    def getpid(_SELF):
        pass
    @classmethod
    def getppid(_SELF):
        pass
    @classmethod
    def getpwnam(_SELF, name):
        pass
    @classmethod
    def getpwuid(_SELF, uid):
        pass
    @classmethod
    def getsockname(_SELF, fd):
        pass
    @classmethod
    def getsockoptByte(_SELF, fd, level, option):
        pass
    @classmethod
    def getsockoptInAddr(_SELF, fd, level, option):
        pass
    @classmethod
    def getsockoptInt(_SELF, fd, level, option):
        pass
    @classmethod
    def getsockoptLinger(_SELF, fd, level, option):
        pass
    @classmethod
    def getsockoptTimeval(_SELF, fd, level, option):
        pass
    @classmethod
    def getsockoptUcred(_SELF, fd, level, option):
        pass
    @classmethod
    def gettid(_SELF):
        pass
    @classmethod
    def getuid(_SELF):
        pass
    @classmethod
    def if_indextoname(_SELF, index):
        pass
    @classmethod
    def inet_pton(_SELF, family, address):
        pass
    @classmethod
    def ioctlInetAddress(_SELF, fd, cmd, interfaceName):
        pass
    @classmethod
    def ioctlInt(_SELF, fd, cmd, arg):
        pass
    @classmethod
    def isatty(_SELF, fd):
        pass
    @classmethod
    def kill(_SELF, pid, signal):
        pass
    @classmethod
    def lchown(_SELF, path, uid, gid):
        pass
    @classmethod
    def link(_SELF, oldPath, newPath):
        pass
    @classmethod
    def listen(_SELF, fd, backlog):
        pass
    @classmethod
    def lseek(_SELF, fd, offset, whence):
        pass
    @classmethod
    def lstat(_SELF, path):
        pass
    @classmethod
    def mincore(_SELF, address, byteCount, vector):
        pass
    @classmethod
    def mkdir(_SELF, path, mode):
        pass
    @classmethod
    def mkfifo(_SELF, path, mode):
        pass
    @classmethod
    def mlock(_SELF, address, byteCount):
        pass
    @classmethod
    def mmap(_SELF, address, byteCount, prot, flags, fd, offset):
        pass
    @classmethod
    def msync(_SELF, address, byteCount, flags):
        pass
    @classmethod
    def munlock(_SELF, address, byteCount):
        pass
    @classmethod
    def munmap(_SELF, address, byteCount):
        pass
    @classmethod
    def open(_SELF, path, flags, mode):
        pass
    @classmethod
    def pipe(_SELF):
        pass
    @classmethod
    def poll(_SELF, fds, timeoutMs):
        pass
    @classmethod
    def posix_fallocate(_SELF, fd, offset, length):
        pass
    @classmethod
    def prctl(_SELF, option, arg2, arg3, arg4, arg5):
        pass
    @classmethod
    def Oed_pread__FileDescriptor__ByteBuffer__int(_SELF, fd, buffer, offset):
        pass
    @classmethod
    def Oed_pread__FileDescriptor__list__int__int__int(_SELF, fd, bytes, byteOffset, byteCount, offset):
        pass
    @classmethod
    def preadBytes(_SELF, fd, buffer, bufferOffset, byteCount, offset):
        pass
    @classmethod
    def Oed_pwrite__FileDescriptor__ByteBuffer__int(_SELF, fd, buffer, offset):
        pass
    @classmethod
    def Oed_pwrite__FileDescriptor__list__int__int__int(_SELF, fd, bytes, byteOffset, byteCount, offset):
        pass
    @classmethod
    def pwriteBytes(_SELF, fd, buffer, bufferOffset, byteCount, offset):
        pass
    @classmethod
    def Oed_read__FileDescriptor__ByteBuffer(_SELF, fd, buffer):
        pass
    @classmethod
    def Oed_read__FileDescriptor__list__int__int(_SELF, fd, bytes, byteOffset, byteCount):
        pass
    @classmethod
    def readBytes(_SELF, fd, buffer, offset, byteCount):
        pass
    @classmethod
    def readlink(_SELF, path):
        pass
    @classmethod
    def readv(_SELF, fd, buffers, offsets, byteCounts):
        pass
    @classmethod
    def Oed_recvfrom__FileDescriptor__ByteBuffer__int__InetSocketAddress(_SELF, fd, buffer, flags, srcAddress):
        pass
    @classmethod
    def Oed_recvfrom__FileDescriptor__list__int__int__int__InetSocketAddress(_SELF, fd, bytes, byteOffset, byteCount, flags, srcAddress):
        pass
    @classmethod
    def recvfromBytes(_SELF, fd, buffer, byteOffset, byteCount, flags, srcAddress):
        pass
    @classmethod
    def remove(_SELF, path):
        pass
    @classmethod
    def rename(_SELF, oldPath, newPath):
        pass
    @classmethod
    def sendfile(_SELF, outFd, inFd, inOffset, byteCount):
        pass
    @classmethod
    def Oed_sendto__FileDescriptor__ByteBuffer__int__InetAddress__int(_SELF, fd, buffer, flags, inetAddress, port):
        pass
    @classmethod
    def Oed_sendto__FileDescriptor__list__int__int__int__InetAddress__int(_SELF, fd, bytes, byteOffset, byteCount, flags, inetAddress, port):
        pass
    @classmethod
    def sendtoBytes(_SELF, fd, buffer, byteOffset, byteCount, flags, inetAddress, port):
        pass
    @classmethod
    def setegid(_SELF, egid):
        pass
    @classmethod
    def setenv(_SELF, name, value, overwrite):
        pass
    @classmethod
    def seteuid(_SELF, euid):
        pass
    @classmethod
    def setgid(_SELF, gid):
        pass
    @classmethod
    def setsid(_SELF):
        pass
    @classmethod
    def setsockoptByte(_SELF, fd, level, option, value):
        pass
    @classmethod
    def setsockoptIfreq(_SELF, fd, level, option, value):
        pass
    @classmethod
    def setsockoptInt(_SELF, fd, level, option, value):
        pass
    @classmethod
    def setsockoptIpMreqn(_SELF, fd, level, option, value):
        pass
    @classmethod
    def setsockoptGroupReq(_SELF, fd, level, option, value):
        pass
    @classmethod
    def setsockoptGroupSourceReq(_SELF, fd, level, option, value):
        pass
    @classmethod
    def setsockoptLinger(_SELF, fd, level, option, value):
        pass
    @classmethod
    def setsockoptTimeval(_SELF, fd, level, option, value):
        pass
    @classmethod
    def setuid(_SELF, uid):
        pass
    @classmethod
    def shutdown(_SELF, fd, how):
        pass
    @classmethod
    def socket(_SELF, domain, type, protocol):
        pass
    @classmethod
    def socketpair(_SELF, domain, type, protocol, fd1, fd2):
        pass
    @classmethod
    def stat(_SELF, path):
        pass
    @classmethod
    def statvfs(_SELF, path):
        pass
    @classmethod
    def strerror(_SELF, errno):
        pass
    @classmethod
    def strsignal(_SELF, signal):
        pass
    @classmethod
    def symlink(_SELF, oldPath, newPath):
        pass
    @classmethod
    def sysconf(_SELF, name):
        pass
    @classmethod
    def tcdrain(_SELF, fd):
        pass
    @classmethod
    def tcsendbreak(_SELF, fd, duration):
        pass
    @classmethod
    def umask(_SELF, mask):
        pass
    @classmethod
    def umaskImpl(_SELF, mask):
        pass
    @classmethod
    def uname(_SELF):
        pass
    @classmethod
    def unsetenv(_SELF, name):
        pass
    @classmethod
    def waitpid(_SELF, pid, status, options):
        pass
    @classmethod
    def Oed_write__FileDescriptor__ByteBuffer(_SELF, fd, buffer):
        pass
    @classmethod
    def Oed_write__FileDescriptor__list__int__int(_SELF, fd, bytes, byteOffset, byteCount):
        pass
    @classmethod
    def writeBytes(_SELF, fd, buffer, offset, byteCount):
        pass
    @classmethod
    def writev(_SELF, fd, buffers, offsets, byteCounts):
        pass
    @classmethod
    def maybeUpdateBufferPosition(_SELF, buffer, originalPosition, bytesReadOrWritten):
        pass
