class Libcore(object):
    os = None
    @classmethod
    def __init__(_SELF):
        pass
