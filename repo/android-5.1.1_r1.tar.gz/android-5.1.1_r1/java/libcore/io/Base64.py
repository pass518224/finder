class Base64(object):
    map = None
    
    @classmethod
    def decode(self, *args):
        fname = "Oed_decode__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def Oed_decode__list(_SELF, _in):
        pass
    @classmethod
    def Oed_decode__list__int(_SELF, _in, len):
        pass
    @classmethod
    def encode(_SELF, _in):
        pass
