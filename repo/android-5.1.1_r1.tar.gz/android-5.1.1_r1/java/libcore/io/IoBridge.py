class IoBridge(object):
    JAVA_MCAST_JOIN_GROUP = 19
    JAVA_MCAST_LEAVE_GROUP = 20
    JAVA_MCAST_JOIN_SOURCE_GROUP = 21
    JAVA_MCAST_LEAVE_SOURCE_GROUP = 22
    JAVA_MCAST_BLOCK_SOURCE = 23
    JAVA_MCAST_UNBLOCK_SOURCE = 24
    JAVA_IP_MULTICAST_TTL = 17
    
    @classmethod
    def recvfrom(self, *args):
        fname = "Oed_recvfrom__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def connect(self, *args):
        fname = "Oed_connect__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def sendto(self, *args):
        fname = "Oed_sendto__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def available(_SELF, fd):
        pass
    @classmethod
    def bind(_SELF, fd, address, port):
        pass
    @classmethod
    def Oed_connect__FileDescriptor__InetAddress__int(_SELF, fd, inetAddress, port):
        pass
    @classmethod
    def Oed_connect__FileDescriptor__InetAddress__int__int(_SELF, fd, inetAddress, port, timeoutMs):
        pass
    @classmethod
    def connectErrno(_SELF, fd, inetAddress, port, timeoutMs):
        pass
    @classmethod
    def connectDetail(_SELF, inetAddress, port, timeoutMs, cause):
        pass
    @classmethod
    def closeAndSignalBlockedThreads(_SELF, fd):
        pass
    @classmethod
    def isConnected(_SELF, fd, inetAddress, port, timeoutMs, remainingTimeoutMs):
        pass
    @classmethod
    def getSocketOption(_SELF, fd, option):
        pass
    @classmethod
    def getSocketOptionErrno(_SELF, fd, option):
        pass
    @classmethod
    def booleanFromInt(_SELF, i):
        pass
    @classmethod
    def booleanToInt(_SELF, b):
        pass
    @classmethod
    def setSocketOption(_SELF, fd, option, value):
        pass
    @classmethod
    def setSocketOptionErrno(_SELF, fd, option, value):
        pass
    @classmethod
    def getGroupSourceReqOp(_SELF, javaValue):
        pass
    @classmethod
    def open(_SELF, path, flags):
        pass
    @classmethod
    def read(_SELF, fd, bytes, byteOffset, byteCount):
        pass
    @classmethod
    def write(_SELF, fd, bytes, byteOffset, byteCount):
        pass
    @classmethod
    def Oed_sendto__FileDescriptor__list__int__int__int__InetAddress__int(_SELF, fd, bytes, byteOffset, byteCount, flags, inetAddress, port):
        pass
    @classmethod
    def Oed_sendto__FileDescriptor__ByteBuffer__int__InetAddress__int(_SELF, fd, buffer, flags, inetAddress, port):
        pass
    @classmethod
    def maybeThrowAfterSendto(_SELF, isDatagram, errnoException):
        pass
    @classmethod
    def Oed_recvfrom__bool__FileDescriptor__list__int__int__int__DatagramPacket__bool(_SELF, isRead, fd, bytes, byteOffset, byteCount, flags, packet, isConnected):
        pass
    @classmethod
    def Oed_recvfrom__bool__FileDescriptor__ByteBuffer__int__DatagramPacket__bool(_SELF, isRead, fd, buffer, flags, packet, isConnected):
        pass
    @classmethod
    def postRecvfrom(_SELF, isRead, packet, isConnected, srcAddress, byteCount):
        pass
    @classmethod
    def maybeThrowAfterRecvfrom(_SELF, isRead, isConnected, errnoException):
        pass
    @classmethod
    def socket(_SELF, stream):
        pass
    @classmethod
    def getSocketLocalAddress(_SELF, fd):
        pass
    @classmethod
    def getSocketLocalPort(_SELF, fd):
        pass
