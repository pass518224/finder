class IoUtils(object):
    TEMPORARY_DIRECTORY_PRNG = None
    class FileReader(object):
        fd = None
        unknownLength = None
        bytes = None
        count = None
        @classmethod
        def __init__(_SELF, absolutePath):
            pass
        @classmethod
        def readFully(_SELF):
            pass
        @classmethod
        def toByteArray(_SELF):
            pass
        @classmethod
        def __str__(_SELF, cs):
            pass
    
    @classmethod
    def closeQuietly(self, *args):
        fname = "Oed_closeQuietly__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def close(_SELF, fd):
        pass
    @classmethod
    def Oed_closeQuietly__AutoCloseable(_SELF, closeable):
        pass
    @classmethod
    def Oed_closeQuietly__FileDescriptor(_SELF, fd):
        pass
    @classmethod
    def Oed_closeQuietly__Socket(_SELF, socket):
        pass
    @classmethod
    def setBlocking(_SELF, fd, blocking):
        pass
    @classmethod
    def readFileAsByteArray(_SELF, absolutePath):
        pass
    @classmethod
    def readFileAsString(_SELF, absolutePath):
        pass
    @classmethod
    def deleteContents(_SELF, dir):
        pass
    @classmethod
    def createTemporaryDirectory(_SELF, prefix):
        pass
    @classmethod
    def canOpenReadOnly(_SELF, path):
        pass
    @classmethod
    def throwInterruptedIoException(_SELF):
        pass
