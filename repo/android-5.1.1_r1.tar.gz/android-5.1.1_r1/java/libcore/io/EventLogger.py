class EventLogger(object):
    REPORTER = None
    class Reporter(object):
        @classmethod
        def report(_SELF, code, list):
            pass
    class DefaultReporter(object):
        @classmethod
        def report(_SELF, code, list):
            pass
    @classmethod
    def setReporter(_SELF, reporter):
        pass
    @classmethod
    def getReporter(_SELF):
        pass
    @classmethod
    def writeEvent(_SELF, code, list):
        pass
