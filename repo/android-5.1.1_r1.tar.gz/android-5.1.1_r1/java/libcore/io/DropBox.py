class DropBox(object):
    REPORTER = None
    class Reporter(object):
        @classmethod
        def addData(_SELF, tag, data, flags):
            pass
        @classmethod
        def addText(_SELF, tag, data):
            pass
    class DefaultReporter(object):
        @classmethod
        def addData(_SELF, tag, data, flags):
            pass
        @classmethod
        def addText(_SELF, tag, data):
            pass
    @classmethod
    def setReporter(_SELF, reporter):
        pass
    @classmethod
    def getReporter(_SELF):
        pass
    @classmethod
    def addData(_SELF, tag, data, flags):
        pass
    @classmethod
    def addText(_SELF, tag, data):
        pass
