class NativeBreakIterator(object):
    BI_CHAR_INSTANCE = 1
    BI_WORD_INSTANCE = 2
    BI_LINE_INSTANCE = 3
    BI_SENT_INSTANCE = 4
    address = None
    type = None
    string = None
    charIterator = None
    
    @classmethod
    def setText(self, *args):
        fname = "Oed_setText__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def next(self, *args):
        fname = "Oed_next__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, address, type):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def finalize(_SELF):
        pass
    @classmethod
    def current(_SELF):
        pass
    @classmethod
    def first(_SELF):
        pass
    @classmethod
    def following(_SELF, offset):
        pass
    @classmethod
    def getText(_SELF):
        pass
    @classmethod
    def last(_SELF):
        pass
    @classmethod
    def Oed_next__int(_SELF, n):
        pass
    @classmethod
    def Oed_next__(_SELF):
        pass
    @classmethod
    def previous(_SELF):
        pass
    @classmethod
    def Oed_setText__CharacterIterator(_SELF, newText):
        pass
    @classmethod
    def Oed_setText__str(_SELF, newText):
        pass
    @classmethod
    def Oed_setText__str__CharacterIterator(_SELF, s, it):
        pass
    @classmethod
    def hasText(_SELF):
        pass
    @classmethod
    def isBoundary(_SELF, offset):
        pass
    @classmethod
    def preceding(_SELF, offset):
        pass
    @classmethod
    def getCharacterInstance(_SELF, locale):
        pass
    @classmethod
    def getLineInstance(_SELF, locale):
        pass
    @classmethod
    def getSentenceInstance(_SELF, locale):
        pass
    @classmethod
    def getWordInstance(_SELF, locale):
        pass
    @classmethod
    def getCharacterInstanceImpl(_SELF, locale):
        pass
    @classmethod
    def getWordInstanceImpl(_SELF, locale):
        pass
    @classmethod
    def getLineInstanceImpl(_SELF, locale):
        pass
    @classmethod
    def getSentenceInstanceImpl(_SELF, locale):
        pass
    @classmethod
    def cloneImpl(_SELF, address):
        pass
    @classmethod
    def closeImpl(_SELF, address):
        pass
    @classmethod
    def setTextImpl(_SELF, address, text):
        pass
    @classmethod
    def precedingImpl(_SELF, address, text, offset):
        pass
    @classmethod
    def isBoundaryImpl(_SELF, address, text, offset):
        pass
    @classmethod
    def nextImpl(_SELF, address, text, n):
        pass
    @classmethod
    def previousImpl(_SELF, address, text):
        pass
    @classmethod
    def currentImpl(_SELF, address, text):
        pass
    @classmethod
    def firstImpl(_SELF, address, text):
        pass
    @classmethod
    def followingImpl(_SELF, address, text, offset):
        pass
    @classmethod
    def lastImpl(_SELF, address, text):
        pass
