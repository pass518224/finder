class RuleBasedCollatorICU(object):
    VALUE_DEFAULT = 1
    VALUE_PRIMARY = 0
    VALUE_SECONDARY = 1
    VALUE_TERTIARY = 2
    VALUE_DEFAULT_STRENGTH = None
    VALUE_QUATERNARY = 3
    VALUE_IDENTICAL = 15
    VALUE_OFF = 16
    VALUE_ON = 17
    VALUE_SHIFTED = 20
    VALUE_NON_IGNORABLE = 21
    VALUE_LOWER_FIRST = 24
    VALUE_UPPER_FIRST = 25
    VALUE_ON_WITHOUT_HANGUL = 28
    VALUE_ATTRIBUTE_VALUE_COUNT = 29
    FRENCH_COLLATION = 0
    ALTERNATE_HANDLING = 1
    CASE_FIRST = 2
    CASE_LEVEL = 3
    DECOMPOSITION_MODE = 4
    STRENGTH = 5
    address = None
    
    @classmethod
    def getCollationElementIterator(self, *args):
        fname = "Oed_getCollationElementIterator__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def equals(self, *args):
        fname = "Oed_equals__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____str(_SELF, rules):
        pass
    @classmethod
    def Oed___init____Locale(_SELF, locale):
        pass
    @classmethod
    def Oed___init____int(_SELF, address):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def compare(_SELF, source, target):
        pass
    @classmethod
    def getDecomposition(_SELF):
        pass
    @classmethod
    def setDecomposition(_SELF, mode):
        pass
    @classmethod
    def getStrength(_SELF):
        pass
    @classmethod
    def setStrength(_SELF, strength):
        pass
    @classmethod
    def setAttribute(_SELF, type, value):
        pass
    @classmethod
    def getAttribute(_SELF, type):
        pass
    @classmethod
    def getCollationKey(_SELF, source):
        pass
    @classmethod
    def getRules(_SELF):
        pass
    @classmethod
    def Oed_getCollationElementIterator__str(_SELF, source):
        pass
    @classmethod
    def Oed_getCollationElementIterator__CharacterIterator(_SELF, it):
        pass
    @classmethod
    def characterIteratorToString(_SELF, it):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def Oed_equals__str__str(_SELF, source, target):
        pass
    @classmethod
    def Oed_equals__Object(_SELF, object):
        pass
    @classmethod
    def finalize(_SELF):
        pass
