class CollationElementIteratorICU(object):
    address = None
    PRIMARY_ORDER_MASK_ = 0xffff0000
    SECONDARY_ORDER_MASK_ = 0x0000ff00
    TERTIARY_ORDER_MASK_ = 0x000000ff
    PRIMARY_ORDER_SHIFT_ = 16
    SECONDARY_ORDER_SHIFT_ = 8
    UNSIGNED_16_BIT_MASK_ = 0x0000FFFF
    
    @classmethod
    def setText(self, *args):
        fname = "Oed_setText__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def reset(_SELF):
        pass
    @classmethod
    def next(_SELF):
        pass
    @classmethod
    def previous(_SELF):
        pass
    @classmethod
    def getMaxExpansion(_SELF, order):
        pass
    @classmethod
    def Oed_setText__str(_SELF, source):
        pass
    @classmethod
    def Oed_setText__CharacterIterator(_SELF, source):
        pass
    @classmethod
    def getOffset(_SELF):
        pass
    @classmethod
    def setOffset(_SELF, offset):
        pass
    @classmethod
    def primaryOrder(_SELF, order):
        pass
    @classmethod
    def secondaryOrder(_SELF, order):
        pass
    @classmethod
    def tertiaryOrder(_SELF, order):
        pass
    @classmethod
    def getInstance(_SELF, collatorAddress, source):
        pass
    @classmethod
    def __init__(_SELF, address):
        pass
    @classmethod
    def finalize(_SELF):
        pass
