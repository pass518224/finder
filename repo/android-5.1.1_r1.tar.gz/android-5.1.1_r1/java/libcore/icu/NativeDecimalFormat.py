class NativeDecimalFormat(object):
    UNUM_DECIMAL_SEPARATOR_SYMBOL = 0
    UNUM_GROUPING_SEPARATOR_SYMBOL = 1
    UNUM_PATTERN_SEPARATOR_SYMBOL = 2
    UNUM_PERCENT_SYMBOL = 3
    UNUM_ZERO_DIGIT_SYMBOL = 4
    UNUM_DIGIT_SYMBOL = 5
    UNUM_MINUS_SIGN_SYMBOL = 6
    UNUM_PLUS_SIGN_SYMBOL = 7
    UNUM_CURRENCY_SYMBOL = 8
    UNUM_INTL_CURRENCY_SYMBOL = 9
    UNUM_MONETARY_SEPARATOR_SYMBOL = 10
    UNUM_EXPONENTIAL_SYMBOL = 11
    UNUM_PERMILL_SYMBOL = 12
    UNUM_PAD_ESCAPE_SYMBOL = 13
    UNUM_INFINITY_SYMBOL = 14
    UNUM_NAN_SYMBOL = 15
    UNUM_SIGNIFICANT_DIGIT_SYMBOL = 16
    UNUM_MONETARY_GROUPING_SEPARATOR_SYMBOL = 17
    UNUM_FORMAT_SYMBOL_COUNT = 18
    UNUM_PARSE_INT_ONLY = 0
    UNUM_GROUPING_USED = 1
    UNUM_DECIMAL_ALWAYS_SHOWN = 2
    UNUM_MAX_INTEGER_DIGITS = 3
    UNUM_MIN_INTEGER_DIGITS = 4
    UNUM_INTEGER_DIGITS = 5
    UNUM_MAX_FRACTION_DIGITS = 6
    UNUM_MIN_FRACTION_DIGITS = 7
    UNUM_FRACTION_DIGITS = 8
    UNUM_MULTIPLIER = 9
    UNUM_GROUPING_SIZE = 10
    UNUM_ROUNDING_MODE = 11
    UNUM_ROUNDING_INCREMENT = 12
    UNUM_FORMAT_WIDTH = 13
    UNUM_PADDING_POSITION = 14
    UNUM_SECONDARY_GROUPING_SIZE = 15
    UNUM_SIGNIFICANT_DIGITS_USED = 16
    UNUM_MIN_SIGNIFICANT_DIGITS = 17
    UNUM_MAX_SIGNIFICANT_DIGITS = 18
    UNUM_LENIENT_PARSE = 19
    UNUM_POSITIVE_PREFIX = 0
    UNUM_POSITIVE_SUFFIX = 1
    UNUM_NEGATIVE_PREFIX = 2
    UNUM_NEGATIVE_SUFFIX = 3
    UNUM_PADDING_CHARACTER = 4
    UNUM_CURRENCY_CODE = 5
    UNUM_DEFAULT_RULESET = 6
    UNUM_PUBLIC_RULESETS = 7
    ICU4C_FIELD_IDS = None
    address = None
    lastPattern = None
    negPrefNull = None
    negSuffNull = None
    posPrefNull = None
    posSuffNull = None
    parseBigDecimal = None
    class FieldPositionIterator(object):
        data = None
        pos = 3
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def forFieldPosition(_SELF, fp):
            pass
        @classmethod
        def next(_SELF):
            pass
        @classmethod
        def fieldId(_SELF):
            pass
        @classmethod
        def field(_SELF):
            pass
        @classmethod
        def start(_SELF):
            pass
        @classmethod
        def limit(_SELF):
            pass
        @classmethod
        def setData(_SELF, data):
            pass
    
    @classmethod
    def parse(self, *args):
        fname = "Oed_parse__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def setRoundingMode(self, *args):
        fname = "Oed_setRoundingMode__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def setDecimalFormatSymbols(self, *args):
        fname = "Oed_setDecimalFormatSymbols__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def formatLong(self, *args):
        fname = "Oed_formatLong__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def formatDouble(self, *args):
        fname = "Oed_formatDouble__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def close(self, *args):
        fname = "Oed_close__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def applyPattern(self, *args):
        fname = "Oed_applyPattern__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def translateFieldId(_SELF, fp):
        pass
    @classmethod
    def Oed___init____str__DecimalFormatSymbols(_SELF, pattern, dfs):
        pass
    @classmethod
    def Oed___init____str__LocaleData(_SELF, pattern, data):
        pass
    @classmethod
    def Oed_close__(_SELF):
        pass
    @classmethod
    def finalize(_SELF):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def Oed_setDecimalFormatSymbols__DecimalFormatSymbols(_SELF, dfs):
        pass
    @classmethod
    def Oed_setDecimalFormatSymbols__LocaleData(_SELF, localeData):
        pass
    @classmethod
    def formatBigDecimal(_SELF, value, field):
        pass
    @classmethod
    def formatBigInteger(_SELF, value, field):
        pass
    @classmethod
    def Oed_formatLong__int__FieldPosition(_SELF, value, field):
        pass
    @classmethod
    def Oed_formatDouble__float__FieldPosition(_SELF, value, field):
        pass
    @classmethod
    def updateFieldPosition(_SELF, fp, fpi):
        pass
    @classmethod
    def applyLocalizedPattern(_SELF, pattern):
        pass
    @classmethod
    def Oed_applyPattern__str(_SELF, pattern):
        pass
    @classmethod
    def formatToCharacterIterator(_SELF, object):
        pass
    @classmethod
    def makeScalePositive(_SELF, scale, val):
        pass
    @classmethod
    def toLocalizedPattern(_SELF):
        pass
    @classmethod
    def toPattern(_SELF):
        pass
    @classmethod
    def Oed_parse__str__ParsePosition(_SELF, string, position):
        pass
    @classmethod
    def getMaximumFractionDigits(_SELF):
        pass
    @classmethod
    def getMaximumIntegerDigits(_SELF):
        pass
    @classmethod
    def getMinimumFractionDigits(_SELF):
        pass
    @classmethod
    def getMinimumIntegerDigits(_SELF):
        pass
    @classmethod
    def getGroupingSize(_SELF):
        pass
    @classmethod
    def getMultiplier(_SELF):
        pass
    @classmethod
    def getNegativePrefix(_SELF):
        pass
    @classmethod
    def getNegativeSuffix(_SELF):
        pass
    @classmethod
    def getPositivePrefix(_SELF):
        pass
    @classmethod
    def getPositiveSuffix(_SELF):
        pass
    @classmethod
    def isDecimalSeparatorAlwaysShown(_SELF):
        pass
    @classmethod
    def isParseBigDecimal(_SELF):
        pass
    @classmethod
    def isParseIntegerOnly(_SELF):
        pass
    @classmethod
    def isGroupingUsed(_SELF):
        pass
    @classmethod
    def setDecimalSeparatorAlwaysShown(_SELF, value):
        pass
    @classmethod
    def setCurrency(_SELF, currencySymbol, currencyCode):
        pass
    @classmethod
    def setGroupingSize(_SELF, value):
        pass
    @classmethod
    def setGroupingUsed(_SELF, value):
        pass
    @classmethod
    def setMaximumFractionDigits(_SELF, value):
        pass
    @classmethod
    def setMaximumIntegerDigits(_SELF, value):
        pass
    @classmethod
    def setMinimumFractionDigits(_SELF, value):
        pass
    @classmethod
    def setMinimumIntegerDigits(_SELF, value):
        pass
    @classmethod
    def setMultiplier(_SELF, value):
        pass
    @classmethod
    def setNegativePrefix(_SELF, value):
        pass
    @classmethod
    def setNegativeSuffix(_SELF, value):
        pass
    @classmethod
    def setPositivePrefix(_SELF, value):
        pass
    @classmethod
    def setPositiveSuffix(_SELF, value):
        pass
    @classmethod
    def setParseBigDecimal(_SELF, value):
        pass
    @classmethod
    def setParseIntegerOnly(_SELF, value):
        pass
    @classmethod
    def Oed_applyPattern__int__bool__str(_SELF, addr, localized, pattern):
        pass
    @classmethod
    def Oed_setRoundingMode__RoundingMode__float(_SELF, roundingMode, roundingIncrement):
        pass
    @classmethod
    def applyPatternImpl(_SELF, addr, localized, pattern):
        pass
    @classmethod
    def cloneImpl(_SELF, addr):
        pass
    @classmethod
    def Oed_close__int(_SELF, addr):
        pass
    @classmethod
    def Oed_formatLong__int__int__FieldPositionIterator(_SELF, addr, value, iter):
        pass
    @classmethod
    def Oed_formatDouble__int__float__FieldPositionIterator(_SELF, addr, value, iter):
        pass
    @classmethod
    def formatDigitList(_SELF, addr, value, iter):
        pass
    @classmethod
    def getAttribute(_SELF, addr, symbol):
        pass
    @classmethod
    def getTextAttribute(_SELF, addr, symbol):
        pass
    @classmethod
    def open(_SELF, pattern, currencySymbol, decimalSeparator, digit, exponentSeparator, groupingSeparator, infinity, internationalCurrencySymbol, minusSign, monetaryDecimalSeparator, nan, patternSeparator, percent, perMill, zeroDigit):
        pass
    @classmethod
    def Oed_parse__int__str__ParsePosition__bool(_SELF, addr, string, position, parseBigDecimal):
        pass
    @classmethod
    def Oed_setDecimalFormatSymbols__int__str__char__char__str__char__str__str__str__char__str__char__str__char__char(_SELF, addr, currencySymbol, decimalSeparator, digit, exponentSeparator, groupingSeparator, infinity, internationalCurrencySymbol, minusSign, monetaryDecimalSeparator, nan, patternSeparator, percent, perMill, zeroDigit):
        pass
    @classmethod
    def setSymbol(_SELF, addr, symbol, str):
        pass
    @classmethod
    def setAttribute(_SELF, addr, symbol, i):
        pass
    @classmethod
    def Oed_setRoundingMode__int__int__float(_SELF, addr, roundingMode, roundingIncrement):
        pass
    @classmethod
    def setTextAttribute(_SELF, addr, symbol, str):
        pass
    @classmethod
    def toPatternImpl(_SELF, addr, localized):
        pass
