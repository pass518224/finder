class CollationKeyICU(object):
    bytes = None
    hashCode = None
    @classmethod
    def __init__(_SELF, source, bytes):
        pass
    @classmethod
    def compareTo(_SELF, other):
        pass
    @classmethod
    def equals(_SELF, object):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def toByteArray(_SELF):
        pass
