class NativeCollation(object):
    
    @classmethod
    def openCollator(self, *args):
        fname = "Oed_openCollator__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def closeCollator(_SELF, address):
        pass
    @classmethod
    def compare(_SELF, address, source, target):
        pass
    @classmethod
    def getAttribute(_SELF, address, type):
        pass
    @classmethod
    def getCollationElementIterator(_SELF, address, source):
        pass
    @classmethod
    def getRules(_SELF, address):
        pass
    @classmethod
    def getSortKey(_SELF, address, source):
        pass
    @classmethod
    def Oed_openCollator__Locale(_SELF, locale):
        pass
    @classmethod
    def Oed_openCollator__str(_SELF, languageTag):
        pass
    @classmethod
    def openCollatorFromRules(_SELF, rules, normalizationMode, collationStrength):
        pass
    @classmethod
    def safeClone(_SELF, address):
        pass
    @classmethod
    def setAttribute(_SELF, address, type, value):
        pass
    @classmethod
    def closeElements(_SELF, address):
        pass
    @classmethod
    def getMaxExpansion(_SELF, address, order):
        pass
    @classmethod
    def getOffset(_SELF, address):
        pass
    @classmethod
    def next(_SELF, address):
        pass
    @classmethod
    def previous(_SELF, address):
        pass
    @classmethod
    def reset(_SELF, address):
        pass
    @classmethod
    def setOffset(_SELF, address, offset):
        pass
    @classmethod
    def setText(_SELF, address, source):
        pass
