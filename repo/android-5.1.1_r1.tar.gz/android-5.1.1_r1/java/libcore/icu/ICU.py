class ICU(object):
    CACHED_PATTERNS = None
    availableLocalesCache = None
    isoCountries = None
    isoLanguages = None
    IDX_LANGUAGE = 0
    IDX_SCRIPT = 1
    IDX_REGION = 2
    IDX_VARIANT = 3
    U_ZERO_ERROR = 0
    U_INVALID_CHAR_FOUND = 10
    U_TRUNCATED_CHAR_FOUND = 11
    U_ILLEGAL_CHAR_FOUND = 12
    U_BUFFER_OVERFLOW_ERROR = 15
    
    @classmethod
    def addLikelySubtags(self, *args):
        fname = "Oed_addLikelySubtags__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getCurrencyDisplayName(self, *args):
        fname = "Oed_getCurrencyDisplayName__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getCurrencySymbol(self, *args):
        fname = "Oed_getCurrencySymbol__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def toLowerCase(self, *args):
        fname = "Oed_toLowerCase__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def toUpperCase(self, *args):
        fname = "Oed_toUpperCase__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def getISOLanguages(_SELF):
        pass
    @classmethod
    def getISOCountries(_SELF):
        pass
    @classmethod
    def parseLangScriptRegionAndVariants(_SELF, string, outputArray):
        pass
    @classmethod
    def localeFromIcuLocaleId(_SELF, localeId):
        pass
    @classmethod
    def localesFromStrings(_SELF, localeNames):
        pass
    @classmethod
    def getAvailableLocales(_SELF):
        pass
    @classmethod
    def getAvailableBreakIteratorLocales(_SELF):
        pass
    @classmethod
    def getAvailableCalendarLocales(_SELF):
        pass
    @classmethod
    def getAvailableCollatorLocales(_SELF):
        pass
    @classmethod
    def getAvailableDateFormatLocales(_SELF):
        pass
    @classmethod
    def getAvailableDateFormatSymbolsLocales(_SELF):
        pass
    @classmethod
    def getAvailableDecimalFormatSymbolsLocales(_SELF):
        pass
    @classmethod
    def getAvailableNumberFormatLocales(_SELF):
        pass
    @classmethod
    def getBestDateTimePattern(_SELF, skeleton, locale):
        pass
    @classmethod
    def getBestDateTimePatternNative(_SELF, skeleton, languageTag):
        pass
    @classmethod
    def getDateFormatOrder(_SELF, pattern):
        pass
    @classmethod
    def getCldrVersion(_SELF):
        pass
    @classmethod
    def getIcuVersion(_SELF):
        pass
    @classmethod
    def getUnicodeVersion(_SELF):
        pass
    @classmethod
    def Oed_toLowerCase__str__Locale(_SELF, s, locale):
        pass
    @classmethod
    def Oed_toLowerCase__str__str(_SELF, s, languageTag):
        pass
    @classmethod
    def Oed_toUpperCase__str__Locale(_SELF, s, locale):
        pass
    @classmethod
    def Oed_toUpperCase__str__str(_SELF, s, languageTag):
        pass
    @classmethod
    def U_FAILURE(_SELF, error):
        pass
    @classmethod
    def getAvailableBreakIteratorLocalesNative(_SELF):
        pass
    @classmethod
    def getAvailableCalendarLocalesNative(_SELF):
        pass
    @classmethod
    def getAvailableCollatorLocalesNative(_SELF):
        pass
    @classmethod
    def getAvailableDateFormatLocalesNative(_SELF):
        pass
    @classmethod
    def getAvailableLocalesNative(_SELF):
        pass
    @classmethod
    def getAvailableNumberFormatLocalesNative(_SELF):
        pass
    @classmethod
    def getAvailableCurrencyCodes(_SELF):
        pass
    @classmethod
    def getCurrencyCode(_SELF, countryCode):
        pass
    @classmethod
    def Oed_getCurrencyDisplayName__Locale__str(_SELF, locale, currencyCode):
        pass
    @classmethod
    def Oed_getCurrencyDisplayName__str__str(_SELF, languageTag, currencyCode):
        pass
    @classmethod
    def getCurrencyFractionDigits(_SELF, currencyCode):
        pass
    @classmethod
    def getCurrencyNumericCode(_SELF, currencyCode):
        pass
    @classmethod
    def Oed_getCurrencySymbol__Locale__str(_SELF, locale, currencyCode):
        pass
    @classmethod
    def Oed_getCurrencySymbol__str__str(_SELF, languageTag, currencyCode):
        pass
    @classmethod
    def getDisplayCountry(_SELF, targetLocale, locale):
        pass
    @classmethod
    def getDisplayCountryNative(_SELF, targetLanguageTag, languageTag):
        pass
    @classmethod
    def getDisplayLanguage(_SELF, targetLocale, locale):
        pass
    @classmethod
    def getDisplayLanguageNative(_SELF, targetLanguageTag, languageTag):
        pass
    @classmethod
    def getDisplayVariant(_SELF, targetLocale, locale):
        pass
    @classmethod
    def getDisplayVariantNative(_SELF, targetLanguageTag, languageTag):
        pass
    @classmethod
    def getDisplayScript(_SELF, targetLocale, locale):
        pass
    @classmethod
    def getDisplayScriptNative(_SELF, targetLanguageTag, languageTag):
        pass
    @classmethod
    def getISO3Country(_SELF, languageTag):
        pass
    @classmethod
    def getISO3Language(_SELF, languageTag):
        pass
    @classmethod
    def Oed_addLikelySubtags__Locale(_SELF, locale):
        pass
    @classmethod
    def Oed_addLikelySubtags__str(_SELF, locale):
        pass
    @classmethod
    def getScript(_SELF, locale):
        pass
    @classmethod
    def getISOLanguagesNative(_SELF):
        pass
    @classmethod
    def getISOCountriesNative(_SELF):
        pass
    @classmethod
    def initLocaleDataNative(_SELF, languageTag, result):
        pass
    @classmethod
    def setDefaultLocale(_SELF, languageTag):
        pass
    @classmethod
    def getDefaultLocale(_SELF):
        pass
