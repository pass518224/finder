class DateIntervalFormat(object):
    FORMAT_SHOW_TIME = 0x00001
    FORMAT_SHOW_WEEKDAY = 0x00002
    FORMAT_SHOW_YEAR = 0x00004
    FORMAT_NO_YEAR = 0x00008
    FORMAT_SHOW_DATE = 0x00010
    FORMAT_NO_MONTH_DAY = 0x00020
    FORMAT_12HOUR = 0x00040
    FORMAT_24HOUR = 0x00080
    FORMAT_UTC = 0x02000
    FORMAT_ABBREV_TIME = 0x04000
    FORMAT_ABBREV_WEEKDAY = 0x08000
    FORMAT_ABBREV_MONTH = 0x10000
    FORMAT_NUMERIC_DATE = 0x20000
    FORMAT_ABBREV_ALL = 0x80000
    DAY_IN_MS = None
    EPOCH_JULIAN_DAY = 2440588
    CACHED_FORMATTERS = None
    class FormatterCache(object):
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def entryEvicted(_SELF, key, value):
            pass
    
    @classmethod
    def formatDateRange(self, *args):
        fname = "Oed_formatDateRange__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def Oed_formatDateRange__int__int__int__str(_SELF, startMs, endMs, flags, olsonId):
        pass
    @classmethod
    def Oed_formatDateRange__Locale__TimeZone__int__int__int(_SELF, locale, tz, startMs, endMs, flags):
        pass
    @classmethod
    def getFormatter(_SELF, skeleton, localeName, tzName):
        pass
    @classmethod
    def toSkeleton(_SELF, startCalendar, endCalendar, flags):
        pass
    @classmethod
    def isMidnight(_SELF, c):
        pass
    @classmethod
    def onTheHour(_SELF, c):
        pass
    @classmethod
    def fallOnDifferentDates(_SELF, c1, c2):
        pass
    @classmethod
    def fallInSameMonth(_SELF, c1, c2):
        pass
    @classmethod
    def fallInSameYear(_SELF, c1, c2):
        pass
    @classmethod
    def isThisYear(_SELF, c):
        pass
    @classmethod
    def dayDistance(_SELF, c1, c2):
        pass
    @classmethod
    def julianDay(_SELF, c):
        pass
    @classmethod
    def createDateIntervalFormat(_SELF, skeleton, localeName, tzName):
        pass
    @classmethod
    def destroyDateIntervalFormat(_SELF, address):
        pass
    @classmethod
    def formatDateInterval(_SELF, address, fromDate, toDate):
        pass
