class NativePluralRules(object):
    ZERO = 0
    ONE = 1
    TWO = 2
    FEW = 3
    MANY = 4
    OTHER = 5
    address = None
    @classmethod
    def __init__(_SELF, address):
        pass
    @classmethod
    def finalize(_SELF):
        pass
    @classmethod
    def forLocale(_SELF, locale):
        pass
    @classmethod
    def quantityForInt(_SELF, value):
        pass
    @classmethod
    def finalizeImpl(_SELF, address):
        pass
    @classmethod
    def forLocaleImpl(_SELF, localeName):
        pass
    @classmethod
    def quantityForIntImpl(_SELF, address, value):
        pass
