class NativeConverter(object):
    
    @classmethod
    def setCallbackEncode(self, *args):
        fname = "Oed_setCallbackEncode__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def setCallbackDecode(self, *args):
        fname = "Oed_setCallbackDecode__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def decode(_SELF, converterHandle, input, inEnd, output, outEnd, data, flush):
        pass
    @classmethod
    def encode(_SELF, converterHandle, input, inEnd, output, outEnd, data, flush):
        pass
    @classmethod
    def openConverter(_SELF, charsetName):
        pass
    @classmethod
    def closeConverter(_SELF, converterHandle):
        pass
    @classmethod
    def resetByteToChar(_SELF, converterHandle):
        pass
    @classmethod
    def resetCharToByte(_SELF, converterHandle):
        pass
    @classmethod
    def getSubstitutionBytes(_SELF, converterHandle):
        pass
    @classmethod
    def getMaxBytesPerChar(_SELF, converterHandle):
        pass
    @classmethod
    def getMinBytesPerChar(_SELF, converterHandle):
        pass
    @classmethod
    def getAveBytesPerChar(_SELF, converterHandle):
        pass
    @classmethod
    def getAveCharsPerByte(_SELF, converterHandle):
        pass
    @classmethod
    def contains(_SELF, converterName1, converterName2):
        pass
    @classmethod
    def getAvailableCharsetNames(_SELF):
        pass
    @classmethod
    def charsetForName(_SELF, charsetName):
        pass
    @classmethod
    def translateCodingErrorAction(_SELF, action):
        pass
    @classmethod
    def Oed_setCallbackDecode__int__CharsetDecoder(_SELF, converterHandle, decoder):
        pass
    @classmethod
    def Oed_setCallbackDecode__int__int__int__str(_SELF, converterHandle, onMalformedInput, onUnmappableInput, subChars):
        pass
    @classmethod
    def Oed_setCallbackEncode__int__CharsetEncoder(_SELF, converterHandle, encoder):
        pass
    @classmethod
    def Oed_setCallbackEncode__int__int__int__list(_SELF, converterHandle, onMalformedInput, onUnmappableInput, subBytes):
        pass
