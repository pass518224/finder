class NativeNormalizer(object):
    @classmethod
    def isNormalized(_SELF, src, form):
        pass
    @classmethod
    def normalize(_SELF, src, form):
        pass
    @classmethod
    def toUNormalizationMode(_SELF, form):
        pass
    @classmethod
    def normalizeImpl(_SELF, src, form):
        pass
    @classmethod
    def isNormalizedImpl(_SELF, src, form):
        pass
    @classmethod
    def __init__(_SELF):
        pass
