class NativeIDN(object):
    @classmethod
    def toASCII(_SELF, s, flags):
        pass
    @classmethod
    def toUnicode(_SELF, s, flags):
        pass
    @classmethod
    def convert(_SELF, s, flags, toAscii):
        pass
    @classmethod
    def convertImpl(_SELF, s, flags, toAscii):
        pass
    @classmethod
    def __init__(_SELF):
        pass
