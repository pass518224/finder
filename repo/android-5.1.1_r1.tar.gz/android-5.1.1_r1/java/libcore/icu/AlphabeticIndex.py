class AlphabeticIndex(object):
    class ImmutableIndex(object):
        peer = None
        
        @classmethod
        def getBucketIndex(self, *args):
            fname = "Oed_getBucketIndex__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        
        @classmethod
        def getBucketCount(self, *args):
            fname = "Oed_getBucketCount__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        
        @classmethod
        def getBucketLabel(self, *args):
            fname = "Oed_getBucketLabel__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def __init__(_SELF, peer):
            pass
        @classmethod
        def finalize(_SELF):
            pass
        @classmethod
        def Oed_getBucketCount__(_SELF):
            pass
        @classmethod
        def Oed_getBucketIndex__str(_SELF, s):
            pass
        @classmethod
        def Oed_getBucketLabel__int(_SELF, index):
            pass
        @classmethod
        def Oed_getBucketCount__int(_SELF, peer):
            pass
        @classmethod
        def Oed_getBucketIndex__int__str(_SELF, peer, s):
            pass
        @classmethod
        def Oed_getBucketLabel__int__int(_SELF, peer, index):
            pass
    peer = None
    
    @classmethod
    def getBucketLabel(self, *args):
        fname = "Oed_getBucketLabel__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def setMaxLabelCount(self, *args):
        fname = "Oed_setMaxLabelCount__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getBucketIndex(self, *args):
        fname = "Oed_getBucketIndex__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getBucketCount(self, *args):
        fname = "Oed_getBucketCount__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def addLabelRange(self, *args):
        fname = "Oed_addLabelRange__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def addLabels(self, *args):
        fname = "Oed_addLabels__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getMaxLabelCount(self, *args):
        fname = "Oed_getMaxLabelCount__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, locale):
        pass
    @classmethod
    def finalize(_SELF):
        pass
    @classmethod
    def Oed_getMaxLabelCount__(_SELF):
        pass
    @classmethod
    def Oed_setMaxLabelCount__int(_SELF, count):
        pass
    @classmethod
    def Oed_addLabels__Locale(_SELF, locale):
        pass
    @classmethod
    def Oed_addLabelRange__int__int(_SELF, codePointStart, codePointEnd):
        pass
    @classmethod
    def Oed_getBucketCount__(_SELF):
        pass
    @classmethod
    def Oed_getBucketIndex__str(_SELF, s):
        pass
    @classmethod
    def Oed_getBucketLabel__int(_SELF, index):
        pass
    @classmethod
    def getImmutableIndex(_SELF):
        pass
    @classmethod
    def create(_SELF, locale):
        pass
    @classmethod
    def destroy(_SELF, peer):
        pass
    @classmethod
    def Oed_getMaxLabelCount__int(_SELF, peer):
        pass
    @classmethod
    def Oed_setMaxLabelCount__int__int(_SELF, peer, count):
        pass
    @classmethod
    def Oed_addLabels__int__str(_SELF, peer, locale):
        pass
    @classmethod
    def Oed_addLabelRange__int__int__int(_SELF, peer, codePointStart, codePointEnd):
        pass
    @classmethod
    def Oed_getBucketCount__int(_SELF, peer):
        pass
    @classmethod
    def Oed_getBucketIndex__int__str(_SELF, peer, s):
        pass
    @classmethod
    def Oed_getBucketLabel__int__int(_SELF, peer, index):
        pass
    @classmethod
    def buildImmutableIndex(_SELF, peer):
        pass
