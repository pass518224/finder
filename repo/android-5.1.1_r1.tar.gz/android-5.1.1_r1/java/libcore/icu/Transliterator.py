class Transliterator(object):
    peer = None
    
    @classmethod
    def transliterate(self, *args):
        fname = "Oed_transliterate__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, id):
        pass
    @classmethod
    def finalize(_SELF):
        pass
    @classmethod
    def getAvailableIDs(_SELF):
        pass
    @classmethod
    def Oed_transliterate__str(_SELF, s):
        pass
    @classmethod
    def create(_SELF, id):
        pass
    @classmethod
    def destroy(_SELF, peer):
        pass
    @classmethod
    def Oed_transliterate__int__str(_SELF, peer, s):
        pass
