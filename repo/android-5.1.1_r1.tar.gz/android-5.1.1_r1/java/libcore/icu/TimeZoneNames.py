class TimeZoneNames(object):
    availableTimeZoneIds = None
    OLSON_NAME = 0
    LONG_NAME = 1
    SHORT_NAME = 2
    LONG_NAME_DST = 3
    SHORT_NAME_DST = 4
    NAME_COUNT = 5
    cachedZoneStrings = None
    class ZoneStringsCache(object):
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def create(_SELF, locale):
            pass
        @classmethod
        def internStrings(_SELF, result):
            pass
    class ANONY_vgjsaqtftkebrppa(object):
        @classmethod
        def compare(_SELF, lhs, rhs):
            pass
    ZONE_STRINGS_COMPARATOR = None
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def getDisplayName(_SELF, zoneStrings, id, daylight, style):
        pass
    @classmethod
    def getZoneStrings(_SELF, locale):
        pass
    @classmethod
    def forLocale(_SELF, locale):
        pass
    @classmethod
    def getExemplarLocation(_SELF, locale, tz):
        pass
    @classmethod
    def fillZoneStrings(_SELF, locale, result):
        pass
