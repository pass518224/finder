class LocaleData(object):
    localeDataCache = None
    firstDayOfWeek = None
    minimalDaysInFirstWeek = None
    amPm = None
    eras = None
    longMonthNames = None
    shortMonthNames = None
    tinyMonthNames = None
    longStandAloneMonthNames = None
    shortStandAloneMonthNames = None
    tinyStandAloneMonthNames = None
    longWeekdayNames = None
    shortWeekdayNames = None
    tinyWeekdayNames = None
    longStandAloneWeekdayNames = None
    shortStandAloneWeekdayNames = None
    tinyStandAloneWeekdayNames = None
    yesterday = None
    today = None
    tomorrow = None
    fullTimeFormat = None
    longTimeFormat = None
    mediumTimeFormat = None
    shortTimeFormat = None
    fullDateFormat = None
    longDateFormat = None
    mediumDateFormat = None
    shortDateFormat = None
    narrowAm = None
    narrowPm = None
    shortDateFormat4 = None
    timeFormat_hm = None
    timeFormat_Hm = None
    timeFormat_hms = None
    timeFormat_Hms = None
    timeFormat12 = None
    timeFormat24 = None
    zeroDigit = None
    decimalSeparator = None
    groupingSeparator = None
    patternSeparator = None
    percent = None
    perMill = None
    monetarySeparator = None
    minusSign = None
    exponentSeparator = None
    infinity = None
    NaN = None
    currencySymbol = None
    internationalCurrencySymbol = None
    numberPattern = None
    integerPattern = None
    currencyPattern = None
    percentPattern = None
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def mapInvalidAndNullLocales(_SELF, locale):
        pass
    @classmethod
    def get(_SELF, locale):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def getDateFormat(_SELF, style):
        pass
    @classmethod
    def getTimeFormat(_SELF, style):
        pass
    @classmethod
    def initLocaleData(_SELF, locale):
        pass
