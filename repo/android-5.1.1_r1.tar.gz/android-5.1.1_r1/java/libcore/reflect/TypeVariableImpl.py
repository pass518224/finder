class TypeVariableImpl(object):
    formalVar = None
    declOfVarUser = None
    name = None
    genericDeclaration = None
    bounds = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def equals(_SELF, o):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def Oed___init____D__str__ListOfTypes(_SELF, genericDecl, name, bounds):
        pass
    @classmethod
    def Oed___init____D__str(_SELF, genericDecl, name):
        pass
    @classmethod
    def findFormalVar(_SELF, layer, name):
        pass
    @classmethod
    def nextLayer(_SELF, decl):
        pass
    @classmethod
    def resolve(_SELF):
        pass
    @classmethod
    def getBounds(_SELF):
        pass
    @classmethod
    def getGenericDeclaration(_SELF):
        pass
    @classmethod
    def getName(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
