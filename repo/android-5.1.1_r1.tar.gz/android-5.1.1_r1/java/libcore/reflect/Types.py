class Types(object):
    PRIMITIVE_TO_SIGNATURE = None
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def getTypeArray(_SELF, types, clone):
        pass
    @classmethod
    def getType(_SELF, type):
        pass
    @classmethod
    def getSignature(_SELF, clazz):
        pass
    @classmethod
    def __str__(_SELF, types):
        pass
    @classmethod
    def appendTypeName(_SELF, out, c):
        pass
    @classmethod
    def appendArrayGenericType(_SELF, out, types):
        pass
    @classmethod
    def appendGenericType(_SELF, out, type):
        pass
