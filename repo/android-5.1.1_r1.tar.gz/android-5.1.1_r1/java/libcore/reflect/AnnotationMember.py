class AnnotationMember(object):
    ERROR = '!'
    ARRAY = '['
    OTHER = '*'
    class DefaultValues:
        NO_VALUE = "NO_VALUE"
    NO_VALUE = None
    name = None
    value = None
    tag = None
    elementType = None
    definingMethod = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____str__Object(_SELF, name, val):
        pass
    @classmethod
    def Oed___init____str__Object__Class__Method(_SELF, name, val, type, m):
        pass
    @classmethod
    def setDefinition(_SELF, copy):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def equals(_SELF, obj):
        pass
    @classmethod
    def equalArrayValue(_SELF, otherValue):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def rethrowError(_SELF):
        pass
    @classmethod
    def validateValue(_SELF):
        pass
    @classmethod
    def copyValue(_SELF):
        pass
