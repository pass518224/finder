class GenericSignatureParser(object):
    exceptionTypes = None
    parameterTypes = None
    formalTypeParameters = None
    returnType = None
    fieldType = None
    interfaceTypes = None
    superclassType = None
    loader = None
    genericDecl = None
    symbol = None
    identifier = None
    eof = None
    buffer = None
    pos = None
    @classmethod
    def __init__(_SELF, loader):
        pass
    @classmethod
    def setInput(_SELF, genericDecl, input):
        pass
    @classmethod
    def parseForClass(_SELF, genericDecl, signature):
        pass
    @classmethod
    def parseForMethod(_SELF, genericDecl, signature, rawExceptionTypes):
        pass
    @classmethod
    def parseForConstructor(_SELF, genericDecl, signature, rawExceptionTypes):
        pass
    @classmethod
    def parseForField(_SELF, genericDecl, signature):
        pass
    @classmethod
    def parseClassSignature(_SELF):
        pass
    @classmethod
    def parseOptFormalTypeParameters(_SELF):
        pass
    @classmethod
    def parseFormalTypeParameter(_SELF):
        pass
    @classmethod
    def parseFieldTypeSignature(_SELF):
        pass
    @classmethod
    def parseClassTypeSignature(_SELF):
        pass
    @classmethod
    def parseOptTypeArguments(_SELF):
        pass
    @classmethod
    def parseTypeArgument(_SELF):
        pass
    @classmethod
    def parseTypeVariableSignature(_SELF):
        pass
    @classmethod
    def parseTypeSignature(_SELF):
        pass
    @classmethod
    def parseMethodTypeSignature(_SELF, rawExceptionTypes):
        pass
    @classmethod
    def parseReturnType(_SELF):
        pass
    @classmethod
    def scanSymbol(_SELF):
        pass
    @classmethod
    def expect(_SELF, c):
        pass
    @classmethod
    def isStopSymbol(_SELF, ch):
        pass
    @classmethod
    def scanIdentifier(_SELF):
        pass
