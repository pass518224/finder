class ListOfTypes(object):
    EMPTY = None
    types = None
    resolvedTypes = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____int(_SELF, capacity):
        pass
    @classmethod
    def Oed___init____list(_SELF, types):
        pass
    @classmethod
    def add(_SELF, type):
        pass
    @classmethod
    def length(_SELF):
        pass
    @classmethod
    def getResolvedTypes(_SELF):
        pass
    @classmethod
    def resolveTypes(_SELF, unresolved):
        pass
    @classmethod
    def __str__(_SELF):
        pass
