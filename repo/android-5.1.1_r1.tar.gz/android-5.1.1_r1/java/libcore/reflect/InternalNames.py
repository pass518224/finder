class InternalNames(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def getClass(_SELF, classLoader, internalName):
        pass
    @classmethod
    def getInternalName(_SELF, c):
        pass
