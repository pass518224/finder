class AnnotationAccess(object):
    NO_ARGUMENTS = None
    VISIBILITY_BUILD = 0x00
    VISIBILITY_RUNTIME = 0x01
    VISIBILITY_SYSTEM = 0x02
    
    @classmethod
    def toAnnotationInstance(self, *args):
        fname = "Oed_toAnnotationInstance__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def getAnnotation(self, *args):
        fname = "Oed_getAnnotation__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def Oed_getAnnotation__Class__Class(_SELF, c, annotationType):
        pass
    @classmethod
    def isInherited(_SELF, annotationType):
        pass
    @classmethod
    def getAnnotations(_SELF, c):
        pass
    @classmethod
    def isAnnotationPresent(_SELF, c, annotationType):
        pass
    @classmethod
    def getDeclaredAnnotations(_SELF, element):
        pass
    @classmethod
    def getDeclaredAnnotation(_SELF, element, annotationClass):
        pass
    @classmethod
    def isDeclaredAnnotationPresent(_SELF, element, annotationClass):
        pass
    @classmethod
    def Oed_getAnnotation__AnnotatedElement__Class(_SELF, element, annotationClass):
        pass
    @classmethod
    def getAnnotationSetOffset(_SELF, element):
        pass
    @classmethod
    def getDexClass(_SELF, element):
        pass
    @classmethod
    def getParameterAnnotations(_SELF, declaringClass, methodDexIndex):
        pass
    @classmethod
    def getDefaultValue(_SELF, method):
        pass
    @classmethod
    def getEnclosingClass(_SELF, c):
        pass
    @classmethod
    def getEnclosingMethodOrConstructor(_SELF, c):
        pass
    @classmethod
    def getMemberClasses(_SELF, c):
        pass
    @classmethod
    def getSignature(_SELF, element):
        pass
    @classmethod
    def getExceptions(_SELF, element):
        pass
    @classmethod
    def getInnerClassFlags(_SELF, c, defaultValue):
        pass
    @classmethod
    def getInnerClassName(_SELF, c):
        pass
    @classmethod
    def isAnonymousClass(_SELF, c):
        pass
    @classmethod
    def getAnnotationReader(_SELF, dex, element, annotationName, expectedFieldCount):
        pass
    @classmethod
    def getOnlyAnnotationValue(_SELF, dex, element, annotationName):
        pass
    @classmethod
    def getAnnotationClass(_SELF, context, dex, typeIndex):
        pass
    @classmethod
    def indexToMethod(_SELF, context, dex, methodIndex):
        pass
    @classmethod
    def annotationSetToAnnotations(_SELF, context, offset):
        pass
    @classmethod
    def Oed_toAnnotationInstance__Class__Class__Annotation(_SELF, context, annotationClass, annotation):
        pass
    @classmethod
    def Oed_toAnnotationInstance__Class__Dex__Class__EncodedValueReader(_SELF, context, dex, annotationClass, reader):
        pass
    @classmethod
    def decodeValue(_SELF, context, type, dex, reader):
        pass
