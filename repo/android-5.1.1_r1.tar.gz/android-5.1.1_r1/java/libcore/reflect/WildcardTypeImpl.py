class WildcardTypeImpl(object):
    extendsBound = None
    superBound = None
    @classmethod
    def __init__(_SELF, extendsBound, superBound):
        pass
    @classmethod
    def getLowerBounds(_SELF):
        pass
    @classmethod
    def getUpperBounds(_SELF):
        pass
    @classmethod
    def equals(_SELF, o):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
