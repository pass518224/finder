class ParameterizedTypeImpl(object):
    args = None
    ownerType0 = None
    ownerTypeRes = None
    rawType = None
    rawTypeName = None
    loader = None
    @classmethod
    def __init__(_SELF, ownerType, rawTypeName, args, loader):
        pass
    @classmethod
    def getActualTypeArguments(_SELF):
        pass
    @classmethod
    def getOwnerType(_SELF):
        pass
    @classmethod
    def getRawType(_SELF):
        pass
    @classmethod
    def getResolvedType(_SELF):
        pass
    @classmethod
    def equals(_SELF, o):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
