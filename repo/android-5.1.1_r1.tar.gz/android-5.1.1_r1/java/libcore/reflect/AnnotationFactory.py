class AnnotationFactory(object):
    cache = None
    klazz = None
    elements = None
    @classmethod
    def getElementsDescription(_SELF, annotationType):
        pass
    @classmethod
    def createAnnotation(_SELF, annotationType, elements):
        pass
    @classmethod
    def __init__(_SELF, klzz, values):
        pass
    @classmethod
    def readObject(_SELF, os):
        pass
    @classmethod
    def equals(_SELF, obj):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def invoke(_SELF, proxy, method, args):
        pass
