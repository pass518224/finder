class GenericArrayTypeImpl(object):
    componentType = None
    @classmethod
    def __init__(_SELF, componentType):
        pass
    @classmethod
    def getGenericComponentType(_SELF):
        pass
    @classmethod
    def equals(_SELF, o):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
