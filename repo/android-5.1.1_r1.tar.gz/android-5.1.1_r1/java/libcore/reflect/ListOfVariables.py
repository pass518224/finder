class ListOfVariables(object):
    array = None
    @classmethod
    def add(_SELF, elem):
        pass
    @classmethod
    def getArray(_SELF):
        pass
