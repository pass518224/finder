class BasicLruCache(object):
    map = None
    maxSize = None
    @classmethod
    def __init__(_SELF, maxSize):
        pass
    @classmethod
    def get(_SELF, key):
        pass
    @classmethod
    def put(_SELF, key, value):
        pass
    @classmethod
    def trimToSize(_SELF, maxSize):
        pass
    @classmethod
    def entryEvicted(_SELF, key, value):
        pass
    @classmethod
    def create(_SELF, key):
        pass
    @classmethod
    def snapshot(_SELF):
        pass
    @classmethod
    def evictAll(_SELF):
        pass
