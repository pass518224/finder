class SneakyThrow(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def sneakyThrow(_SELF, t):
        pass
    @classmethod
    def sneakyThrow2(_SELF, t):
        pass
