class EmptyArray(object):
    BOOLEAN = None
    BYTE = None
    CHAR = None
    DOUBLE = None
    FLOAT = None
    INT = None
    LONG = None
    CLASS = None
    OBJECT = None
    STRING = None
    THROWABLE = None
    STACK_TRACE_ELEMENT = None
    TYPE = None
    TYPE_VARIABLE = None
    @classmethod
    def __init__(_SELF):
        pass
