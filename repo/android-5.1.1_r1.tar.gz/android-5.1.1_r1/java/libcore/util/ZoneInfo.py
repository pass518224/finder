class ZoneInfo(object):
    MILLISECONDS_PER_DAY = None
    MILLISECONDS_PER_400_YEARS = None
    UNIX_OFFSET = 62167219200000L
    NORMAL = None
    LEAP = None
    mRawOffset = None
    mEarliestRawOffset = None
    mUseDst = None
    mDstSavings = None
    mTransitions = None
    mOffsets = None
    mTypes = None
    mIsDsts = None
    class WallTime(object):
        calendar = None
        year = None
        month = None
        monthDay = None
        hour = None
        minute = None
        second = None
        weekDay = None
        yearDay = None
        isDst = None
        gmtOffsetSeconds = None
        @classmethod
        def __init__(_SELF):
            pass
        @classmethod
        def createGregorianCalendar(_SELF):
            pass
        @classmethod
        def localtime(_SELF, timeSeconds, zoneInfo):
            pass
        @classmethod
        def mktime(_SELF, zoneInfo):
            pass
        @classmethod
        def tryOffsetAdjustments(_SELF, zoneInfo, oldWallTimeSeconds, targetInterval, transitionIndex, isDstToFind):
            pass
        @classmethod
        def getOffsetsOfType(_SELF, zoneInfo, startIndex, isDst):
            pass
        @classmethod
        def doWallTimeSearch(_SELF, zoneInfo, initialTransitionIndex, wallTimeSeconds, mustMatchDst):
            pass
        @classmethod
        def setYear(_SELF, year):
            pass
        @classmethod
        def setMonth(_SELF, month):
            pass
        @classmethod
        def setMonthDay(_SELF, monthDay):
            pass
        @classmethod
        def setHour(_SELF, hour):
            pass
        @classmethod
        def setMinute(_SELF, minute):
            pass
        @classmethod
        def setSecond(_SELF, second):
            pass
        @classmethod
        def setWeekDay(_SELF, weekDay):
            pass
        @classmethod
        def setYearDay(_SELF, yearDay):
            pass
        @classmethod
        def setIsDst(_SELF, isDst):
            pass
        @classmethod
        def setGmtOffset(_SELF, gmtoff):
            pass
        @classmethod
        def getYear(_SELF):
            pass
        @classmethod
        def getMonth(_SELF):
            pass
        @classmethod
        def getMonthDay(_SELF):
            pass
        @classmethod
        def getHour(_SELF):
            pass
        @classmethod
        def getMinute(_SELF):
            pass
        @classmethod
        def getSecond(_SELF):
            pass
        @classmethod
        def getWeekDay(_SELF):
            pass
        @classmethod
        def getYearDay(_SELF):
            pass
        @classmethod
        def getGmtOffset(_SELF):
            pass
        @classmethod
        def getIsDst(_SELF):
            pass
        @classmethod
        def copyFieldsToCalendar(_SELF):
            pass
        @classmethod
        def copyFieldsFromCalendar(_SELF):
            pass
        @classmethod
        def findTransitionIndex(_SELF, timeZone, timeSeconds):
            pass
    class OffsetInterval(object):
        startWallTimeSeconds = None
        endWallTimeSeconds = None
        isDst = None
        totalOffsetSeconds = None
        @classmethod
        def create(_SELF, timeZone, transitionIndex):
            pass
        @classmethod
        def __init__(_SELF, startWallTimeSeconds, endWallTimeSeconds, isDst, totalOffsetSeconds):
            pass
        @classmethod
        def containsWallTime(_SELF, wallTimeSeconds):
            pass
        @classmethod
        def getIsDst(_SELF):
            pass
        @classmethod
        def getTotalOffsetSeconds(_SELF):
            pass
        @classmethod
        def getEndWallTimeSeconds(_SELF):
            pass
        @classmethod
        def getStartWallTimeSeconds(_SELF):
            pass
    class CheckedArithmeticException(object):
        pass
    
    @classmethod
    def getOffset(self, *args):
        fname = "Oed_getOffset__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def makeTimeZone(_SELF, id, it):
        pass
    @classmethod
    def __init__(_SELF, name, transitions, types, gmtOffsets, isDsts):
        pass
    @classmethod
    def Oed_getOffset__int__int__int__int__int__int(_SELF, era, year, month, day, dayOfWeek, millis):
        pass
    @classmethod
    def Oed_getOffset__int(_SELF, when):
        pass
    @classmethod
    def inDaylightTime(_SELF, time):
        pass
    @classmethod
    def getRawOffset(_SELF):
        pass
    @classmethod
    def setRawOffset(_SELF, off):
        pass
    @classmethod
    def getDSTSavings(_SELF):
        pass
    @classmethod
    def useDaylightTime(_SELF):
        pass
    @classmethod
    def hasSameRules(_SELF, timeZone):
        pass
    @classmethod
    def equals(_SELF, obj):
        pass
    @classmethod
    def hashCode(_SELF):
        pass
    @classmethod
    def __str__(_SELF):
        pass
    @classmethod
    def clone(_SELF):
        pass
    @classmethod
    def checkedAdd(_SELF, a, b):
        pass
    @classmethod
    def checkedSubtract(_SELF, a, b):
        pass
