class ZoneInfoDB(object):
    DATA = None
    class TzData(object):
        mappedFile = None
        version = None
        zoneTab = None
        ids = None
        byteOffsets = None
        rawUtcOffsetsCache = None
        CACHE_SIZE = 1
        class ANONY_cpkkpqpkshorkbsi(object):
            @classmethod
            def create(_SELF, id):
                pass
        cache = None
        
        @classmethod
        def getAvailableIDs(self, *args):
            fname = "Oed_getAvailableIDs__" + "__".join(i.__class__.__name__ for i in args)
            func = getattr(self, fname)
            return func(*args)
        @classmethod
        def __init__(_SELF, paths):
            pass
        @classmethod
        def loadData(_SELF, path):
            pass
        @classmethod
        def readHeader(_SELF):
            pass
        @classmethod
        def readZoneTab(_SELF, it, zoneTabOffset, zoneTabSize):
            pass
        @classmethod
        def readIndex(_SELF, it, indexOffset, dataOffset):
            pass
        @classmethod
        def Oed_getAvailableIDs__(_SELF):
            pass
        @classmethod
        def Oed_getAvailableIDs__int(_SELF, rawUtcOffset):
            pass
        @classmethod
        def getRawUtcOffsets(_SELF):
            pass
        @classmethod
        def getVersion(_SELF):
            pass
        @classmethod
        def getZoneTab(_SELF):
            pass
        @classmethod
        def makeTimeZone(_SELF, id):
            pass
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def getInstance(_SELF):
        pass
