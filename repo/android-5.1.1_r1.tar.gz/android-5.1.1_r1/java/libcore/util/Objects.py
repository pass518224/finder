class Objects(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def equal(_SELF, a, b):
        pass
    @classmethod
    def hashCode(_SELF, o):
        pass
    @classmethod
    def __str__(_SELF, o):
        pass
