class CollectionUtils(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def dereferenceIterable(_SELF, iterable, trim):
        pass
    @classmethod
    def removeDuplicates(_SELF, list, comparator):
        pass
