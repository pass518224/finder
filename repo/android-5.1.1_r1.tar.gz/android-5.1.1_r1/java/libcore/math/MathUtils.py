class MathUtils(object):
    LONG_POWERS_OF_TEN = None
    @classmethod
    def __init__(_SELF):
        pass
