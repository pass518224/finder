class NetworkEventDispatcher(object):
    instance = None
    listeners = None
    @classmethod
    def getInstance(_SELF):
        pass
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def addListener(_SELF, toAdd):
        pass
    @classmethod
    def removeListener(_SELF, toRemove):
        pass
    @classmethod
    def onNetworkConfigurationChanged(_SELF):
        pass
