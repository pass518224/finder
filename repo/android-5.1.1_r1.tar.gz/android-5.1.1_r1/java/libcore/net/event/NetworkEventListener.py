class NetworkEventListener(object):
    @classmethod
    def onNetworkConfigurationChanged(_SELF):
        pass
