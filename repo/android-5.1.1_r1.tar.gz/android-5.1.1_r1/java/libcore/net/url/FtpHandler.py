class FtpHandler(object):
    
    @classmethod
    def openConnection(self, *args):
        fname = "Oed_openConnection__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed_openConnection__URL(_SELF, u):
        pass
    @classmethod
    def Oed_openConnection__URL__Proxy(_SELF, url, proxy):
        pass
    @classmethod
    def getDefaultPort(_SELF):
        pass
