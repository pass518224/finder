class JarHandler(object):
    @classmethod
    def openConnection(_SELF, u):
        pass
    @classmethod
    def parseURL(_SELF, url, spec, start, limit):
        pass
    @classmethod
    def toExternalForm(_SELF, url):
        pass
