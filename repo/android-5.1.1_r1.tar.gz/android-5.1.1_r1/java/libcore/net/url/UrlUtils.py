class UrlUtils(object):
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def canonicalizePath(_SELF, path, discardRelativePrefix):
        pass
    @classmethod
    def authoritySafePath(_SELF, authority, path):
        pass
    @classmethod
    def getSchemePrefix(_SELF, spec):
        pass
    @classmethod
    def isValidSchemeChar(_SELF, index, c):
        pass
    @classmethod
    def findFirstOf(_SELF, string, chars, start, end):
        pass
