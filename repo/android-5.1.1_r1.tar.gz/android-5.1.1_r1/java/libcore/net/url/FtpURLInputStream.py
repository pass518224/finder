class FtpURLInputStream(object):
    _is = None
    controlSocket = None
    
    @classmethod
    def read(self, *args):
        fname = "Oed_read__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, _is, controlSocket):
        pass
    @classmethod
    def Oed_read__(_SELF):
        pass
    @classmethod
    def Oed_read__list__int__int(_SELF, buf, off, nbytes):
        pass
    @classmethod
    def reset(_SELF):
        pass
    @classmethod
    def mark(_SELF, limit):
        pass
    @classmethod
    def markSupported(_SELF):
        pass
    @classmethod
    def close(_SELF):
        pass
    @classmethod
    def available(_SELF):
        pass
    @classmethod
    def skip(_SELF, byteCount):
        pass
