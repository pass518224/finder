class JarURLConnectionImpl(object):
    jarCache = None
    jarFileURL = None
    jarInput = None
    jarFile = None
    jarEntry = None
    closed = None
    class JarURLConnectionInputStream(object):
        jarFile = None
        @classmethod
        def __init__(_SELF, _in, file):
            pass
        @classmethod
        def close(_SELF):
            pass
    @classmethod
    def __init__(_SELF, url):
        pass
    @classmethod
    def connect(_SELF):
        pass
    @classmethod
    def getJarFile(_SELF):
        pass
    @classmethod
    def findJarFile(_SELF):
        pass
    @classmethod
    def openJarFile(_SELF):
        pass
    @classmethod
    def getJarEntry(_SELF):
        pass
    @classmethod
    def findJarEntry(_SELF):
        pass
    @classmethod
    def getInputStream(_SELF):
        pass
    @classmethod
    def getContentType(_SELF):
        pass
    @classmethod
    def getContentLength(_SELF):
        pass
    @classmethod
    def getContent(_SELF):
        pass
    @classmethod
    def getPermission(_SELF):
        pass
    @classmethod
    def getUseCaches(_SELF):
        pass
    @classmethod
    def setUseCaches(_SELF, usecaches):
        pass
    @classmethod
    def getDefaultUseCaches(_SELF):
        pass
    @classmethod
    def setDefaultUseCaches(_SELF, defaultusecaches):
        pass
