class FileURLConnection(object):
    class ANONY_flwgdoubhxblmkra(object):
        @classmethod
        def compare(_SELF, a, b):
            pass
    HEADER_COMPARATOR = None
    filename = None
    _is = None
    length = 1
    lastModified = 1
    isDir = None
    permission = None
    headerKeysAndValues = None
    CONTENT_TYPE_VALUE_IDX = 1
    CONTENT_LENGTH_VALUE_IDX = 3
    LAST_MODIFIED_VALUE_IDX = 5
    headerFields = None
    
    @classmethod
    def getHeaderField(self, *args):
        fname = "Oed_getHeaderField__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def __init__(_SELF, url):
        pass
    @classmethod
    def connect(_SELF):
        pass
    @classmethod
    def Oed_getHeaderField__str(_SELF, key):
        pass
    @classmethod
    def getHeaderFieldKey(_SELF, position):
        pass
    @classmethod
    def Oed_getHeaderField__int(_SELF, position):
        pass
    @classmethod
    def getHeaderFields(_SELF):
        pass
    @classmethod
    def getContentLength(_SELF):
        pass
    @classmethod
    def getContentLengthLong(_SELF):
        pass
    @classmethod
    def getContentType(_SELF):
        pass
    @classmethod
    def getContentTypeForPlainFiles(_SELF):
        pass
    @classmethod
    def getDirectoryListing(_SELF, f):
        pass
    @classmethod
    def getInputStream(_SELF):
        pass
    @classmethod
    def getPermission(_SELF):
        pass
