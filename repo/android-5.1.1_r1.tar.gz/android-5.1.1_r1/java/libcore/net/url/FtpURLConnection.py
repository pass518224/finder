class FtpURLConnection(object):
    FTP_PORT = 21
    FTP_DATAOPEN = 125
    FTP_OPENDATA = 150
    FTP_OK = 200
    FTP_USERREADY = 220
    FTP_TRANSFEROK = 226
    FTP_LOGGEDIN = 230
    FTP_FILEOK = 250
    FTP_PASWD = 331
    FTP_NOTFOUND = 550
    controlSocket = None
    dataSocket = None
    acceptSocket = None
    ctrlInput = None
    inputStream = None
    ctrlOutput = None
    dataPort = None
    username = "anonymous"
    password = ""
    replyCode = None
    hostName = None
    proxy = None
    currentProxy = None
    uri = None
    
    @classmethod
    def __init__(self, *args):
        fname = "Oed___init____" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def Oed___init____URL(_SELF, url):
        pass
    @classmethod
    def Oed___init____URL__Proxy(_SELF, url, proxy):
        pass
    @classmethod
    def cd(_SELF):
        pass
    @classmethod
    def connect(_SELF):
        pass
    @classmethod
    def connectInternal(_SELF):
        pass
    @classmethod
    def getContentType(_SELF):
        pass
    @classmethod
    def getFile(_SELF):
        pass
    @classmethod
    def getInputStream(_SELF):
        pass
    @classmethod
    def getPermission(_SELF):
        pass
    @classmethod
    def getOutputStream(_SELF):
        pass
    @classmethod
    def getReply(_SELF):
        pass
    @classmethod
    def login(_SELF):
        pass
    @classmethod
    def port(_SELF):
        pass
    @classmethod
    def readLine(_SELF):
        pass
    @classmethod
    def readMultiLine(_SELF):
        pass
    @classmethod
    def sendFile(_SELF):
        pass
    @classmethod
    def setDoInput(_SELF, newValue):
        pass
    @classmethod
    def setDoOutput(_SELF, newValue):
        pass
    @classmethod
    def setType(_SELF):
        pass
    @classmethod
    def write(_SELF, command):
        pass
