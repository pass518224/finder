class MimeUtils(object):
    mimeTypeToExtensionMap = None
    extensionToMimeTypeMap = None
    @classmethod
    def add(_SELF, mimeType, extension):
        pass
    @classmethod
    def getContentTypesPropertiesStream(_SELF):
        pass
    @classmethod
    def applyOverrides(_SELF):
        pass
    @classmethod
    def __init__(_SELF):
        pass
    @classmethod
    def hasMimeType(_SELF, mimeType):
        pass
    @classmethod
    def guessMimeTypeFromExtension(_SELF, extension):
        pass
    @classmethod
    def hasExtension(_SELF, extension):
        pass
    @classmethod
    def guessExtensionFromMimeType(_SELF, mimeType):
        pass
