class UriCodec(object):
    
    @classmethod
    def decode(self, *args):
        fname = "Oed_decode__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def appendEncoded(self, *args):
        fname = "Oed_appendEncoded__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    
    @classmethod
    def appendHex(self, *args):
        fname = "Oed_appendHex__" + "__".join(i.__class__.__name__ for i in args)
        func = getattr(self, fname)
        return func(*args)
    @classmethod
    def isRetained(_SELF, c):
        pass
    @classmethod
    def validate(_SELF, uri, start, end, name):
        pass
    @classmethod
    def validateSimple(_SELF, s, legal):
        pass
    @classmethod
    def Oed_appendEncoded__StringBuilder__str__Charset__bool(_SELF, builder, s, charset, isPartiallyEncoded):
        pass
    @classmethod
    def encode(_SELF, s, charset):
        pass
    @classmethod
    def Oed_appendEncoded__StringBuilder__str(_SELF, builder, s):
        pass
    @classmethod
    def appendPartiallyEncoded(_SELF, builder, s):
        pass
    @classmethod
    def Oed_decode__str__bool__Charset__bool(_SELF, s, convertPlus, charset, throwOnFailure):
        pass
    @classmethod
    def hexToInt(_SELF, c):
        pass
    @classmethod
    def Oed_decode__str(_SELF, s):
        pass
    @classmethod
    def Oed_appendHex__StringBuilder__str__Charset(_SELF, builder, s, charset):
        pass
    @classmethod
    def Oed_appendHex__StringBuilder__bytes(_SELF, sb, b):
        pass
