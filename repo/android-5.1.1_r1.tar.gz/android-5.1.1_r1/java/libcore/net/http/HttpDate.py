class HttpDate(object):
    class ANONY_bkvxzybgvbhoyxzy(object):
        @classmethod
        def initialValue(_SELF):
            pass
    STANDARD_DATE_FORMAT = None
    BROWSER_COMPATIBLE_DATE_FORMATS = None
    @classmethod
    def parse(_SELF, value):
        pass
    @classmethod
    def format(_SELF, value):
        pass
